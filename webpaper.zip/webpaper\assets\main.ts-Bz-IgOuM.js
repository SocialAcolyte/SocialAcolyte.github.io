const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/snapshot-capture-Cjq9wqKF.js","assets/pinned-types-Ploj16yZ.js","assets/card-types-u4cCMT4q.js","assets/logger-DShRSVht.js","assets/onboarding-types-DQLgLn1i.js"])))=>i.map(i=>d[i]);
import{h as xt,e as Mr,b as oe,s as ht,S as Jt,a as _o,P as Xt,n as zo}from"./pinned-types-Ploj16yZ.js";import{a as Br,C as qo,i as jo,c as he,_ as Lr}from"./card-types-u4cCMT4q.js";import{createLogger as ee}from"./logger-DShRSVht.js";import{S as Ho}from"./onboarding-types-DQLgLn1i.js";async function It(e,t){const n={injected:!1,attachmentLikely:!1,copiedToClipboard:!1};return n.copiedToClipboard=await Yo(t),e.focus(),Go(e,t)||Uo(e,t)?(n.injected=!0,n.attachmentLikely=!0,n):(Ir(e,t),n.injected=!0,n)}function Go(e,t){try{const n=new DataTransfer;n.setData("text/plain",t),n.setData("text/html",Jo(t).replace(/\n/g,"<br>"));const r=new ClipboardEvent("paste",{clipboardData:n,bubbles:!0,cancelable:!0});return!e.dispatchEvent(r)}catch{return!1}}function Uo(e,t){try{const n=new DataTransfer;n.setData("text/plain",t);const r=new InputEvent("beforeinput",{inputType:"insertFromPaste",data:t,dataTransfer:n,bubbles:!0,cancelable:!0});return!e.dispatchEvent(r)}catch{return!1}}function Ko(e,t){try{e.focus(),e.dispatchEvent(new FocusEvent("focus",{bubbles:!0}));const n=new KeyboardEvent("keydown",{key:"Unidentified",code:"Unidentified",bubbles:!0,cancelable:!0});e.dispatchEvent(n);const r=new KeyboardEvent("keypress",{key:"Unidentified",code:"Unidentified",bubbles:!0,cancelable:!0});e.dispatchEvent(r);const i=new InputEvent("beforeinput",{inputType:"insertText",data:t,bubbles:!0,cancelable:!0});e.dispatchEvent(i);const o=new InputEvent("input",{inputType:"insertText",data:t,bubbles:!0,cancelable:!1});e.dispatchEvent(o);const a=new Event("change",{bubbles:!0});e.dispatchEvent(a);const s=new KeyboardEvent("keyup",{key:"Unidentified",code:"Unidentified",bubbles:!0,cancelable:!0});e.dispatchEvent(s)}catch(n){console.error("[Webpaper] Keyboard sequence dispatch failed:",n)}}function qn(e,t){try{let n=e;for(;n;){const r=Object.keys(n),i=r.find(a=>a.startsWith("__reactFiber$")||a.startsWith("__reactEvents$")||a.startsWith("__reactContainer$")),o=r.find(a=>a.startsWith("__reactProps$")||a.startsWith("__reactEventHandlers$"));if(i||o){const a=i?n[i]:null,s=o?n[o]:null;if(s){if(typeof s.onChange=="function")try{s.onChange({target:e,currentTarget:e,type:"change",simulated:!0})}catch{}if(typeof s.onInput=="function")try{s.onInput({target:e,currentTarget:e,type:"input",simulated:!0})}catch{}}let l=a,c=0;for(;l&&c<10;){const d=l.memoizedProps;if(d){if(typeof d.onChange=="function")try{d.onChange({target:e,currentTarget:e,type:"change",simulated:!0})}catch{}if(typeof d.onInput=="function")try{d.onInput({target:e,currentTarget:e,type:"input",simulated:!0})}catch{}}l=l.return,c++}}n=n.parentElement}}catch(n){console.error("[Webpaper] React state synchronization failed:",n)}}function Ir(e,t){if(e.focus(),e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement){Vo(e,t),qn(e);return}let n=!1;try{const r=window.getSelection();r&&r.rangeCount>0&&(r.getRangeAt(0).deleteContents(),n=document.execCommand("insertText",!1,t))}catch{}if(!n)try{n=document.execCommand("insertText",!1,t)}catch{n=!1}if(!n)try{const r=document.createTextNode(t),i=window.getSelection();if(i&&i.rangeCount>0){const o=i.getRangeAt(0);o.deleteContents(),o.insertNode(r),o.setStartAfter(r),o.setEndAfter(r),i.removeAllRanges(),i.addRange(o),n=!0}else e.appendChild(r),n=!0}catch{e.innerText=t,n=!0}Ko(e,t),qn(e)}async function Yo(e){try{return await navigator.clipboard.writeText(e),!0}catch{try{const t=document.createElement("textarea");t.value=e,t.style.cssText="position:fixed;left:-9999px;top:-9999px;opacity:0;",document.body.appendChild(t),t.select();const n=document.execCommand("copy");return document.body.removeChild(t),n}catch{return!1}}}function Vo(e,t){var i;const n=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,r=Object.getOwnPropertyDescriptor(n,"value");(i=r==null?void 0:r.set)==null||i.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}function Jo(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}const jn={name:"ChatGPT",supportsAttachmentCard:!0,detect(){const e=location.hostname;return e==="chatgpt.com"||e==="chat.openai.com"},getInput(){return document.querySelector("#prompt-textarea")??document.querySelector('[contenteditable="true"][data-placeholder]')??document.querySelector('textarea[data-id="root"]')},async injectText(e){const t=this.getInput();t&&await It(t,e)},getSendButton(){return document.querySelector('[data-testid="send-button"]')??document.querySelector('button[aria-label="Send prompt"]')??document.querySelector("form button:not([disabled])")},triggerSend(){var e,t;(t=(e=this.getSendButton)==null?void 0:e.call(this))==null||t.click()},getConversationContext(){const e=document.querySelectorAll("[data-message-author-role]");return Array.from(e).slice(-3).map(n=>{var o;const r=n.getAttribute("data-message-author-role"),i=((o=n.textContent)==null?void 0:o.slice(0,200))??"";return`${r}: ${i}`}).join(`
`)},getMessageList(){const e=document.querySelector('[data-message-author-role="user"]');if(!e)return null;let t=e.parentElement;for(;t&&t!==document.body;){const n=getComputedStyle(t).overflowY;if(n==="auto"||n==="scroll")return t;t=t.parentElement}return e.parentElement},isUserMessage(e){var t,n;return((t=e.getAttribute)==null?void 0:t.call(e,"data-message-author-role"))==="user"?!0:((n=e.querySelector)==null?void 0:n.call(e,'[data-message-author-role="user"]'))!=null},getUserMessageTextContainer(e){var t,n;return((t=e.getAttribute)==null?void 0:t.call(e,"data-message-author-role"))==="user"?e:((n=e.querySelector)==null?void 0:n.call(e,'[data-message-author-role="user"]'))??e}},Xo={name:"Claude",supportsAttachmentCard:!0,detect(){return location.hostname==="claude.ai"},getInput(){return document.querySelector('[contenteditable="true"].ProseMirror')??document.querySelector('div[contenteditable="true"]')??document.querySelector(".input-area [contenteditable]")},async injectText(e){const t=this.getInput();t&&await It(t,e)},getSendButton(){return document.querySelector('button[aria-label="Send Message"]')??document.querySelector('button[aria-label="Send message"]')??document.querySelector("fieldset button:last-of-type")},triggerSend(){var e,t;(t=(e=this.getSendButton)==null?void 0:e.call(this))==null||t.click()},getConversationContext(){const e=document.querySelectorAll("[data-is-streaming], .font-claude-message, .font-user-message");return Array.from(e).slice(-3).map(n=>{var a;const i=n.classList.contains("font-claude-message")?"assistant":"user",o=((a=n.textContent)==null?void 0:a.slice(0,200))??"";return`${i}: ${o}`}).join(`
`)},getMessageList(){const e=document.querySelector(".font-user-message");if(!e)return null;let t=e.parentElement;for(;t&&t!==document.body;){const n=getComputedStyle(t).overflowY;if(n==="auto"||n==="scroll")return t;t=t.parentElement}return e.parentElement},isUserMessage(e){var t,n;return(t=e.classList)!=null&&t.contains("font-user-message")?!0:((n=e.querySelector)==null?void 0:n.call(e,".font-user-message"))!=null},getUserMessageTextContainer(e){var t,n;return(t=e.classList)!=null&&t.contains("font-user-message")?e:((n=e.querySelector)==null?void 0:n.call(e,".font-user-message"))??e}},Qo={name:"Gemini",detect(){return location.hostname==="gemini.google.com"},getInput(){const e=document.querySelector('[role="textbox"][contenteditable="true"]')??document.querySelector('rich-textarea [contenteditable="true"]')??document.querySelector(".input-area [contenteditable]")??document.querySelector('[contenteditable="true"]');if(e)return e;const t=document.querySelectorAll('rich-textarea, gemini-input-area, [class*="input"]');for(const n of t){const r=n.shadowRoot;if(!r)continue;const i=r.querySelector('[contenteditable="true"]');if(i)return i}return null},async injectText(e){const t=this.getInput();t&&await It(t,e)},getSendButton(){return document.querySelector('button[aria-label*="Send" i]')??document.querySelector("button.send-button")??document.querySelector('button[data-test-id*="send" i]')??document.querySelector('button[mattooltip="Send"]')},triggerSend(){var e,t;(t=(e=this.getSendButton)==null?void 0:e.call(this))==null||t.click()},getConversationContext(){const e=document.querySelectorAll("message-content, .conversation-container [data-message-id]");return Array.from(e).slice(-3).map(n=>{var r;return((r=n.textContent)==null?void 0:r.slice(0,200))??""}).join(`
`)},getMessageList(){return document.querySelector(".conversation-container")??null},isUserMessage(e){var t,n,r;return!!(e.tagName==="USER-QUERY"||(t=e.querySelector)!=null&&t.call(e,"user-query")||(r=(n=e.classList)==null?void 0:n.contains)!=null&&r.call(n,"user-query"))},getUserMessageTextContainer(e){var t;return((t=e.querySelector)==null?void 0:t.call(e,'.query-text, [class*="query-text"]'))??e}},Ze={name:"Grok",detect(){const e=location.hostname;return!!(e==="grok.com"||e==="www.grok.com"||(e==="x.com"||e==="twitter.com")&&(location.pathname.startsWith("/i/grok")||location.pathname.startsWith("/grok")))},getInput(){return document.querySelector('div[contenteditable="true"][role="textbox"]')??document.querySelector('[contenteditable="true"][data-placeholder]')??document.querySelector('main [contenteditable="true"]')??document.querySelector('[contenteditable="true"]')??document.querySelector('textarea[placeholder*="Ask" i]')??document.querySelector("textarea")},async injectText(e){const t=this.getInput();t&&await It(t,e)},getSendButton(){return document.querySelector('button[aria-label*="Send" i]')??document.querySelector('button[aria-label*="Submit" i]')??document.querySelector('button[data-testid*="send" i]')??document.querySelector('button[type="submit"]')??document.querySelector("form button:last-of-type")},triggerSend(){var e,t;(t=(e=this.getSendButton)==null?void 0:e.call(this))==null||t.click()},getConversationContext(){const e=document.querySelectorAll('[data-message-id], .message, [class*="message-content" i]');return Array.from(e).slice(-3).map(n=>{var r;return((r=n.textContent)==null?void 0:r.slice(0,200))??""}).join(`
`)}},Hn={name:"Perplexity",detect(){return location.hostname==="www.perplexity.ai"||location.hostname==="perplexity.ai"},getInput(){return document.querySelector('textarea[placeholder*="Ask"]')??document.querySelector("textarea")??document.querySelector('[contenteditable="true"]')},injectText(e){const t=this.getInput();t&&(t instanceof HTMLTextAreaElement?Zo(t,e):(t.focus(),document.execCommand("insertText",!1,e)))},triggerSend(){var t;const e=document.querySelector('button[aria-label="Submit"]')??document.querySelector('button[aria-label="Send"]')??((t=document.querySelector('button svg[data-icon="arrow-right"]'))==null?void 0:t.closest("button"));e==null||e.click()},getConversationContext(){const e=document.querySelectorAll(".prose");return Array.from(e).slice(-2).map(n=>{var r;return((r=n.textContent)==null?void 0:r.slice(0,200))??""}).join(`
`)}};function Zo(e,t){var r;const n=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value");(r=n==null?void 0:n.set)==null||r.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0}))}const ei={name:"HuggingChat",detect(){return location.hostname==="huggingface.co"&&location.pathname.startsWith("/chat")},getInput(){return document.querySelector("textarea[placeholder]")},injectText(e){const t=this.getInput();t instanceof HTMLTextAreaElement&&ti(t,e)},triggerSend(){const e=document.querySelector('form button[type="submit"]');e==null||e.click()}};function ti(e,t){var r;const n=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value");(r=n==null?void 0:n.set)==null||r.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0}))}const Re={name:"Generic",detect(){return Dt()>=50},getInput(){const e=document.querySelectorAll("textarea");for(const n of e)if(Qt(n))return n;const t=document.querySelectorAll('[contenteditable="true"]');for(const n of t)if(Qt(n))return n;return e[0]??null},injectText(e){var n;const t=this.getInput();if(t)if(t instanceof HTMLTextAreaElement){const r=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value");(n=r==null?void 0:r.set)==null||n.call(t,e),t.dispatchEvent(new Event("input",{bubbles:!0}))}else t.focus(),document.execCommand("insertText",!1,e)},triggerSend(){const e=['button[type="submit"]','button[aria-label*="send" i]','button[aria-label*="submit" i]','button svg[data-icon="paper-plane"]'];for(const t of e){const n=document.querySelector(t),r=(n==null?void 0:n.tagName)==="BUTTON"?n:n==null?void 0:n.closest("button");if(r){r.click();return}}}};function Dt(){let e=0;const t=document.querySelectorAll("textarea");for(const s of t)if(Qt(s)){e+=30;break}document.querySelectorAll('[class*="chat" i], [class*="conversation" i], [class*="message" i], [id*="chat" i]').length>0&&(e+=20),document.querySelectorAll('[class*="typing" i], [class*="streaming" i], [class*="loading-dots" i]').length>0&&(e+=15),document.querySelectorAll('.markdown, .prose, [class*="markdown" i], pre > code').length>0&&(e+=10);const o=document.body.innerText.slice(0,5e3).toLowerCase(),a=["ai assistant","chatbot","powered by ai","ask me anything"];for(const s of a)if(o.includes(s)){e+=10;break}return e}function Qt(e){var r;const t=e.closest("form")??((r=e.parentElement)==null?void 0:r.parentElement);if(!t)return!1;const n=t.querySelectorAll("button");for(const i of n){const o=(i.textContent+i.getAttribute("aria-label")+i.className).toLowerCase();if(o.includes("send")||o.includes("submit")||o.includes("arrow"))return!0}return!1}function Dr(e){const t=["[data-testid]","[data-feature-name]","[data-stid]","[id]","[class]","[aria-label]"];for(const n of t){const r=document.querySelectorAll(n);for(const i of r){const o=i.id+" "+i.className+" "+(i.getAttribute("data-testid")??"")+" "+(i.getAttribute("data-feature-name")??"")+" "+(i.getAttribute("data-stid")??"")+" "+(i.getAttribute("aria-label")??"");if(e.test(o))return!0}}return!1}const ni={...Re,name:"Amazon Rufus",detect(){return Dr(/\brufus\b/i)?Dt()>=30||!!document.querySelector('textarea, [contenteditable="true"]'):!1}},ri={...Re,name:"Expedia Romie",detect(){return Dr(/\bromie\b/i)?Dt()>=30||!!document.querySelector('textarea, [contenteditable="true"]'):!1}},oi={...Re,name:"NVIDIA Build",detect(){return Dt()>=30}};function se(e){const t=document.querySelector(e);try{return(t==null?void 0:t.contentDocument)??null}catch{return null}}const ii={name:"Intercom",detect(){return!!document.querySelector("#intercom-container, .intercom-messenger-frame")},getInput(){const e=se(".intercom-messenger-frame iframe");return e?e.querySelector('[contenteditable="true"]')??e.querySelector("textarea"):document.querySelector('#intercom-container [contenteditable="true"]')},injectText(e){const t=this.getInput();t&&$e(t,e)},triggerSend(){const e=se(".intercom-messenger-frame iframe"),t=(e==null?void 0:e.querySelector('[aria-label="Send"]'))??document.querySelector('#intercom-container button[aria-label="Send"]');t==null||t.click()}},ai={name:"Drift",detect(){return!!document.querySelector("#drift-widget, #drift-frame")},getInput(){const e=se("#drift-frame");return(e==null?void 0:e.querySelector("textarea"))??(e==null?void 0:e.querySelector('[contenteditable="true"]'))??null},injectText(e){const t=this.getInput();t&&$e(t,e)},triggerSend(){const e=se("#drift-frame"),t=e==null?void 0:e.querySelector('button[type="submit"]');t==null||t.click()}},si={name:"Zendesk",detect(){return!!document.querySelector('iframe[title*="Zendesk"], #launcher, #webWidget')},getInput(){const e=se('iframe[title*="Zendesk"]');return(e==null?void 0:e.querySelector("textarea"))??(e==null?void 0:e.querySelector('[contenteditable="true"]'))??null},injectText(e){const t=this.getInput();t&&$e(t,e)},triggerSend(){const e=se('iframe[title*="Zendesk"]'),t=e==null?void 0:e.querySelector('button[type="submit"]');t==null||t.click()}},li={name:"Crisp",detect(){return!!document.querySelector(".crisp-client")},getInput(){return document.querySelector(".crisp-client textarea")??document.querySelector('.crisp-client [contenteditable="true"]')},injectText(e){const t=this.getInput();t&&$e(t,e)},triggerSend(){const e=document.querySelector('.crisp-client button[data-action="send"]');e==null||e.click()}},ci={name:"Tidio",detect(){return!!document.querySelector("#tidio-chat, #tidio-chat-iframe")},getInput(){const e=se("#tidio-chat-iframe");return(e==null?void 0:e.querySelector("textarea"))??(e==null?void 0:e.querySelector('[contenteditable="true"]'))??null},injectText(e){const t=this.getInput();t&&$e(t,e)},triggerSend(){const e=se("#tidio-chat-iframe"),t=e==null?void 0:e.querySelector('button[type="submit"]');t==null||t.click()}},di={name:"HubSpot",detect(){return!!document.querySelector("#hubspot-messages-iframe-container")},getInput(){const e=se("#hubspot-messages-iframe-container iframe");return(e==null?void 0:e.querySelector("textarea"))??(e==null?void 0:e.querySelector('[contenteditable="true"]'))??null},injectText(e){const t=this.getInput();t&&$e(t,e)},triggerSend(){const e=se("#hubspot-messages-iframe-container iframe"),t=e==null?void 0:e.querySelector('button[type="submit"]');t==null||t.click()}};function $e(e,t){var n;if(e instanceof HTMLTextAreaElement){const r=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value");(n=r==null?void 0:r.set)==null||n.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0}))}else e.focus(),document.execCommand("insertText",!1,t)}const ui=["amazon.com","www.amazon.com","smile.amazon.com","amazon.co.uk","www.amazon.co.uk","amazon.de","www.amazon.de","amazon.fr","www.amazon.fr","amazon.ca","www.amazon.ca","amazon.in","www.amazon.in","amazon.com.au","www.amazon.com.au","amazon.co.jp","www.amazon.co.jp","amazon.com.mx","www.amazon.com.mx","amazon.com.br","www.amazon.com.br","amazon.it","www.amazon.it","amazon.es","www.amazon.es","amazon.nl","www.amazon.nl"],fi=["expedia.com","www.expedia.com","expedia.co.uk","www.expedia.co.uk","expedia.ca","www.expedia.ca","expedia.com.au","www.expedia.com.au","expedia.de","www.expedia.de","expedia.fr","www.expedia.fr"],pi=["build.nvidia.com","api.nvidia.com"],wn={"chatgpt.com":jn,"chat.openai.com":jn,"claude.ai":Xo,"gemini.google.com":Qo,"grok.com":Ze,"www.grok.com":Ze,"x.com":Ze,"twitter.com":Ze,"perplexity.ai":Hn,"www.perplexity.ai":Hn,"huggingface.co":ei,...Object.fromEntries(ui.map(e=>[e,ni])),...Object.fromEntries(fi.map(e=>[e,ri])),...Object.fromEntries(pi.map(e=>[e,oi]))},Fn=[{selector:"#intercom-container",adapter:ii},{selector:"#drift-widget",adapter:ai},{selector:'iframe[title*="Zendesk"]',adapter:si},{selector:".crisp-client",adapter:li},{selector:"#tidio-chat",adapter:ci},{selector:"#hubspot-messages-iframe-container",adapter:di}];function Tr(){const e=location.hostname,t=wn[e];if(t&&t.detect())return{type:"chatbot-detected",platform:t.name,confidence:100,hostname:e,adapter:t.name};for(const{selector:n,adapter:r}of Fn)if(document.querySelector(n))return{type:"chatbot-detected",platform:r.name,confidence:90,hostname:e,adapter:r.name};return Re.detect()?{type:"chatbot-detected",platform:"Generic",confidence:60,hostname:e,adapter:"Generic"}:null}function Or(e){const t=wn[e.hostname];if(t&&t.name===e.adapter)return t;for(const{adapter:n}of Fn)if(n.name===e.adapter)return n;return e.adapter==="Generic"?Re:null}function xi(e,t=1e4){let n,r;const i=new MutationObserver(()=>{clearTimeout(r),r=setTimeout(()=>{const a=location.hostname,s=wn[a];if(s&&s.detect()){o(),e({type:"chatbot-detected",platform:s.name,confidence:100,hostname:a,adapter:s.name});return}for(const{selector:l,adapter:c}of Fn)if(document.querySelector(l)){o(),e({type:"chatbot-detected",platform:c.name,confidence:90,hostname:a,adapter:c.name});return}Re.detect()&&(o(),e({type:"chatbot-detected",platform:"Generic",confidence:60,hostname:a,adapter:"Generic"}))},300)});i.observe(document.body,{childList:!0,subtree:!0}),n=setTimeout(()=>{o()},t);function o(){clearTimeout(n),clearTimeout(r),i.disconnect()}return o}const Je="surface-overlay-root";function Gn(e,t){var u,p;if(document.getElementById(Je))return;const n=document.createElement("div");n.id=Je,n.style.cssText="all: initial; position: fixed; z-index: 2147483647;";const r=n.attachShadow({mode:"open"});r.innerHTML=`
    <style>
      @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }

      :host {
        all: initial;
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', sans-serif;
        -webkit-font-smoothing: antialiased;
      }

      .srf-root {
        position: relative;
      }

      /* In-chat Surface toggle — rounded square (8px) per the brand guide's
       * "no fully-round pills" rule. Transparent fill, 1px #9E9E9E border,
       * inverts to black on hover (this IS a primary CTA in the chat UI).
       * No shadow, no scale. */
      .srf-fab {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        background: transparent;
        border: 1px solid #9E9E9E;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.2s ease, border-color 0.2s ease, opacity 0.2s ease;
        animation: fadeIn 0.2s ease-out;
        position: relative;
        user-select: none;
        padding: 0;
      }

      .srf-fab:hover {
        background: #000;
        border-color: #000;
      }

      .srf-fab svg {
        width: 16px;
        height: 19px;
        color: #586675;
        transition: color 0.2s ease;
      }

      .srf-fab:hover svg {
        color: #FFFFFF;
      }

      /* ARMED state — green dot indicator, no pulse (calm) */
      .srf-fab.armed .srf-status-dot {
        background: #34C759;
      }

      /* DISARMED state — dimmed and gray dot */
      .srf-fab.disarmed {
        opacity: 0.55;
      }

      .srf-fab.disarmed .srf-status-dot {
        background: #7A7F88;
      }

      .srf-fab.unauth {
        opacity: 0.45;
      }

      .srf-status-dot {
        position: absolute;
        bottom: -3px;
        right: -3px;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #34C759;
        border: 2px solid #FFFFFF;
      }

      /* ── Tooltip ── */

      .srf-tooltip {
        position: absolute;
        bottom: 44px;
        right: 0;
        background: #FFFFFF;
        color: #000;
        font-size: 12px;
        font-weight: 400;
        letter-spacing: 0.01em;
        padding: 10px 14px;
        border: 1px solid #9E9E9E;
        border-radius: 8px;
        white-space: nowrap;
        pointer-events: none;
        opacity: 0;
        transform: translateY(4px);
        transition: opacity 0.2s ease, transform 0.2s ease;
        line-height: 1.4;
      }

      .srf-fab:hover ~ .srf-tooltip,
      .srf-tooltip.visible {
        opacity: 1;
        transform: translateY(0);
      }

      .srf-tooltip.intro {
        opacity: 1;
        transform: translateY(0);
      }

      .srf-tooltip-strong {
        color: #000;
      }

      .srf-tooltip-dim {
        color: #6B6B70;
        font-weight: 400;
      }

      /* Dark chatbot backgrounds — keep the transparent fill, just brighten
       * the border so it stays visible. Hover still inverts to white (marketing
       * CTA pattern, inverted for dark surfaces). */
      @media (prefers-color-scheme: dark) {
        .srf-fab {
          background: transparent;
          border-color: #9E9E9E;
        }
        .srf-fab svg {
          color: #9FB0C4;
        }
        .srf-fab:hover {
          background: #FFF;
          border-color: #FFF;
        }
        .srf-fab:hover svg {
          color: #586675;
        }
        .srf-status-dot { border-color: transparent; }
        .srf-tooltip {
          background: #1C1C1E;
          color: #FFFFFF;
          border-color: #9E9E9E;
        }
        .srf-tooltip-strong { color: #FFFFFF; }
        .srf-tooltip-dim { color: #A4A4A4; }
      }
    </style>

    <div class="srf-root">
      <button
        class="srf-fab ${t.enabled?"armed":"disarmed"} ${t.signedIn?"":"unauth"}"
        id="srf-fab"
        title="Webpaper"
        aria-label="Webpaper arm/disarm"
      >
        <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="0" y="0" width="32" height="32" rx="8" fill="#232c3b"/>
          <rect x="8" y="5" width="7" height="4" fill="#f4f7fb"/>
          <rect x="19" y="5" width="7" height="4" fill="#f4f7fb"/>
          <rect x="10" y="6" width="3" height="3" fill="#e79bb6"/>
          <rect x="21" y="6" width="3" height="3" fill="#e79bb6"/>
          <rect x="6" y="9" width="20" height="17" rx="5" fill="#f4f7fb"/>
          <rect x="12" y="15" width="3" height="3" fill="#3b424c"/>
          <rect x="17" y="15" width="3" height="3" fill="#3b424c"/>
          <rect x="14.5" y="19" width="3" height="2.5" fill="#e79bb6"/>
          <rect x="9" y="19" width="3" height="2.5" fill="#ecaec0"/>
          <rect x="20" y="19" width="3" height="2.5" fill="#ecaec0"/>
        </svg>
        <span class="srf-status-dot"></span>
      </button>
      <div class="srf-tooltip ${t.signedIn?"intro":""}" id="srf-tooltip">
        ${Zt(t.enabled,t.signedIn)}
      </div>
    </div>
  `,document.body.appendChild(n);const i=r.getElementById("srf-fab"),o=r.getElementById("srf-tooltip");let a=t.enabled,s=!1;function l(){var y,E;const m=(E=(y=t.adapter).getSendButton)==null?void 0:E.call(y),g=t.adapter.getInput(),h=m??g;if(h){const C=h.getBoundingClientRect();if(C.width>0||C.height>0){n.style.display="",n.style.right="",n.style.bottom="",m?(n.style.top=`${C.top+C.height/2-16}px`,n.style.left=`${C.left-40}px`):(n.style.top=`${C.top+6}px`,n.style.left=`${C.right-40}px`);return}}n.style.display="",n.style.top="",n.style.left="",n.style.right="24px",n.style.bottom="24px"}l();const c=new ResizeObserver(l),d=((p=(u=t.adapter).getSendButton)==null?void 0:p.call(u))??t.adapter.getInput();d&&c.observe(d),c.observe(document.documentElement),window.addEventListener("scroll",l,{passive:!0,capture:!0}),window.addEventListener("resize",l);const f=new MutationObserver(()=>{var g,h;const m=((h=(g=t.adapter).getSendButton)==null?void 0:h.call(g))??t.adapter.getInput();m&&m!==d&&(c.disconnect(),c.observe(m),c.observe(document.documentElement)),l()});f.observe(document.body,{childList:!0,subtree:!0}),n._cleanup=()=>{c.disconnect(),f.disconnect(),window.removeEventListener("scroll",l,{capture:!0}),window.removeEventListener("resize",l)},i.addEventListener("click",()=>{if(!t.signedIn){Un(o,'<span class="srf-tooltip-strong">Sign in to Webpaper</span><br><span class="srf-tooltip-dim">Click the extension icon in your browser</span>',3e3);return}a=!a,i.classList.toggle("armed",a),i.classList.toggle("disarmed",!a),t.onToggle(a),o.innerHTML=Zt(a,!0),Un(o,null,2200)}),i.addEventListener("mouseenter",()=>{s=!0,o.classList.add("visible")}),i.addEventListener("mouseleave",()=>{s=!1,setTimeout(()=>{!s&&!o.classList.contains("intro")&&o.classList.remove("visible")},100)}),t.signedIn&&setTimeout(()=>{o.classList.remove("intro"),s||o.classList.remove("visible")},4e3)}function Zt(e,t){return t?e?'<span class="srf-tooltip-strong">Armed — fires on next send</span><br><span class="srf-tooltip-dim">Click to disarm</span>':'<span class="srf-tooltip-strong">Disarmed</span><br><span class="srf-tooltip-dim">Click to arm for next send</span>':'<span class="srf-tooltip-strong">Webpaper</span><br><span class="srf-tooltip-dim">Sign in to share your identity</span>'}function Un(e,t,n){t&&(e.innerHTML=t),e.classList.add("visible"),setTimeout(()=>{e.classList.remove("visible")},n)}function En(e){const t=document.getElementById(Je);if(!(t!=null&&t.shadowRoot))return;const n=t.shadowRoot.getElementById("srf-fab");if(!n)return;n.classList.toggle("armed",e),n.classList.toggle("disarmed",!e);const r=t.shadowRoot.getElementById("srf-tooltip");r&&(r.innerHTML=Zt(e,!0))}function hi(e,t=2400){const n=document.getElementById(Je);if(!(n!=null&&n.shadowRoot))return;const r=n.shadowRoot.getElementById("srf-tooltip");r&&(r.innerHTML=e,r.classList.add("visible"),setTimeout(()=>r.classList.remove("visible"),t))}function mi(){const e=document.getElementById(Je);e&&e._cleanup&&e._cleanup(),e==null||e.remove()}function Pr(e){var o;const t=e.readonly!==!1,n=document.createElement("span");n.setAttribute("data-srf-cards-container",e.id),n.style.display="inline-block",n.style.maxWidth="100%",n.style.verticalAlign="middle";const r=n.attachShadow({mode:"open"});r.innerHTML=Ci;const i=r.getElementById("list");for(let a=0;a<e.cards.length;a++){const s=e.cards[a];(o=s.content)!=null&&o.trim()&&i.appendChild(gi(s,a,t))}return n}function gi(e,t,n){const r=Br(e.type),i=e.label??r.label,o=e.type==="biography",a=document.createElement("div");a.className="item";const s=document.createElement("button");s.type="button",s.className=`chip ${o?"marquee":""}`,s.setAttribute("data-srf-chip-type",e.type),s.style.setProperty("--accent",r.accent),s.style.setProperty("--enter-delay",`${t*40}ms`);const l=document.createElement("span");l.className="dot";const c=document.createElement("span");c.className="icon",c.innerHTML=Yn[e.type]??Yn.identity;const d=document.createElement("span");if(d.className="label",d.textContent=i,s.appendChild(l),s.appendChild(c),s.appendChild(d),!n&&r.removable){const p=document.createElement("span");p.className="close",p.setAttribute("role","button"),p.setAttribute("aria-label",`Detach ${i}`),p.innerHTML=ki,p.addEventListener("click",m=>{m.stopPropagation(),a.classList.add("removing"),setTimeout(()=>a.remove(),180)}),s.appendChild(p)}const f=document.createElement("div");f.className="body";let u=!1;return s.addEventListener("click",()=>{u||(f.appendChild(bi(e)),u=!0),a.classList.toggle("open")}),a.appendChild(s),a.appendChild(f),a}function bi(e){switch(e.type){case"biography":return yi(e.content);case"instructions":return Si(e.content);case"interests":return Kn(e.content,!1);case"connected-apps":return Kn(e.content,!0);case"preferences":case"memory":case"calendar":return wi(e.content);case"projects":return Fi(e.content);case"allergies":return Ei(e.content);default:{const t=document.createElement("div");return t.className="body-text",t.textContent=e.content,t}}}function yi(e){const t=document.createElement("div");t.className="bio";const n=e.split(`
`),r={};let i=-1;for(let a=0;a<n.length;a++){const s=n[a];if(/^About\s*:/i.test(s.trim())||s.trim()==="About:"){i=a+1;break}const l=s.match(/^([A-Za-z]+)\s*:\s*(.+)$/);l&&(r[l[1].toLowerCase()]=l[2].trim())}if(r.name){const a=document.createElement("div");a.className="bio-name",a.textContent=r.name,t.appendChild(a)}const o=[];if(r.occupation&&o.push(r.occupation),r.location&&o.push(r.location),o.length){const a=document.createElement("div");a.className="bio-sub",a.textContent=o.join(" · "),t.appendChild(a)}if(i>-1){const a=n.slice(i).join(`
`).trim();if(a){const s=document.createElement("p");s.className="bio-about",s.textContent=a,t.appendChild(s)}}return t}function Si(e){const t=document.createElement("blockquote");return t.className="instructions",t.textContent=e,t}function Kn(e,t){const n=document.createElement("div");n.className="pills";const r=e.split(/[,\n]/).map(i=>i.trim()).filter(Boolean);for(const i of r){const o=document.createElement("span");o.className=t?"pill pill-app":"pill",o.textContent=i,n.appendChild(o)}return n}function wi(e){const t=document.createElement("ul");t.className="list";const n=e.split(`
`).map(r=>r.replace(/^[-•]\s*/,"").trim()).filter(Boolean);for(const r of n){const i=document.createElement("li");i.textContent=r,t.appendChild(i)}return t}function Fi(e){const t=document.createElement("div");t.className="projects";const n=e.split(`
`).map(r=>r.replace(/^[-•]\s*/,"").trim()).filter(Boolean);for(const r of n){const i=document.createElement("div");i.className="proj";const o=r.indexOf(":");if(o>0){const a=document.createElement("span");a.className="proj-slug",a.textContent=r.slice(0,o).trim();const s=document.createElement("span");s.className="proj-desc",s.textContent=r.slice(o+1).trim(),i.appendChild(a),i.appendChild(s)}else i.textContent=r;t.appendChild(i)}return t}function Ei(e){const t=document.createElement("ul");t.className="list allergies";const n=e.split(`
`).map(r=>r.replace(/^[-•]\s*/,"").trim()).filter(Boolean);for(const r of n){const i=document.createElement("li");i.textContent=r,t.appendChild(i)}return t}const ki='<svg viewBox="0 0 12 12" width="9" height="9" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 3 L9 9 M9 3 L3 9"/></svg>',Yn={biography:'<svg viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="6" r="3"/><path d="M2 14c0-3.3 2.7-6 6-6s6 2.7 6 6v.5H2V14z"/></svg>',projects:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2" y="3" width="12" height="10" rx="1.5"/><path d="M5 6h6 M5 9h6 M5 12h3"/></svg>',interests:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M8 13.5L2.5 8a3.5 3.5 0 0 1 5-5L8 3.5 8.5 3a3.5 3.5 0 0 1 5 5L8 13.5z"/></svg>',instructions:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M4 3v10 M4 3l4 4-4 4 M9 13h3"/></svg>',allergies:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M8 2L14 13H2L8 2z"/><path d="M8 7v3 M8 11.5v0"/></svg>',"connected-apps":'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2" y="2" width="5" height="5" rx="1"/><rect x="9" y="2" width="5" height="5" rx="1"/><rect x="2" y="9" width="5" height="5" rx="1"/><rect x="9" y="9" width="5" height="5" rx="1"/></svg>',calendar:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2" y="3" width="12" height="11" rx="1.5"/><path d="M2 6h12 M5 1.5v3 M11 1.5v3"/></svg>',memory:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M8 3a4 4 0 0 0-4 4v1a3 3 0 0 0 3 3h2a3 3 0 0 0 3-3V7a4 4 0 0 0-4-4z"/><path d="M8 11v3"/></svg>',preferences:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M3 5h10 M3 8h7 M3 11h10"/><circle cx="11" cy="5" r="1.5"/><circle cx="8" cy="8" r="1.5"/><circle cx="11" cy="11" r="1.5"/></svg>',identity:'<svg viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="6" r="3"/><path d="M2 14c0-3.3 2.7-6 6-6s6 2.7 6 6v.5H2V14z"/></svg>'},Ci=`
<style>
  :host {
    all: initial;
    display: inline-block;
    max-width: 100%;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    -webkit-font-smoothing: antialiased;
    line-height: 1.45;
  }
  * { box-sizing: border-box; }

  @keyframes mesh-drift {
    0%   { background-position:   0%   0%; }
    100% { background-position: 100% 100%; }
  }
  @keyframes chip-enter {
    from { opacity: 0; transform: translateY(3px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes chip-leave {
    to { opacity: 0; transform: translateY(2px) scale(0.94); }
  }

  #list {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    align-items: flex-start;
  }

  .item {
    display: inline-flex;
    flex-direction: column;
    min-width: 0;
    flex: 0 0 auto;
    max-width: 100%;
  }

  /* ── Chip ───────────────────────────────────────────────────────── */

  .chip {
    --accent: #586675;
    position: relative;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 28px;
    padding: 0 10px;
    border: 1px solid #d6d6db;
    border-radius: 999px;
    background: #fff;
    color: #1f1f24;
    font: inherit;
    font-size: 12px;
    line-height: 1;
    cursor: pointer;
    user-select: none;
    overflow: hidden;
    isolation: isolate;
    transition: border-color 0.15s ease, transform 0.15s ease;
    animation: chip-enter 0.22s cubic-bezier(0.2, 0.8, 0.2, 1) backwards;
    animation-delay: var(--enter-delay, 0ms);
  }
  .chip:hover { border-color: #1f1f24; transform: translateY(-1px); }
  .item.removing .chip { animation: chip-leave 0.18s ease forwards; }

  .dot {
    width: 6px; height: 6px;
    border-radius: 50%;
    background: var(--accent);
    flex-shrink: 0;
  }
  .icon {
    width: 12px; height: 12px;
    color: #6b6b70;
    flex-shrink: 0;
    display: inline-flex;
  }
  .icon svg { width: 100%; height: 100%; display: block; }

  .label {
    font-weight: 500;
    color: #1f1f24;
    white-space: nowrap;
  }
  .close {
    width: 18px; height: 18px;
    margin-left: 2px;
    border-radius: 50%;
    color: #9090a0;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: background 0.15s ease, color 0.15s ease;
  }
  .close:hover { background: rgba(0, 0, 0, 0.06); color: #1f1f24; }

  /* ── Marquee — Biography chip with the Surface mesh ───────────── */

  .chip.marquee {
    color: #fff;
    border-color: transparent;
    padding: 0 12px;
  }
  .chip.marquee::before {
    content: '';
    position: absolute;
    inset: 0;
    z-index: -1;
    pointer-events: none;
    background:
      radial-gradient(ellipse 65% 62% at 0%   15%, rgba(255, 110,  60, 0.95) 0%, transparent 65%),
      radial-gradient(ellipse 60% 62% at 100% 22%, rgba(140,  70, 240, 0.85) 0%, transparent 65%),
      radial-gradient(ellipse 65% 60% at 95%  92%, rgba( 50, 130, 255, 0.82) 0%, transparent 65%),
      radial-gradient(ellipse 55% 50% at 50%   0%, rgba(255, 140,  90, 0.78) 0%, transparent 65%),
      linear-gradient(135deg, #2a1c4a 0%, #4a1a3a 50%, #1a2a4a 100%);
    background-size: 200% 200%;
    animation: mesh-drift 9s ease-in-out infinite alternate;
    filter: blur(0.5px);
  }
  .chip.marquee .dot { background: #fff; }
  .chip.marquee .icon { color: rgba(255,255,255,0.95); }
  .chip.marquee .label { color: #fff; }
  .chip.marquee .close { color: rgba(255,255,255,0.7); }
  .chip.marquee .close:hover { background: rgba(255,255,255,0.18); color: #fff; }
  .chip.marquee:hover { transform: translateY(-1px); border-color: transparent; }

  /* ── Body (revealed when chip is clicked) ──────────────────────── */

  .body {
    display: none;
    margin-top: 6px;
    padding: 12px 14px;
    background: #fbfbfd;
    border: 1px solid #e5e5ea;
    border-left: 3px solid var(--accent, #586675);
    border-radius: 10px;
    color: #1f1f24;
    font-size: 13px;
    line-height: 1.55;
    max-width: min(420px, 100%);
    animation: chip-enter 0.22s ease;
  }
  .item.open .body { display: block; }

  /* ── Body renderers ─────────────────────────────────────────────── */

  .bio-name { font-size: 16px; font-weight: 500; color: #0d0d12; line-height: 1.2; letter-spacing: -0.01em; }
  .bio-sub { margin-top: 2px; color: #6b6b70; font-size: 12px; }
  .bio-about { margin: 10px 0 0; color: #2c2c33; font-size: 13px; line-height: 1.6; white-space: pre-wrap; }

  blockquote.instructions {
    margin: 0;
    padding: 0 0 0 10px;
    color: #2c2c33;
    font-style: italic;
    line-height: 1.6;
    white-space: pre-wrap;
  }

  .pills { display: flex; flex-wrap: wrap; gap: 6px; }
  .pill {
    display: inline-flex; align-items: center;
    height: 22px;
    padding: 0 10px;
    border: 1px solid #d6d6db;
    border-radius: 999px;
    background: #fff;
    color: #1f1f24;
    font-size: 12px;
    line-height: 1;
  }
  .pill-app {
    background: rgba(52, 199, 89, 0.08);
    border-color: rgba(52, 199, 89, 0.25);
    color: #1d6f3a;
  }

  ul.list { margin: 0; padding: 0; list-style: none; }
  ul.list li { padding: 5px 0; border-bottom: 1px solid rgba(0,0,0,0.05); color: #2c2c33; }
  ul.list li:last-child { border-bottom: none; }

  ul.list.allergies li { color: #b91c2a; padding-left: 14px; position: relative; }
  ul.list.allergies li::before {
    content: '';
    width: 6px; height: 6px; border-radius: 50%;
    background: #b91c2a;
    position: absolute; left: 0; top: 11px;
  }

  .projects { display: flex; flex-direction: column; gap: 6px; }
  .proj {
    display: flex; flex-direction: column;
    padding: 8px 10px;
    background: #fff;
    border: 1px solid #ececf0;
    border-radius: 6px;
  }
  .proj-slug { font-size: 12px; font-weight: 500; color: #0d0d12; }
  .proj-desc { margin-top: 2px; font-size: 12px; color: #6b6b70; line-height: 1.5; }

  /* ── Dark mode ──────────────────────────────────────────────────── */
  @media (prefers-color-scheme: dark) {
    .chip {
      background: #1c1c20;
      border-color: rgba(255, 255, 255, 0.14);
      color: #f0f0f3;
    }
    .chip:hover { border-color: rgba(255, 255, 255, 0.5); }
    .icon { color: rgba(255, 255, 255, 0.66); }
    .label { color: #f0f0f3; }
    .close { color: rgba(255, 255, 255, 0.5); }
    .close:hover { background: rgba(255, 255, 255, 0.1); color: #fff; }
    .body {
      background: #1c1c20;
      border-color: rgba(255, 255, 255, 0.08);
      color: #e8e8eb;
    }
    .bio-name { color: #fff; }
    .bio-sub { color: rgba(255, 255, 255, 0.5); }
    .bio-about { color: rgba(255, 255, 255, 0.85); }
    blockquote.instructions { color: rgba(255, 255, 255, 0.85); }
    .pill {
      background: rgba(255, 255, 255, 0.06);
      border-color: rgba(255, 255, 255, 0.14);
      color: #f0f0f3;
    }
    .pill-app {
      background: rgba(52, 199, 89, 0.14);
      border-color: rgba(52, 199, 89, 0.3);
      color: #65d38f;
    }
    ul.list li { color: #d4d4d8; border-bottom-color: rgba(255, 255, 255, 0.06); }
    ul.list.allergies li { color: #ff8a8a; }
    ul.list.allergies li::before { background: #ff8a8a; }
    .proj {
      background: rgba(255, 255, 255, 0.04);
      border-color: rgba(255, 255, 255, 0.08);
    }
    .proj-slug { color: #fff; }
    .proj-desc { color: rgba(255, 255, 255, 0.6); }
  }
</style>
<div id="list" role="list" aria-label="Webpaper profile cards"></div>
`,me=ee("watcher");let mt=null,st=!1;function Vn(){if(!st||!mt){me.warn("forceRescan called before watcher installed");return}mt()}function Ni(e){if(st)return me.warn("installMessageWatcher called twice — ignoring"),()=>{};const t=document.body,n=new WeakSet,r=[];me.info("installed",{adapter:e.name}),Wt(t,"initial");let i=null;const o=c=>{i==null&&(i=window.setTimeout(()=>{i=null,Wt(t,c),l()},100))},a=c=>{for(const d of c){for(const f of Array.from(d.addedNodes)){if(!(f instanceof Element))continue;const u=$r(f);if(xt(u)){o("added-with-markers");return}}if(d.type==="characterData"){const f=d.target.textContent??"";if(xt(f)){o("chardata-with-markers");return}}d.addedNodes.length>0&&l()}},s=new MutationObserver(a);s.observe(t,{childList:!0,subtree:!0,characterData:!0}),r.push(s);const l=()=>{const c=Wr(t);for(const d of c){if(n.has(d))continue;n.add(d);const f=new MutationObserver(a);f.observe(d,{childList:!0,subtree:!0,characterData:!0}),r.push(f),o("new-shadow-root")}};return l(),mt=()=>Wt(t,"force-rescan"),st=!0,()=>{for(const c of r)c.disconnect();i!=null&&window.clearTimeout(i),mt=null,st=!1,me.info("teardown")}}function Wt(e,t){const n=$r(e);if(!xt(n))return;const r=[e,...Wr(e)];let i=0;for(const o of r)i+=Ai(o);i>0&&me.debug(`scan(${t}) processed ${i}`)}function Ai(e){var l,c;const t=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),n=[],r=/CFG:START:([a-z0-9]+)/g,i=/CFG:END:([a-z0-9]+)/g;let o=t.nextNode();for(;o;){const d=o.data;r.lastIndex=0;let f;for(;(f=r.exec(d))!==null;)n.push({id:f[1],kind:"start",node:o,offset:f.index,endOffset:f.index+f[0].length});for(i.lastIndex=0;(f=i.exec(d))!==null;)n.push({id:f[1],kind:"end",node:o,offset:f.index,endOffset:f.index+f[0].length});o=t.nextNode()}const a=new Set;let s=0;for(let d=0;d<n.length;d++){if(a.has(d))continue;const f=n[d];if(f.kind!=="start")continue;let u=-1;for(let m=d+1;m<n.length;m++){if(a.has(m))continue;const g=n[m];if(g.kind==="end"&&g.id===f.id){u=m;break}}if(u===-1)continue;const p=n[u];a.add(d),a.add(u),!((c=(l=f.node.parentElement)==null?void 0:l.closest)!=null&&c.call(l,"[data-srf-cards-container]"))&&vi(f.id,f,p)&&s++}return s}function vi(e,t,n){try{const r=document.createRange();r.setStart(t.node,t.offset),r.setEnd(n.node,n.endOffset);const i=r.toString(),o=Rr(i);if(r.deleteContents(),o.length===0)return me.debug("no cards parsed from wrap, leaving range deleted",{id:e}),!0;const a=Pr({cards:o,id:e,readonly:!0});return r.insertNode(a),!0}catch(r){return me.warn("replaceWithCards failed, fallback",{id:e,err:r}),Mi(e,t,n)}}function Mi(e,t,n){var r;try{const i=/⁣?CFG:START:[a-z0-9]+⁣?/g,o=/⁣?CFG:END:[a-z0-9]+⁣?/g,a=t.node.parentElement,s=n.node.parentElement;if(!a)return!1;let l="",c=a;const d=[];for(;c&&(l+=c.textContent??"",l+=`
`,d.push(c),c!==s);)c=c.nextElementSibling;l=l.replace(i,"").replace(o,"").trim();const f=Rr(l);for(const p of d)p.style.display="none";if(f.length===0)return!0;const u=Pr({cards:f,id:e,readonly:!0});return(r=a.parentElement)==null||r.insertBefore(u,a),!0}catch(i){return me.error("fallback failed",{id:e,err:i}),!1}}function Rr(e){const t=[];for(const[i,o]of Object.entries(qo)){if(!jo(i))continue;const a=`[${o.promptSection}]`;let s=e.indexOf(a);for(;s!==-1;)t.push({type:i,start:s,bracketEnd:s+a.length}),s=e.indexOf(a,s+1)}t.sort((i,o)=>i.start-o.start);let n=-1;for(const i of["--- INSTRUCTIONS ---","---INSTRUCTIONS---","[OBSERVED BEHAVIOR]"]){const o=e.indexOf(i);o!==-1&&(n===-1||o<n)&&(n=o)}const r=[];for(let i=0;i<t.length;i++){const o=t[i];if(n!==-1&&o.start>=n)break;let a=i+1<t.length?t[i+1].start:e.length;n!==-1&&n<a&&(a=n);const s=e.slice(o.bracketEnd,a).trim();s&&r.push({type:o.type,content:s})}return r}function $r(e){const t=[],n=r=>{if(r.nodeType===Node.TEXT_NODE){t.push(r.data);return}if(r.nodeType===Node.ELEMENT_NODE){const i=r,o=i.shadowRoot;if(o)for(const a of Array.from(o.childNodes))n(a);for(const a of Array.from(i.childNodes))n(a);return}for(const i of Array.from(r.childNodes))n(i)};return n(e),t.join("")}function Wr(e){const t=[],n=r=>{if(r.nodeType===Node.ELEMENT_NODE){const i=r.shadowRoot;if(i){t.push(i);for(const o of Array.from(i.childNodes))n(o)}for(const o of Array.from(r.childNodes))n(o);return}for(const i of Array.from(r.childNodes))n(i)};return n(e),t}const Bi=ee("inject"),Li="--- Surface IDENTITY ---";function Ii(e){let t=!1;function n(a){if(!e.isEnabled()||t||!a)return!1;if(!e.getPrompt())return Bi.warn("armed but no cached prompt — passing through"),!1;const l=Jn(a);return!(!l.trim()||l.includes(Li)||xt(l))}function r(a){var d;const s=e.getPrompt();if(!s)return!1;const l=Jn(a),c=`${s}${l}`;return Di(a),Ir(a,c),(d=e.onAugmented)==null||d.call(e),setTimeout(()=>{var f,u;t=!0;try{const p=(u=(f=e.adapter).getSendButton)==null?void 0:u.call(f);p?p.click():e.adapter.triggerSend()}finally{setTimeout(()=>{t=!1},200)}setTimeout(Vn,500),setTimeout(Vn,1500)},60),!0}function i(a){if(a.key!=="Enter"||a.shiftKey||a.ctrlKey||a.metaKey||a.altKey||a.isComposing)return;const s=e.adapter.getInput();if(!s)return;const l=a.target;!s.contains(l)&&l!==s||n(s)&&(a.preventDefault(),a.stopPropagation(),a.stopImmediatePropagation(),r(s))}function o(a){var f,u;if(t)return;const s=a.target;if(!s)return;const l=s.closest("button");if(!l)return;const c=(u=(f=e.adapter).getSendButton)==null?void 0:u.call(f);if(!c||l!==c)return;const d=e.adapter.getInput();n(d)&&(a.preventDefault(),a.stopPropagation(),a.stopImmediatePropagation(),r(d))}return document.addEventListener("keydown",i,{capture:!0}),document.addEventListener("click",o,{capture:!0}),()=>{document.removeEventListener("keydown",i,{capture:!0}),document.removeEventListener("click",o,{capture:!0})}}function Jn(e){return e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement?e.value:e.textContent??""}function Di(e){var r;if(e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement){const i=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,o=Object.getOwnPropertyDescriptor(i,"value");(r=o==null?void 0:o.set)==null||r.call(e,""),e.dispatchEvent(new Event("input",{bubbles:!0}));return}e.focus();const t=document.createRange();t.selectNodeContents(e);const n=window.getSelection();n==null||n.removeAllRanges(),n==null||n.addRange(t),document.execCommand("delete",!1)}const He=[],Ti=200,Oi=new Set(["rollback"]);function q(e,t,n){if(He.length>=Ti&&He.shift(),He.push({ts:Date.now(),stage:e,message:t,detail:n}),Oi.has(e)||/\b(fail|failed|error|timed out|timeout|broke)\b/i.test(t))try{chrome.runtime.sendMessage({type:"activity-log",payload:{level:e==="rollback"?"warn":"error",source:"polish",message:t,detail:{stage:e,hostname:location.hostname,url:location.href,info:n}}}).catch(()=>{})}catch{}}function Pi(){return[...He]}function Ri(){He.length=0}const z={rules:"srf-polish-rules-styles",auto:"srf-polish-auto-styles",manual:"srf-polish-manual-styles"},$i=["arial","helvetica","times new roman","times","verdana","georgia","palatino","garamond","comic sans ms","impact","lucida console","tahoma","trebuchet ms","courier new","courier"];function Wi(){const e=new Set,t=document.querySelectorAll("body, h1, h2, h3, p, a, span, div, li, td, th, button, input"),n=Math.min(t.length,50);for(let r=0;r<n;r++){const i=getComputedStyle(t[r]).fontFamily.toLowerCase();for(const o of $i)if(i.includes(o)){e.add(o);break}}return e}function _r(e){const t=e.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);return t?.299*Number(t[1])+.587*Number(t[2])+.114*Number(t[3])<128:!1}const _i=["inter","sf pro","roboto","open sans","lato","montserrat","poppins","nunito","raleway","source sans","dm sans","plus jakarta","manrope","geist","figtree","outfit"];function en(e){const t=e.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);return t?[Number(t[1]),Number(t[2]),Number(t[3])]:null}function zi(){const e=getComputedStyle(document.body),t=e.backgroundColor,n=e.color,r=e.fontFamily,i=_r(t),o=r.toLowerCase(),a=_i.some(g=>o.includes(g));let s=!1;const l=document.querySelectorAll('button, [role="button"], input[type="submit"]');for(let g=0;g<Math.min(l.length,5);g++)if(parseFloat(getComputedStyle(l[g]).borderRadius)>=4){s=!0;break}let c=!1;const d=document.querySelectorAll("a, button");for(let g=0;g<Math.min(d.length,5);g++){const h=getComputedStyle(d[g]).transitionDuration;if(h&&h!=="0s"&&h!=="0ms"){c=!0;break}}let f="";const u=document.querySelectorAll("a[href]");for(let g=0;g<Math.min(u.length,5);g++){const h=getComputedStyle(u[g]).color,y=en(h);if(y){const E=.299*y[0]+.587*y[1]+.114*y[2];if(E>30&&E<230){f=h;break}}}const p=document.querySelector('main, article, [role="main"], .content, .container'),m=p?p.getBoundingClientRect().width:document.body.clientWidth;return{bgColor:t,textColor:n,accentColor:f,primaryFont:r,isModernFont:a,hasRoundedButtons:s,hasTransitions:c,avgContentWidth:m,isDark:i}}function qi(e,t){let n="";switch(e){case"education":n+=`article, .post, .content, .lesson, .text { max-width: 720px; margin-left: auto; margin-right: auto; }
`,n+=`blockquote { border-left: 3px solid rgba(99, 102, 241, 0.3); padding-left: 16px; margin-left: 0; font-style: italic; }
`,n+=`p + p { margin-top: 1.2em; }
`;break;case"shopping":n+=`[class*="card"], [class*="product"], [class*="item"] { transition: transform 0.2s ease, box-shadow 0.2s ease; }
`,n+=`[class*="card"]:hover, [class*="product"]:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
`;break;case"coding":n+=`pre, code, .code, .CodeMirror, .monaco-editor { font-family: 'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace !important; }
`,n+=`pre { border-radius: 8px; padding: 16px; }
`;break;case"finance":n+=`table { border-collapse: collapse; }
`,n+=`td, th { padding: 8px 12px; }
`;break;case"general_ai":n+=`[class*="message"], [class*="chat"], [class*="bubble"] { border-radius: 12px; }
`,n+=`[class*="avatar"], [class*="icon"] img { border-radius: 50%; }
`;break}return n}function ji(e,t){const n=(t==null?void 0:t.isDark)??_r(getComputedStyle(document.body).backgroundColor),r=(t==null?void 0:t.isModernFont)&&!(e!=null&&e.trim()),i=(t==null?void 0:t.hasRoundedButtons)??!1,o=(t==null?void 0:t.hasTransitions)??!1,a=e&&e.trim()?`${e}, -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif`:"'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif";let s="";r||((!e||!e.trim())&&(s+=`@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
`),Wi().size>0&&(s+=`body { font-family: ${a}; }
`,s+=`h1, h2, h3, h4, h5, h6 { font-family: ${a}; letter-spacing: -0.02em; }
`)),s+=`body { line-height: 1.6; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
`;let l="";const c=en((t==null?void 0:t.textColor)??getComputedStyle(document.body).color),d=en((t==null?void 0:t.bgColor)??getComputedStyle(document.body).backgroundColor);n?c&&c[0]===255&&c[1]===255&&c[2]===255&&(l+=`body { color: #e2e8f0; }
`):(c&&c[0]===0&&c[1]===0&&c[2]===0&&(l+=`body { color: #1a1a2e; }
`),d&&d[0]===255&&d[1]===255&&d[2]===255&&(l+=`body { background-color: #fafafa; }
`)),l+=`::selection { background: rgba(99, 102, 241, 0.2); }
`;let f="";o||(f+=`a, button, input, select, textarea, [role="button"] { transition: all 0.15s ease; }
`),f+=`input:focus, textarea:focus, select:focus { outline: none; box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.15); }
`,f+=`::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: ${n?"rgba(255,255,255,0.1)":"rgba(0,0,0,0.12)"}; border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: ${n?"rgba(255,255,255,0.2)":"rgba(0,0,0,0.2)"}; }
`;let u="";return u+=`html { scroll-behavior: smooth; }
`,i||(u+=`button, [role="button"], input[type="submit"], input[type="button"] { border-radius: 6px; }
`,u+=`input:not([type="checkbox"]):not([type="radio"]), textarea, select { border-radius: 6px; }
`),u+=`img { border-radius: 4px; transition: transform 0.3s ease, box-shadow 0.3s ease; }
`,u+=`article img:hover, figure img:hover, .content img:hover { transform: scale(1.01); box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
`,u+=`[class*="card"]:hover, [class*="Card"]:hover, [class*="item"]:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.08); transition: transform 0.2s ease, box-shadow 0.2s ease; }
`,u+=`@keyframes srfFadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
`,u+=`main, article, [role="main"], .content, .container { animation: srfFadeIn 0.4s ease both; }
`,[s,l,f,u]}function Hi(e,t){const n=zi();if(q("tokens","Page design tokens scanned",JSON.stringify({font:n.primaryFont.split(",")[0].replace(/['"]/g,"").trim(),isModernFont:n.isModernFont,hasRoundedButtons:n.hasRoundedButtons,hasTransitions:n.hasTransitions,isDark:n.isDark,bgColor:n.bgColor,contentWidth:Math.round(n.avgContentWidth)})),document.getElementById(z.rules))return q("rules","Skipped — rules already applied"),{result:"already",tokens:n};const r=[];n.isModernFont&&r.push("fonts (already modern)"),n.hasRoundedButtons&&r.push("button radius (already rounded)"),n.hasTransitions&&r.push("transitions (already exist)"),q("rules",`Applying rules engine${r.length?`. Skipping: ${r.join(", ")}`:""}`,t?`Category: ${t}`:void 0);const i=ji(e,n);t&&t!=="unknown"&&i.push(qi(t,n.isDark)),Mr();const o=document.createElement("style");o.id=z.rules,o.textContent=`/* Surface Polish Rules Engine — zero AI, adaptive */
`,document.head.appendChild(o),o.textContent+=oe(i[0]);let a=1;function s(){a<i.length&&(o.textContent+=oe(i[a]),a++,a<i.length&&requestAnimationFrame(s))}return requestAnimationFrame(s),{result:"applied",tokens:n}}function Gi(){const e=document.body,t=e.querySelectorAll("*").length,n=e.querySelectorAll("[style]").length,r=e.querySelectorAll("img").length,i=e.querySelectorAll("iframe").length;let o=0,a=!1;for(const g of Array.from(e.querySelectorAll("*")))g.shadowRoot&&(o++,a=!0);const s=/^[a-z]{1,3}[A-Z_-][a-zA-Z0-9_-]{6,}$/;let l=0;const c=e.querySelectorAll("[class]"),d=Math.min(c.length,100);for(let g=0;g<d;g++){const h=c[g].className;if(typeof h=="string")for(const y of h.split(" "))s.test(y)&&l++}const f=!!document.getElementById("root")||!!document.getElementById("__next"),u=[],p=[];let m="high";return t<500?u.push("Simple page — great fit"):t<2e3?u.push("Medium page — should work well"):(p.push(`Large (${t} elements) — may truncate`),m="medium"),r>10&&u.push("Image-rich — polish will shine"),n>20&&(p.push(`${n} inline styles — some resist`),m==="high"&&(m="medium")),l>15&&(p.push("Hashed classes — fragile selectors"),m==="high"&&(m="medium")),f&&p.push("SPA — re-renders may revert"),a&&(p.push(`${o} shadow DOM — untouchable`),m="low"),i>2&&p.push(`${i} iframes — untouchable`),{insights:u,confidence:m,warnings:p,elementCount:t}}function tn(){const e=[];e.push("### VISUAL DESIGN SYSTEM SPEC (GROUND TRUTH)");const t=getComputedStyle(document.body),n=t.backgroundColor,r=t.color,i=Ui(n);e.push(`- **Theme Mode:** ${i?"Dark Mode":"Light Mode"}`),e.push(`- **Body Background:** ${n}`),e.push(`- **Body Text Color:** ${r}`);const o={};try{for(const u of Array.from(document.styleSheets))try{for(const p of Array.from(u.cssRules))if(p instanceof CSSStyleRule&&(p.selectorText===":root"||p.selectorText==="body"))for(let m=0;m<p.style.length;m++){const g=p.style[m];if(g.startsWith("--")){const h=g.toLowerCase();(h.includes("color")||h.includes("bg")||h.includes("text")||h.includes("accent")||h.includes("font")||h.includes("radius")||h.includes("spacing")||h.includes("gap"))&&(o[g]=p.style.getPropertyValue(g).trim())}}}catch{}}catch{}const a=Object.keys(o).slice(0,15);if(a.length>0){e.push("- **Active CSS Custom Variables:**");for(const u of a)e.push(`  - \`${u}\`: ${o[u]}`)}e.push(`
### TYPOGRAPHY STACK`);const s=document.querySelector("h1"),l=document.querySelector("p"),c=document.querySelector('button, [role="button"], input[type="submit"]');if(s){const u=getComputedStyle(s);e.push(`- **Headings (H1):** font-family: ${u.fontFamily} | font-size: ${u.fontSize} | font-weight: ${u.fontWeight} | line-height: ${u.lineHeight} | color: ${u.color}`)}if(l){const u=getComputedStyle(l);e.push(`- **Paragraphs (Body):** font-family: ${u.fontFamily} | font-size: ${u.fontSize} | font-weight: ${u.fontWeight} | line-height: ${u.lineHeight} | color: ${u.color}`)}if(c){const u=getComputedStyle(c);e.push(`- **Interactive (Buttons):** font-family: ${u.fontFamily} | font-size: ${u.fontSize} | font-weight: ${u.fontWeight}`)}if(e.push(`
### INTERACTIVE AESTHETICS`),c){const u=getComputedStyle(c);e.push(`- **Button Style:** bg: ${u.backgroundColor} | text: ${u.color} | border-radius: ${u.borderRadius} | border: ${u.border} | padding: ${u.padding} | shadow: ${u.boxShadow||"none"} | transition: ${u.transition||"none"}`)}else e.push("- **Button Style:** No button sampled.");e.push(`
### RESPONSIVE LAYOUT GEOMETRY & LANDMARKS`);const d=[{tag:"header",el:document.querySelector("header")},{tag:"nav",el:document.querySelector('nav, [role="navigation"]')},{tag:"main",el:document.querySelector('main, article, [role="main"]')},{tag:"aside",el:document.querySelector('aside, [class*="sidebar"]')},{tag:"footer",el:document.querySelector("footer")}];for(const u of d)if(u.el){const p=u.el.getBoundingClientRect(),m=getComputedStyle(u.el);e.push(`- **\`<${u.tag}>\` Element:**`),e.push(`  - Dimensions: ${Math.round(p.width)}px x ${Math.round(p.height)}px`),e.push(`  - Styling: display: ${m.display} | position: ${m.position} | padding: ${m.padding} | margin: ${m.margin} | gap: ${m.gap||"none"}`),m.display==="flex"?e.push(`  - Flex Direction: ${m.flexDirection}`):m.display==="grid"&&e.push(`  - Grid Columns: ${m.gridTemplateColumns}`)}let f=!1;try{const u=document.querySelectorAll("[class]");let p=0;const m=Math.min(u.length,50),g=[/^(bg|text|p|m|rounded|flex|grid|border|w|h|justify|items|gap)-[a-z0-9]/,/^hover:/,/^focus:/];for(let h=0;h<m;h++){const y=u[h].className;if(typeof y=="string")for(const E of y.split(/\s+/))g.some(C=>C.test(E))&&p++}p>15&&(f=!0)}catch{}return e.push(`
### UTILITY FRAMEWORK DETECTION
- **Tailwind CSS Detected:** ${f?"Yes":"No"}`),e.join(`
`)}function Ui(e){const t=e.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);return t?.299*Number(t[1])+.587*Number(t[2])+.114*Number(t[3])<128:!1}function nn(){const e=document.body.cloneNode(!0),t=["script","style","svg","canvas","iframe","noscript","audio","template","object","embed","map","area"];for(const r of t){const i=e.getElementsByTagName(r);for(let o=i.length-1;o>=0;o--)i[o].remove()}e.querySelectorAll("#srf-polish-overlay, #surface-overlay-root, .srf-preview-bar-container").forEach(r=>r.remove());for(const r of Array.from(e.querySelectorAll("*"))){const i=r.tagName.toLowerCase(),o=[];for(const a of Array.from(r.attributes))(a.name.startsWith("data-")||a.name.startsWith("aria-")||a.name==="jsaction"||a.name==="jscontroller"||a.name==="jsmodel"||a.name==="jsname"||a.name==="tabindex")&&o.push(a.name),a.name==="src"&&a.value.startsWith("data:image")&&r.setAttribute("src","[data-img]"),a.name==="srcset"&&o.push("srcset");if(o.forEach(a=>r.removeAttribute(a)),i==="img"||i==="video"||i==="picture"){const a=r.getAttribute("src");let s=null;if(r.id?s=document.getElementById(r.id):a&&a!=="[data-img]"&&(s=document.querySelector(`[src="${CSS.escape(a)}"]`)),s){const l=s.getBoundingClientRect();l.width>0&&l.height>0&&r.setAttribute("data-srf-size",`${Math.round(l.width)}x${Math.round(l.height)}`)}}}return e.innerHTML}const Ki=new Set(["@font-face","@keyframes","@charset"]),Yi=/^srf-|^wp-/;function Vi(e=4e4){const t=[],n=new Set;let r=0,i=!1;for(const a of Array.from(document.styleSheets)){const s=a.ownerNode;if(s instanceof Element){const c=s.getAttribute("id")??"";if(Yi.test(c))continue}let l;try{l=a.cssRules}catch{r++;continue}for(const c of Array.from(l)){const d=c.cssText.trim(),f=d.match(/^(@[\w-]+)/);f&&Ki.has(f[1])||n.has(d)||(n.add(d),d.includes("--")&&(i=!0),t.push(d))}}const o=t.join(`
`).slice(0,e);return{rules:o,ruleCount:t.length,sizeChars:o.length,crossOriginSkipped:r,hasCustomProps:i}}function et(e){const t=window.getComputedStyle(e);return t.display!=="none"&&t.visibility!=="hidden"&&t.opacity!=="0"}function ze(e,t=200){return(e??"").replace(/\s+/g," ").trim().slice(0,t)}function Ji(){var s;const e=[];document.querySelectorAll("h1,h2,h3,h4").forEach(l=>{if(!et(l))return;const c=ze(l.textContent,120);c&&e.push({level:parseInt(l.tagName[1]),text:c})});const t=[];document.querySelectorAll("p").forEach(l=>{if(!et(l))return;const c=ze(l.textContent,180);c.length>30&&t.push(c)});const n=[],r=new Set;document.querySelectorAll('nav a, header a, [role="navigation"] a').forEach(l=>{if(!et(l))return;const c=ze(l.textContent,60);c&&!r.has(c)&&(r.add(c),n.push(c))});const i=[],o=new Set;document.querySelectorAll('button, a[class*="btn"], a[class*="cta"], [class*="button"], input[type="submit"]').forEach(l=>{if(!et(l))return;const c=ze(l.textContent||l.value,80);c&&!o.has(c)&&(o.add(c),i.push(c))});const a=[];return document.querySelectorAll("img[alt]").forEach(l=>{const c=ze(l.alt,60);c&&a.push(c)}),{title:document.title,description:((s=document.querySelector('meta[name="description"]'))==null?void 0:s.getAttribute("content"))??"",url:location.href,headings:e.slice(0,12),paragraphs:t.slice(0,6),navLinks:n.slice(0,12),ctas:i.slice(0,8),imageAlts:a.slice(0,6)}}function Xi(e){const t=[];return t.push(`URL: ${e.url}`),e.title&&t.push(`TITLE: ${e.title}`),e.description&&t.push(`DESC: ${e.description}`),e.headings.length&&(t.push("HEADINGS:"),e.headings.forEach(n=>t.push(`  H${n.level}: ${n.text}`))),e.paragraphs.length&&(t.push("COPY:"),e.paragraphs.forEach(n=>t.push(`  — ${n}`))),e.navLinks.length&&t.push(`NAV: ${e.navLinks.join(" | ")}`),e.ctas.length&&t.push(`CTAs: ${e.ctas.join(" | ")}`),t.join(`
`)}const Qi=new Set(["SCRIPT","STYLE","NOSCRIPT","IFRAME","SVG","CANVAS","AUDIO","VIDEO","TEMPLATE","OBJECT","EMBED"]),Zi=new Set(["data-reactid","data-react-checksum","jsaction","jscontroller","jsname","jsmodel","aria-describedby","tabindex","autocomplete"]);function ea(e=3e4){const t=document.body.cloneNode(!0);return t.querySelectorAll(Array.from(Qi).join(",")).forEach(n=>n.remove()),t.querySelectorAll("*").forEach(n=>{for(const r of Array.from(n.attributes))(Zi.has(r.name)||r.name.startsWith("data-")&&r.name!=="data-srf-size")&&n.removeAttribute(r.name);if(n.childNodes.length===1&&n.childNodes[0].nodeType===Node.TEXT_NODE){const r=n.childNodes[0];r.data.length>120&&(r.data=r.data.slice(0,100)+"…")}}),t.innerHTML.slice(0,e)}function rn(e){const{includeDOM:t=!0,cssMaxChars:n=35e3,domMaxChars:r=25e3}=e,i=Vi(n),o=Ji(),a=[];if(a.push(`### PAGE CONTENT
${Xi(o)}`),a.push(`### FULL STYLESHEET (${i.ruleCount} rules, ${i.crossOriginSkipped} cross-origin sheets skipped)
\`\`\`css
${i.rules}
\`\`\``),t){const s=ea(r);a.push(`### DOM STRUCTURE
\`\`\`html
${s}
\`\`\``)}return a.join(`

`)}function on(){const e=location.pathname.replace(/\/+$/,"")||"/";return`${location.hostname}${e}`}async function an(){var o,a;const e=[];e.push(document.title.replace(/^\(\d+\)\s*/,""));const t=(o=document.querySelector('meta[name="description"]'))==null?void 0:o.getAttribute("content");t&&e.push(t);const n=Array.from(document.querySelectorAll("h1, h2, h3")).slice(0,20);for(const s of n){const l=(a=s.textContent)==null?void 0:a.trim();l&&e.push(l.slice(0,120))}const r=Array.from(document.querySelectorAll("script[src]")).map(s=>s.getAttribute("src")??"").filter(Boolean).sort(),i=Array.from(document.querySelectorAll('link[rel="stylesheet"][href]')).map(s=>s.getAttribute("href")??"").filter(Boolean).sort();return e.push(...r,...i),ta(e.join(`
`))}async function ta(e){try{const t=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(e)),n=new Uint8Array(t);let r=0n;for(let i=0;i<8;i++)r=r<<8n|BigInt(n[i]);return r.toString(36)}catch{let t=5381;for(let n=0;n<e.length;n++)t=(t<<5)+t+e.charCodeAt(n)|0;return(t>>>0).toString(36)}}const ae=[{rules:"",auto:"",manual:""}];let K=0;function ne(){const e={rules:Te(z.rules),auto:Te(z.auto),manual:Te(z.manual)};if(K>=0){const t=ae[K];if(t.rules===e.rules&&t.auto===e.auto&&t.manual===e.manual)return}ae.length=K+1,ae.push(e),K=ae.length-1}function zr(){return K<=0?!1:(K--,kn(ae[K]),!0)}function na(){return K>=ae.length-1?!1:(K++,kn(ae[K]),!0)}function qe(){return{position:K+1,total:ae.length,canBack:K>0,canForward:K<ae.length-1}}function sn(){K=0,kn(ae[0])}function Xn(){const e=Te(z.manual),t=Te(z.auto),n=Te(z.rules);return e?"manual":t?"auto":n?"rules":"unpolished"}function X(e){let t=document.getElementById(e);return t||(t=document.createElement("style"),t.id=e,document.head.appendChild(t)),t}function Te(e){var t;return((t=document.getElementById(e))==null?void 0:t.textContent)??""}function kn(e){_t(z.rules,e.rules),_t(z.auto,e.auto),_t(z.manual,e.manual)}function _t(e,t){let n=document.getElementById(e);t?(n||(n=document.createElement("style"),n.id=e,document.head.appendChild(n)),n.textContent=t):n&&n.remove()}const Xe="srf-polish-overlay-root";let we=0,lt=null;function qr(){let e=document.getElementById(Xe);if(e&&e.shadowRoot)return e.shadowRoot;e=document.createElement("div"),e.id=Xe,e.style.cssText="all: initial; position: fixed; z-index: 2147483646; bottom: 24px; left: 24px; pointer-events: none;";const t=e.attachShadow({mode:"open"});return t.innerHTML=`
    <style>
      @keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes fadeOut { from { opacity: 1; transform: translateY(0); } to { opacity: 0; transform: translateY(6px); } }
      @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
      @keyframes progressFill { from { width: 0%; } to { width: 100%; } }
      @keyframes checkPop { 0% { transform: scale(0); opacity: 0; } 60% { transform: scale(1.2); } 100% { transform: scale(1); opacity: 1; } }
      @keyframes scanLine {
        0% { top: 0; opacity: 0; }
        10% { opacity: 1; }
        90% { opacity: 1; }
        100% { top: 100%; opacity: 0; }
      }

      :host {
        all: initial;
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', sans-serif;
        -webkit-font-smoothing: antialiased;
      }

      /* Scan line that sweeps the viewport */
      .scan-line {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 2px;
        background: linear-gradient(90deg, transparent, rgba(99, 102, 241, 0.4), transparent);
        animation: scanLine 1.2s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        pointer-events: none;
        z-index: 2147483647;
        display: none;
      }
      .scan-line.active { display: block; }

      /* Main card */
      .card {
        display: none;
        align-items: center;
        gap: 10px;
        background: #FFFFFF;
        border: 1px solid #9E9E9E;
        border-radius: 8px;
        padding: 12px 16px;
        pointer-events: auto;
        animation: fadeIn 0.2s cubic-bezier(0.25, 0.1, 0.25, 1);
        font-size: 13px;
        color: #363636;
        max-width: 260px;
        transition: all 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
        overflow: hidden;
      }
      .card.visible { display: flex; }
      .card.fading { animation: fadeOut 0.25s cubic-bezier(0.25, 0.1, 0.25, 1) forwards; }
      .card.error { border-color: #FF3B30; }
      .card.success { border-color: #34C759; }

      /* Pill mode — shrinks when AI is streaming and page is already transforming */
      .card.pill {
        padding: 8px 14px;
        max-width: 180px;
        border-color: rgba(99, 102, 241, 0.3);
        background: rgba(255, 255, 255, 0.92);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
      }

      /* Progress bar */
      .progress-track {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 2px;
        background: rgba(0, 0, 0, 0.04);
        overflow: hidden;
      }
      .progress-bar {
        height: 100%;
        background: rgba(99, 102, 241, 0.5);
        border-radius: 1px;
        width: 0%;
        transition: width 0.3s ease;
      }

      /* Pulsing dot for pill mode */
      .dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: rgb(99, 102, 241);
        animation: pulse 1.5s ease-in-out infinite;
        flex-shrink: 0;
        display: none;
      }
      .pill .dot { display: block; }

      /* Checkmark for completion */
      .check {
        width: 16px;
        height: 16px;
        flex-shrink: 0;
        display: none;
      }
      .check.pop {
        display: block;
        animation: checkPop 0.3s cubic-bezier(0.25, 0.1, 0.25, 1) forwards;
      }

      .spinner {
        width: 14px;
        height: 14px;
        border: 1px solid #E5E5EA;
        border-top-color: #363636;
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
        flex-shrink: 0;
      }
      @keyframes spin { to { transform: rotate(360deg); } }

      .title { font-weight: 400; letter-spacing: 0.01em; color: #000; white-space: nowrap; }
      .subtitle { color: #6B6B70; font-size: 12px; margin-top: 2px; letter-spacing: 0.01em; }

      @media (prefers-color-scheme: dark) {
        .card {
          background: #1C1C1E;
          border-color: #636366;
          color: #FFFFFF;
        }
        .card.pill {
          background: rgba(28, 28, 30, 0.92);
          border-color: rgba(99, 102, 241, 0.3);
        }
        .title { color: #FFFFFF; }
        .subtitle { color: #A4A4A4; }
        .spinner { border-color: #38383A; border-top-color: #FFFFFF; }
        .progress-track { background: rgba(255, 255, 255, 0.04); }
      }
    </style>

    <div class="scan-line" id="scanLine"></div>
    <div class="card" id="card">
      <div class="spinner" id="spinner"></div>
      <div class="dot" id="dot"></div>
      <svg class="check" id="check" viewBox="0 0 16 16" fill="none">
        <circle cx="8" cy="8" r="7.5" stroke="#34C759" stroke-width="1"/>
        <path d="M5 8.5L7 10.5L11 6" stroke="#34C759" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <div>
        <div class="title" id="title">Analyzing page</div>
        <div class="subtitle" id="subtitle"></div>
      </div>
      <div class="progress-track"><div class="progress-bar" id="progress"></div></div>
    </div>
  `,document.body.appendChild(e),t}function gt(e="Streaming styles…"){const t=qr(),n=t.getElementById("card"),r=t.getElementById("title"),i=t.getElementById("subtitle"),o=t.getElementById("spinner"),a=t.getElementById("dot"),s=t.getElementById("check"),l=t.getElementById("scanLine"),c=t.getElementById("progress");!n||!r||!i||!o||!l||!c||!a||!s||(Cn(),n.classList.remove("fading","error","success","pill"),s.classList.remove("pop"),we=1,l.classList.add("active"),n.classList.add("visible"),o.style.display="",r.textContent="Analyzing page",i.textContent="",c.style.width="15%",lt=setTimeout(()=>{we<2&&(we=2,l.classList.remove("active"),r.textContent="Applying styles",i.textContent=e,c.style.width="45%")},300),setTimeout(()=>{we<3&&bt()},1500))}function bt(){const e=document.getElementById(Xe);if(!(e!=null&&e.shadowRoot))return;const t=e.shadowRoot.getElementById("card"),n=e.shadowRoot.getElementById("spinner"),r=e.shadowRoot.getElementById("progress");!t||!n||!r||(we=3,t.classList.add("pill"),n.style.display="none",r.style.width="70%")}function zt(e){const t=document.getElementById(Xe);if(!(t!=null&&t.shadowRoot))return;const n=t.shadowRoot.getElementById("subtitle");n&&(n.textContent=e)}function ie(){const e=document.getElementById(Xe);if(!(e!=null&&e.shadowRoot))return;const t=e.shadowRoot.getElementById("card"),n=e.shadowRoot.getElementById("scanLine");t&&(Cn(),we=0,n==null||n.classList.remove("active"),t.classList.add("fading"),setTimeout(()=>{t.classList.remove("visible","fading","pill")},250))}function V(e,t=""){const n=qr(),r=n.getElementById("card"),i=n.getElementById("title"),o=n.getElementById("subtitle"),a=n.getElementById("spinner"),s=n.getElementById("check"),l=n.getElementById("progress");if(!(!r||!i||!o||!a||!s||!l))if(Cn(),r.classList.remove("fading","pill"),r.classList.add("visible"),a.style.display="none",we=4,e==="cached")r.classList.remove("error"),r.classList.add("success"),s.classList.add("pop"),i.textContent="Polished",o.textContent=t||"From cache",l.style.width="100%",setTimeout(()=>ie(),1500);else if(e==="ai")r.classList.remove("error"),r.classList.add("success"),s.classList.add("pop"),i.textContent="Polished",o.textContent=t||"Personalized for you",l.style.width="100%",setTimeout(()=>ie(),1500);else{r.classList.remove("success"),r.classList.add("error"),i.textContent="Polish failed",o.innerHTML="";const c=document.createElement("div");c.textContent=t||"Your page was not modified",c.style.whiteSpace="normal";const d=document.createElement("div");d.textContent="Full log saved — open Webpaper › Activity",d.style.cssText="margin-top:5px;font-size:11px;opacity:0.75;",o.appendChild(c),o.appendChild(d),o.style.whiteSpace="normal",o.style.maxWidth="280px",l.style.width="0%";const f=()=>{r.removeEventListener("click",f),ie()};r.addEventListener("click",f),r.style.cursor="pointer",r.title="Click to dismiss (log stays in the popup)"}}function Cn(){lt&&(clearTimeout(lt),lt=null)}const ra=["chrome:","chrome-extension:","file:","about:","edge:"];function Qn(e){const t=document.createElement("template");t.innerHTML=e,t.content.querySelectorAll("script").forEach(r=>r.remove());const n=document.createTreeWalker(t.content,NodeFilter.SHOW_ELEMENT);for(let r=n.nextNode();r;r=n.nextNode()){const i=r;for(const o of Array.from(i.attributes))(/^on/i.test(o.name)||o.name==="href"&&o.value.trim().toLowerCase().startsWith("javascript:"))&&i.removeAttribute(o.name)}return t.innerHTML}let Zn=!1;function er(e){var f;const t=["background-color","color","border","border-radius","padding","font-family","font-size","font-weight","text-decoration","cursor","display","letter-spacing","text-transform","box-shadow","transition"],r=window.getComputedStyle(e).backgroundColor;if(!(r==="rgba(0, 0, 0, 0)"||r==="transparent"||r===""))return;const o=e.tagName.toLowerCase(),a=new Set(((f=e.className)==null?void 0:f.toString().split(/\s+/).filter(Boolean))??[]),s=Array.from(document.querySelectorAll(o)).filter(u=>u!==e&&!e.contains(u));if(s.length===0)return;const l=s.map(u=>{var g;const p=new Set(((g=u.className)==null?void 0:g.toString().split(/\s+/).filter(Boolean))??[]),m=[...a].filter(h=>p.has(h)).length;return{c:u,overlap:m}}).sort((u,p)=>p.overlap-u.overlap);if(l[0].overlap===0)return;const c=window.getComputedStyle(l[0].c),d=e;for(const u of t){const p=c.getPropertyValue(u).trim();p&&p!=="none"&&p!=="auto"&&!p.startsWith("rgba(0, 0, 0, 0)")&&d.style.setProperty(u,p)}}function jr(){if(document.getElementById("srf-img-shimmer-styles"))return;const e=document.createElement("style");e.id="srf-img-shimmer-styles",e.textContent=`
    @keyframes srf-img-shimmer { 0% { background-position: -400px 0; } 100% { background-position: 400px 0; } }
    .srf-gen-img-wrap { position: relative; display: block; overflow: hidden; }
    .srf-gen-img-wrap.loading {
      min-height: 180px; border-radius: 12px;
      background: linear-gradient(100deg, rgba(120,120,140,0.10) 30%, rgba(120,120,140,0.22) 50%, rgba(120,120,140,0.10) 70%);
      background-size: 800px 100%; animation: srf-img-shimmer 1.4s linear infinite;
    }
    .srf-gen-img-wrap.loading::after {
      content: 'Generating image…'; position: absolute; inset: 0;
      display: flex; align-items: center; justify-content: center;
      font: 500 12px -apple-system, sans-serif; color: rgba(120,120,140,0.9);
      letter-spacing: 0.02em;
    }
    .srf-gen-img-wrap img { display: block; width: 100%; height: auto; }
  `,(document.head||document.documentElement).appendChild(e)}function oa(e){try{const t=e?document.querySelector(e):null;if(t)return{el:t,fellBack:!1}}catch{}for(const t of["main","article",'[role="main"]',"#content",".content","#app","#root","body"]){const n=document.querySelector(t);if(n)return{el:n,fellBack:!0}}return{el:null,fellBack:!0}}function ia(e,t){var s;if(!((s=e.imagePrompt)!=null&&s.trim()))return{ok:!1,reason:"no imagePrompt"};const{el:n,fellBack:r}=oa(e.selector);if(!n)return{ok:!1,reason:"no insertion target found (not even body)"};const i=r?"beforeend":e.where??"beforeend";r&&q("info",`insert-image selector "${e.selector}" not found — placed in <${n.tagName.toLowerCase()}> instead`);const o=e.imagePrompt.trim();if(e.asBackground){const l=n;return t.push({prompt:o,setImage:c=>{l.style.setProperty("background-image",`url("${c}")`,"important"),l.style.setProperty("background-size","cover","important"),l.style.setProperty("background-position","center","important"),l.style.setProperty("background-repeat","no-repeat","important"),q("info",`Generated background applied to "${e.selector}"`)},fail:()=>q("info",`Background image generation failed for "${e.selector}"`)}),{ok:!0,anchor:n}}jr();const a=Hr(e.className,e.imageStyle);return n.insertAdjacentElement(i,a),t.push(Gr(a,o,e.alt??"",e.selector)),{ok:!0,anchor:a}}function Hr(e,t){const n=document.createElement("div");return n.className=["srf-gen-img-wrap","loading",e==null?void 0:e.trim()].filter(Boolean).join(" "),t&&n.setAttribute("style",t),n}function Gr(e,t,n,r){return{prompt:t,setImage:i=>{const o=document.createElement("img");o.src=i,o.alt=n,o.loading="lazy",e.classList.remove("loading"),e.appendChild(o),q("info",`Generated image inserted at "${r}"`)},fail:()=>{e.remove(),q("info",`Image generation failed/empty for "${r}"`)}}}function aa(e,t){if(t<=0)return[];const n=e.closest('main, article, [role="main"], #content, .content')??document.body,r=Array.from(n.querySelectorAll("section, article, main > div, .content > div, p")).filter(a=>{if(a.querySelector(".srf-gen-img-wrap")||a.closest(".srf-gen-img-wrap"))return!1;const s=a.getBoundingClientRect();return s.width>=240&&s.height>=120});r.sort((a,s)=>s.getBoundingClientRect().height-a.getBoundingClientRect().height);const i=Math.max(1,Math.floor(r.length/t)),o=[];for(let a=0;a<r.length&&o.length<t;a+=i)o.push(r[a]);return o}async function sa(e,t,n){if(e.length===0)return 0;const r=new Map;for(const o of e){const a=r.get(o.prompt)??[];a.push(o),r.set(o.prompt,a)}let i=0;return await Promise.allSettled([...r.entries()].map(async([o,a])=>{let s=[];try{const c=await chrome.runtime.sendMessage({type:"grok-generate-image",payload:{prompt:o,count:2,runId:n}});c!=null&&c.success&&Array.isArray(c.images)&&(s=c.images.filter(Boolean))}catch(c){q("info","Image generation errored",c instanceof Error?c.message:String(c))}if(s.length===0){a.forEach(c=>c.fail());return}a.forEach((c,d)=>{c.setImage(s[d%s.length]),i++});const l=s.length-a.length;l>0&&t&&t.prompt===o&&aa(t.anchor,l).forEach((d,f)=>{jr();const u=Hr();d.insertAdjacentElement("beforeend",u),Gr(u,o,t.alt,"auto-spread").setImage(s[a.length+f]),i++})})),i}async function Nn(e=!1){if(Zn&&!e||(Zn=!0,ra.includes(location.protocol))||!location.hostname)return;Mr(),await ca();const{srf_polish_always_on:t,srf_polish_prefs:n,srf_blocklist:r}=await chrome.storage.local.get(["srf_polish_always_on","srf_polish_prefs","srf_blocklist"]);if(t!==!0)return;if(Array.isArray(r)&&r.includes(location.hostname)){chrome.runtime.sendMessage({type:"telemetry-event",payload:{kind:"polish_blocked",hostname:location.hostname,ts:Date.now(),sessionId:ot()}});return}if(!e){const m=on(),g=await an();let h=null;try{h=await chrome.runtime.sendMessage({type:"polish-get-cache",payload:{pageKey:m,fingerprint:g}})}catch{}if(h!=null&&h.css){q("cache",`Cache HIT for ${m}`,`${h.css.length} chars of cached CSS`);const E=X(z.auto);E.textContent=oe(ht(h.css,he(location.hostname))),ne(),V("cached"),chrome.runtime.sendMessage({type:"telemetry-event",payload:{kind:"polish_cache_hit",hostname:location.hostname,ts:Date.now(),sessionId:ot()}}),Ge("kept");return}q("cache",`Cache MISS for ${m} — running personalized clean`),ue="webpaper-clean",St(),gt("Personalizing for you…"),setTimeout(()=>bt(),400),yt(85e3,"auto-clean on load");const y=rn({includeDOM:!0,cssMaxChars:12e3,domMaxChars:2e4});chrome.runtime.sendMessage({type:"polish-run-manual",payload:{url:location.href,dom:y,mode:"webpaper-clean",personalise:!1,pageKey:m,fingerprint:g}}).catch(()=>{ie(),Se()});return}const i=n??{},o=he(location.hostname),{result:a,tokens:s}=Hi(i.fonts,o);a==="applied"&&(ne(),chrome.runtime.sendMessage({type:"telemetry-event",payload:{kind:"polish_rules_applied",hostname:location.hostname,ts:Date.now(),sessionId:ot()}}));const l=tn(),c=nn(),d=`${l}

### FULL WEBPAGE DOM
\`\`\`html
${c}
\`\`\``,f=on(),u=await an();let p=null;try{p=await chrome.runtime.sendMessage({type:"polish-get-cache",payload:{pageKey:f,fingerprint:u}})}catch{return}if(p!=null&&p.css){q("cache",`Cache HIT for ${f}`,`${p.css.length} chars of cached CSS`);const m=X(z.auto);m.textContent=oe(ht(p.css,he(location.hostname))),ne(),V("cached"),chrome.runtime.sendMessage({type:"telemetry-event",payload:{kind:"polish_cache_hit",hostname:location.hostname,ts:Date.now(),sessionId:ot()}}),Ge("kept");return}q("cache",`Cache MISS for ${f} — requesting AI polish`),St(),gt("Streaming styles from Claude…"),yt(55e3,"no response from service worker within 55s"),chrome.runtime.sendMessage({type:"polish-auto-polish",payload:{hostname:location.hostname,url:location.href,dom:d,pageKey:f,fingerprint:u}})}let ct=null;function yt(e,t){Se(),ct=setTimeout(()=>{q("info",`Overlay watchdog fired: ${t}`),ie(),V("error","Polish timed out — no response")},e)}function Se(){ct!==null&&(clearTimeout(ct),ct=null)}let tt=!1,nt=!1,ue="optimise";function la(){chrome.runtime.onMessage.addListener((e,t,n)=>{var r,i,o,a,s,l,c,d,f,u,p,m,g,h,y,E,C,T,B,w,A,O,N,L,v,I,$,P;if(!((i=(r=e==null?void 0:e.type)==null?void 0:r.startsWith)!=null&&i.call(r,"polish-"))&&!((a=(o=e==null?void 0:e.type)==null?void 0:o.startsWith)!=null&&a.call(o,"webpaper-")))return!1;if(e.type==="polish-devlog-entry"){const x=((s=e.payload)==null?void 0:s.stage)??"info",b=((l=e.payload)==null?void 0:l.message)??"";return q(x,b,(c=e.payload)==null?void 0:c.detail),x==="ai-request"&&(b.includes("Pass 1")?zt("Analyzing page…"):b.includes("Pass 2")?zt("Generating styles…"):b.includes("Variations")&&zt(`Generating ${((u=(f=(d=e.payload)==null?void 0:d.detail)==null?void 0:f.match(/(\d+)x/))==null?void 0:u[1])??"N"} in parallel…`)),!1}if(e.type==="polish-stream-start"){const x=((p=e.payload)==null?void 0:p.layer)==="manual"?z.manual:z.auto;return X(x).textContent="",x===z.auto?tt=!1:nt=!1,!1}if(e.type==="polish-auto-polish-css"){const x=X(z.auto);return x.textContent=(x.textContent??"")+(((m=e.payload)==null?void 0:m.chunk)??""),!tt&&(x.textContent??"").includes("}")&&(tt=!0,bt()),!1}if(e.type==="polish-css-chunk"){const x=X(z.manual);return x.textContent=(x.textContent??"")+(((g=e.payload)==null?void 0:g.chunk)??""),!nt&&(x.textContent??"").includes("}")&&(nt=!0,bt()),!1}if(e.type==="polish-auto-polish-done"){Se();const x=X(z.auto),b=(x.textContent??"").length,S=ht(x.textContent??"",he(location.hostname));x.textContent=oe(S);const F=(x.textContent??"").length;return q("ai-done",`Auto-polish complete: ${b} chars raw → ${F} chars after validator`,b!==F?`Validator stripped ${b-F} chars`:"Validator: nothing stripped"),tt=!1,ie(),ne(),V("ai"),Ge("kept"),!1}if(e.type==="polish-done"){Se();const x=X(z.manual),b=x.textContent??"",S=b.length;q("info",`polish-done fired. Manual layer has ${S} chars before sanitize.`),b.trim()&&(x.textContent=oe(b)),q("ai-done",`Manual polish (${ue}) complete: ${S} chars → ${((h=x.textContent)==null?void 0:h.length)??0} after boost`),q("info","Generated CSS",b.substring(0,500)+(S>500?"…":"")),nt=!1,ie(),ne();const F=((E=(y=document.getElementById(z.manual))==null?void 0:y.textContent)==null?void 0:E.length)??0;return q("info",`After takeSnapshot: manual layer has ${F} chars`),V("ai"),Ge("kept"),ue!=="redesign"&&ue!=="minimise"&&ue!=="prompt"&&da(),ue==="minimise"&&b.trim()&&chrome.runtime.sendMessage({type:"webpaper-clean-done",payload:{css:b,url:location.href,title:document.title}}).catch(()=>{}),!1}if(e.type==="polish-error")return Se(),ie(),V("error",((C=e.payload)==null?void 0:C.error)??""),!1;if(e.type==="polish-run-variations"){const x=Math.min(Math.max(((T=e.payload)==null?void 0:T.count)??3,2),5),b=((B=e.payload)==null?void 0:B.mode)??"redesign";ue=b,St(),gt(`Generating ${x} variations…`),yt(12e4,`variations (${b} x${x}) timeout`);const S=tn(),F=nn(),M=`${S}

### FULL WEBPAGE DOM
\`\`\`html
${F}
\`\`\``;return chrome.runtime.sendMessage({type:"polish-run-variations-bg",payload:{url:location.href,dom:M,mode:b,count:x,personalise:((w=e.payload)==null?void 0:w.personalise)??!1,fixDescription:(A=e.payload)==null?void 0:A.fixDescription}}),n({success:!0}),!1}if(e.type==="polish-variation-ready"){const x=X(z.manual),b=((O=e.payload)==null?void 0:O.css)??"";return x.textContent=b?oe(b):"",ne(),q("info",`Variation ${((N=e.payload)==null?void 0:N.index)??"?"}/${((L=e.payload)==null?void 0:L.total)??"?"} applied`,`${(((v=e.payload)==null?void 0:v.css)??"").length} chars`),!1}if(e.type==="polish-variations-done")return Se(),ie(),V("ai",`${((I=e.payload)==null?void 0:I.count)??"?"} variations ready — use Undo/Redo to flip through them`),Ge("kept"),!1;if(e.type==="agent-query-dom"){const x=String((($=e.payload)==null?void 0:$.selector)??"");try{const b=x?Array.from(document.querySelectorAll(x)):[],S=b.slice(0,3).map(F=>{const M=F.outerHTML??"";return M.length>400?M.slice(0,400)+"…":M});n({count:b.length,samples:S})}catch{n({count:0,samples:[],invalid:!0})}return!1}if(e.type==="agent-read-page"){try{const x=rn({includeDOM:!0,cssMaxChars:8e3,domMaxChars:16e3});n({context:x})}catch(x){n({context:"",error:String(x)})}return!1}if(e.type==="polish-start-manual"){const x=((P=e.payload)==null?void 0:P.mode)??"optimise";q("info",`polish-start-manual received: mode=${x}`),ue=x,St(),gt(`${x[0].toUpperCase()+x.slice(1)}ing page…`),yt(85e3,`manual polish (${x}) timeout`);const b=tn(),S=nn();let F;return x==="prompt"||x==="webpaper-clean"?F=rn({includeDOM:!0,cssMaxChars:12e3,domMaxChars:2e4}):F=`${b}

### FULL WEBPAGE DOM
\`\`\`html
${S}
\`\`\``,q("info",`DOM prepared: ${F.length} chars`),(async()=>{var k,D,W;let M,R;if(x==="webpaper-clean")try{M=on(),R=await an()}catch{}chrome.runtime.sendMessage({type:"polish-run-manual",payload:{url:location.href,dom:F,mode:x,personalise:((k=e.payload)==null?void 0:k.personalise)??!1,fixDescription:(D=e.payload)==null?void 0:D.fixDescription,model:(W=e.payload)==null?void 0:W.model,pageKey:M,fingerprint:R}}).catch(()=>{})})(),n({success:!0}),!1}if(e.type==="webpaper-apply"){Se();const{css:x,mutations:b}=e.payload;if(x!=null&&x.trim()){const k=X(z.manual),D=ht(x,he(location.hostname));k.textContent=oe((k.textContent??"")+`
`+D)}const S=[],F=[];let M=0,R=null;if(Array.isArray(b)&&b.length>0)for(const k of b)try{if(k.op==="insert-image"){M++;const W=F.length,_=ia(k,F);S.push({op:k.op,selector:k.selector,ok:_.ok,reason:_.reason}),_.ok&&_.anchor&&!k.asBackground&&F.length>W&&(R={anchor:_.anchor,prompt:(k.imagePrompt??"").trim(),alt:k.alt??""});continue}const D=document.querySelector(k.selector);if(!D){S.push({op:k.op,selector:k.selector,ok:!1,reason:"selector matched nothing"});continue}if(k.op==="insert"&&k.html){D.insertAdjacentHTML(k.where??"beforeend",Qn(k.html));const W=k.where??"beforeend",_=D.children,te=W==="afterbegin"?_[0]:W==="beforeend"?_[_.length-1]:null;te&&er(te),S.push({op:k.op,selector:k.selector,ok:!0})}else k.op==="text"&&k.content!==void 0?(D.textContent=k.content,S.push({op:k.op,selector:k.selector,ok:!0})):k.op==="remove"?(D.remove(),S.push({op:k.op,selector:k.selector,ok:!0})):k.op==="attr"&&k.attr&&(D.setAttribute(k.attr,k.value??""),S.push({op:k.op,selector:k.selector,ok:!0}))}catch(D){S.push({op:k.op,selector:k.selector,ok:!1,reason:String(D)})}if(ne(),ie(),F.length>0){const k=M===1?R:null;V("ai","Generating images…"),sa(F,k).then(D=>{ne(),D>0&&V("ai",`${D} image${D===1?"":"s"} added`)})}else V("ai");return chrome.runtime.sendMessage({type:"webpaper-mutation-results",payload:{mutations:S,cssApplied:!!(x!=null&&x.trim())}}).catch(()=>{}),n({ok:!0}),!1}if(e.type==="polish-apply-mutations"){const{css:x,mutations:b}=e.payload;if(x!=null&&x.trim()){const S=X(z.manual);S.textContent=oe(x)}if(Array.isArray(b))for(const S of b)try{const F=document.querySelector(S.selector);if(!F)continue;if(S.op==="insert"&&S.html){const M=F.childElementCount;F.insertAdjacentHTML(S.where??"beforeend",Qn(S.html));const R=F.children,k=S.where??"beforeend",D=k==="afterbegin"?R[0]??null:k==="beforeend"?R[R.length-1]??null:null;D&&D.className&&F.childElementCount>M&&er(D)}else S.op==="text"&&S.content!==void 0?F.textContent=S.content:S.op==="remove"?F.remove():S.op==="attr"&&S.attr&&F.setAttribute(S.attr,S.value??"")}catch{}return ne(),n({ok:!0}),!1}if(e.type==="polish-remove-now")return sn(),n({ok:!0}),!1;if(e.type==="polish-apply-now")return Nn(!0),n({ok:!0}),!1;if(e.type==="polish-history-back"){const x=zr(),b=qe();return b.position===1&&chrome.runtime.sendMessage({type:"polish-log-taste",payload:{hostname:location.hostname,action:"undone"}}),n({ok:x,...b}),!1}if(e.type==="polish-history-forward"){const x=na();return n({ok:x,...qe()}),!1}if(e.type==="polish-get-history-state")return n(qe()),!1;if(e.type==="polish-get-page-status")return n({status:Xn(),...qe()}),!1;if(e.type==="polish-analyze-page")return n(Gi()),!1;if(e.type==="polish-reset")return q("reset","User reset to original"),sn(),n({ok:!0,...qe(),status:Xn()}),!1;if(e.type==="polish-get-devlog")return n({log:Pi()}),!1;if(e.type==="polish-capture-snapshot")return(async()=>{try{const{captureSnapshot:x}=await Lr(async()=>{const{captureSnapshot:S}=await import("./snapshot-capture-Cjq9wqKF.js");return{captureSnapshot:S}},__vite__mapDeps([0,1,2,3,4])),b=x();n({success:!0,snapshot:b})}catch(x){n({success:!1,error:x instanceof Error?x.message:String(x)})}})(),!0;if(e.type==="polish-get-share-css"){const x=document.getElementById(z.manual),b=document.getElementById(z.auto),S=(x==null?void 0:x.textContent)??"",F=(b==null?void 0:b.textContent)??"",M=S.trim()||F.trim()||"";return n({css:M}),!1}return e.type==="polish-clear-devlog"&&(Ri(),n({ok:!0})),!1})}async function ca(){if(location.hash.includes("srf-polish="))try{const{readShareFromHash:e}=await Lr(async()=>{const{readShareFromHash:r}=await import("./share-encoder-Bm__IQjr.js");return{readShareFromHash:r}},[]),t=await e(location.hash);if(!(t!=null&&t.css))return;q("info",`Shared polish detected in URL${t.mode?` (${t.mode})`:""}`,`${t.css.length} chars`);const n=X(z.manual);n.textContent=oe(t.css),ne(),V("ai","Shared polish applied");try{const r=location.href.split("#")[0];history.replaceState(null,"",r)}catch{}}catch(e){q("info","Shared polish decode failed",e instanceof Error?e.message:String(e))}}let rt=null;function ot(){return rt||(rt=crypto.randomUUID(),rt)}function Ge(e){setTimeout(()=>{var n;const t=document.getElementById(z.auto);t&&(((n=t.textContent)==null?void 0:n.length)??0)>0&&chrome.runtime.sendMessage({type:"polish-log-taste",payload:{hostname:location.hostname,action:e}})},3e4)}let dt=0;function St(){dt=document.body.scrollHeight}function da(){setTimeout(()=>{let e=0;const t=[document.querySelector("h1"),document.querySelector("p"),document.querySelector("button"),document.querySelector("a"),document.querySelector("main")??document.querySelector("article")].filter(Boolean);for(const o of t){const a=getComputedStyle(o),s=o.getBoundingClientRect();(a.visibility==="hidden"||a.opacity==="0"||a.display==="none"||s.left<-1e3||s.top<-1e3)&&e++}if(e>=2){qt("Content hidden — polish reverted");return}const n=getComputedStyle(document.body),r=n.color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/),i=n.backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);if(r&&i){const o=.2126*(+r[1]/255)+.7152*(+r[2]/255)+.0722*(+r[3]/255),a=.2126*(+i[1]/255)+.7152*(+i[2]/255)+.0722*(+i[3]/255),s=Math.max(o,a)+.05,l=Math.min(o,a)+.05;if(s/l<2){qt("Low contrast — polish reverted");return}}if(dt>0){const o=document.body.scrollHeight;if(Math.abs(o-dt)/dt>1.5){qt("Layout broken — polish reverted");return}}},2e3)}function qt(e){q("rollback",`Auto-rollback triggered: ${e}`),zr(),V("error",e),chrome.runtime.sendMessage({type:"polish-log-taste",payload:{hostname:location.hostname,action:"undone"}})}let Y=null,G=null,fe=null,pe=null,jt=null;const ua=`
  #srf-grok-x-toggle {
    position: fixed;
    right: 24px;
    bottom: 24px;
    width: 56px;
    height: 56px;
    border-radius: 50%;
    background-color: #000000;
    color: #ffffff;
    border: 1px solid #2f3336;
    cursor: pointer;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: transform 0.2s ease, background-color 0.2s ease;
    z-index: 2147483645;
  }
  #srf-grok-x-toggle:hover {
    transform: scale(1.08);
    background-color: #15181c;
  }
  #srf-grok-x-toggle svg {
    width: 22px;
    height: 22px;
    fill: currentColor;
  }

  #srf-grok-x-drawer {
    position: fixed;
    top: 0;
    right: -420px;
    width: 400px;
    height: 100vh;
    background-color: #000000;
    color: #e7e9ea;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    box-shadow: -4px 0 24px rgba(0, 0, 0, 0.5);
    transition: right 0.35s cubic-bezier(0.16, 1, 0.3, 1);
    z-index: 2147483646;
    display: flex;
    flex-direction: column;
    border-left: 1px solid #2f3336;
    box-sizing: border-box;
    text-align: left;
  }
  #srf-grok-x-drawer.open {
    right: 0;
  }

  .grok-x-header {
    padding: 16px;
    border-bottom: 1px solid #2f3336;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .grok-x-title-area {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .grok-x-title {
    font-size: 20px;
    font-weight: 800;
    margin: 0;
    letter-spacing: -0.4px;
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .grok-x-brain-badge {
    font-size: 10px;
    background: linear-gradient(135deg, #1d9bf0, #8ecdf8);
    color: #ffffff;
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: bold;
    text-transform: uppercase;
  }
  .grok-x-close-btn {
    background: none;
    border: none;
    color: #71767b;
    cursor: pointer;
    padding: 8px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.2s, color 0.2s;
  }
  .grok-x-close-btn:hover {
    background-color: rgba(239, 243, 244, 0.1);
    color: #e7e9ea;
  }

  .grok-x-content {
    flex: 1;
    overflow-y: auto;
    padding: 12px 16px;
    display: flex;
    flex-direction: column;
    gap: 16px;
  }

  .grok-x-tweet-card {
    border-bottom: 1px solid #2f3336;
    padding-bottom: 16px;
    display: flex;
    gap: 12px;
  }
  .grok-x-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background-color: #1d9bf0;
    color: #ffffff;
    font-weight: bold;
    font-size: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    user-select: none;
  }
  .grok-x-tweet-body {
    flex: 1;
  }
  .grok-x-tweet-header {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 4px;
    margin-bottom: 4px;
  }
  .grok-x-author-name {
    font-weight: 700;
    color: #e7e9ea;
    font-size: 15px;
  }
  .grok-x-author-name:hover {
    text-decoration: underline;
    cursor: pointer;
  }
  .grok-x-verified-icon {
    width: 14px;
    height: 14px;
    fill: #1d9bf0;
    display: inline-block;
  }
  .grok-x-author-handle {
    color: #71767b;
    font-size: 14px;
  }
  .grok-x-dot {
    color: #71767b;
    font-size: 12px;
  }
  .grok-x-timestamp {
    color: #71767b;
    font-size: 14px;
  }
  .grok-x-tweet-text {
    font-size: 15px;
    line-height: 20px;
    color: #e7e9ea;
    white-space: pre-wrap;
    word-break: break-word;
    margin-bottom: 12px;
  }

  .grok-x-actions {
    display: flex;
    justify-content: space-between;
    max-width: 320px;
    color: #71767b;
    font-size: 13px;
  }
  .grok-x-action {
    display: flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;
    transition: color 0.15s ease;
    background: none;
    border: none;
    padding: 4px;
    color: #71767b;
  }
  .grok-x-action svg {
    width: 16px;
    height: 16px;
    fill: currentColor;
  }
  .grok-x-action:hover.reply { color: #1d9bf0; }
  .grok-x-action:hover.retweet { color: #00ba7c; }
  .grok-x-action:hover.like { color: #f91880; }
  .grok-x-action:hover.views { color: #1d9bf0; }
  .grok-x-action.active.like { color: #f91880; font-weight: bold; }
  .grok-x-action.active.retweet { color: #00ba7c; font-weight: bold; }

  .grok-x-cn-card {
    border: 1px solid #2f3336;
    border-radius: 12px;
    padding: 16px;
    background-color: #15181c;
  }
  .grok-x-cn-header {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
    font-weight: 700;
    color: #e7e9ea;
    margin-bottom: 8px;
  }
  .grok-x-cn-header svg {
    width: 16px;
    height: 16px;
    fill: #e7e9ea;
  }
  .grok-x-cn-text {
    font-size: 13px;
    line-height: 18px;
    color: #e7e9ea;
    margin-bottom: 12px;
  }
  .grok-x-cn-sources-title {
    font-size: 11px;
    font-weight: 700;
    color: #71767b;
    margin-bottom: 4px;
    text-transform: uppercase;
  }
  .grok-x-cn-source {
    font-size: 11px;
    color: #1d9bf0;
    text-decoration: none;
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    margin-bottom: 2px;
  }
  .grok-x-cn-source:hover {
    text-decoration: underline;
  }

  .grok-x-footer {
    padding: 16px;
    border-top: 1px solid #2f3336;
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .grok-x-inject-btn {
    width: 100%;
    padding: 12px;
    border-radius: 9999px;
    background-color: #e7e9ea;
    color: #0f1419;
    font-weight: 700;
    font-size: 15px;
    border: none;
    cursor: pointer;
    transition: background-color 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
  }
  .grok-x-inject-btn:hover {
    background-color: #d7dbdc;
  }
  .grok-x-inject-btn:active {
    transform: scale(0.98);
  }

  /* Inline embedded styles */
  .srf-grok-x-inline-wrapper {
    margin: 24px 0;
    padding: 20px;
    border: 1px solid #2f3336;
    border-radius: 16px;
    background-color: #000000;
    color: #e7e9ea;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    max-width: 100%;
    box-sizing: border-box;
    animation: grokFadeIn 0.3s ease;
  }
  @keyframes grokFadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .srf-grok-x-inline-wrapper .grok-x-tweet-card:last-child {
    border-bottom: none;
    padding-bottom: 0;
  }

  /* Light Theme Syncing */
  body.srf-light-theme #srf-grok-x-toggle {
    background-color: #ffffff;
    color: #0f1419;
    border-color: #eff3f4;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
  }
  body.srf-light-theme #srf-grok-x-toggle:hover {
    background-color: #f7f9f9;
  }
  body.srf-light-theme #srf-grok-x-drawer {
    background-color: #ffffff;
    color: #0f1419;
    border-left-color: #eff3f4;
    box-shadow: -4px 0 24px rgba(0, 0, 0, 0.08);
  }
  body.srf-light-theme .grok-x-header {
    border-bottom-color: #eff3f4;
  }
  body.srf-light-theme .grok-x-close-btn {
    color: #536471;
  }
  body.srf-light-theme .grok-x-close-btn:hover {
    background-color: rgba(15, 20, 25, 0.1);
    color: #0f1419;
  }
  body.srf-light-theme .grok-x-tweet-card {
    border-bottom-color: #eff3f4;
  }
  body.srf-light-theme .grok-x-author-name {
    color: #0f1419;
  }
  body.srf-light-theme .grok-x-author-handle,
  body.srf-light-theme .grok-x-dot,
  body.srf-light-theme .grok-x-timestamp {
    color: #536471;
  }
  body.srf-light-theme .grok-x-tweet-text {
    color: #0f1419;
  }
  body.srf-light-theme .grok-x-actions {
    color: #536471;
  }
  body.srf-light-theme .grok-x-action {
    color: #536471;
  }
  body.srf-light-theme .grok-x-cn-card {
    border-color: #eff3f4;
    background-color: #f7f9f9;
  }
  body.srf-light-theme .grok-x-cn-header {
    color: #0f1419;
  }
  body.srf-light-theme .grok-x-cn-header svg {
    fill: #0f1419;
  }
  body.srf-light-theme .grok-x-cn-text {
    color: #0f1419;
  }
  body.srf-light-theme .grok-x-cn-sources-title {
    color: #536471;
  }
  body.srf-light-theme .grok-x-footer {
    border-top-color: #eff3f4;
  }
  body.srf-light-theme .grok-x-inject-btn {
    background-color: #0f1419;
    color: #ffffff;
  }
  body.srf-light-theme .grok-x-inject-btn:hover {
    background-color: #272c30;
  }
  body.srf-light-theme .srf-grok-x-inline-wrapper {
    background-color: #ffffff;
    color: #0f1419;
    border-color: #eff3f4;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
  }
`,fa='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path></svg>',pa='<svg class="grok-x-verified-icon" viewBox="0 0 24 24"><path d="M22.5 12.5c0-1.58-.875-2.95-2.148-3.6.154-.435.238-.905.238-1.4 0-2.21-1.71-3.99-3.818-3.99-.48 0-.941.1-1.358.275C14.77 2.57 13.5 1.75 12 1.75s-2.77.82-3.412 2.035c-.417-.175-.878-.275-1.358-.275-2.108 0-3.818 1.78-3.818 3.99 0 .495.084.965.238 1.4-1.273.65-2.148 2.02-2.148 3.6 0 1.58.875 2.95 2.148 3.6-.154.435-.238.905-.238 1.4 0 2.21 1.71 3.99 3.818 3.99.48 0 .941-.1 1.358-.275C9.23 21.43 10.5 22.25 12 22.25s2.77-.82 3.412-2.035c.417.175.878.275 1.358.275 2.108 0 3.818-1.78 3.818-3.99 0-.495-.084-.965-.238-1.4 1.273-.65 2.148-2.02 2.148-3.6zm-12.72 4.18l-3.32-3.56 1.43-1.42 1.83 1.96 4.79-5.12 1.43 1.41-6.16 6.73z"></path></svg>',xa='<svg viewBox="0 0 24 24"><path d="M19 4H5c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-1 12H6v-2h12v2zm0-4H6V8h12v4z"></path></svg>',ha='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"></path></svg>',ma='<svg viewBox="0 0 24 24"><path d="M1.751 10c0-4.42 3.584-8 8.005-8h4.366c4.49 0 8.129 3.64 8.129 8.13 0 2.96-1.57 5.57-3.93 7.02v2.74c0 .83-.98 1.28-1.63.77l-3.47-2.7c-.43.08-.88.13-1.34.13h-2.12c-4.42 0-8.005-3.58-8.005-8.02zm8.005-6c-3.317 0-6.005 2.69-6.005 6 0 3.32 2.688 6 6.005 6h2.12c.51 0 1.01-.06 1.5-.18l.26-.06 2.36 1.83v-1.72l.14-.1c2.1-1.32 3.36-3.64 3.36-6.1 0-3.38-2.75-6.13-6.13-6.13H9.756z"></path></svg>',ga='<svg viewBox="0 0 24 24"><path d="M4.5 3.88l4.432 4.14-1.364 1.46L5.5 7.55V16c0 1.1.898 2 2 2h7.5v2H7.5c-2.209 0-4-1.79-4-4V7.55L1.432 9.48.068 8.02 4.5 3.88zM16.5 6H9V4h7.5c2.209 0 4 1.79 4 4v8.45l2.068-1.93 1.364 1.46-4.432 4.14-4.432-4.14 1.364-1.46 2.068 1.93V8c0-1.1-.898-2-2-2z"></path></svg>',ba='<svg viewBox="0 0 24 24"><path d="M16.697 5.5c-1.222-.06-2.679.69-3.89 2.26L12 8.782l-.807-1.02c-1.211-1.57-2.668-2.32-3.89-2.26-2.73.13-4.502 2.47-4.502 5.6 0 4.17 4.103 8.33 8.78 11.42l.419.28.419-.28c4.677-3.09 8.78-7.25 8.78-11.42 0-3.13-1.772-5.47-4.502-5.6zM12 20.46c-4.062-2.7-7.502-6.38-7.502-9.36 0-2.3 1.173-3.6 2.702-3.68.805-.04 1.836.48 2.766 1.83l2.034 2.58 2.034-2.58c.93-1.35 1.961-1.87 2.766-1.83 1.529.08 2.702 1.38 2.702 3.68 0 2.98-3.44 6.66-7.502 9.36z"></path></svg>',ya='<svg viewBox="0 0 24 24"><path d="M8.75 21V3h2v18h-2zM18 21V9h2v12h-2zM4 21v-6h2v6H4zm9.375 0v-9h2v9h-2z"></path></svg>';async function Ur(){var e;try{const{srf_enabled:t,srf_active_brain:n}=await chrome.storage.local.get(["srf_enabled","srf_active_brain"]);if(t===!1||n!=="grok"){Kr(),tr();return}if(tr(),Y&&G)return;const r=await chrome.runtime.sendMessage({type:"srf-fetch-x-content",payload:{url:location.href,title:document.title,description:((e=document.querySelector('meta[name="description"]'))==null?void 0:e.getAttribute("content"))||""}});if(!r||!r.success||!r.content){console.warn("[Grok X] Failed to generate related X content.");return}pe=r.content;const o=getComputedStyle(document.body).backgroundColor;Ca(o)?document.body.classList.remove("srf-light-theme"):document.body.classList.add("srf-light-theme"),fe||(fe=document.createElement("style"),fe.id="srf-grok-x-styles",fe.textContent=ua,document.head.appendChild(fe)),Sa(),wa()}catch(t){console.error("[Grok X] Failed to bootstrap:",t)}}function Kr(){G&&(G.remove(),G=null),Y&&(Y.remove(),Y=null),fe&&(fe.remove(),fe=null),document.querySelectorAll(".srf-grok-x-inline-wrapper").forEach(e=>e.remove()),pe=null}function tr(){jt||(jt=e=>{("srf_enabled"in e||"srf_active_brain"in e)&&Ur()},chrome.storage.onChanged.addListener(jt))}function Sa(){document.getElementById("srf-grok-x-toggle")||(G=document.createElement("button"),G.id="srf-grok-x-toggle",G.title="Grok X-Feed",G.innerHTML=fa,G.addEventListener("click",e=>{e.stopPropagation(),wt()}),document.body.appendChild(G))}function wa(){if(document.getElementById("srf-grok-x-drawer"))return;Y=document.createElement("div"),Y.id="srf-grok-x-drawer";const e=`
    <div class="grok-x-header">
      <div class="grok-x-title-area">
        <h2 class="grok-x-title">X Feed <span class="grok-x-brain-badge">Grok</span></h2>
      </div>
      <button class="grok-x-close-btn" id="srf-grok-close-drawer" title="Close">
        ${ha}
      </button>
    </div>
  `;let t="";if(pe){if(pe.communityNote){const r=pe.communityNote,i=r.sources.map(o=>`<a class="grok-x-cn-source" href="${o.split(" ")[0]}" target="_blank" rel="noopener">${o}</a>`).join("");t+=`
        <div class="grok-x-cn-card">
          <div class="grok-x-cn-header">
            ${xa}
            <span>Readers added context</span>
          </div>
          <div class="grok-x-cn-text">${r.content}</div>
          <div class="grok-x-cn-sources-title">Sources</div>
          ${i}
        </div>
      `}t+=pe.tweets.map(r=>Yr(r)).join("")}const n=`
    <div class="grok-x-footer">
      <button class="grok-x-inject-btn" id="srf-grok-inject-inline">
        <span>Inject Into Site Layout</span>
      </button>
    </div>
  `;Y.innerHTML=`
    ${e}
    <div class="grok-x-content">
      ${t}
    </div>
    ${n}
  `,Fa(Y),document.body.appendChild(Y)}function Yr(e){const t=e.verified?pa:"";return`
    <div class="grok-x-tweet-card" data-tweet-id="${e.id}">
      <div class="grok-x-avatar">${e.authorAvatar}</div>
      <div class="grok-x-tweet-body">
        <div class="grok-x-tweet-header">
          <span class="grok-x-author-name">${e.authorName}</span>
          ${t}
          <span class="grok-x-author-handle">@${e.authorHandle}</span>
          <span class="grok-x-dot">·</span>
          <span class="grok-x-timestamp">${e.timestamp}</span>
        </div>
        <div class="grok-x-tweet-text">${e.content}</div>
        <div class="grok-x-actions">
          <button class="grok-x-action reply" title="Reply">
            ${ma}
            <span>${e.replies}</span>
          </button>
          <button class="grok-x-action retweet" title="Repost">
            ${ga}
            <span>${e.retweets}</span>
          </button>
          <button class="grok-x-action like" title="Like">
            ${ba}
            <span>${e.likes}</span>
          </button>
          <button class="grok-x-action views" title="Views">
            ${ya}
            <span>${e.views}</span>
          </button>
        </div>
      </div>
    </div>
  `}function Fa(e){var t,n;(t=e.querySelector("#srf-grok-close-drawer"))==null||t.addEventListener("click",()=>{wt(!1)}),e.querySelectorAll(".grok-x-tweet-card").forEach(r=>{const i=r.querySelector(".grok-x-action.like");i==null||i.addEventListener("click",()=>{const a=i.querySelector("span");if(a){const s=i.classList.contains("active");let l=parseInt(a.textContent||"0");s?(i.classList.remove("active"),l--):(i.classList.add("active"),l++),a.textContent=l.toString()}});const o=r.querySelector(".grok-x-action.retweet");o==null||o.addEventListener("click",()=>{const a=o.querySelector("span");if(a){const s=o.classList.contains("active");let l=parseInt(a.textContent||"0");s?(o.classList.remove("active"),l--):(o.classList.add("active"),l++),a.textContent=l.toString()}})}),(n=e.querySelector("#srf-grok-inject-inline"))==null||n.addEventListener("click",()=>{Ea()})}function wt(e){if(!Y)return;const t=Y.classList.contains("open");(e!==void 0?e:!t)?(Y.classList.add("open"),G&&(G.style.transform="scale(0) rotate(90deg)",G.style.opacity="0")):(Y.classList.remove("open"),G&&(G.style.transform="scale(1) rotate(0deg)",G.style.opacity="1"))}function Ea(){if(!pe)return;const t=[document.querySelector("main p:nth-of-type(3)"),document.querySelector("article p:nth-of-type(3)"),document.querySelector("p:nth-of-type(4)"),document.querySelector("#mw-content-text p:nth-of-type(3)"),document.querySelector(".wiki p:nth-of-type(2)"),document.querySelector("main p:nth-of-type(1)"),document.querySelector("body p:nth-of-type(3)")].filter(Boolean)[0];if(!t){console.warn("[Grok X] Could not find a suitable layout element to inject tweets inline.");return}const n=t.nextElementSibling;if(n&&n.classList.contains("srf-grok-x-inline-wrapper")){wt(!1);return}const r=document.createElement("div");r.className="srf-grok-x-inline-wrapper";const i=pe.tweets.slice(0,2).map(o=>Yr(o)).join("");r.innerHTML=`
    <div style="font-size: 13px; font-weight: 700; color: #71767b; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between;">
      <span>PROMOTED CONTEXT BY GROK</span>
      <span style="font-size: 10px; background: rgba(29, 155, 240, 0.15); color: #1d9bf0; padding: 2px 6px; border-radius: 4px;">TWITTER / X</span>
    </div>
    ${i}
  `,ka(r),t.insertAdjacentElement("afterend",r),wt(!1)}function ka(e){e.querySelectorAll(".grok-x-tweet-card").forEach(t=>{const n=t.querySelector(".grok-x-action.like");n==null||n.addEventListener("click",()=>{const i=n.querySelector("span");if(i){const o=n.classList.contains("active");let a=parseInt(i.textContent||"0");o?(n.classList.remove("active"),a--):(n.classList.add("active"),a++),i.textContent=a.toString()}});const r=t.querySelector(".grok-x-action.retweet");r==null||r.addEventListener("click",()=>{const i=r.querySelector("span");if(i){const o=r.classList.contains("active");let a=parseInt(i.textContent||"0");o?(r.classList.remove("active"),a--):(r.classList.add("active"),a++),i.textContent=a.toString()}})})}function Ca(e){const t=e.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);return t?.299*Number(t[1])+.587*Number(t[2])+.114*Number(t[3])<128:!1}const Vr="surface-onboarding-guide";let je=null;async function Na(){var i;const e=await chrome.runtime.sendMessage({type:"onboarding-get-state"}),t=e==null?void 0:e.payload;if(!t||t.completed||!t.startedAt)return;const n=location.hostname.replace(/^www\./,""),r=Ho.find(o=>n===o.domain||n.endsWith(`.${o.domain}`));r&&((i=t.visitedSites)!=null&&i.includes(r.domain)&&document.getElementById(Vr)||(Aa(r),await chrome.runtime.sendMessage({type:"onboarding-mark-visited",payload:{domain:r.domain}})))}function Aa(e){je&&(je.remove(),je=null);const t=document.createElement("div");t.id=Vr;const n=t.attachShadow({mode:"closed"}),r={"profile-injection":"Profile Injection","widget-detection":"Widget Detection","category-filtering":"Category Filtering","calendar-aware":"Calendar Aware","dev-context":"Developer Context",education:"Education Mode","design-taste":"Design Taste"};n.innerHTML=`
    <style>
      :host {
        all: initial;
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
      }

      .guide {
        position: fixed;
        bottom: 24px;
        right: 24px;
        width: 360px;
        background: #FFFFFF;
        border: 1px solid #9E9E9E;
        border-radius: 16px;
        padding: 0;
        z-index: 2147483647;
        animation: slideUp 0.35s cubic-bezier(0.25, 0.1, 0.25, 1) both;
        overflow: hidden;
      }

      @keyframes slideUp {
        from { opacity: 0; transform: translateY(16px); }
        to   { opacity: 1; transform: translateY(0); }
      }

      @keyframes fadeOut {
        from { opacity: 1; transform: translateY(0); }
        to   { opacity: 0; transform: translateY(8px); }
      }

      .guide.dismissing {
        animation: fadeOut 0.2s ease forwards;
      }

      /* Header gradient bar */
      .guide-header {
        background: linear-gradient(135deg,
          rgba(255, 130, 80, 0.12) 0%,
          rgba(140, 80, 240, 0.10) 50%,
          rgba(60, 140, 255, 0.08) 100%);
        padding: 16px 20px 12px;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
      }

      .guide-header-left {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }

      .guide-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 10px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #6B6B70;
        padding: 3px 8px;
        border-radius: 4px;
        border: 1px solid #E5E5EA;
        background: rgba(255, 255, 255, 0.7);
        width: fit-content;
      }

      .guide-badge-dot {
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background: #34C759;
      }

      .guide-site-name {
        font-size: 18px;
        font-weight: 500;
        color: #000;
        line-height: 1.2;
      }

      .guide-close {
        background: none;
        border: none;
        width: 28px;
        height: 28px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6B6B70;
        transition: all 0.15s ease;
        flex-shrink: 0;
        margin-top: -2px;
      }

      .guide-close:hover {
        background: rgba(0, 0, 0, 0.06);
        color: #000;
      }

      /* Body */
      .guide-body {
        padding: 16px 20px 20px;
      }

      .guide-text {
        font-size: 13px;
        line-height: 1.6;
        color: #363636;
        margin-bottom: 16px;
      }

      .guide-demo-label {
        font-size: 11px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        color: #7A7F88;
        margin-bottom: 6px;
      }

      .guide-demo-desc {
        font-size: 12px;
        line-height: 1.5;
        color: #6B6B70;
        padding: 10px 14px;
        background: #F4F4F7;
        border-radius: 8px;
        border: 1px solid #E5E5EA;
        margin-bottom: 16px;
      }

      /* Actions */
      .guide-actions {
        display: flex;
        gap: 8px;
      }

      .guide-btn {
        flex: 1;
        padding: 10px 16px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 500;
        font-family: inherit;
        cursor: pointer;
        transition: opacity 0.15s ease;
        text-align: center;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
      }

      .guide-btn-primary {
        background: #000;
        color: #FFF;
        border: 1px solid #000;
      }

      .guide-btn-primary:hover {
        opacity: 0.85;
      }

      .guide-btn-secondary {
        background: transparent;
        color: #6B6B70;
        border: 1px solid #E5E5EA;
      }

      .guide-btn-secondary:hover {
        border-color: #9E9E9E;
        color: #000;
      }

      /* Taste voting (for design sites) */
      .guide-taste {
        display: flex;
        gap: 8px;
        margin-top: 12px;
      }

      .guide-taste-btn {
        flex: 1;
        padding: 10px 16px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 500;
        font-family: inherit;
        cursor: pointer;
        transition: all 0.15s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        background: transparent;
        border: 1px solid #E5E5EA;
        color: #6B6B70;
      }

      .guide-taste-btn:hover {
        border-color: #9E9E9E;
        color: #000;
      }

      .guide-taste-btn.love:hover {
        border-color: #34C759;
        color: #34C759;
      }

      .guide-taste-btn.pass:hover {
        border-color: #9E9E9E;
      }

      .guide-taste-btn.voted {
        border-color: #34C759;
        background: rgba(52, 199, 89, 0.08);
        color: #34C759;
      }
    </style>

    <div class="guide">
      <div class="guide-header">
        <div class="guide-header-left">
          <span class="guide-badge">
            <span class="guide-badge-dot"></span>
            ${r[e.demo]??e.demo}
          </span>
          <span class="guide-site-name">${e.name}</span>
        </div>
        <button class="guide-close" id="close">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>

      <div class="guide-body">
        <div class="guide-text">${e.guide}</div>

        <div class="guide-demo-label">What Webpaper does here</div>
        <div class="guide-demo-desc">${e.pitch}</div>

        ${e.demo==="design-taste"?`
          <div class="guide-demo-label">Rate this design</div>
          <div class="guide-taste">
            <button class="guide-taste-btn love" id="vote-love">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
              </svg>
              Love it
            </button>
            <button class="guide-taste-btn pass" id="vote-pass">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
              Not for me
            </button>
          </div>
        `:`
          <div class="guide-actions">
            <button class="guide-btn guide-btn-primary" id="dismiss">Got it</button>
          </div>
        `}
      </div>
    </div>
  `,document.body.appendChild(t),je=t;const i=n.getElementById("close"),o=n.getElementById("dismiss"),a=n.getElementById("vote-love"),s=n.getElementById("vote-pass"),l=()=>{const c=n.querySelector(".guide");c&&(c.classList.add("dismissing"),setTimeout(()=>{t.remove(),je=null},200))};i==null||i.addEventListener("click",l),o==null||o.addEventListener("click",l),a==null||a.addEventListener("click",async()=>{a.classList.add("voted"),s==null||s.classList.remove("voted"),await chrome.runtime.sendMessage({type:"onboarding-taste-vote",payload:{domain:e.domain,vote:"love"}}),await chrome.runtime.sendMessage({type:"polish-add-liked-site",payload:{hostname:e.domain,title:e.name}}),setTimeout(l,800)}),s==null||s.addEventListener("click",async()=>{s.classList.add("voted"),a==null||a.classList.remove("voted"),await chrome.runtime.sendMessage({type:"onboarding-taste-vote",payload:{domain:e.domain,vote:"pass"}}),setTimeout(l,600)})}const Ft=ee("autofill"),va=["name","given-name","family-name","email","street-address","address-level1","address-level2","country","organization","organization-title","bday","url"],Ma={fname:"given-name",firstname:"given-name","first-name":"given-name",lname:"family-name",lastname:"family-name","last-name":"family-name",surname:"family-name",email:"email",mail:"email","e-mail":"email",fullname:"name","full-name":"name",name:"name",city:"address-level2",town:"address-level2",state:"address-level1",region:"address-level1",province:"address-level1",country:"country",company:"organization",org:"organization",employer:"organization",title:"organization-title",role:"organization-title","job-title":"organization-title",street:"street-address",address:"street-address"};let re=null,Ue=null,it=null,nr=0;const Ba=6e4;async function La(){location.protocol==="chrome-extension:"||location.protocol==="chrome:"||!await Ia()||(document.addEventListener("focusin",Da,{capture:!0}),document.addEventListener("focusout",Ta,{capture:!0}),Ft.info("installed",{host:location.hostname}))}async function Ia(){try{const e=`srf_autofill_${location.hostname}`,{[e]:t}=await chrome.storage.local.get(e);return t===!0}catch{return!1}}function Da(e){const t=e.target;if(t&&(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)){if(!Jr(t))return;Ue=t,Pa(t)}}function Ta(){setTimeout(()=>{document.activeElement!==re&&(Et(),Ue=null)},150)}function Jr(e){const t=(e.getAttribute("autocomplete")??"").toLowerCase().trim();if(t&&va.includes(t))return t;const n=(e.name||e.id||e.getAttribute("placeholder")||"").toLowerCase();if(!n)return null;for(const[r,i]of Object.entries(Ma))if(n.includes(r))return i;return null}async function Oa(){if(it&&Date.now()-nr<Ba)return it;try{const e=await chrome.runtime.sendMessage({type:"autofill-get-fields"});return it=(e==null?void 0:e.payload)??null,nr=Date.now(),it}catch(e){return Ft.warn("view fetch failed",e),null}}function Pa(e,t){Et();const n=e.getBoundingClientRect();re=document.createElement("div"),re.setAttribute("data-srf-autofill-pill",""),re.style.cssText=`
    all: initial;
    position: fixed;
    z-index: 2147483647;
    top: ${n.top-32}px;
    left: ${n.left}px;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    font-size: 12px;
    color: #fff;
    background: #000;
    border: 1px solid #000;
    border-radius: 6px;
    padding: 5px 10px;
    cursor: pointer;
    user-select: none;
    line-height: 1.2;
  `,re.textContent="Fill from Webpaper",re.addEventListener("mousedown",r=>{r.preventDefault(),r.stopPropagation(),Ra()}),document.body.appendChild(re)}function Et(){re&&(re.remove(),re=null)}async function Ra(e){const t=await Oa();if(!t){Ft.warn("no profile view — aborting fill"),Et();return}const r=(Ue==null?void 0:Ue.closest("form"))??document;let i=0;const o=r.querySelectorAll("input, textarea");for(const a of o){const s=Jr(a);if(!s)continue;const l=t[s];l&&(a.value&&a.value.trim().length>0||($a(a,String(l)),i++))}Ft.info("filled",{count:i,host:location.hostname}),Et()}function $a(e,t){var i;const n=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,r=Object.getOwnPropertyDescriptor(n,"value");(i=r==null?void 0:r.set)==null||i.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}const Xr=ee("light-dom"),Wa=["firstName","city","occupation"];async function _a(){if(location.protocol==="chrome-extension:"||location.protocol==="chrome:"||!await za())return;const t=await qa();if(!t)return;rr(document,t),or(document,t),new MutationObserver(r=>{for(const i of r)for(const o of Array.from(i.addedNodes))o.nodeType===Node.ELEMENT_NODE&&(rr(o,t),or(o,t))}).observe(document.body,{childList:!0,subtree:!0}),Xr.info("installed",{host:location.hostname})}async function za(){try{const e=`srf_lightdom_${location.hostname}`,{[e]:t}=await chrome.storage.local.get(e);return t===!0}catch{return!1}}async function qa(){try{const e=await chrome.runtime.sendMessage({type:"lightdom-get-tokens"});return(e==null?void 0:e.payload)??null}catch(e){return Xr.warn("view fetch failed",e),null}}function rr(e,t){var r;const n=(r=e.querySelectorAll)==null?void 0:r.call(e,"[data-srf-token]");if(n)for(const i of Array.from(n)){const o=i.getAttribute("data-srf-token")??"";if(!Qr(o))continue;const a=t[o];a&&i.getAttribute("data-srf-applied")!=="1"&&(i.textContent=a,i.setAttribute("data-srf-applied","1"))}}function or(e,t){var o;const n=document.createTreeWalker(e,NodeFilter.SHOW_COMMENT),r=[];let i=n.nextNode();for(;i;){const s=i.data.trim().match(/^cfg:([a-zA-Z]+)$/);s&&Qr(s[1])&&r.push({node:i,key:s[1]}),i=n.nextNode()}for(const{node:a,key:s}of r){const l=t[s];if(!l)continue;const c=document.createTextNode(l);(o=a.parentNode)==null||o.replaceChild(c,a)}}function Qr(e){return Wa.includes(e)}const kt=ee("preview-bar"),Zr="surface-preview-bar";let Oe=null;async function An(e){Oe&&Oe();const t=await Ha();if(kt.info("install",{count:t.length,host:location.hostname}),t.length===0){kt.debug("no cards to preview, skipping bar");return}const n=Ua(t,e);Oe=Ya(n,e.adapter)}function ja(){var e;Oe&&(Oe(),Oe=null),(e=document.getElementById(Zr))==null||e.remove()}async function Ha(){var e;try{const t=await chrome.runtime.sendMessage({type:"get-active-cards",payload:{host:location.hostname}}),n=(e=t==null?void 0:t.payload)==null?void 0:e.cards;return Array.isArray(n)?n:[]}catch(t){return kt.warn("fetch failed",t),[]}}async function Ga(e){try{await chrome.runtime.sendMessage({type:"set-card-attached",payload:{host:location.hostname,cardType:e,attached:!1}})}catch(t){kt.warn("detach failed",{type:e,err:t})}}function Ua(e,t){const n=document.createElement("div");n.id=Zr,n.style.position="fixed",n.style.zIndex="2147483646",n.style.left="0",n.style.top="0";const r=n.attachShadow({mode:"open"});r.innerHTML=Va;const i=r.getElementById("list");for(let o=0;o<e.length;o++)i.appendChild(Ka(e[o],o,n,t));return document.body.appendChild(n),n}function Ka(e,t,n,r){const i=Br(e.type),o=e.label??i.label,a=e.type==="biography",s=document.createElement("div");s.className="item";const l=document.createElement("button");l.type="button",l.className=`chip ${a?"marquee":""}`,l.style.setProperty("--accent",i.accent),l.style.setProperty("--enter-delay",`${t*40}ms`);const c=document.createElement("span");c.className="dot";const d=document.createElement("span");d.className="label",d.textContent=o;const f=document.createElement("span");f.className="close",f.setAttribute("role","button"),f.setAttribute("aria-label",`Detach ${o}`),f.innerHTML='<svg viewBox="0 0 12 12" width="9" height="9" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 3 L9 9 M9 3 L3 9"/></svg>',l.appendChild(c),l.appendChild(d),l.appendChild(f);let u=!1;const p=document.createElement("div");return p.className="body",l.addEventListener("click",m=>{if(!m.target.closest(".close")){if(!u){const g=document.createElement("div");g.className="body-text",g.textContent=e.content,p.appendChild(g),u=!0}s.classList.toggle("open")}}),f.addEventListener("click",async m=>{m.stopPropagation(),s.classList.add("removing"),setTimeout(async()=>{var h;s.remove(),await Ga(e.type),await r.onChange();const g=(h=n.shadowRoot)==null?void 0:h.getElementById("list");g&&g.children.length===0&&(n.style.display="none")},180)}),s.appendChild(l),s.appendChild(p),s}function Ya(e,t){const n=()=>{const l=t.getInput();let c=!1;if(l){const d=l.getBoundingClientRect();let f=l,u=l;for(let m=0;m<6&&f&&(f=f.parentElement,!!f);m++){const g=f.getBoundingClientRect();if(g.width>d.width*1.05&&g.width>=280){u=f;break}}const p=u.getBoundingClientRect();p.width>=200&&p.top>0&&p.top<window.innerHeight&&(e.style.display="",e.style.transform="",e.style.right="",e.style.bottom="",e.style.maxWidth="",e.style.left=`${Math.max(8,p.left)}px`,e.style.top=`${Math.max(8,p.top-52)}px`,e.style.width=`${Math.min(p.width,720)}px`,c=!0)}c||(e.style.display="",e.style.left="50%",e.style.right="",e.style.top="",e.style.bottom="24px",e.style.transform="translateX(-50%)",e.style.maxWidth="min(720px, calc(100vw - 32px))",e.style.width="auto")};n();const r=new ResizeObserver(n),i=t.getInput();i&&r.observe(i),r.observe(document.documentElement);const o=()=>n(),a=()=>n();window.addEventListener("scroll",o,{passive:!0,capture:!0}),window.addEventListener("resize",a);const s=new MutationObserver(n);return s.observe(document.body,{childList:!0,subtree:!0}),()=>{r.disconnect(),s.disconnect(),window.removeEventListener("scroll",o,{capture:!0}),window.removeEventListener("resize",a),e.remove()}}const Va=`
<style>
  :host {
    all: initial;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    -webkit-font-smoothing: antialiased;
  }
  * { box-sizing: border-box; }

  @keyframes mesh-drift {
    0%   { background-position:   0%   0%; }
    100% { background-position: 100% 100%; }
  }
  @keyframes fade-in {
    from { opacity: 0; transform: translateY(2px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes chip-enter {
    from { opacity: 0; transform: translateY(3px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes chip-leave {
    to { opacity: 0; transform: translateY(2px) scale(0.94); }
  }

  .bar {
    position: relative;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 10px;
    background: rgba(255, 255, 255, 0.96);
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    border: 1px solid #d6d6db;
    border-radius: 14px;
    overflow: hidden;
    isolation: isolate;
    animation: fade-in 0.22s ease;
  }
  .bar::before {
    content: '';
    position: absolute;
    inset: 0;
    z-index: -1;
    pointer-events: none;
    background:
      radial-gradient(ellipse 60% 60% at 0%   0%,   rgba(255, 130,  80, 0.16) 0%, transparent 60%),
      radial-gradient(ellipse 60% 60% at 100% 0%,   rgba(140,  80, 240, 0.14) 0%, transparent 60%),
      radial-gradient(ellipse 60% 60% at 50% 100%,  rgba( 60, 140, 255, 0.14) 0%, transparent 60%);
    background-size: 200% 200%;
    animation: mesh-drift 12s ease-in-out infinite alternate;
    filter: blur(14px);
  }

  .label-pre {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 10px;
    color: #6b6b70;
    padding: 0 6px 0 4px;
    white-space: nowrap;
    flex-shrink: 0;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    font-weight: 500;
  }
  .label-pre::after {
    content: '';
    width: 1px;
    height: 14px;
    background: rgba(0, 0, 0, 0.1);
    margin-left: 4px;
  }

  #list {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    flex: 1 1 auto;
    min-width: 0;
    align-items: center;
  }

  .item {
    display: inline-flex;
    flex-direction: column;
    min-width: 0;
    flex: 0 0 auto;
  }

  .chip {
    --accent: #586675;
    position: relative;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 28px;
    padding: 0 6px 0 10px;
    border: 1px solid #d6d6db;
    border-radius: 999px;
    background: #fff;
    color: #1f1f24;
    font: inherit;
    font-size: 12px;
    line-height: 1;
    cursor: pointer;
    user-select: none;
    overflow: hidden;
    isolation: isolate;
    transition: border-color 0.15s ease, transform 0.15s ease;
    animation: chip-enter 0.2s cubic-bezier(0.2, 0.8, 0.2, 1) backwards;
    animation-delay: var(--enter-delay, 0ms);
  }
  .chip:hover { border-color: #1f1f24; transform: translateY(-1px); }
  .item.removing .chip { animation: chip-leave 0.18s ease forwards; }

  .dot {
    width: 6px; height: 6px;
    border-radius: 50%;
    background: var(--accent);
    flex-shrink: 0;
  }
  .label {
    font-weight: 500;
    color: #1f1f24;
    white-space: nowrap;
  }
  .close {
    width: 18px; height: 18px;
    margin-left: 2px;
    border-radius: 50%;
    color: #9090a0;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: background 0.15s ease, color 0.15s ease;
  }
  .close:hover { background: rgba(0, 0, 0, 0.06); color: #1f1f24; }

  /* Marquee — biography chip with full Surface mesh */
  .chip.marquee {
    color: #fff;
    border-color: transparent;
  }
  .chip.marquee::before {
    content: '';
    position: absolute;
    inset: 0;
    z-index: -1;
    pointer-events: none;
    background:
      radial-gradient(ellipse 65% 62% at 0%   15%, rgba(255, 110,  60, 0.95) 0%, transparent 65%),
      radial-gradient(ellipse 60% 62% at 100% 22%, rgba(140,  70, 240, 0.85) 0%, transparent 65%),
      radial-gradient(ellipse 65% 60% at 95%  92%, rgba( 50, 130, 255, 0.82) 0%, transparent 65%),
      radial-gradient(ellipse 55% 50% at 50%   0%, rgba(255, 140,  90, 0.78) 0%, transparent 65%),
      linear-gradient(135deg, #2a1c4a 0%, #4a1a3a 50%, #1a2a4a 100%);
    background-size: 200% 200%;
    animation: mesh-drift 9s ease-in-out infinite alternate;
  }
  .chip.marquee .dot { background: #fff; }
  .chip.marquee .label { color: #fff; }
  .chip.marquee .close { color: rgba(255,255,255,0.7); }
  .chip.marquee .close:hover { background: rgba(255,255,255,0.18); color: #fff; }
  .chip.marquee:hover { border-color: transparent; }

  /* Body — revealed when chip clicked */
  .body {
    display: none;
    margin-top: 6px;
    padding: 8px 10px;
    background: rgba(255, 255, 255, 0.92);
    border: 1px solid #d6d6db;
    border-left: 3px solid var(--accent, #586675);
    border-radius: 8px;
    font-size: 12px;
    color: #2c2c33;
    line-height: 1.5;
    max-width: 320px;
    white-space: pre-wrap;
    animation: fade-in 0.18s ease;
  }
  .item.open .body { display: block; }

  @media (prefers-color-scheme: dark) {
    .bar {
      background: rgba(23, 23, 27, 0.92);
      border-color: rgba(255, 255, 255, 0.14);
    }
    .label-pre { color: rgba(255, 255, 255, 0.55); }
    .label-pre::after { background: rgba(255, 255, 255, 0.1); }
    .chip {
      background: rgba(255, 255, 255, 0.06);
      border-color: rgba(255, 255, 255, 0.16);
      color: #f0f0f3;
    }
    .chip:hover { border-color: rgba(255, 255, 255, 0.5); }
    .label { color: #f0f0f3; }
    .close { color: rgba(255, 255, 255, 0.55); }
    .close:hover { background: rgba(255, 255, 255, 0.1); color: #fff; }
    .body {
      background: rgba(28, 28, 32, 0.92);
      border-color: rgba(255, 255, 255, 0.1);
      color: rgba(255, 255, 255, 0.85);
    }
  }
</style>
<div class="bar" role="toolbar" aria-label="Webpaper profile cards — click × to detach before sending">
  <span class="label-pre">Sending</span>
  <div id="list"></div>
</div>
`;function Ja(){const e=location.hostname;e!=="grok.com"&&!e.endsWith(".grok.com")||window.addEventListener("message",t=>{if(t.source!==window)return;const n=t.data,r=n&&typeof n=="object"?n.__webpaperGrokStatsig:void 0;typeof r=="string"&&r.length>0&&chrome.runtime.sendMessage({type:"grok-statsig-captured",payload:{id:r}}).catch(()=>{})})}const ir="srf-skin-base";async function eo(){try{const e=await chrome.storage.local.get(Jt);Xa(e[Jt])}catch{}}function Xa(e){const t=_o(e);let n=document.getElementById(ir);if(!t){n==null||n.remove();return}n||(n=document.createElement("style"),n.id=ir,(document.head||document.documentElement).prepend(n)),n.textContent=t}function Qa(){try{chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&Jt in e&&eo()})}catch{}}const ln="wp-pinned-look";async function to(){var e,t;try{const n=await chrome.storage.local.get([Xt,"srf_enabled"]);if(n.srf_enabled===!1){(e=document.getElementById(ln))==null||e.remove();return}const r=n[Xt];Za((t=r==null?void 0:r[zo(location.hostname)])==null?void 0:t.css)}catch{}}function Za(e){let t=document.getElementById(ln);if(!e){t==null||t.remove();return}document.documentElement.classList.add("srf-polished-root"),document.documentElement.hasAttribute("data-srf-polished")||document.documentElement.setAttribute("data-srf-polished","1"),t||(t=document.createElement("style"),t.id=ln,(document.head||document.documentElement).appendChild(t)),t.textContent=e}function es(){try{chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&(Xt in e||"srf_enabled"in e)&&to()})}catch{}}const ts=1,ns=["BN","BN","BN","BN","BN","BN","BN","BN","BN","S","B","S","WS","B","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","B","B","B","S","WS","ON","ON","ET","ET","ET","ON","ON","ON","ON","ON","ES","CS","ES","CS","CS","EN","EN","EN","EN","EN","EN","EN","EN","EN","EN","CS","ON","ON","ON","ON","ON","ON","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","ON","ON","ON","ON","ON","ON","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","ON","ON","ON","ON","BN","BN","BN","BN","BN","BN","B","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","BN","CS","ON","ET","ET","ET","ET","ON","ON","ON","ON","L","ON","ON","BN","ON","ON","ET","ET","EN","EN","ON","L","ON","ON","ON","EN","L","ON","ON","ON","ON","ON","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","ON","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","L","ON","L","L","L","L","L","L","L","L"],ar=[[697,698,"ON"],[706,719,"ON"],[722,735,"ON"],[741,749,"ON"],[751,767,"ON"],[768,879,"NSM"],[884,885,"ON"],[894,894,"ON"],[900,901,"ON"],[903,903,"ON"],[1014,1014,"ON"],[1155,1161,"NSM"],[1418,1418,"ON"],[1421,1422,"ON"],[1423,1423,"ET"],[1424,1424,"R"],[1425,1469,"NSM"],[1470,1470,"R"],[1471,1471,"NSM"],[1472,1472,"R"],[1473,1474,"NSM"],[1475,1475,"R"],[1476,1477,"NSM"],[1478,1478,"R"],[1479,1479,"NSM"],[1480,1535,"R"],[1536,1541,"AN"],[1542,1543,"ON"],[1544,1544,"AL"],[1545,1546,"ET"],[1547,1547,"AL"],[1548,1548,"CS"],[1549,1549,"AL"],[1550,1551,"ON"],[1552,1562,"NSM"],[1563,1610,"AL"],[1611,1631,"NSM"],[1632,1641,"AN"],[1642,1642,"ET"],[1643,1644,"AN"],[1645,1647,"AL"],[1648,1648,"NSM"],[1649,1749,"AL"],[1750,1756,"NSM"],[1757,1757,"AN"],[1758,1758,"ON"],[1759,1764,"NSM"],[1765,1766,"AL"],[1767,1768,"NSM"],[1769,1769,"ON"],[1770,1773,"NSM"],[1774,1775,"AL"],[1776,1785,"EN"],[1786,1808,"AL"],[1809,1809,"NSM"],[1810,1839,"AL"],[1840,1866,"NSM"],[1867,1957,"AL"],[1958,1968,"NSM"],[1969,1983,"AL"],[1984,2026,"R"],[2027,2035,"NSM"],[2036,2037,"R"],[2038,2041,"ON"],[2042,2044,"R"],[2045,2045,"NSM"],[2046,2069,"R"],[2070,2073,"NSM"],[2074,2074,"R"],[2075,2083,"NSM"],[2084,2084,"R"],[2085,2087,"NSM"],[2088,2088,"R"],[2089,2093,"NSM"],[2094,2136,"R"],[2137,2139,"NSM"],[2140,2143,"R"],[2144,2191,"AL"],[2192,2193,"AN"],[2194,2198,"AL"],[2199,2207,"NSM"],[2208,2249,"AL"],[2250,2273,"NSM"],[2274,2274,"AN"],[2275,2306,"NSM"],[2362,2362,"NSM"],[2364,2364,"NSM"],[2369,2376,"NSM"],[2381,2381,"NSM"],[2385,2391,"NSM"],[2402,2403,"NSM"],[2433,2433,"NSM"],[2492,2492,"NSM"],[2497,2500,"NSM"],[2509,2509,"NSM"],[2530,2531,"NSM"],[2546,2547,"ET"],[2555,2555,"ET"],[2558,2558,"NSM"],[2561,2562,"NSM"],[2620,2620,"NSM"],[2625,2626,"NSM"],[2631,2632,"NSM"],[2635,2637,"NSM"],[2641,2641,"NSM"],[2672,2673,"NSM"],[2677,2677,"NSM"],[2689,2690,"NSM"],[2748,2748,"NSM"],[2753,2757,"NSM"],[2759,2760,"NSM"],[2765,2765,"NSM"],[2786,2787,"NSM"],[2801,2801,"ET"],[2810,2815,"NSM"],[2817,2817,"NSM"],[2876,2876,"NSM"],[2879,2879,"NSM"],[2881,2884,"NSM"],[2893,2893,"NSM"],[2901,2902,"NSM"],[2914,2915,"NSM"],[2946,2946,"NSM"],[3008,3008,"NSM"],[3021,3021,"NSM"],[3059,3064,"ON"],[3065,3065,"ET"],[3066,3066,"ON"],[3072,3072,"NSM"],[3076,3076,"NSM"],[3132,3132,"NSM"],[3134,3136,"NSM"],[3142,3144,"NSM"],[3146,3149,"NSM"],[3157,3158,"NSM"],[3170,3171,"NSM"],[3192,3198,"ON"],[3201,3201,"NSM"],[3260,3260,"NSM"],[3276,3277,"NSM"],[3298,3299,"NSM"],[3328,3329,"NSM"],[3387,3388,"NSM"],[3393,3396,"NSM"],[3405,3405,"NSM"],[3426,3427,"NSM"],[3457,3457,"NSM"],[3530,3530,"NSM"],[3538,3540,"NSM"],[3542,3542,"NSM"],[3633,3633,"NSM"],[3636,3642,"NSM"],[3647,3647,"ET"],[3655,3662,"NSM"],[3761,3761,"NSM"],[3764,3772,"NSM"],[3784,3790,"NSM"],[3864,3865,"NSM"],[3893,3893,"NSM"],[3895,3895,"NSM"],[3897,3897,"NSM"],[3898,3901,"ON"],[3953,3966,"NSM"],[3968,3972,"NSM"],[3974,3975,"NSM"],[3981,3991,"NSM"],[3993,4028,"NSM"],[4038,4038,"NSM"],[4141,4144,"NSM"],[4146,4151,"NSM"],[4153,4154,"NSM"],[4157,4158,"NSM"],[4184,4185,"NSM"],[4190,4192,"NSM"],[4209,4212,"NSM"],[4226,4226,"NSM"],[4229,4230,"NSM"],[4237,4237,"NSM"],[4253,4253,"NSM"],[4957,4959,"NSM"],[5008,5017,"ON"],[5120,5120,"ON"],[5760,5760,"WS"],[5787,5788,"ON"],[5906,5908,"NSM"],[5938,5939,"NSM"],[5970,5971,"NSM"],[6002,6003,"NSM"],[6068,6069,"NSM"],[6071,6077,"NSM"],[6086,6086,"NSM"],[6089,6099,"NSM"],[6107,6107,"ET"],[6109,6109,"NSM"],[6128,6137,"ON"],[6144,6154,"ON"],[6155,6157,"NSM"],[6158,6158,"BN"],[6159,6159,"NSM"],[6277,6278,"NSM"],[6313,6313,"NSM"],[6432,6434,"NSM"],[6439,6440,"NSM"],[6450,6450,"NSM"],[6457,6459,"NSM"],[6464,6464,"ON"],[6468,6469,"ON"],[6622,6655,"ON"],[6679,6680,"NSM"],[6683,6683,"NSM"],[6742,6742,"NSM"],[6744,6750,"NSM"],[6752,6752,"NSM"],[6754,6754,"NSM"],[6757,6764,"NSM"],[6771,6780,"NSM"],[6783,6783,"NSM"],[6832,6877,"NSM"],[6880,6891,"NSM"],[6912,6915,"NSM"],[6964,6964,"NSM"],[6966,6970,"NSM"],[6972,6972,"NSM"],[6978,6978,"NSM"],[7019,7027,"NSM"],[7040,7041,"NSM"],[7074,7077,"NSM"],[7080,7081,"NSM"],[7083,7085,"NSM"],[7142,7142,"NSM"],[7144,7145,"NSM"],[7149,7149,"NSM"],[7151,7153,"NSM"],[7212,7219,"NSM"],[7222,7223,"NSM"],[7376,7378,"NSM"],[7380,7392,"NSM"],[7394,7400,"NSM"],[7405,7405,"NSM"],[7412,7412,"NSM"],[7416,7417,"NSM"],[7616,7679,"NSM"],[8125,8125,"ON"],[8127,8129,"ON"],[8141,8143,"ON"],[8157,8159,"ON"],[8173,8175,"ON"],[8189,8190,"ON"],[8192,8202,"WS"],[8203,8205,"BN"],[8207,8207,"R"],[8208,8231,"ON"],[8232,8232,"WS"],[8233,8233,"B"],[8234,8238,"BN"],[8239,8239,"CS"],[8240,8244,"ET"],[8245,8259,"ON"],[8260,8260,"CS"],[8261,8286,"ON"],[8287,8287,"WS"],[8288,8303,"BN"],[8304,8304,"EN"],[8308,8313,"EN"],[8314,8315,"ES"],[8316,8318,"ON"],[8320,8329,"EN"],[8330,8331,"ES"],[8332,8334,"ON"],[8352,8399,"ET"],[8400,8432,"NSM"],[8448,8449,"ON"],[8451,8454,"ON"],[8456,8457,"ON"],[8468,8468,"ON"],[8470,8472,"ON"],[8478,8483,"ON"],[8485,8485,"ON"],[8487,8487,"ON"],[8489,8489,"ON"],[8494,8494,"ET"],[8506,8507,"ON"],[8512,8516,"ON"],[8522,8525,"ON"],[8528,8543,"ON"],[8585,8587,"ON"],[8592,8721,"ON"],[8722,8722,"ES"],[8723,8723,"ET"],[8724,9013,"ON"],[9083,9108,"ON"],[9110,9257,"ON"],[9280,9290,"ON"],[9312,9351,"ON"],[9352,9371,"EN"],[9450,9899,"ON"],[9901,10239,"ON"],[10496,11123,"ON"],[11126,11263,"ON"],[11493,11498,"ON"],[11503,11505,"NSM"],[11513,11519,"ON"],[11647,11647,"NSM"],[11744,11775,"NSM"],[11776,11869,"ON"],[11904,11929,"ON"],[11931,12019,"ON"],[12032,12245,"ON"],[12272,12287,"ON"],[12288,12288,"WS"],[12289,12292,"ON"],[12296,12320,"ON"],[12330,12333,"NSM"],[12336,12336,"ON"],[12342,12343,"ON"],[12349,12351,"ON"],[12441,12442,"NSM"],[12443,12444,"ON"],[12448,12448,"ON"],[12539,12539,"ON"],[12736,12773,"ON"],[12783,12783,"ON"],[12829,12830,"ON"],[12880,12895,"ON"],[12924,12926,"ON"],[12977,12991,"ON"],[13004,13007,"ON"],[13175,13178,"ON"],[13278,13279,"ON"],[13311,13311,"ON"],[19904,19967,"ON"],[42128,42182,"ON"],[42509,42511,"ON"],[42607,42610,"NSM"],[42611,42611,"ON"],[42612,42621,"NSM"],[42622,42623,"ON"],[42654,42655,"NSM"],[42736,42737,"NSM"],[42752,42785,"ON"],[42888,42888,"ON"],[43010,43010,"NSM"],[43014,43014,"NSM"],[43019,43019,"NSM"],[43045,43046,"NSM"],[43048,43051,"ON"],[43052,43052,"NSM"],[43064,43065,"ET"],[43124,43127,"ON"],[43204,43205,"NSM"],[43232,43249,"NSM"],[43263,43263,"NSM"],[43302,43309,"NSM"],[43335,43345,"NSM"],[43392,43394,"NSM"],[43443,43443,"NSM"],[43446,43449,"NSM"],[43452,43453,"NSM"],[43493,43493,"NSM"],[43561,43566,"NSM"],[43569,43570,"NSM"],[43573,43574,"NSM"],[43587,43587,"NSM"],[43596,43596,"NSM"],[43644,43644,"NSM"],[43696,43696,"NSM"],[43698,43700,"NSM"],[43703,43704,"NSM"],[43710,43711,"NSM"],[43713,43713,"NSM"],[43756,43757,"NSM"],[43766,43766,"NSM"],[43882,43883,"ON"],[44005,44005,"NSM"],[44008,44008,"NSM"],[44013,44013,"NSM"],[64285,64285,"R"],[64286,64286,"NSM"],[64287,64296,"R"],[64297,64297,"ES"],[64298,64335,"R"],[64336,64450,"AL"],[64451,64466,"ON"],[64467,64829,"AL"],[64830,64847,"ON"],[64848,64911,"AL"],[64912,64913,"ON"],[64914,64967,"AL"],[64968,64975,"ON"],[64976,65007,"BN"],[65008,65020,"AL"],[65021,65023,"ON"],[65024,65039,"NSM"],[65040,65049,"ON"],[65056,65071,"NSM"],[65072,65103,"ON"],[65104,65104,"CS"],[65105,65105,"ON"],[65106,65106,"CS"],[65108,65108,"ON"],[65109,65109,"CS"],[65110,65118,"ON"],[65119,65119,"ET"],[65120,65121,"ON"],[65122,65123,"ES"],[65124,65126,"ON"],[65128,65128,"ON"],[65129,65130,"ET"],[65131,65131,"ON"],[65136,65278,"AL"],[65279,65279,"BN"],[65281,65282,"ON"],[65283,65285,"ET"],[65286,65290,"ON"],[65291,65291,"ES"],[65292,65292,"CS"],[65293,65293,"ES"],[65294,65295,"CS"],[65296,65305,"EN"],[65306,65306,"CS"],[65307,65312,"ON"],[65339,65344,"ON"],[65371,65381,"ON"],[65504,65505,"ET"],[65506,65508,"ON"],[65509,65510,"ET"],[65512,65518,"ON"],[65520,65528,"BN"],[65529,65533,"ON"],[65534,65535,"BN"],[65793,65793,"ON"],[65856,65932,"ON"],[65936,65948,"ON"],[65952,65952,"ON"],[66045,66045,"NSM"],[66272,66272,"NSM"],[66273,66299,"EN"],[66422,66426,"NSM"],[67584,67870,"R"],[67871,67871,"ON"],[67872,68096,"R"],[68097,68099,"NSM"],[68100,68100,"R"],[68101,68102,"NSM"],[68103,68107,"R"],[68108,68111,"NSM"],[68112,68151,"R"],[68152,68154,"NSM"],[68155,68158,"R"],[68159,68159,"NSM"],[68160,68324,"R"],[68325,68326,"NSM"],[68327,68408,"R"],[68409,68415,"ON"],[68416,68863,"R"],[68864,68899,"AL"],[68900,68903,"NSM"],[68904,68911,"AL"],[68912,68921,"AN"],[68922,68927,"AL"],[68928,68937,"AN"],[68938,68968,"R"],[68969,68973,"NSM"],[68974,68974,"ON"],[68975,69215,"R"],[69216,69246,"AN"],[69247,69290,"R"],[69291,69292,"NSM"],[69293,69311,"R"],[69312,69327,"AL"],[69328,69336,"ON"],[69337,69369,"AL"],[69370,69375,"NSM"],[69376,69423,"R"],[69424,69445,"AL"],[69446,69456,"NSM"],[69457,69487,"AL"],[69488,69505,"R"],[69506,69509,"NSM"],[69510,69631,"R"],[69633,69633,"NSM"],[69688,69702,"NSM"],[69714,69733,"ON"],[69744,69744,"NSM"],[69747,69748,"NSM"],[69759,69761,"NSM"],[69811,69814,"NSM"],[69817,69818,"NSM"],[69826,69826,"NSM"],[69888,69890,"NSM"],[69927,69931,"NSM"],[69933,69940,"NSM"],[70003,70003,"NSM"],[70016,70017,"NSM"],[70070,70078,"NSM"],[70089,70092,"NSM"],[70095,70095,"NSM"],[70191,70193,"NSM"],[70196,70196,"NSM"],[70198,70199,"NSM"],[70206,70206,"NSM"],[70209,70209,"NSM"],[70367,70367,"NSM"],[70371,70378,"NSM"],[70400,70401,"NSM"],[70459,70460,"NSM"],[70464,70464,"NSM"],[70502,70508,"NSM"],[70512,70516,"NSM"],[70587,70592,"NSM"],[70606,70606,"NSM"],[70608,70608,"NSM"],[70610,70610,"NSM"],[70625,70626,"NSM"],[70712,70719,"NSM"],[70722,70724,"NSM"],[70726,70726,"NSM"],[70750,70750,"NSM"],[70835,70840,"NSM"],[70842,70842,"NSM"],[70847,70848,"NSM"],[70850,70851,"NSM"],[71090,71093,"NSM"],[71100,71101,"NSM"],[71103,71104,"NSM"],[71132,71133,"NSM"],[71219,71226,"NSM"],[71229,71229,"NSM"],[71231,71232,"NSM"],[71264,71276,"ON"],[71339,71339,"NSM"],[71341,71341,"NSM"],[71344,71349,"NSM"],[71351,71351,"NSM"],[71453,71453,"NSM"],[71455,71455,"NSM"],[71458,71461,"NSM"],[71463,71467,"NSM"],[71727,71735,"NSM"],[71737,71738,"NSM"],[71995,71996,"NSM"],[71998,71998,"NSM"],[72003,72003,"NSM"],[72148,72151,"NSM"],[72154,72155,"NSM"],[72160,72160,"NSM"],[72193,72198,"NSM"],[72201,72202,"NSM"],[72243,72248,"NSM"],[72251,72254,"NSM"],[72263,72263,"NSM"],[72273,72278,"NSM"],[72281,72283,"NSM"],[72330,72342,"NSM"],[72344,72345,"NSM"],[72544,72544,"NSM"],[72546,72548,"NSM"],[72550,72550,"NSM"],[72752,72758,"NSM"],[72760,72765,"NSM"],[72850,72871,"NSM"],[72874,72880,"NSM"],[72882,72883,"NSM"],[72885,72886,"NSM"],[73009,73014,"NSM"],[73018,73018,"NSM"],[73020,73021,"NSM"],[73023,73029,"NSM"],[73031,73031,"NSM"],[73104,73105,"NSM"],[73109,73109,"NSM"],[73111,73111,"NSM"],[73459,73460,"NSM"],[73472,73473,"NSM"],[73526,73530,"NSM"],[73536,73536,"NSM"],[73538,73538,"NSM"],[73562,73562,"NSM"],[73685,73692,"ON"],[73693,73696,"ET"],[73697,73713,"ON"],[78912,78912,"NSM"],[78919,78933,"NSM"],[90398,90409,"NSM"],[90413,90415,"NSM"],[92912,92916,"NSM"],[92976,92982,"NSM"],[94031,94031,"NSM"],[94095,94098,"NSM"],[94178,94178,"ON"],[94180,94180,"NSM"],[113821,113822,"NSM"],[113824,113827,"BN"],[117760,117973,"ON"],[118e3,118009,"EN"],[118010,118012,"ON"],[118016,118451,"ON"],[118458,118480,"ON"],[118496,118512,"ON"],[118528,118573,"NSM"],[118576,118598,"NSM"],[119143,119145,"NSM"],[119155,119162,"BN"],[119163,119170,"NSM"],[119173,119179,"NSM"],[119210,119213,"NSM"],[119273,119274,"ON"],[119296,119361,"ON"],[119362,119364,"NSM"],[119365,119365,"ON"],[119552,119638,"ON"],[120513,120513,"ON"],[120539,120539,"ON"],[120571,120571,"ON"],[120597,120597,"ON"],[120629,120629,"ON"],[120655,120655,"ON"],[120687,120687,"ON"],[120713,120713,"ON"],[120745,120745,"ON"],[120771,120771,"ON"],[120782,120831,"EN"],[121344,121398,"NSM"],[121403,121452,"NSM"],[121461,121461,"NSM"],[121476,121476,"NSM"],[121499,121503,"NSM"],[121505,121519,"NSM"],[122880,122886,"NSM"],[122888,122904,"NSM"],[122907,122913,"NSM"],[122915,122916,"NSM"],[122918,122922,"NSM"],[123023,123023,"NSM"],[123184,123190,"NSM"],[123566,123566,"NSM"],[123628,123631,"NSM"],[123647,123647,"ET"],[124140,124143,"NSM"],[124398,124399,"NSM"],[124643,124643,"NSM"],[124646,124646,"NSM"],[124654,124655,"NSM"],[124661,124661,"NSM"],[124928,125135,"R"],[125136,125142,"NSM"],[125143,125251,"R"],[125252,125258,"NSM"],[125259,126063,"R"],[126064,126143,"AL"],[126144,126207,"R"],[126208,126287,"AL"],[126288,126463,"R"],[126464,126703,"AL"],[126704,126705,"ON"],[126706,126719,"AL"],[126720,126975,"R"],[126976,127019,"ON"],[127024,127123,"ON"],[127136,127150,"ON"],[127153,127167,"ON"],[127169,127183,"ON"],[127185,127221,"ON"],[127232,127242,"EN"],[127243,127247,"ON"],[127279,127279,"ON"],[127338,127343,"ON"],[127405,127405,"ON"],[127584,127589,"ON"],[127744,128728,"ON"],[128732,128748,"ON"],[128752,128764,"ON"],[128768,128985,"ON"],[128992,129003,"ON"],[129008,129008,"ON"],[129024,129035,"ON"],[129040,129095,"ON"],[129104,129113,"ON"],[129120,129159,"ON"],[129168,129197,"ON"],[129200,129211,"ON"],[129216,129217,"ON"],[129232,129240,"ON"],[129280,129623,"ON"],[129632,129645,"ON"],[129648,129660,"ON"],[129664,129674,"ON"],[129678,129734,"ON"],[129736,129736,"ON"],[129741,129756,"ON"],[129759,129770,"ON"],[129775,129784,"ON"],[129792,129938,"ON"],[129940,130031,"ON"],[130032,130041,"EN"],[130042,130042,"ON"],[131070,131071,"BN"],[196606,196607,"BN"],[262142,262143,"BN"],[327678,327679,"BN"],[393214,393215,"BN"],[458750,458751,"BN"],[524286,524287,"BN"],[589822,589823,"BN"],[655358,655359,"BN"],[720894,720895,"BN"],[786430,786431,"BN"],[851966,851967,"BN"],[917502,917759,"BN"],[917760,917999,"NSM"],[918e3,921599,"BN"],[983038,983039,"BN"],[1048574,1048575,"BN"],[1114110,1114111,"BN"]];function rs(e){if(e<=255)return ns[e];let t=0,n=ar.length-1;for(;t<=n;){const r=t+n>>1,i=ar[r];if(e<i[0]){n=r-1;continue}if(e>i[1]){t=r+1;continue}return i[2]}return"L"}function os(e){const t=e.length;if(t===0)return null;const n=new Array(t);let r=!1;for(let c=0;c<t;){const d=e.charCodeAt(c);let f=d,u=1;if(d>=55296&&d<=56319&&c+1<t){const m=e.charCodeAt(c+1);m>=56320&&m<=57343&&(f=(d-55296<<10)+(m-56320)+65536,u=2)}const p=rs(f);(p==="R"||p==="AL"||p==="AN")&&(r=!0);for(let m=0;m<u;m++)n[c+m]=p;c+=u}if(!r)return null;let i=0;for(let c=0;c<t;c++){const d=n[c];if(d==="L"){i=0;break}if(d==="R"||d==="AL"){i=1;break}}const o=new Int8Array(t);for(let c=0;c<t;c++)o[c]=i;const a=i&1?"R":"L",s=a;let l=s;for(let c=0;c<t;c++)n[c]==="NSM"?n[c]=l:l=n[c];l=s;for(let c=0;c<t;c++){const d=n[c];d==="EN"?n[c]=l==="AL"?"AN":"EN":(d==="R"||d==="L"||d==="AL")&&(l=d)}for(let c=0;c<t;c++)n[c]==="AL"&&(n[c]="R");for(let c=1;c<t-1;c++)n[c]==="ES"&&n[c-1]==="EN"&&n[c+1]==="EN"&&(n[c]="EN"),n[c]==="CS"&&(n[c-1]==="EN"||n[c-1]==="AN")&&n[c+1]===n[c-1]&&(n[c]=n[c-1]);for(let c=0;c<t;c++){if(n[c]!=="EN")continue;let d;for(d=c-1;d>=0&&n[d]==="ET";d--)n[d]="EN";for(d=c+1;d<t&&n[d]==="ET";d++)n[d]="EN"}for(let c=0;c<t;c++){const d=n[c];(d==="WS"||d==="ES"||d==="ET"||d==="CS")&&(n[c]="ON")}l=s;for(let c=0;c<t;c++){const d=n[c];d==="EN"?n[c]=l==="L"?"L":"EN":(d==="R"||d==="L")&&(l=d)}for(let c=0;c<t;c++){if(n[c]!=="ON")continue;let d=c+1;for(;d<t&&n[d]==="ON";)d++;const f=c>0?n[c-1]:s,u=d<t?n[d]:s,p=f!=="L"?"R":"L";if(p===(u!=="L"?"R":"L"))for(let g=c;g<d;g++)n[g]=p;c=d-1}for(let c=0;c<t;c++)n[c]==="ON"&&(n[c]=a);for(let c=0;c<t;c++){const d=n[c];o[c]&1?(d==="L"||d==="AN"||d==="EN")&&o[c]++:d==="R"?o[c]++:(d==="AN"||d==="EN")&&(o[c]+=2)}return o}function is(e,t){const n=os(e);if(n===null)return null;const r=new Int8Array(t.length);for(let i=0;i<t.length;i++)r[i]=n[t[i]];return r}const as=/[ \t\n\r\f]+/g,ss=/[\t\n\r\f]| {2,}|^ | $/;function ls(e){const t=e??"normal";return t==="pre-wrap"?{mode:t,preserveOrdinarySpaces:!0,preserveHardBreaks:!0}:{mode:t,preserveOrdinarySpaces:!1,preserveHardBreaks:!1}}function cs(e){if(!ss.test(e))return e;let t=e.replace(as," ");return t.charCodeAt(0)===32&&(t=t.slice(1)),t.length>0&&t.charCodeAt(t.length-1)===32&&(t=t.slice(0,-1)),t}function ds(e){return/[\r\f]/.test(e)?e.replace(/\r\n/g,`
`).replace(/[\r\f]/g,`
`):e}let Ke=null,cn;function us(){return Ke===null&&(Ke=new Intl.Segmenter(cn,{granularity:"word"})),Ke}function fs(){Ke=null}function ps(e){const t=e&&e.length>0?e:void 0;cn!==t&&(cn=t,Ke=null)}const xs=new RegExp("\\p{Script=Arabic}","u"),be=new RegExp("\\p{M}","u"),vn=new RegExp("\\p{Nd}","u");function sr(e){return xs.test(e)}function lr(e){return e>=19968&&e<=40959||e>=13312&&e<=19903||e>=131072&&e<=173791||e>=173824&&e<=177983||e>=177984&&e<=178207||e>=178208&&e<=183983||e>=183984&&e<=191471||e>=191472&&e<=192093||e>=194560&&e<=195103||e>=196608&&e<=201551||e>=201552&&e<=205743||e>=205744&&e<=210041||e>=63744&&e<=64255||e>=12288&&e<=12351||e>=12352&&e<=12447||e>=12448&&e<=12543||e>=12592&&e<=12687||e>=44032&&e<=55215||e>=65280&&e<=65519}function le(e){for(let t=0;t<e.length;t++){const n=e.charCodeAt(t);if(!(n<12288)){if(n>=55296&&n<=56319&&t+1<e.length){const r=e.charCodeAt(t+1);if(r>=56320&&r<=57343){const i=(n-55296<<10)+(r-56320)+65536;if(lr(i))return!0;t++;continue}}if(lr(n))return!0}}return!1}function hs(e){const t=Qe(e);return t!==null&&(Mn.has(t)||Ae.has(t))}const ms=new Set([" "," ","⁠","\uFEFF"]),gs=new Set(["-","‐","–","—"]);function bs(e){const t=Qe(e);return t!==null&&ms.has(t)}function ys(e){const t=Qe(e);return t!==null&&gs.has(t)}function no(e,t){return bs(e)?!1:t?!(hs(e)||ys(e)):!0}const Mn=new Set(["，","．","！","：","；","？","、","。","・","）","〕","〉","》","」","』","】","〗","〙","〛","ー","々","〻","ゝ","ゞ","ヽ","ヾ"]),Tt=new Set(['"',"(","[","{","¡","¿","“","‘","‚","„","«","‹","⸘","（","〔","〈","《","「","『","【","〖","〘","〚"]),Bn=new Set(["'","’"]),Ae=new Set([".",",","!","?",":",";","،","؛","؟","।","॥","၊","။","၌","၍","၏",")","]","}","%",'"',"”","’","»","›","…"]),Ss=new Set([":",".","،","؛"]),ws=new Set(["၏"]),Fs=new Set(["”","’","»","›","」","』","】","》","〉","〕","）"]);function Es(e){if(Ln(e))return!0;let t=!1;for(const n of e){if(Ae.has(n)||Pt(n)){t=!0;continue}if(!(t&&be.test(n)))return!1}return t}function ks(e){for(const t of e)if(!Mn.has(t)&&!Ae.has(t))return!1;return e.length>0}function Cs(e){if(Ln(e))return!0;for(const t of e)if(!Tt.has(t)&&!Bn.has(t)&&!be.test(t)&&!Pt(t))return!1;return e.length>0}function Ln(e){let t=!1;for(const n of e)if(!(n==="\\"||be.test(n))){if(Tt.has(n)||Ae.has(n)||Bn.has(n)){t=!0;continue}return!1}return t}function Ot(e,t){const n=t-1;if(n<=0)return Math.max(n,0);const r=e.charCodeAt(n);if(r<56320||r>57343)return n;const i=n-1;if(i<0)return n;const o=e.charCodeAt(i);return o>=55296&&o<=56319?i:n}function Qe(e){if(e.length===0)return null;const t=Ot(e,e.length);return e.slice(t)}function Ns(e){for(const t of e)if(!be.test(t))return t;return null}function As(e){for(let t=e.length;t>0;){const n=Ot(e,t),r=e.slice(n,t);if(!be.test(r))return r;t=n}return null}const vs=[36,37,43,43,92,92,162,165,176,177,1423,1423,1545,1547,1642,1642,2046,2047,2546,2547,2553,2555,2801,2801,3065,3065,3449,3449,3647,3647,6107,6107,8240,8247,8279,8279,8352,8399,8451,8451,8457,8457,8470,8470,8722,8723,43064,43064,65020,65020,65129,65130,65284,65285,65504,65505,65509,65510,73693,73696,123647,123647,126124,126124,126128,126128];function Ms(e,t){for(let n=0;n<t.length;n+=2)if(e>=t[n]&&e<=t[n+1])return!0;return!1}function Pt(e){const t=e.codePointAt(0);return t!==void 0&&Ms(t,vs)}function Bs(e){const t=As(e);return t!==null&&Pt(t)}function Ls(e){const t=Ns(e);return t!==null&&vn.test(t)}function Is(e){const t=Array.from(e);let n=t.length;for(;n>0;){const r=t[n-1];if(be.test(r)){n--;continue}if(Tt.has(r)||Bn.has(r)){n--;continue}break}return n<=0||n===t.length?null:{head:t.slice(0,n).join(""),tail:t.slice(n).join("")}}function Ds(e,t,n){return n==="text"&&!t&&e.length===1&&e!=="-"&&e!=="—"?e:null}function cr(e,t,n,r){const i=t[r],o=e[r];if(i==null)return o;const a=n[r];if(o.length===a)return o;const s=i.repeat(a);return e[r]=s,s}function dr(e,t){return e&&t!==null&&Ss.has(t)}function Ts(e){const t=Qe(e);return t!==null&&ws.has(t)}function Os(e){if(e.length<2||e[0]!==" ")return null;const t=e.slice(1);return new RegExp("^\\p{M}+$","u").test(t)?{space:" ",marks:t}:null}function dn(e){let t=e.length;for(;t>0;){const n=Ot(e,t),r=e.slice(n,t);if(Fs.has(r))return!0;if(!Ae.has(r))return!1;t=n}return!1}function Ps(e,t){if(t.preserveOrdinarySpaces||t.preserveHardBreaks){if(e===" ")return"preserved-space";if(e==="	")return"tab";if(t.preserveHardBreaks&&e===`
`)return"hard-break"}return e===" "?"space":e===" "||e===" "||e==="⁠"||e==="\uFEFF"?"glue":e==="​"?"zero-width-break":e==="­"?"soft-hyphen":"text"}const Rs=/[\x20\t\n\xA0\xAD\u200B\u202F\u2060\uFEFF]/;function Q(e){return e.length===1?e[0]:e.join("")}function $s(e,t){const n=[];for(let r=e.length-1;r>=0;r--)n.push(e[r]);return n.push(t),Q(n)}function Ws(e,t,n,r){if(!Rs.test(e))return[{text:e,isWordLike:t,kind:"text",start:n}];const i=[];let o=null,a=[],s=n,l=!1,c=0;for(const d of e){const f=Ps(d,r),u=f==="text"&&t;if(o!==null&&f===o&&u===l){a.push(d),c+=d.length;continue}o!==null&&i.push({text:Q(a),isWordLike:l,kind:o,start:s}),o=f,a=[d],s=n+c,l=u,c+=d.length}return o!==null&&i.push({text:Q(a),isWordLike:l,kind:o,start:s}),i}function un(e){return e==="space"||e==="preserved-space"||e==="zero-width-break"||e==="hard-break"}const _s=/^[A-Za-z][A-Za-z0-9+.-]*:$/;function zs(e,t){const n=e.texts[t];return n.startsWith("www.")?!0:_s.test(n)&&t+1<e.len&&e.kinds[t+1]==="text"&&e.texts[t+1]==="//"}function qs(e){return e.includes("?")&&(e.includes("://")||e.startsWith("www."))}function js(e){const t=e.texts.slice(),n=e.isWordLike.slice(),r=e.kinds.slice(),i=e.starts.slice();for(let a=0;a<e.len;a++){if(r[a]!=="text"||!zs(e,a))continue;const s=[t[a]];let l=a+1;for(;l<e.len&&!un(r[l]);){s.push(t[l]),n[a]=!0;const c=t[l].includes("?");if(r[l]="text",t[l]="",l++,c)break}t[a]=Q(s)}let o=0;for(let a=0;a<t.length;a++){const s=t[a];s.length!==0&&(o!==a&&(t[o]=s,n[o]=n[a],r[o]=r[a],i[o]=i[a]),o++)}return t.length=o,n.length=o,r.length=o,i.length=o,{len:o,texts:t,isWordLike:n,kinds:r,starts:i}}function Hs(e){const t=[],n=[],r=[],i=[];for(let o=0;o<e.len;o++){const a=e.texts[o];if(t.push(a),n.push(e.isWordLike[o]),r.push(e.kinds[o]),i.push(e.starts[o]),!qs(a))continue;const s=o+1;if(s>=e.len||un(e.kinds[s]))continue;const l=[],c=e.starts[s];let d=s;for(;d<e.len&&!un(e.kinds[d]);)l.push(e.texts[d]),d++;l.length>0&&(t.push(Q(l)),n.push(!0),r.push("text"),i.push(c),o=d-1)}return{len:t.length,texts:t,isWordLike:n,kinds:r,starts:i}}const Gs=new Set([":","-","/","×",",",".","+","–","—"]),Us=/[\p{P}\p{S}\p{Co}]/u,Ks=new RegExp("\\p{Emoji_Presentation}","u"),Ys=new Set(["?","֊","-","‐","‒","–","—","…","‼","‽","⁉"]);function Vs(e){return e>=33&&e<=47&&e!==45||e>=58&&e<=64&&e!==63||e>=91&&e<=96||e>=123&&e<=126}function ro(e){const t=e.charCodeAt(0);return t<128?Vs(t):!Ys.has(e)&&!Ks.test(e)&&Us.test(e)}function ur(e){let t=!1;for(const n of e)if(!be.test(n)){if(!ro(n))return!1;t=!0}return t}function Js(e){for(let t=e.length;t>0;){const n=Ot(e,t),r=e.slice(n,t);if(be.test(r)){t=n;continue}return ro(r)||Pt(r)}return!1}function Xs(e,t,n,r){const i=!t&&ur(e),o=!r&&ur(n),a=Bs(e),s=(t||a)&&Js(e);return!i&&!o&&!s||le(e)||le(n)?!1:(t||i||a)&&(r||o)}function oo(e){for(const t of e)if(vn.test(t))return!0;return!1}function Ct(e){if(e.length===0)return!1;for(const t of e)if(!(vn.test(t)||Gs.has(t)))return!1;return!0}function Qs(e){const t=[],n=[],r=[],i=[];for(let o=0;o<e.len;o++){const a=e.texts[o],s=e.kinds[o];if(s==="text"&&Ct(a)&&oo(a)){const l=[a];let c=o+1;for(;c<e.len&&e.kinds[c]==="text"&&Ct(e.texts[c]);)l.push(e.texts[c]),c++;t.push(Q(l)),n.push(!0),r.push("text"),i.push(e.starts[o]),o=c-1;continue}t.push(a),n.push(e.isWordLike[o]),r.push(s),i.push(e.starts[o])}return{len:t.length,texts:t,isWordLike:n,kinds:r,starts:i}}function Zs(e){const t=[],n=[],r=[],i=[];let o=0;for(;o<e.len;){const a=e.texts[o],s=e.kinds[o],l=e.isWordLike[o];if(s==="text"){const c=[a];let d=o+1,f=l;for(;d<e.len&&e.kinds[d]==="text"&&Xs(e.texts[d-1],e.isWordLike[d-1],e.texts[d],e.isWordLike[d]);){const u=e.texts[d];c.push(u),f=f||e.isWordLike[d],d++}if(d>o+1){t.push(Q(c)),n.push(f),r.push("text"),i.push(e.starts[o]),o=d;continue}}t.push(a),n.push(l),r.push(s),i.push(e.starts[o]),o++}return{len:t.length,texts:t,isWordLike:n,kinds:r,starts:i}}function el(e){const t=[],n=[],r=[],i=[];for(let o=0;o<e.len;o++){const a=e.texts[o];if(e.kinds[o]==="text"&&a.includes("-")){const s=a.split("-");let l=s.length>1;for(let c=0;c<s.length;c++){const d=s[c];if(!l)break;(d.length===0||!oo(d)||!Ct(d))&&(l=!1)}if(l){let c=0;for(let d=0;d<s.length;d++){const f=s[d],u=d<s.length-1?`${f}-`:f;t.push(u),n.push(!0),r.push("text"),i.push(e.starts[o]+c),c+=u.length}continue}}t.push(a),n.push(e.isWordLike[o]),r.push(e.kinds[o]),i.push(e.starts[o])}return{len:t.length,texts:t,isWordLike:n,kinds:r,starts:i}}function tl(e){const t=[],n=[],r=[],i=[];let o=0;for(;o<e.len;){const a=[e.texts[o]];let s=e.isWordLike[o],l=e.kinds[o],c=e.starts[o];if(l==="glue"){const d=[a[0]],f=c;for(o++;o<e.len&&e.kinds[o]==="glue";)d.push(e.texts[o]),o++;const u=Q(d);if(o<e.len&&e.kinds[o]==="text")a[0]=u,a.push(e.texts[o]),s=e.isWordLike[o],l="text",c=f,o++;else{t.push(u),n.push(!1),r.push("glue"),i.push(f);continue}}else o++;if(l==="text")for(;o<e.len&&e.kinds[o]==="glue";){const d=[];for(;o<e.len&&e.kinds[o]==="glue";)d.push(e.texts[o]),o++;const f=Q(d);if(o<e.len&&e.kinds[o]==="text"){a.push(f,e.texts[o]),s=s||e.isWordLike[o],o++;continue}a.push(f)}t.push(Q(a)),n.push(s),r.push(l),i.push(c)}return{len:t.length,texts:t,isWordLike:n,kinds:r,starts:i}}function nl(e){const t=e.texts.slice(),n=e.isWordLike.slice(),r=e.kinds.slice(),i=e.starts.slice();for(let o=0;o<t.length-1;o++){if(r[o]!=="text"||r[o+1]!=="text"||!le(t[o])||!le(t[o+1]))continue;const a=Is(t[o]);a!==null&&(t[o]=a.head,t[o+1]=a.tail+t[o+1],i[o+1]=i[o]+a.head.length)}return{len:t.length,texts:t,isWordLike:n,kinds:r,starts:i}}function rl(e,t,n){const r=us();let i=0;const o=[],a=[],s=[],l=[],c=[],d=[],f=[],u=[],p=[],m=[],g=[],h=[];for(const w of r.segment(e))for(const A of Ws(w.segment,w.isWordLike??!1,w.index,n)){let b=function(){d[x]!==null&&(a[x]=[cr(o,d,f,x)],d[x]=null),a[x].push(A.text),s[x]=s[x]||A.isWordLike,u[x]=u[x]||L,p[x]=p[x]||v,m[x]=$,g[x]=P,h[x]=dr(p[x],I)};const O=A.kind==="text",N=Ds(A.text,A.isWordLike,A.kind),L=le(A.text),v=sr(A.text),I=Qe(A.text),$=dn(A.text),P=Ts(A.text),x=i-1;t.carryCJKAfterClosingQuote&&O&&i>0&&l[x]==="text"&&L&&u[x]&&m[x]||O&&i>0&&l[x]==="text"&&ks(A.text)&&u[x]||O&&i>0&&l[x]==="text"&&g[x]?b():O&&i>0&&l[x]==="text"&&A.isWordLike&&v&&h[x]?(b(),s[x]=!0):N!==null&&i>0&&l[x]==="text"&&d[x]===N?f[x]=(f[x]??1)+1:O&&!A.isWordLike&&i>0&&l[x]==="text"&&!u[x]&&(Es(A.text)||A.text==="-"&&s[x])?b():(o[i]=A.text,a[i]=[A.text],s[i]=A.isWordLike,l[i]=A.kind,c[i]=A.start,d[i]=N,f[i]=N===null?0:1,u[i]=L,p[i]=v,m[i]=$,g[i]=P,h[i]=dr(v,I),i++)}for(let w=0;w<i;w++){if(d[w]!==null){o[w]=cr(o,d,f,w);continue}o[w]=Q(a[w])}for(let w=1;w<i;w++)l[w]==="text"&&!s[w]&&Ln(o[w])&&l[w-1]==="text"&&!u[w-1]&&(o[w-1]+=o[w],s[w-1]=s[w-1]||s[w],o[w]="");const y=Array.from({length:i},()=>null);let E=-1;for(let w=i-1;w>=0;w--){const A=o[w];if(A.length!==0){if(l[w]==="text"&&!s[w]&&E>=0&&l[E]==="text"&&(Cs(A)||A==="-"&&Ls(o[E]))){const O=y[E]??[];O.push(A),y[E]=O,c[E]=c[w],o[w]="";continue}E=w}}for(let w=0;w<i;w++){const A=y[w];A!=null&&(o[w]=$s(A,o[w]))}let C=0;for(let w=0;w<i;w++){const A=o[w];A.length!==0&&(C!==w&&(o[C]=A,s[C]=s[w],l[C]=l[w],c[C]=c[w]),C++)}o.length=C,s.length=C,l.length=C,c.length=C;const T=tl({len:C,texts:o,isWordLike:s,kinds:l,starts:c}),B=nl(Zs(el(Qs(Hs(js(T))))));for(let w=0;w<B.len-1;w++){const A=Os(B.texts[w]);A!==null&&(B.kinds[w]!=="space"&&B.kinds[w]!=="preserved-space"||B.kinds[w+1]!=="text"||!sr(B.texts[w+1])||(B.texts[w]=A.space,B.isWordLike[w]=!1,B.kinds[w]=B.kinds[w]==="preserved-space"?"preserved-space":"space",B.texts[w+1]=A.marks+B.texts[w+1],B.starts[w+1]=B.starts[w]+A.space.length))}return B}function ol(e,t){if(e.len===0)return[];if(!t.preserveHardBreaks)return[{startSegmentIndex:0,endSegmentIndex:e.len,consumedEndSegmentIndex:e.len}];const n=[];let r=0;for(let i=0;i<e.len;i++)e.kinds[i]==="hard-break"&&(n.push({startSegmentIndex:r,endSegmentIndex:i,consumedEndSegmentIndex:i+1}),r=i+1);return r<e.len&&n.push({startSegmentIndex:r,endSegmentIndex:e.len,consumedEndSegmentIndex:e.len}),n}function il(e,t,n){if(t.len<=1)return t;const r=[],i=[],o=[],a=[];let s=-1,l=!1;function c(u){r.push(t.texts[u]),i.push(t.isWordLike[u]),o.push("text"),a.push(t.starts[u])}function d(u,p){let m=!1;for(let y=u;y<p;y++)m=m||t.isWordLike[y];const g=t.starts[u],h=p<t.len?t.starts[p]:e.length;r.push(e.slice(g,h)),i.push(m),o.push("text"),a.push(g)}function f(u){if(!(s<0)){if(l)s+1===u?c(s):d(s,u);else for(let p=s;p<u;p++)c(p);s=-1,l=!1}}for(let u=0;u<t.len;u++){const p=t.texts[u],m=t.kinds[u];if(m==="text"){s>=0&&!no(t.texts[u-1],n)&&f(u),s<0&&(s=u),l=l||le(p);continue}f(u),r.push(p),i.push(t.isWordLike[u]),o.push(m),a.push(t.starts[u])}return f(t.len),{len:r.length,texts:r,isWordLike:i,kinds:o,starts:a}}function al(e,t,n="normal",r="normal"){const i=ls(n),o=i.mode==="pre-wrap"?ds(e):cs(e);if(o.length===0)return{normalized:o,chunks:[],len:0,texts:[],isWordLike:[],kinds:[],starts:[]};const a=rl(o,t,i),s=r==="keep-all"?il(o,a,t.breakKeepAllAfterPunctuation):a;return{normalized:o,chunks:ol(s,i),...s}}let Be=null;const fn=new Map;let Le=null;const sl=96,ll=new RegExp("\\p{Emoji_Presentation}","u"),cl=/[\p{Emoji_Presentation}\p{Extended_Pictographic}\p{Regional_Indicator}\uFE0F\u20E3]/u;let ut=null;const pn=new Map;function In(){if(Be!==null)return Be;if(typeof OffscreenCanvas<"u")return Be=new OffscreenCanvas(1,1).getContext("2d"),Be;if(typeof document<"u")return Be=document.createElement("canvas").getContext("2d"),Be;throw new Error("Text measurement requires OffscreenCanvas or a DOM canvas context.")}function dl(e){let t=fn.get(e);return t||(t=new Map,fn.set(e,t)),t}function xe(e,t){let n=t.get(e);return n===void 0&&(n={width:In().measureText(e).width,containsCJK:le(e)},t.set(e,n)),n}function We(){if(Le!==null)return Le;if(typeof navigator>"u")return Le={lineFitEpsilon:.005,carryCJKAfterClosingQuote:!1,breakKeepAllAfterPunctuation:!0,preferPrefixWidthsForBreakableRuns:!1,preferEarlySoftHyphenBreak:!1},Le;const e=navigator.userAgent,n=navigator.vendor==="Apple Computer, Inc."&&e.includes("Safari/")&&!e.includes("Chrome/")&&!e.includes("Chromium/")&&!e.includes("CriOS/")&&!e.includes("FxiOS/")&&!e.includes("EdgiOS/"),r=e.includes("Chrome/")||e.includes("Chromium/")||e.includes("CriOS/")||e.includes("Edg/");return Le={lineFitEpsilon:n?1/64:.005,carryCJKAfterClosingQuote:r,breakKeepAllAfterPunctuation:!n,preferPrefixWidthsForBreakableRuns:n,preferEarlySoftHyphenBreak:n},Le}function ul(e){const t=e.match(/(\d+(?:\.\d+)?)\s*px/);return t?parseFloat(t[1]):16}function io(){return ut===null&&(ut=new Intl.Segmenter(void 0,{granularity:"grapheme"})),ut}function fl(e){return ll.test(e)||e.includes("️")}function pl(e){return cl.test(e)}function xl(e,t){let n=pn.get(e);if(n!==void 0)return n;const r=In();r.font=e;const i=r.measureText("😀").width;if(n=0,i>t+.5&&typeof document<"u"&&document.body!==null){const o=document.createElement("span");o.style.font=e,o.style.display="inline-block",o.style.visibility="hidden",o.style.position="absolute",o.textContent="😀",document.body.appendChild(o);const a=o.getBoundingClientRect().width;document.body.removeChild(o),i-a>.5&&(n=i-a)}return pn.set(e,n),n}function hl(e){let t=0;const n=io();for(const r of n.segment(e))fl(r.segment)&&t++;return t}function ml(e,t){return t.emojiCount===void 0&&(t.emojiCount=hl(e)),t.emojiCount}function Fe(e,t,n){return n===0?t.width:t.width-ml(e,t)*n}function gl(e,t,n,r,i){if(t.breakableFitAdvances!==void 0&&t.breakableFitMode===i)return t.breakableFitAdvances;t.breakableFitMode=i;const o=io(),a=[];for(const d of o.segment(e))a.push(d.segment);if(a.length<=1)return t.breakableFitAdvances=null,t.breakableFitAdvances;if(i==="sum-graphemes"){const d=[];for(const f of a){const u=xe(f,n);d.push(Fe(f,u,r))}return t.breakableFitAdvances=d,t.breakableFitAdvances}if(i==="pair-context"||a.length>sl){const d=[];let f=null,u=0;for(const p of a){const m=xe(p,n),g=Fe(p,m,r);if(f===null)d.push(g);else{const h=f+p,y=xe(h,n);d.push(Fe(h,y,r)-u)}f=p,u=g}return t.breakableFitAdvances=d,t.breakableFitAdvances}const s=[];let l="",c=0;for(const d of a){l+=d;const f=xe(l,n),u=Fe(l,f,r);s.push(u-c),c=u}return t.breakableFitAdvances=s,t.breakableFitAdvances}function bl(e,t){const n=In();n.font=e;const r=dl(e),i=ul(e),o=t?xl(e,i):0;return{cache:r,fontSize:i,emojiCorrection:o}}function yl(){fn.clear(),pn.clear(),ut=null}function Sl(e){return e==="space"||e==="zero-width-break"||e==="soft-hyphen"}function Rt(e){return e==="space"||e==="preserved-space"||e==="tab"||e==="zero-width-break"||e==="soft-hyphen"}function Dn(e,t,n=e.widths.length){for(;t<n;){const r=e.kinds[t];if(!Sl(r))break;t++}return t}function ao(e,t){if(t<=0)return 0;const n=e%t;return Math.abs(n)<=1e-6?t:t-n}function so(e,t,n){return e.letterSpacing!==0&&t&&e.spacingGraphemeCounts[n]>0?e.letterSpacing:0}function Tn(e,t){return t===0?0:e+t}function wl(e,t){return e.letterSpacing!==0&&e.spacingGraphemeCounts[t]>0?e.letterSpacing:0}function lo(e,t,n,r,i){const o=t==="tab"?i+wl(e,n):e.lineEndFitAdvances[n];return Tn(r,o)}function Nt(e,t,n,r){const i=t==="tab"?0:e.lineEndFitAdvances[n];return Tn(r,i)}function At(e,t,n,r,i){const o=t==="tab"?i:e.lineEndPaintAdvances[n];return Tn(r,o)}function co(e,t,n){return e.letterSpacing!==0&&t?n+e.letterSpacing:n}function uo(e,t){return e.letterSpacing===0?t:t+e.letterSpacing}function Pe(e,t,n){let r=t;for(;r<e.length&&e[r]<n;)r++;return r}function Fl(e,t,n,r,i){if(e.letterSpacing===0)return 0;if(i>0)return e.spacingGraphemeCounts[r]>0?e.letterSpacing:0;for(let o=r-1;o>=t;o--){const a=e.kinds[o];if(!(a==="space"||a==="zero-width-break"||a==="hard-break")){if(a==="soft-hyphen"){if(o===r-1)return 0;continue}return o===t&&n>0||e.spacingGraphemeCounts[o]>0?e.letterSpacing:0}}return 0}function fo(e,t,n,r,i,o){return t+Fl(e,n,r,i,o)}function El(e,t){let n=0,r=e.chunks.length;for(;n<r;){const i=Math.floor((n+r)/2);t<e.chunks[i].consumedEndSegmentIndex?r=i:n=i+1}return n<e.chunks.length?n:-1}function po(e,t,n){let r=n.segmentIndex;if(n.graphemeIndex>0)return t;const i=e.chunks[t];return i.startSegmentIndex===i.endSegmentIndex&&r===i.startSegmentIndex||(r<i.startSegmentIndex&&(r=i.startSegmentIndex),r=Dn(e,r,i.endSegmentIndex),r<i.endSegmentIndex)?(n.segmentIndex=r,n.graphemeIndex=0,t):i.consumedEndSegmentIndex>=e.widths.length?-1:(n.segmentIndex=i.consumedEndSegmentIndex,n.graphemeIndex=0,t+1)}function On(e,t){if(t.segmentIndex>=e.widths.length)return-1;const n=El(e,t.segmentIndex);return n<0?-1:po(e,n,t)}function kl(e,t,n){if(n.segmentIndex>=e.widths.length)return-1;let r=t;for(;r<e.chunks.length&&n.segmentIndex>=e.chunks[r].consumedEndSegmentIndex;)r++;return r>=e.chunks.length?-1:po(e,r,n)}function Cl(e,t){return xo(e,t)}function Nl(e,t,n){const{widths:r,kinds:i,breakableFitAdvances:o,breakablePreferredBreaks:a}=e;if(r.length===0)return 0;const l=We().lineFitEpsilon,c=t+l;let d=0,f=0,u=!1,p=0,m=0,g=0,h=0,y=-1,E=0;function C(){y=-1,E=0}function T(L=g,v=h,I=f){d++,n==null||n(I,p,m,L,v),f=0,u=!1,C()}function B(L,v){u=!0,p=L,m=0,g=L+1,h=0,f=v}function w(L,v,I){u=!0,p=L,m=v,g=L,h=v+1,f=I}function A(L,v){if(!u){B(L,v);return}f+=v,g=L+1,h=0}function O(L,v){const I=o[L],$=a[L]??null;let P=$===null?-1:Pe($,0,v+1),x=-1,b=0,S=v;for(;S<I.length;){const F=I[S];if(!u)w(L,S,F);else if(f+F>c){if($!==null&&x>v){T(L,x,b),S=x,P=Pe($,P,S+1),x=-1,b=0;continue}T(),w(L,S,F)}else f+=F,g=L,h=S+1;const M=S+1;$!==null&&$[P]===M&&(x=M,b=f,P++),S++}u&&g===L&&h===I.length&&(g=L+1,h=0)}let N=0;for(;N<r.length&&!(!u&&(N=Dn(e,N),N>=r.length));){const L=r[N],v=i[N],I=Rt(v);if(!u){L>c&&o[N]!==null?O(N,0):B(N,L),I&&(y=N+1,E=f-L),N++;continue}if(f+L>c){if(I){A(N,L),T(N+1,0,f-L),N++;continue}if(y>=0){if(g>y||g===y&&h>0){T();continue}T(y,0,E);continue}if(L>c&&o[N]!==null){T(),O(N,0),N++;continue}T();continue}A(N,L),I&&(y=N+1,E=f-L),N++}return u&&T(),d}function xo(e,t,n){if(e.simpleLineWalkFastPath)return Nl(e,t,n);const{widths:r,kinds:i,breakableFitAdvances:o,breakablePreferredBreaks:a,discretionaryHyphenWidth:s,chunks:l}=e;if(r.length===0||l.length===0)return 0;const c=We(),d=c.lineFitEpsilon,f=t+d;let u=0,p=0,m=!1,g=0,h=0,y=0,E=0,C=-1,T=0,B=0,w=null;function A(){C=-1,T=0,B=0,w=null}function O(){return w==="soft-hyphen"&&C===y&&E===0?B:p}function N(b=y,S=E,F){u++,n!==void 0&&n(fo(e,F??O(),g,h,b,S),g,h,b,S),p=0,m=!1,A()}function L(b,S){m=!0,g=b,h=0,y=b+1,E=0,p=S}function v(b,S,F){m=!0,g=b,h=S,y=b,E=S+1,p=F}function I(b,S){if(!m){L(b,S);return}p+=S,y=b+1,E=0}function $(b,S,F,M,R,k){if(!S)return;const D=Nt(e,b,F,R),W=At(e,b,F,R,M);C=F+1,T=p-k+D,B=p-k+W,w=b}function P(b,S){const F=o[b],M=a[b]??null;let R=M===null?-1:Pe(M,0,S+1),k=-1,D=0,W=S;for(;W<F.length;){const _=F[W];if(!m)v(b,W,_);else{const ce=co(e,!0,_),ye=p+ce;if(uo(e,ye)>f){if(M!==null&&k>S){N(b,k,D),W=k,R=Pe(M,R,W+1),k=-1,D=0;continue}N(),v(b,W,_)}else p=ye,y=b,E=W+1}const te=W+1;M!==null&&M[R]===te&&(k=te,D=p,R++),W++}m&&y===b&&E===F.length&&(y=b+1,E=0)}function x(b){u++,n==null||n(0,b.startSegmentIndex,0,b.consumedEndSegmentIndex,0),A()}for(let b=0;b<l.length;b++){const S=l[b];if(S.startSegmentIndex===S.endSegmentIndex){x(S);continue}m=!1,p=0,g=S.startSegmentIndex,h=0,y=S.startSegmentIndex,E=0,A();let F=S.startSegmentIndex;for(;F<S.endSegmentIndex&&!(!m&&(F=Dn(e,F,S.endSegmentIndex),F>=S.endSegmentIndex));){const M=i[F],R=Rt(M),k=so(e,m,F),D=M==="tab"?ao(p+k,e.tabStopAdvance):r[F],W=k+D,_=lo(e,M,F,k,D);if(M==="soft-hyphen"){m&&(y=F+1,E=0,C=F+1,T=p+s,B=p+s,w=M),F++;continue}if(!m){_>f&&o[F]!==null?P(F,0):L(F,D),$(M,R,F,D,k,W),F++;continue}if(p+_>f){const ce=p+Nt(e,M,F,k),ye=p+At(e,M,F,k,D);if(w==="soft-hyphen"&&c.preferEarlySoftHyphenBreak&&T<=f){N(C,0,B);continue}if(R&&ce<=f){I(F,W),N(F+1,0,ye),F++;continue}if(C>=0&&T<=f){if(y>C||y===C&&E>0){N();continue}const _e=C;N(_e,0,B),F=_e;continue}if(_>f&&o[F]!==null){N(),P(F,0),F++;continue}N();continue}I(F,W),$(M,R,F,D,k,W),F++}if(m){const M=C===S.consumedEndSegmentIndex?B:p;N(S.consumedEndSegmentIndex,0,M)}}return u}function ho(e,t,n,r){const i=e.chunks[n];if(i.startSegmentIndex===i.endSegmentIndex)return t.segmentIndex=i.consumedEndSegmentIndex,t.graphemeIndex=0,0;const{widths:o,kinds:a,breakableFitAdvances:s,breakablePreferredBreaks:l,discretionaryHyphenWidth:c}=e,d=We(),f=d.lineFitEpsilon,u=r+f,p=t.segmentIndex,m=t.graphemeIndex;let g=0,h=!1,y=t.segmentIndex,E=t.graphemeIndex,C=-1,T=0,B=0,w=null;function A(){return w==="soft-hyphen"&&C===y&&E===0?B:g}function O(x=y,b=E,S=A()){return h?(t.segmentIndex=x,t.graphemeIndex=b,fo(e,S,p,m,x,b)):null}function N(x,b){h=!0,y=x+1,E=0,g=b}function L(x,b,S){h=!0,y=x,E=b+1,g=S}function v(x,b){if(!h){N(x,b);return}g+=b,y=x+1,E=0}function I(x,b,S,F,M,R){if(!b)return;const k=Nt(e,x,S,M),D=At(e,x,S,M,F);C=S+1,T=g-R+k,B=g-R+D,w=x}function $(x,b){const S=s[x],F=l[x]??null;let M=F===null?-1:Pe(F,0,b+1),R=-1,k=0;for(let D=b;D<S.length;D++){const W=S[D];if(!h)L(x,D,W);else{const te=co(e,!0,W),ce=g+te;if(uo(e,ce)>u)return F!==null&&R>b?O(x,R,k):O();g=ce,y=x,E=D+1}const _=D+1;F!==null&&F[M]===_&&(R=_,k=g,M++)}return h&&y===x&&E===S.length&&(y=x+1,E=0),null}function P(){return w!=="soft-hyphen"||C<0?null:T<=u?O(C,0,B):null}for(let x=t.segmentIndex;x<i.endSegmentIndex;x++){const b=a[x],S=Rt(b),F=x===t.segmentIndex?t.graphemeIndex:0,M=so(e,h,x),R=b==="tab"?ao(g+M,e.tabStopAdvance):o[x],k=M+R,D=lo(e,b,x,M,R);if(b==="soft-hyphen"&&F===0){h&&(y=x+1,E=0,C=x+1,T=g+c,B=g+c,w=b);continue}if(!h){if(F>0){const _=$(x,F);if(_!==null)return _}else if(D>u&&s[x]!==null){const _=$(x,0);if(_!==null)return _}else N(x,R);I(b,S,x,R,M,k);continue}if(g+D>u){const _=g+Nt(e,b,x,M),te=g+At(e,b,x,M,R);if(w==="soft-hyphen"&&d.preferEarlySoftHyphenBreak&&T<=u)return O(C,0,B);const ce=P();if(ce!==null)return ce;if(S&&_<=u)return v(x,k),O(x+1,0,te);if(C>=0&&T<=u)return y>C||y===C&&E>0?O():O(C,0,B);if(D>u&&s[x]!==null){const ye=O();if(ye!==null)return ye;const _e=$(x,0);if(_e!==null)return _e}return O()}v(x,k),I(b,S,x,R,M,k)}return C===i.consumedEndSegmentIndex&&E===0?O(i.consumedEndSegmentIndex,0,B):O(i.consumedEndSegmentIndex,0,g)}function Al(e,t,n){const{widths:r,kinds:i,breakableFitAdvances:o,breakablePreferredBreaks:a}=e,l=We().lineFitEpsilon,c=n+l;let d=0,f=!1,u=t.segmentIndex,p=t.graphemeIndex,m=-1,g=0;for(let h=t.segmentIndex;h<r.length;h++){const y=i[h],E=Rt(y),C=h===t.segmentIndex?t.graphemeIndex:0,T=o[h],B=r[h];if(!f){if(C>0||B>c&&T!==null){const w=T,A=a[h]??null;let O=A===null?-1:Pe(A,0,C+1),N=-1,L=0;const v=w[C];f=!0,d=v,u=h,p=C+1,A!==null&&A[O]===p&&(N=p,L=d,O++);for(let I=C+1;I<w.length;I++){const $=w[I];if(d+$>c)return A!==null&&N>C?(t.segmentIndex=h,t.graphemeIndex=N,L):(t.segmentIndex=u,t.graphemeIndex=p,d);d+=$,u=h,p=I+1,A!==null&&A[O]===p&&(N=p,L=d,O++)}u===h&&p===w.length&&(u=h+1,p=0)}else f=!0,d=B,u=h+1,p=0;E&&(m=h+1,g=d-B);continue}if(d+B>c)return E?(t.segmentIndex=h+1,t.graphemeIndex=0,d):m>=0?u>m||u===m&&p>0?(t.segmentIndex=u,t.graphemeIndex=p,d):(t.segmentIndex=m,t.graphemeIndex=0,g):(t.segmentIndex=u,t.graphemeIndex=p,d);d+=B,u=h+1,p=0,E&&(m=h+1,g=d-B)}return f?(t.segmentIndex=u,t.graphemeIndex=p,d):null}function mo(e,t,n,r){return e.simpleLineWalkFastPath?Al(e,t,r):ho(e,t,n,r)}function vt(e,t,n){const r=On(e,t);return r<0?null:mo(e,t,r,n)}function vl(e,t){if(e.widths.length===0)return{lineCount:0,maxLineWidth:0};const n={segmentIndex:0,graphemeIndex:0};let r=0,i=0;if(!e.simpleLineWalkFastPath){let o=On(e,n);for(;o>=0;){const a=ho(e,n,o,t);if(a===null)return{lineCount:r,maxLineWidth:i};r++,a>i&&(i=a),o=kl(e,o,n)}return{lineCount:r,maxLineWidth:i}}for(;;){const o=vt(e,n,t);if(o===null)return{lineCount:r,maxLineWidth:i};r++,o>i&&(i=o)}}let ft=null,xn=new WeakMap;function Ml(){return ft===null&&(ft=new Intl.Segmenter(void 0,{granularity:"grapheme"})),ft}function fr(e,t,n){let r=n.get(e);if(r!==void 0)return r;r=[];const i=Ml();for(const o of i.segment(t[e]))r.push(o.segment);return n.set(e,r),r}function Bl(e,t,n){return n>t&&e[n-1]==="soft-hyphen"}function pr(e,t,n,r){for(let i=n;i<r;i++)e+=t[i];return e}function go(e){let t=xn.get(e);return t!==void 0||(t=new Map,xn.set(e,t)),t}function bo(e,t,n,r,i,o){let a="";const s=Bl(e.kinds,n,i);for(let l=n;l<i;l++)if(!(e.kinds[l]==="soft-hyphen"||e.kinds[l]==="hard-break"))if(l===n&&r>0){const c=fr(l,e.segments,t);a=pr(a,c,r,c.length)}else a+=e.segments[l];if(o>0){s&&(a+="-");const l=fr(i,e.segments,t);a=pr(a,l,n===i?r:0,o)}else s&&(a+="-");return a}function Ll(){ft=null,xn=new WeakMap}let pt=null;function Pn(){return pt===null&&(pt=new Intl.Segmenter(void 0,{granularity:"grapheme"})),pt}function Il(e){return{widths:[],lineEndFitAdvances:[],lineEndPaintAdvances:[],kinds:[],simpleLineWalkFastPath:!0,segLevels:null,breakableFitAdvances:[],breakablePreferredBreaks:[],letterSpacing:0,spacingGraphemeCounts:[],discretionaryHyphenWidth:0,tabStopAdvance:0,chunks:[],segments:[]}}function Dl(e,t){const n=[];let r=[],i=0,o=!1,a=!1,s=!1;function l(){r.length!==0&&(n.push({text:r.length===1?r[0]:r.join(""),start:i}),r=[],o=!1,a=!1,s=!1)}function c(f,u,p){r=[f],i=u,o=p,a=dn(f),s=Tt.has(f)}function d(f,u){r.push(f),o=o||u;const p=dn(f);f.length===1&&Ae.has(f)?a=a||p:a=p,s=!1}for(const f of Pn().segment(e)){const u=f.segment,p=le(u);if(r.length===0){c(u,f.index,p);continue}if(s||Mn.has(u)||Ae.has(u)||t.carryCJKAfterClosingQuote&&p&&a){d(u,p);continue}if(!o&&!p){d(u,p);continue}l(),c(u,f.index,p)}return l(),n}function Tl(e,t,n){if(t.length<=1)return t;const r=[];let i=-1,o=!1;function a(l,c){const d=t[l].start,f=c<t.length?t[c].start:e.length;r.push({text:e.slice(d,f),start:d})}function s(l){if(!(i<0)){if(o)i+1===l?r.push(t[i]):a(i,l);else for(let c=i;c<l;c++)r.push(t[c]);i=-1,o=!1}}for(let l=0;l<t.length;l++){const c=t[l];i>=0&&!no(t[l-1].text,n)&&s(l),i<0&&(i=l),o=o||le(c.text)}return s(t.length),r}function xr(e,t){if(t==="zero-width-break"||t==="soft-hyphen"||t==="hard-break")return 0;if(t==="tab")return 1;let n=0;const r=Pn();for(const i of r.segment(e))n++;return n}function Ol(e){return e==="-"||e==="֊"||e==="‐"||e==="‒"||e==="–"||e==="—"}function Pl(e){if(!/[-\u058A\u2010\u2012\u2013\u2014]/u.test(e))return null;const t=[];let n=0;for(const r of Pn().segment(e))n++,Ol(r.segment)&&t.push(n);return t.length===0?null:t}function Rl(e,t,n){return t>1?e+(t-1)*n:e}function $l(e,t,n,r,i){const o=We(),{cache:a,emojiCorrection:s}=bl(t,pl(e.normalized)),l=Fe("-",xe("-",a),s)+(i===0?0:i*2),d=Fe(" ",xe(" ",a),s)*8,f=i!==0;if(e.len===0)return Il();const u=[],p=[],m=[],g=[];let h=e.chunks.length<=1&&!f;const y=n?[]:null,E=[],C=[],T=[],B=n?[]:null,w=Array.from({length:e.len});function A(v,I,$,P,x,b,S,F,M){x!=="text"&&x!=="space"&&x!=="zero-width-break"&&(h=!1),u.push(I),p.push($),m.push(P),g.push(x),y==null||y.push(b),E.push(S),C.push(F),f&&T.push(M),B!==null&&B.push(v)}function O(v,I,$,P,x){const b=xe(v,a),S=f?xr(v,I):0,F=Rl(Fe(v,b,s),S,i),M=I==="space"||I==="preserved-space"||I==="zero-width-break"?0:F,R=M===0?0:M+(S>0?i:0),k=I==="space"||I==="zero-width-break"?0:F;if(x&&P&&v.length>1){let D="sum-graphemes";i!==0?D="segment-prefixes":Ct(v)?D="pair-context":o.preferPrefixWidthsForBreakableRuns&&(D="segment-prefixes");const W=gl(v,b,a,s,D),_=W===null||r==="keep-all"?null:Pl(v);A(v,F,R,k,I,$,W,_,S);return}A(v,F,R,k,I,$,null,null,S)}for(let v=0;v<e.len;v++){w[v]=u.length;const I=e.texts[v],$=e.isWordLike[v],P=e.kinds[v],x=e.starts[v];if(P==="soft-hyphen"){A(I,0,l,l,P,x,null,null,0);continue}if(P==="hard-break"){A(I,0,0,0,P,x,null,null,0);continue}if(P==="tab"){A(I,0,0,0,P,x,null,null,f?xr(I,P):0);continue}const b=xe(I,a);if(P==="text"&&b.containsCJK){const S=Dl(I,o),F=r==="keep-all"?Tl(I,S,o.breakKeepAllAfterPunctuation):S;for(let M=0;M<F.length;M++){const R=F[M];O(R.text,"text",x+R.start,$,r==="keep-all"||!le(R.text))}continue}O(I,P,x,$,!0)}const N=Wl(e.chunks,w,u.length),L=y===null?null:is(e.normalized,y);return B!==null?{widths:u,lineEndFitAdvances:p,lineEndPaintAdvances:m,kinds:g,simpleLineWalkFastPath:h,segLevels:L,breakableFitAdvances:E,breakablePreferredBreaks:C,letterSpacing:i,spacingGraphemeCounts:T,discretionaryHyphenWidth:l,tabStopAdvance:d,chunks:N,segments:B}:{widths:u,lineEndFitAdvances:p,lineEndPaintAdvances:m,kinds:g,simpleLineWalkFastPath:h,segLevels:L,breakableFitAdvances:E,breakablePreferredBreaks:C,letterSpacing:i,spacingGraphemeCounts:T,discretionaryHyphenWidth:l,tabStopAdvance:d,chunks:N}}function Wl(e,t,n){const r=[];for(let i=0;i<e.length;i++){const o=e[i],a=o.startSegmentIndex<t.length?t[o.startSegmentIndex]:n,s=o.endSegmentIndex<t.length?t[o.endSegmentIndex]:n,l=o.consumedEndSegmentIndex<t.length?t[o.consumedEndSegmentIndex]:n;r.push({startSegmentIndex:a,endSegmentIndex:s,consumedEndSegmentIndex:l})}return r}function _l(e,t,n,r){const i=(r==null?void 0:r.wordBreak)??"normal",o=(r==null?void 0:r.letterSpacing)??0,a=al(e,We(),r==null?void 0:r.whiteSpace,i);return $l(a,t,n,i,o)}function ve(e,t,n){return _l(e,t,!0,n)}function zl(e,t,n){const r=Cl(e,t);return{lineCount:r,height:r*n}}function ql(e,t,n,r,i,o,a){return{text:bo(e,t,r,i,o,a),width:n,start:{segmentIndex:r,graphemeIndex:i},end:{segmentIndex:o,graphemeIndex:a}}}function jl(e,t,n,r,i){return{width:e,start:{segmentIndex:t,graphemeIndex:n},end:{segmentIndex:r,graphemeIndex:i}}}function Hl(e,t){return ql(e,go(e),t.width,t.start.segmentIndex,t.start.graphemeIndex,t.end.segmentIndex,t.end.graphemeIndex)}function Rn(e,t){return vl(e,t)}function Mt(e){let t=0;return xo(e,Number.POSITIVE_INFINITY,n=>{n>t&&(t=n)}),t}function Gl(e,t,n){const r=e,i={segmentIndex:t.segmentIndex,graphemeIndex:t.graphemeIndex},o=On(r,i);if(o<0)return null;const a=i.segmentIndex,s=i.graphemeIndex,l=mo(r,i,o,n);return l===null?null:jl(l,a,s,i.segmentIndex,i.graphemeIndex)}function hn(){fs(),pt=null,Ll(),yl()}function yo(e){ps(e),hn()}const Ul=(()=>{let e=null;return()=>e||(e=typeof OffscreenCanvas<"u"?new OffscreenCanvas(1,1).getContext("2d"):document.createElement("canvas").getContext("2d"),e)})();function Kl(){const e=navigator.platform||"";return/Win/i.test(e)?'"Segoe UI"':/Mac|iPhone|iPad/i.test(e)?'"Helvetica Neue"':'"DejaVu Sans"'}const hr=/\b(system-ui|-apple-system|BlinkMacSystemFont|ui-sans-serif|ui-serif|ui-monospace|ui-rounded)\b/i;function Bt(e,t){const n=getComputedStyle(e),r=[];let i=(t==null?void 0:t.fontFamily)??n.fontFamily??"serif";hr.test(i)&&(i=i.replace(hr,Kl()),r.push("system-ui stack resolved to a named face — widths may differ slightly"));const o=(t==null?void 0:t.sizePx)??(parseFloat(n.fontSize)||16),a=String((t==null?void 0:t.weight)??n.fontWeight??"400"),l=`${(t==null?void 0:t.italic)??n.fontStyle==="italic"?"italic ":""}${a==="400"||a==="normal"?"":`${a} `}${Vl(o)}px ${i}`.trim();if(!Yl(l))return null;let c=(t==null?void 0:t.lineHeightPx)??0;if(!c){const f=n.lineHeight;c=f&&f!=="normal"&&parseFloat(f)||0,c||(c=Math.round(o*1.4),r.push("line-height:normal — assumed size×1.4"))}let d=(t==null?void 0:t.letterSpacingPx)??0;if((t==null?void 0:t.letterSpacingPx)===void 0){const f=n.letterSpacing;if(f&&f!=="normal"){const u=parseFloat(f);Number.isFinite(u)&&/px\s*$/.test(f)?d=u:r.push(`letter-spacing "${f}" not in px — ignored`)}}return{font:l,sizePx:o,lineHeightPx:c,letterSpacingPx:d,degraded:r}}function Yl(e){const t=Ul();if(!t)return!1;try{t.font="10px monospace";const n=t.font;return t.font=e,t.font!==n||/^10px\s+monospace$/i.test(e)}catch{return!1}}function Vl(e){return Math.round(e*100)/100}function So(e){const t=getComputedStyle(e),n=[],r=t.whiteSpace,i=r==="normal"||r==="pre-wrap"?r:null;i||n.push(`white-space:${r} is outside pretext's contract`);const o=t.wordBreak,a=o==="normal"||o==="keep-all"?o:null;a||n.push(`word-break:${o} not modeled`),t.textTransform&&t.textTransform!=="none"&&n.push(`text-transform:${t.textTransform} changes rendered glyphs — measured on source text`),t.hyphens==="auto"&&n.push("hyphens:auto — browser may hyphenate where pretext will not"),t.textAlign==="justify"&&n.push("justified text — browser spacing diverges from measured widths");const s=t.wordSpacing;return s&&s!=="normal"&&parseFloat(s)!==0&&n.push(`word-spacing:${s} not modeled`),{inEnvelope:n.length===0&&!!i&&!!a,notes:n,whiteSpace:i,wordBreak:a}}const mn=ee("pretext");let gn=!1,mr=!1,bn;const Ee=new Map,Jl=400,wo=new Set;function Xl(e){wo.add(e)}async function Fo(){var e;if(!mr){mr=!0;const t=(e=document.documentElement.lang)==null?void 0:e.split("-")[0];if(t)try{yo(t),bn=t}catch{}try{document.fonts.addEventListener("loadingdone",()=>{Ee.clear(),hn(),mn.info("webfonts loaded late — pretext caches cleared");for(const n of wo)try{n()}catch(r){mn.warn("fonts invalidation hook threw",r)}})}catch{}window.addEventListener("pagehide",()=>{Ee.clear(),hn()})}if(!gn){try{await document.fonts.ready}catch{}gn=!0}}function Ql(){return gn}function Zl(){var t;Ee.clear();const e=(t=document.documentElement.lang)==null?void 0:t.split("-")[0];if(e&&e!==bn)try{yo(e),bn=e}catch{}}function gr(e,t,n){const r=`${t.font}\0${t.letterSpacingPx}\0${n.whiteSpace??"normal"}\0${n.wordBreak??"normal"}\0${e}`,i=Ee.get(r);if(i)return i;const o=ve(e,t.font,{...n,letterSpacing:t.letterSpacingPx||void 0});return Ee.size>=Jl&&Ee.clear(),Ee.set(r,o),o}function Eo(e){try{const t=document.querySelector(`[data-wp-uid="${CSS.escape(e)}"]`);if(t)return t}catch{}try{return document.querySelector(e)}catch{return null}}function ec(e){return(e.innerText||e.textContent||"").replace(/\s+/g," ").trim()}function Z(e){const t=getComputedStyle(e);return Math.max(1,e.clientWidth-(parseFloat(t.paddingLeft)||0)-(parseFloat(t.paddingRight)||0))}function tc(e,t){const n=Eo(e);if(!n)return{target:e,ok:!1,error:"no-target"};const r=So(n),i=r.whiteSpace==="pre-wrap"?n.textContent??"":ec(n);if(!i.trim())return{target:e,ok:!1,error:"no-target"};const o={whiteSpace:r.whiteSpace??"normal",wordBreak:r.wordBreak??"normal"},a=Bt(n);if(!a)return{target:e,ok:!1,error:"measurement-failed"};const s=Z(n);try{const l=gr(i,a,o),c=zl(l,s,a.lineHeightPx),d=Math.max(1,c.lineCount),f=[...r.notes,...a.degraded],u={target:e,ok:!0,current:{lines:d,heightPx:Math.round(d*a.lineHeightPx),widthPx:Math.round(s),font:a.font},naturalWidthPx:Math.ceil(Mt(l)),confidence:f.length===0?"exact":"degraded",envelopeNotes:f.length?f.slice(0,4):void 0,textSample:i.slice(0,60)};if(t){const p=Bt(n,t);if(!p)return{...u,ok:!1,error:"measurement-failed"};const m=t.widthPx??s,g=gr(i,p,o),h=Rn(g,m),y=Math.max(1,h.lineCount);u.predicted={lines:y,heightPx:Math.round(y*p.lineHeightPx),maxLineWidthPx:Math.ceil(h.maxLineWidth)},u.tightWidthPx=br(g,m,y),p.degraded.length&&(u.confidence="degraded",u.envelopeNotes=[...u.envelopeNotes??[],...p.degraded].slice(0,4))}else u.tightWidthPx=br(l,s,d);return u}catch(l){return mn.warn("measure failed",l),{target:e,ok:!1,error:"measurement-failed"}}}function br(e,t,n){let r=1,i=Math.ceil(t);for(;r<i;){const o=Math.floor((r+i)/2);Rn(e,o).lineCount<=n?i=o:r=o+1}return r}const nc=/[ \t\n\f\r]+/,yr=/^[ \t\n\f\r]+/,Sr=/[ \t\n\f\r]+$/,wr={segmentIndex:0,graphemeIndex:0},rc={itemIndex:0,segmentIndex:0,graphemeIndex:0};function Ht(e){return{segmentIndex:e.segmentIndex,graphemeIndex:e.graphemeIndex}}function Fr(e){return e.segmentIndex===0&&e.graphemeIndex===0}function at(e,t,n){const r=`${e}\0${t}`,i=n.get(r);if(i!==void 0)return i;const o=t===0?void 0:{letterSpacing:t},a=Mt(ve("A A",e,o)),s=Mt(ve("AA",e,o)),l=Math.max(0,a-s);return n.set(r,l),l}function oc(e){const t={segmentIndex:0,graphemeIndex:0},n=vt(e,t,Number.POSITIVE_INFINITY);return n===null?null:{endGraphemeIndex:t.graphemeIndex,endSegmentIndex:t.segmentIndex,width:n}}function ic(e,t){return e===0&&t>0}function ko(e){const t=[],n=Array.from({length:e.length}),r=new Map;let i=0;for(let o=0;o<e.length;o++){const a=e[o],s=a.letterSpacing??0,l=yr.test(a.text),c=Sr.test(a.text),d=a.text.replace(yr,"").replace(Sr,"");if(d.length===0){nc.test(a.text)&&i===0&&(i=at(a.font,s,r));continue}const f=i>0?i:l?at(a.font,s,r):0,u=ve(d,a.font,s===0?void 0:{letterSpacing:s}),p=oc(u);if(p===null){i=c?at(a.font,s,r):0;continue}const m={break:a.break??"normal",endGraphemeIndex:p.endGraphemeIndex,endSegmentIndex:p.endSegmentIndex,extraWidth:a.extraWidth??0,gapBefore:f,naturalWidth:p.width,prepared:u,sourceItemIndex:o};t.push(m),n[o]=m,i=c?at(a.font,s,r):0}return{items:t,itemsBySourceItemIndex:n}}function ac(e,t,n,r){if(e.items.length===0||n.itemIndex>=e.items.length)return null;const i=Math.max(1,t);let o=0,a=i,s=n.itemIndex;e:for(;s<e.items.length;){const l=e.items[s];if(!Fr(n)&&n.segmentIndex===l.endSegmentIndex&&n.graphemeIndex===l.endGraphemeIndex){s++,n.segmentIndex=0,n.graphemeIndex=0;continue}const c=o===0?0:l.gapBefore,d=Fr(n);if(l.break==="never"){if(!d){s++,n.segmentIndex=0,n.graphemeIndex=0;continue}const y=l.naturalWidth+l.extraWidth,E=c+y;if(o>0&&E>a)break e;r==null||r(l,c,y,Ht(wr),{segmentIndex:l.endSegmentIndex,graphemeIndex:l.endGraphemeIndex}),o+=E,a=Math.max(0,i-o),s++,n.segmentIndex=0,n.graphemeIndex=0;continue}const f=c+l.extraWidth;if(o>0&&f>=a)break e;if(d){const y=f+l.naturalWidth;if(y<=a){r==null||r(l,c,l.naturalWidth+l.extraWidth,Ht(wr),{segmentIndex:l.endSegmentIndex,graphemeIndex:l.endGraphemeIndex}),o+=y,a=Math.max(0,i-o),s++,n.segmentIndex=0,n.graphemeIndex=0;continue}}const u=Math.max(1,a-f),p={segmentIndex:n.segmentIndex,graphemeIndex:n.graphemeIndex},m=vt(l.prepared,p,u);if(m===null){s++,n.segmentIndex=0,n.graphemeIndex=0;continue}if(n.segmentIndex===p.segmentIndex&&n.graphemeIndex===p.graphemeIndex){s++,n.segmentIndex=0,n.graphemeIndex=0;continue}const g=m+l.extraWidth,h=c+g;if(o>0&&d&&h>a)break e;if(o>0&&d&&c>0&&ic(p.segmentIndex,p.graphemeIndex)){const y={segmentIndex:0,graphemeIndex:0};if(vt(l.prepared,y,Math.max(1,i-l.extraWidth))!==null&&(y.segmentIndex>p.segmentIndex||y.segmentIndex===p.segmentIndex&&y.graphemeIndex>p.graphemeIndex))break e}if(r==null||r(l,c,g,Ht(n),{segmentIndex:p.segmentIndex,graphemeIndex:p.graphemeIndex}),o+=h,a=Math.max(0,i-o),p.segmentIndex===l.endSegmentIndex&&p.graphemeIndex===l.endGraphemeIndex){s++,n.segmentIndex=0,n.graphemeIndex=0;continue}n.segmentIndex=p.segmentIndex,n.graphemeIndex=p.graphemeIndex;break}return o===0?null:(n.itemIndex=s,o)}function Co(e,t,n=rc){const r=e,i={itemIndex:n.itemIndex,segmentIndex:n.segmentIndex,graphemeIndex:n.graphemeIndex},o=[],a=ac(r,t,i,(s,l,c,d,f)=>{o.push({itemIndex:s.sourceItemIndex,gapBefore:l,occupiedWidth:c,start:d,end:f})});return a===null?null:{fragments:o,width:a,end:i}}function sc(e,t){return bo(e.prepared,go(e.prepared),t.start.segmentIndex,t.start.graphemeIndex,t.end.segmentIndex,t.end.graphemeIndex)}function lc(e,t){const n=e,r=[];for(let i=0;i<t.fragments.length;i++){const o=t.fragments[i],a=n.itemsBySourceItemIndex[o.itemIndex];if(a===void 0)throw new Error("Missing rich-text inline item for fragment");r.push({itemIndex:o.itemIndex,text:sc(a,o),gapBefore:o.gapBefore,occupiedWidth:o.occupiedWidth,start:o.start,end:o.end})}return{fragments:r,width:t.width,end:t.end}}const No=50;function Ao(e,t,n,r,i=0){const o=[];for(const a of e)n<=a.top-i||t>=a.bottom+i||o.push({left:a.left-r,right:a.right+r});return o}function cc(e,t,n=No){let r=[e];for(let i=0;i<t.length;i++){const o=t[i],a=[];for(let s=0;s<r.length;s++){const l=r[s];if(o.right<=l.left||o.left>=l.right){a.push(l);continue}o.left>l.left&&a.push({left:l.left,right:o.left}),o.right<l.right&&a.push({left:o.right,right:l.right})}r=a}return r.filter(i=>i.right-i.left>=n)}const Me=ee("typeset"),Er="p, h1, h2, h3, h4, blockquote",dc='img, svg, video, iframe, canvas, input, button, select, textarea, [contenteditable="true"], table, pre, code',kr=400,uc=.35,$n="[data-wp-obstacle]",J=new Map;async function fc(e){var T,B,w,A,O;await Fo(),xc();const t=pc(e.target);if(!t)return{ok:!1,error:"no-target",detail:`Nothing matched "${e.target}".`};if(hc(t),t.closest("form"))return{ok:!1,error:"out-of-envelope",detail:"The target is (inside) a <form> — typeset is for article prose only. Use CSS-tier moves here."};const n=new Set(e.moves),r=Math.min(((T=e.spec)==null?void 0:T.maxBlocks)??60,120),i=Math.min(Math.max(((B=e.spec)==null?void 0:B.dropCapLines)??3,2),5),o=Math.min(Math.max(((w=e.spec)==null?void 0:w.headlineMaxLines)??2,1),4),a=((A=e.spec)==null?void 0:A.wrap)==="single"||((O=e.spec)==null?void 0:O.wrap)==="both"?e.spec.wrap:"auto",s=Mo(t).slice(0,r);if(!s.length)return{ok:!1,error:"no-target",detail:`"${e.target}" matched a container with no typesettable prose (paragraphs/headings). The article's text likely lives in a different node — query_dom for the element that DIRECTLY holds the <p> tags and pass that selector.`};const l=t.querySelectorAll('input:not([type="hidden"]), select, textarea, [contenteditable="true"]').length;if(l>s.length)return{ok:!1,error:"out-of-envelope",detail:`This looks like an app surface (${l} form controls vs ${s.length} prose blocks), not an article. Typeset is for reading pages — use CSS-tier moves here.`};const c=`ts-${Date.now().toString(36)}`;mc(t,c);const d=[],f={moves:n,wrapMode:a,dropCapLines:i,headlineMaxLines:o,firstPara:!0,firstHeading:n.has("fit-headline")};for(const N of s){if(/^h[1-4]$/.test(N.tagName.toLowerCase())&&!gc(N))continue;const L=vo(N,f);if(!L)continue;const v=document.createElement("div");v.setAttribute("data-wp-ts",c),v.setAttribute("data-wp-ts-layer","1"),v.setAttribute("aria-hidden","true"),Mc(N,v),d.push({original:N,painted:v,...L})}if(!d.length)return Gt(c),{ok:!1,error:"measurement-failed",detail:"Every candidate block failed measurement — page fonts may be too exotic for typesetting. The page was left untouched."};let u=0,p=0,m=0;const g=Z(t),h=[];try{for(const N of d)N.original.insertAdjacentElement("afterend",N.painted),Bc(N.original,c);for(const N of d){const L=Z(N.painted)||g;if(L<120){yn(N);continue}const v=Io(N,L);u+=v.lines,p+=v.justified,m+=v.splitRows,h.push(N)}}catch(N){Me.warn("typeset paint threw — rolling the pass back",N);for(const L of d)yn(L);return Gt(c),{ok:!1,error:"measurement-failed",detail:"Typesetting failed mid-paint; the page was rolled back to its original state."}}if(!h.length)return Gt(c),{ok:!1,error:"out-of-envelope",detail:"Every block sits in a layout context too narrow to typeset — the page was left native."};d.length=0,d.push(...h);const y={tsId:c,container:t,blocks:d,lastWidth:g,frozen:!1,obstacles:[],observer:new ResizeObserver(()=>To(c)),onSelection:()=>{const N=J.get(c);N&&Oc(N)}};y.observer.observe(t),document.addEventListener("selectionchange",y.onSelection,{passive:!0}),J.set(c,y),Lc(y);const E=window;E.__wpStack=E.__wpStack||[],E.__wpStack.push({kind:"typeset",tsId:c});const C=document.querySelectorAll($n).length;return{ok:!0,achieved:{blocks:d.length,lines:u,justified:p,dropCap:f.capLetter,headlinePx:f.headlinePx,obstacles:C||void 0,splitRows:m||void 0,containerHeightPx:Math.round(t.getBoundingClientRect().height)}}}function vo(e,t){const n=/^h[1-4]$/.test(e.tagName.toLowerCase());let r=bc(e);if(!r.length)return null;const i=Bt(e);if(!i)return null;let o=i.sizePx,a=i.lineHeightPx;const s=t.envelope??(()=>{const h=So(e);return{whiteSpace:h.whiteSpace,wordBreak:h.wordBreak}})(),l=s.wordBreak==="keep-all"||s.whiteSpace==="pre-wrap",c=r.every(h=>h.font===r[0].font&&h.letterSpacing===r[0].letterSpacing&&h.color===r[0].color&&h.textDecoration===r[0].textDecoration),d=l&&c&&r.every(h=>!h.href);let f;if(n&&t.firstHeading&&(t.firstHeading=!1,f=t.headlineMaxLines,!d)){const h=t.fitWidthPx??Z(e),y=yc(r,o,h,t.headlineMaxLines);if(y&&y!==o){const E=y/o;r=r.map(C=>Lo(C,E)),a=Math.round(a*E),o=y,t.headlinePx=y}}let u;if(!n&&t.firstPara&&t.moves.has("dropcap")&&!d){t.firstPara=!1;const h=[...r[0].text][0]??"";if(new RegExp("\\p{L}|\\p{N}","u").test(h)){const y=Math.round(t.dropCapLines*a*.98),E=r[0].font.replace(/(\d+(?:\.\d+)?)px/,`${y}px`);try{const C=ve(h,E),T=Math.ceil(Mt(C))+Math.round(o*.35);r=[{...r[0],text:[...r[0].text].slice(1).join("").replace(/^\s+/,"")},...r.slice(1)].filter(B=>B.text),u={letter:h,widthPx:T,lines:t.dropCapLines},t.capLetter=h}catch{}}}else n||(t.firstPara=!1);let p;if(d){const h=s.whiteSpace==="pre-wrap"?e.textContent??"":r.map(y=>y.text).join("");try{p=kc(ve(h,r[0].font,{whiteSpace:s.whiteSpace??"normal",wordBreak:s.wordBreak??"normal",letterSpacing:r[0].letterSpacing||void 0}))}catch(y){return Me.warn("prepareWithSegments failed — block skipped",y),null}}else try{p=Ec(ko(r.map(Bo)))}catch(h){return Me.warn("prepareRichInline failed — block skipped",h),null}const m=getComputedStyle(e).direction==="rtl",g=n||m?"single":t.wrapMode;return{runs:r,mode:d?"core":"rich",source:p,rtl:m,lineHeightPx:a,sizePx:o,isHeading:n,justify:!n&&t.moves.has("justify"),wrap:g,cap:u,fit:f,envelope:s}}function Mo(e){return Array.from(e.querySelectorAll(Er)).filter(t=>!t.querySelector(Er)&&!t.querySelector(dc)&&!t.closest("[data-wp-ts]")&&(t.innerText||"").trim().length>0)}function pc(e){const t=Eo(e);let n=[];try{n=Array.from(document.querySelectorAll(e)).slice(0,8)}catch{}if(t&&!n.includes(t)&&n.unshift(t),n.length<=1)return t;let r=null,i=0;for(const o of n){const a=Mo(o).length;a>i&&(r=o,i=a)}return r??t}function Wn(e){document.querySelectorAll(`[data-wp-ts="${CSS.escape(e)}"][data-wp-ts-layer]`).forEach(t=>t.remove()),document.querySelectorAll(`[data-wp-ts="${CSS.escape(e)}"][data-wp-ts-orig], [data-wp-ts="${CSS.escape(e)}"][data-wp-ts-adj]`).forEach(t=>{const n=t.getAttribute("data-wp-ts-prev");n===null||n==="__none__"?t.removeAttribute("style"):t.setAttribute("style",n),t.removeAttribute("data-wp-ts"),t.removeAttribute("data-wp-ts-orig"),t.removeAttribute("data-wp-ts-adj"),t.removeAttribute("data-wp-ts-prev")})}function xc(){const e=new Set;document.querySelectorAll("[data-wp-ts]").forEach(t=>{const n=t.getAttribute("data-wp-ts");n&&e.add(n)});for(const t of e)J.has(t)||(Wn(t),Me.info("restored stale typeset from a previous session",{tsId:t}))}function hc(e){for(const t of Array.from(J.values())){const n=t.container;if(n!==e&&!n.contains(e)&&!e.contains(n))continue;$t(t),Wn(t.tsId);const r=window;r.__wpStack&&(r.__wpStack=r.__wpStack.filter(i=>!(i.kind==="typeset"&&i.tsId===t.tsId))),Me.info("refreshed prior typeset for re-run",{tsId:t.tsId})}}function mc(e,t){for(const n of Array.from(e.querySelectorAll("figure, table, aside, div, img"))){if(n.closest("[data-wp-ts-layer]"))continue;const r=getComputedStyle(n).cssFloat;r!=="left"&&r!=="right"||n.tagName==="DIV"&&!n.querySelector("img, figure, video, svg, picture")&&(n.innerText||"").length>=200||(n.setAttribute("data-wp-ts",t),n.setAttribute("data-wp-ts-adj","1"),n.setAttribute("data-wp-ts-prev",n.getAttribute("style")??"__none__"),n.style.setProperty("float","none","important"),n.style.setProperty("clear","both","important"),n.style.setProperty("margin-left","auto","important"),n.style.setProperty("margin-right","auto","important"),n.style.setProperty("max-width","100%","important"))}}function gc(e){const t=e.parentElement;if(t){const n=getComputedStyle(t).display;if(n.includes("flex")||n.includes("grid"))return!1}return Z(e)>=200}function yn(e){e.painted.remove();const t=e.original;if(!t.hasAttribute("data-wp-ts-orig"))return;const n=t.getAttribute("data-wp-ts-prev");n===null||n==="__none__"?t.removeAttribute("style"):t.setAttribute("style",n),t.removeAttribute("data-wp-ts"),t.removeAttribute("data-wp-ts-orig"),t.removeAttribute("data-wp-ts-prev")}function Gt(e){document.querySelectorAll(`[data-wp-ts="${CSS.escape(e)}"][data-wp-ts-adj]`).forEach(t=>{const n=t.getAttribute("data-wp-ts-prev");n===null||n==="__none__"?t.removeAttribute("style"):t.setAttribute("style",n),t.removeAttribute("data-wp-ts"),t.removeAttribute("data-wp-ts-adj"),t.removeAttribute("data-wp-ts-prev")})}function bc(e){const t=[],n=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);for(let r=n.nextNode();r;r=n.nextNode()){const i=r.parentElement;if(!i)continue;const o=(r.textContent||"").replace(/\s+/g," ");if(!o)continue;const a=Bt(i);if(!a)continue;const s=getComputedStyle(i),l=i.closest("a[href]");t.push({text:o,font:a.font,letterSpacing:a.letterSpacingPx,color:s.color,textDecoration:s.textDecorationLine!=="none"?s.textDecorationLine:"",href:l?l.href:null,sizePx:a.sizePx})}return t.length&&(t[0].text=t[0].text.replace(/^\s+/,""),t[t.length-1].text=t[t.length-1].text.replace(/\s+$/,"")),t.filter(r=>r.text)}function Bo(e){return{text:e.text,font:e.font,letterSpacing:e.letterSpacing||void 0}}function Lo(e,t){const n=Math.round(e.sizePx*t*10)/10;return{...e,sizePx:n,font:e.font.replace(/(\d+(?:\.\d+)?)px/,`${n}px`)}}function yc(e,t,n,r){const i=e.reduce((c,d)=>c+d.text.split(/\s+/).filter(Boolean).length,0),o=Math.max(1,Math.min(r,i)),a=c=>{try{const d=c/t,f=e.map(h=>Bo(Lo(h,d)));if(f.length===1){const h=ve(f[0].text,f[0].font,{letterSpacing:f[0].letterSpacing}),y=Rn(h,n);return y.lineCount<=o&&y.maxLineWidth<=n}const u=ko(f);let p,m=0,g=0;for(;;){const h=Co(u,n,p);if(!h)break;if(m++,g=Math.max(g,h.width),p=h.end,m>o)return!1}return m<=o&&g<=n}catch{return!1}};let s=Math.max(12,Math.round(t*.7)),l=Math.round(t*2.2);if(!a(s))return null;for(;s<l;){const c=Math.ceil((s+l+1)/2);if(a(c)?s=c:l=c-1,l-s<=0)break}return s}const Sc=12;function wc(e,t,n,r,i,o,a,s,l=!1){const c=l?{left:0,right:e-t}:{left:t,right:e},d=Ao(i,n,r,Sc);if(!d.length)return[{left:c.left,width:Math.max(40,c.right-c.left)}];const f=cc(c,d,No);if(!f.length)return[];const u=Math.max(72,4.5*a);if((o==="both"||o==="auto"&&f.length>=2&&f.every(g=>g.right-g.left>=u))&&f.length>=2)return[...f].sort((g,h)=>g.left-h.left).map(g=>({left:g.left,width:g.right-g.left}));const m=Fc(f,d);return m.right-m.left<s?[{left:c.left,width:Math.max(40,c.right-c.left)}]:[{left:m.left,width:m.right-m.left}]}function Fc(e,t){const n=t.reduce((r,i)=>r+(i.left+i.right)/2,0)/t.length;return e.reduce((r,i)=>{const o=r.right-r.left,a=i.right-i.left;if(a>o)return i;if(a<o)return r;const s=Math.abs((r.left+r.right)/2-n);return Math.abs((i.left+i.right)/2-n)>s?i:r})}function Ec(e){return{start:void 0,next:(t,n)=>Co(e,t,n),materialize:t=>lc(e,t)}}function kc(e){return{start:{segmentIndex:0,graphemeIndex:0},next:(n,r)=>Gl(e,r,n),materialize:n=>{const r=Hl(e,n);return{fragments:[{text:r.text,itemIndex:0,gapBefore:0}],width:r.width}}}}function Io(e,t,n=[]){const{source:r,runs:i,lineHeightPx:o,cap:a}=e,s=[];let l=r.start;const c=Math.max(80,4*e.sizePx);for(let h=0;;h++){const y=a&&h<a.lines?a.widthPx:0,E=wc(t,y,h*o,(h+1)*o,n,e.wrap,e.sizePx,c,e.rtl);if(!E.length){if(s.push([]),h>kr)break;continue}const C=[];let T=!1;for(const B of E){const w=r.next(B.width,l);if(!w){T=!0;break}C.push({raw:w,left:B.left,width:B.width}),l=w.end}if(C.length&&s.push(C),T||h>kr)break}for(;s.length&&s[s.length-1].length===0;)s.pop();const d=`${Math.round(t)}|${s.map(h=>h.length?h.map(y=>`${Math.round(y.left)},${Math.round(y.width)}`).join("+"):"_").join(";")}`;if(d===e.lastKey&&e.lastCounts)return e.lastCounts;if(e.lastKey=d,e.painted.textContent="",e.painted.style.position="relative",e.painted.style.direction=e.rtl?"rtl":"ltr",a){const h=document.createElement("span");h.textContent=a.letter;const y=Math.round(a.lines*o*.98);h.style.cssText=`position:absolute;${e.rtl?"right":"left"}:0;top:0;font:${i[0].font.replace(/(\d+(?:\.\d+)?)px/,`${y}px`)};line-height:${a.lines*o}px;color:${i[0].color};user-select:text;`,h.setAttribute("aria-hidden","true"),e.painted.appendChild(h)}let f=0,u=0,p=0;const m=s.length-1;for(let h=0;h<s.length;h++){const y=s[h],E=document.createElement("div"),C=w=>`height:${o}px;line-height:${o}px;white-space:pre;margin:0;margin-inline-start:${w>0?w:0}px;padding:0;border:0;background:none;text-indent:0;text-transform:none;text-align:start;`;if(!y.length){E.style.cssText=C(0),e.painted.appendChild(E);continue}p++,y.length>=2&&u++;const T=y[0],B=e.rtl?Math.max(0,t-(T.left+T.width)):T.left;E.style.cssText=`${C(B)}${y.length>1?"position:relative;":""}`;for(let w=0;w<y.length;w++){const A=y[w],O=r.materialize(A.raw),N=O.fragments[O.fragments.length-1];N&&(N.text=N.text.replace(/ +$/,""));const L=h===m&&w===y.length-1,v=w<y.length-1;let I=0;if(!L&&(v||e.justify)){let P=0;for(const b of O.fragments)P+=vc(b.text),b.gapBefore>0&&P++;const x=A.width-O.width;if(P>0&&x>0){const b=x/P;b<=uc*e.sizePx&&(I=b,f++)}}let $=E;if(w>0){const P=document.createElement("span");P.style.cssText=`position:absolute;left:${A.left-T.left}px;top:0;height:${o}px;line-height:${o}px;white-space:pre;margin:0;padding:0;border:0;background:transparent;text-indent:0;text-transform:none;text-align:start;`,E.appendChild(P),$=P}for(const P of O.fragments){const x=i[P.itemIndex];if(!x)continue;const b=document.createElement(x.href?"a":"span");x.href&&(b.href=x.href),b.textContent=P.text;const S=P.gapBefore>0?(P.gapBefore+(I||0)).toFixed(3):"0";b.style.cssText=`font:${x.font};color:${x.color};margin:0;margin-inline-start:${S}px;padding:0;border:0;background:transparent;display:inline;text-transform:none;${x.letterSpacing?`letter-spacing:${x.letterSpacing}px;`:""}${x.textDecoration?`text-decoration:${x.textDecoration};`:"text-decoration:none;"}${I?`word-spacing:${I.toFixed(3)}px;`:"word-spacing:0;"}`,$.appendChild(b)}}e.painted.appendChild(E)}a&&s.length<a.lines&&(e.painted.style.minHeight=`${a.lines*o}px`);const g={lines:p,justified:f,splitRows:u};return e.lastCounts=g,g}function _n(e,t,n){const r=t.painted;if(!r.isConnected)return;const i=n??e.container.getBoundingClientRect(),o=r.getBoundingClientRect(),a=getComputedStyle(r),s=o.left-i.left+(parseFloat(a.paddingLeft)||0),l=o.top-i.top+(parseFloat(a.paddingTop)||0),c=e.obstacles.map(d=>({left:d.left-s,right:d.right-s,top:d.top-l,bottom:d.bottom-l}));Io(t,Z(r)||Z(e.container),c)}let Ut;function Do(){Ut===void 0&&(Ut=requestAnimationFrame(()=>{Ut=void 0,Nc()}))}function Cc(){if(J.size){for(const e of J.values())e.fontsDirty=!0;Do()}}function Nc(){for(const e of Array.from(J.values()))e.fontsDirty&&(e.frozen||(e.fontsDirty=!1,e.blocks.some(t=>t.painted.isConnected)&&Ac(e)))}function Ac(e){var i;const t=e.container.getBoundingClientRect(),n=[];let r=0;for(const o of e.blocks){if(!o.painted.isConnected){n.push(o);continue}const a={moves:new Set([...o.justify?["justify"]:[],...o.cap?["dropcap"]:[]]),wrapMode:o.wrap,dropCapLines:((i=o.cap)==null?void 0:i.lines)??3,headlineMaxLines:o.fit??2,firstPara:!!o.cap,firstHeading:o.fit!==void 0,fitWidthPx:Z(o.painted)||Z(e.container),envelope:o.envelope},s=vo(o.original,a);if(!s){yn(o),Me.warn("font rebuild failed — block restored to native rendering",{tsId:e.tsId,block:o.original.tagName.toLowerCase()});continue}Object.assign(o,s),o.lastKey=void 0,o.lastCounts=void 0,_n(e,o,t),n.push(o),r++}e.blocks=n,Me.info("rebuilt typeset after late font load",{tsId:e.tsId,rebuilt:r,blocks:n.length})}Xl(Cc);function vc(e){let t=0;for(let n=0;n<e.length;n++)e[n]===" "&&t++;return t}function Mc(e,t){const n=getComputedStyle(e);t.style.margin=`${n.marginTop} ${n.marginRight} ${n.marginBottom} ${n.marginLeft}`,t.style.padding=`${n.paddingTop} ${n.paddingRight} ${n.paddingBottom} ${n.paddingLeft}`}function Bc(e,t){e.setAttribute("data-wp-ts",t),e.setAttribute("data-wp-ts-orig","1"),e.setAttribute("data-wp-ts-prev",e.getAttribute("style")??"__none__");const n=e.style;n.setProperty("position","absolute","important"),n.setProperty("width","1px","important"),n.setProperty("height","1px","important"),n.setProperty("margin","-1px","important"),n.setProperty("padding","0","important"),n.setProperty("overflow","hidden","important"),n.setProperty("clip","rect(0 0 0 0)","important"),n.setProperty("white-space","nowrap","important"),n.setProperty("border","0","important")}function Lc(e){let t=0,n=[];const r=()=>{if(!e.blocks.some(a=>a.painted.isConnected)){$t(e);return}if(e.raf=requestAnimationFrame(r),e.frozen||(t++%20===0&&(n=Array.from(document.querySelectorAll($n))),!n.length&&!e.obstacles.length))return;const i=e.container.getBoundingClientRect(),o=[];for(const a of n){if(!a.isConnected)continue;const s=a.getBoundingClientRect();s.width<=0||s.height<=0||s.right<i.left||s.left>i.right||s.bottom<i.top||s.top>i.bottom||o.push({left:s.left-i.left,top:s.top-i.top,right:s.right-i.left,bottom:s.bottom-i.top})}if(Ic(e.obstacles,o)){e.obstacles=o;for(const a of e.blocks)_n(e,a,i)}};e.raf=requestAnimationFrame(r)}function Ic(e,t){if(e.length!==t.length)return!0;for(let n=0;n<t.length;n++){const r=e[n],i=t[n];if(Math.abs(r.left-i.left)>1.5||Math.abs(r.top-i.top)>1.5||Math.abs(r.right-i.right)>1.5||Math.abs(r.bottom-i.bottom)>1.5)return!0}return!1}function $t(e){e.raf&&cancelAnimationFrame(e.raf),e.observer.disconnect(),document.removeEventListener("selectionchange",e.onSelection),J.delete(e.tsId)}function Dc(){const e=window;for(const t of Array.from(J.values()))$t(t),Wn(t.tsId),e.__wpStack&&(e.__wpStack=e.__wpStack.filter(n=>!(n.kind==="typeset"&&n.tsId===t.tsId)))}function Cr(e){const t=e.className&&typeof e.className=="string"?e.className.split(/\s+/).filter(Boolean)[0]:"";return`${e.tagName.toLowerCase()}${e.id?`#${e.id}`:""}${t?`.${t}`:""}`}function Tc(){const e=Array.from(J.values()).filter(r=>r.blocks.some(i=>i.painted.isConnected)),t=[];for(const r of e){const i=r.blocks.filter(o=>o.painted.isConnected).map(o=>o.painted.getBoundingClientRect());i.length&&t.push({container:Cr(r.container),blocks:r.blocks.length,columnLeftPx:Math.round(Math.min(...i.map(o=>o.left))),columnRightPx:Math.round(Math.max(...i.map(o=>o.right))),proseTopPx:Math.round(Math.min(...i.map(o=>o.top))+window.scrollY),proseBottomPx:Math.round(Math.max(...i.map(o=>o.bottom))+window.scrollY)})}const n=[];for(const r of Array.from(document.querySelectorAll($n))){const i=r.getBoundingClientRect(),o={el:Cr(r),rect:{left:Math.round(i.left),top:Math.round(i.top),width:Math.round(i.width),height:Math.round(i.height)},intersectsProse:!1,linesDisplaced:0};if(i.width<=0||i.height<=0){o.hint="zero-size or hidden — it can never displace text",n.push(o);continue}for(const a of e)for(const s of a.blocks){if(!s.painted.isConnected)continue;const l=s.painted.getBoundingClientRect();if(i.right<=l.left||i.left>=l.right||i.bottom<=l.top||i.top>=l.bottom)continue;o.intersectsProse=!0;const c=getComputedStyle(s.painted),d=l.left+(parseFloat(c.paddingLeft)||0),f=l.top+(parseFloat(c.paddingTop)||0),u={left:i.left-d,top:i.top-f,right:i.right-d,bottom:i.bottom-f},p=Z(s.painted),m=Math.max(1,Math.ceil(l.height/s.lineHeightPx));for(let g=0;g<m;g++){const h=Ao([u],g*s.lineHeightPx,(g+1)*s.lineHeightPx,12);h.length&&h.some(y=>y.left<p&&y.right>0)&&o.linesDisplaced++}}if(o.intersectsProse)o.linesDisplaced||(o.hint="overlaps prose but displaces no lines — likely wider than the carve can honor (band degrades to full measure)");else{const a=t[0];a?i.left>=a.columnRightPx?o.hint=`sits RIGHT of the text column (column x ${a.columnLeftPx}–${a.columnRightPx}) — move it left into the prose`:i.right<=a.columnLeftPx?o.hint=`sits LEFT of the text column (column x ${a.columnLeftPx}–${a.columnRightPx}) — move it right into the prose`:o.hint=`vertically outside the prose (prose spans page-y ${a.proseTopPx}–${a.proseBottomPx}) — it is over figures/margins/chrome where nothing moves`:o.hint="no active typeset — run typeset first; obstacles displace typeset text only"}n.push(o)}return{typesets:t,obstacles:n}}function To(e){const t=J.get(e);!t||t.relayoutQueued||(t.relayoutQueued=!0,requestAnimationFrame(()=>{const n=J.get(e);if(!n)return;if(n.relayoutQueued=!1,!n.blocks.some(o=>o.painted.isConnected)){$t(n);return}if(n.frozen)return;const r=Z(n.container);if(Math.abs(r-n.lastWidth)<1)return;n.lastWidth=r;const i=n.container.getBoundingClientRect();for(const o of n.blocks)_n(n,o,i)}))}function Oc(e){const t=e.frozen,n=document.getSelection();if(!n||n.isCollapsed)e.frozen=!1;else{const r=n.anchorNode,i=n.focusNode;e.frozen=e.blocks.some(o=>!!r&&o.painted.contains(r)||!!i&&o.painted.contains(i))}t&&!e.frozen&&(e.fontsDirty?Do():To(e.tsId))}const Kt=ee("pretext-bridge");function Pc(){chrome.runtime.onMessage.addListener((e,t,n)=>{if((e==null?void 0:e.type)==="pretext-status"){const r={ok:!0,version:ts,fontsReady:Ql()};return n(r),!1}if((e==null?void 0:e.type)==="pretext-measure")return Rc(e).then(n).catch(r=>{Kt.warn("measure failed",r),n({ok:!1,error:"measurement-failed"})}),!0;if((e==null?void 0:e.type)==="pretext-reflow-status"){try{n({ok:!0,report:Tc()})}catch(r){Kt.warn("reflow-status failed",r),n({ok:!1})}return!1}return(e==null?void 0:e.type)==="pretext-typeset"?(fc(e).then(n).catch(r=>{Kt.warn("typeset failed",r),n({ok:!1,error:"measurement-failed",detail:String(r)})}),!0):!1})}async function Rc(e){await Fo();const t=(e.targets??[]).slice(0,12);return t.length?{ok:!0,results:t.map(n=>tc(n,e.candidate))}:{ok:!1,error:"no-target"}}const Nr=ee("spa-watch"),$c=2e3;let Ar=!1;function Wc(e){var o;if(Ar)return;Ar=!0;let t=location.href,n=!1;const r=()=>{n||(n=!0,setTimeout(()=>{if(n=!1,location.href!==t){t=location.href,Nr.info("route change",{href:location.href});try{e()}catch(a){Nr.warn("route-change handler threw",a)}}},0))},i=a=>{const s=history[a];history[a]=function(...l){const c=s.apply(this,l);return r(),c}};try{i("pushState"),i("replaceState")}catch{}window.addEventListener("popstate",r,{passive:!0}),window.addEventListener("hashchange",r,{passive:!0});try{(o=window.navigation)==null||o.addEventListener("navigatesuccess",r)}catch{}setInterval(r,$c)}const ke="srf-highlight",Ce="srf-highlight-secondary",vr="srf-highlight-styles",_c=`
.${ke}, .${Ce} {
  background: transparent;
  position: relative;
  border-radius: 2px;
  transition: background 0.2s;
}
.${ke} {
  background: rgba(255, 220, 50, 0.4);
  outline: 1.5px solid rgba(220, 180, 0, 0.5);
  outline-offset: 1px;
}
.${Ce} {
  background: rgba(100, 160, 255, 0.2);
  outline: 1.5px solid rgba(80, 130, 220, 0.35);
  outline-offset: 1px;
}
.${ke}::after, .${Ce}::after {
  content: attr(data-srf-reason);
  position: absolute;
  bottom: calc(100% + 4px);
  left: 0;
  background: #1a1a1a;
  color: #fff;
  font-size: 11px;
  line-height: 1.4;
  padding: 4px 8px;
  border-radius: 5px;
  white-space: nowrap;
  max-width: 240px;
  overflow: hidden;
  text-overflow: ellipsis;
  pointer-events: none;
  opacity: 0;
  transform: translateY(3px);
  transition: opacity 0.15s, transform 0.15s;
  z-index: 2147483647;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}
.${ke}:hover::after, .${Ce}:hover::after {
  opacity: 1;
  transform: translateY(0);
}
`;function zn(){if(document.getElementById(vr))return;const e=document.createElement("style");e.id=vr,e.textContent=_c,document.head.appendChild(e)}function Oo(){document.querySelectorAll(`.${ke}, .${Ce}`).forEach(e=>{const t=e.parentNode;if(t){for(;e.firstChild;)t.insertBefore(e.firstChild,e);t.removeChild(e),t.normalize()}})}const Po=new Set(["SCRIPT","STYLE","NOSCRIPT","IFRAME","TEXTAREA","INPUT","SELECT","CODE","PRE"]);function zc(e,t,n,r){if(t.length<6)return!1;const i=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode(a){const s=a.parentElement;if(!s||s.classList.contains(ke)||s.classList.contains(Ce)||Po.has(s.tagName))return NodeFilter.FILTER_REJECT;const l=window.getComputedStyle(s);return l.display==="none"||l.visibility==="hidden"?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}});let o;for(;o=i.nextNode();){const s=(o.textContent??"").indexOf(t);if(s===-1)continue;const l=document.createElement("mark");l.className=n,l.setAttribute("data-srf-reason",r);const c=document.createRange();return c.setStart(o,s),c.setEnd(o,s+t.length),c.surroundContents(l),!0}return!1}function qc(e){zn();let t=0;for(const n of e){const r=n.relevance==="primary"?ke:Ce;zc(document.body,n.text,r,n.reason)&&t++}return t}function jc(e=15e3){var o;const t=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(a){const s=a.parentElement;if(!s||Po.has(s.tagName))return NodeFilter.FILTER_REJECT;const l=window.getComputedStyle(s);return l.display==="none"||l.visibility==="hidden"?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),n=[];let r=0,i;for(;(i=t.nextNode())&&r<e;){const a=((o=i.textContent)==null?void 0:o.trim())??"";a.length>1&&(n.push(a),r+=a.length)}return n.join(" ").slice(0,e)}const Ie=ee("image-video");let De=null,Yt=!1;async function Hc(){if(De)return De;const{srf_image_video_enabled:e}=await chrome.storage.local.get("srf_image_video_enabled");if(e!==!0)return Ie.info("Image→Video enhancer disabled via flag (srf_image_video_enabled !== true)"),()=>{};Yt=!0,Ie.info("Image→Video enhancer ENABLED — starting isolated module");const t=[],n=()=>{Yt&&(Ie.info(`Tearing down Image→Video enhancer. Restoring ${t.length} images...`),t.length=0,Yt=!1,De=null,Ie.info("Image→Video enhancer fully torn down — page should be back to original state"))};return De=n,Ie.info("Image→Video enhancer skeleton installed (no changes yet — safe)"),n}try{chrome.storage.onChanged.addListener(e=>{"srf_image_video_enabled"in e&&e.srf_image_video_enabled.newValue!==!0&&De&&(Ie.info("srf_image_video_enabled turned off — tearing down"),De())})}catch{}const H=ee("main");window.__wpMainLoaded=!0;let j=null,U=null,Ne=null,de=!0,Ye=null,Ve=null,Vt=null;async function Ro(){if(Ja(),(await chrome.storage.local.get("srf_enabled")).srf_enabled===!1){H.info("Extension initially disabled via master switch — skipping content injection");return}eo(),Qa(),to(),es();const t=Tr();if(t){await Sn(t);return}xi(async n=>{(await chrome.storage.local.get("srf_enabled")).srf_enabled!==!1&&await Sn(n)},12e4)}async function Sn(e){var n;U=e,j=Or(e),chrome.runtime.sendMessage({type:"chatbot-detected",payload:e}),Lt("detect",e.hostname,{platform:e.platform,category:he(e.hostname),meta:{confidence:e.confidence,detectedType:e.adapter==="Generic"?"heuristic":e.confidence>=90?"known":"widget"}}),e.adapter==="Generic"&&Lt("new_chatbot_candidate",e.hostname,{platform:e.platform,meta:{detectedType:"heuristic"}});const t=await chrome.runtime.sendMessage({type:"get-auth-state"});if(!((n=t==null?void 0:t.payload)!=null&&n.authenticated)){Gn(e,{enabled:!1,signedIn:!1,adapter:j,onToggle:()=>{}});return}de=!0,!Ve&&j&&(Ve=Ni(j)),await ge(),Gn(e,{enabled:de,signedIn:!0,adapter:j,onToggle:Uc}),Gc(),await An({adapter:j,onChange:async()=>{await ge()}})}async function ge(){var n;if(!U||!j)return;const e=he(U.hostname),t=await chrome.runtime.sendMessage({type:"get-meta-prompt",payload:{hostname:U.hostname,category:e}});Ne=((n=t==null?void 0:t.payload)==null?void 0:n.prompt)??null,Ne?H.info("prompt cached",{bytes:Ne.length,sections:t.payload.sections}):H.warn("no prompt cached — interceptor will pass through")}function Gc(){Ye||j&&(Ye=Ii({adapter:j,getPrompt:()=>Ne,isEnabled:()=>de,onAugmented:()=>{de=!1,En(!1),hi('<span class="srf-tooltip-strong">Profile sent</span><br><span class="srf-tooltip-dim">Disarmed — click to re-arm</span>',2800),U&&j&&Lt("fire",U.hostname,{platform:j.name,category:he(U.hostname),meta:{promptBytes:(Ne==null?void 0:Ne.length)??0,compiled:!1}})}}))}async function Uc(e){de=e,En(e),U&&j&&Lt(e?"arm":"disarm",U.hostname,{platform:j.name,meta:e?void 0:{reason:"manual"}}),e&&await ge()}function Lt(e,t,n={}){try{Vt||(Vt=crypto.randomUUID());const r={kind:e,hostname:t,platform:n.platform,category:n.category,ts:Date.now(),sessionId:Vt,meta:n.meta};chrome.runtime.sendMessage({type:"telemetry-event",payload:r})}catch(r){H.warn("telemetry emit failed",r)}}chrome.runtime.onMessage.addListener((e,t,n)=>{var r;return(e==null?void 0:e.type)==="inject-prompt"?(Kc((r=e.payload)==null?void 0:r.prompt).then(n),!0):(e==null?void 0:e.type)==="auto-inject-toggled"?(de=e.payload.enabled,En(de),de&&ge(),n({success:!0}),!1):(e==null?void 0:e.type)==="get-armed-state"?(n({armed:de}),!1):(e==null?void 0:e.type)==="srf-teardown"?($o(),n({success:!0}),!1):((e==null?void 0:e.type)==="cards-prefs-changed"&&(j&&U&&(ge(),An({adapter:j,onChange:async()=>{await ge()}})),n({success:!0})),!1)});function $o(){Ye&&(Ye(),Ye=null),Ve&&(Ve(),Ve=null),ja(),mi();try{sn()}catch(e){H.warn("Failed to reset styles on teardown",e)}try{Kr()}catch(e){H.warn("Failed to teardown Grok X-Feed",e)}H.info("teardown complete")}async function Kc(e){if(!e)return{success:!1,error:"no prompt"};if(!j){const i=Tr();i&&(U=i,j=Or(i))}if(!j)return{success:!1,error:"no adapter — chatbot not detected"};const t=j.getInput();if(!t)return{success:!1,error:"input field not found"};const n=t instanceof HTMLTextAreaElement?t.value:t.textContent??"",r=n?`${e}

---

${n}`:e;try{return await j.injectText(r),{success:!0,supportsAttachmentCard:j.supportsAttachmentCard??!1,platform:j.name}}catch(i){return{success:!1,error:i instanceof Error?i.message:String(i)}}}try{chrome.storage.onChanged.addListener(async e=>{if("srf_enabled"in e&&(e.srf_enabled.newValue!==!1?(H.info("Master switch turned ON — re-initializing extension content scripts"),U?await Sn(U):await Ro(),Nn(!0).catch(i=>H.warn("auto-polish restoration failed",i))):(H.info("Master switch turned OFF — tearing down extension content scripts"),$o())),!j||!U)return;`srf_card_prefs_${U.hostname.replace(/^www\./,"")}`in e&&(ge(),An({adapter:j,onChange:async()=>{await ge()}}))})}catch{}la();Pc();Wc(()=>{Dc(),Zl()});Ro().catch(e=>H.error("init",e));Nn().catch(e=>H.warn("auto-polish",e));Na().catch(e=>H.warn("onboarding guide",e));La().catch(e=>H.warn("autofill",e));_a().catch(e=>H.warn("light-dom",e));Ur().catch(e=>H.warn("grok-x-feed",e));async function Wo(){var n;const e=await chrome.storage.local.get(["srf_enabled","srf_highlight_enabled"]);if(e.srf_enabled===!1||e.srf_highlight_enabled===!1||U)return;const t=jc();if(t.trim()){Oo(),zn();try{const r=await chrome.runtime.sendMessage({type:"surface-analyze-page",payload:{pageText:t,pageUrl:location.href}});if((n=r==null?void 0:r.targets)!=null&&n.length){const i=qc(r.targets);H.info("Webpaper highlights applied",{count:i,total:r.targets.length})}}catch(r){H.warn("Webpaper highlights failed",r)}}}chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type==="surface-clear-highlights"){Oo(),n({success:!0});return}if(e.type==="surface-run-highlights")return Wo().then(()=>n({success:!0})).catch(()=>n({success:!1})),!0});zn();setTimeout(()=>{Wo().catch(e=>H.warn("Webpaper highlights init",e))},1500);Hc().catch(e=>H.warn("image-video enhancer failed to start",e));export{z as S};
