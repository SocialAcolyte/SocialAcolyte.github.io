const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/snapshot-capture-Dc_gV2El.js","assets/profile-markers-BUHYoXfg.js","assets/card-types-u4cCMT4q.js","assets/logger-DShRSVht.js","assets/onboarding-types-BOQBz6-q.js"])))=>i.map(i=>d[i]);
import{h as Ie}from"./profile-markers-BUHYoXfg.js";import{a as Yt,C as Lo,i as Ao,c as J,_ as Kt}from"./card-types-u4cCMT4q.js";import{createLogger as Q}from"./logger-DShRSVht.js";import{S as Io}from"./onboarding-types-BOQBz6-q.js";async function Pe(e,t){const o={injected:!1,attachmentLikely:!1,copiedToClipboard:!1};return o.copiedToClipboard=await Fo(t),e.focus(),Mo(e,t)||$o(e,t)?(o.injected=!0,o.attachmentLikely=!0,o):(Xt(e,t),o.injected=!0,o)}function Mo(e,t){try{const o=new DataTransfer;o.setData("text/plain",t),o.setData("text/html",_o(t).replace(/\n/g,"<br>"));const n=new ClipboardEvent("paste",{clipboardData:o,bubbles:!0,cancelable:!0});return!e.dispatchEvent(n)}catch{return!1}}function $o(e,t){try{const o=new DataTransfer;o.setData("text/plain",t);const n=new InputEvent("beforeinput",{inputType:"insertFromPaste",data:t,dataTransfer:o,bubbles:!0,cancelable:!0});return!e.dispatchEvent(n)}catch{return!1}}function qo(e,t){try{e.focus(),e.dispatchEvent(new FocusEvent("focus",{bubbles:!0}));const o=new KeyboardEvent("keydown",{key:"Unidentified",code:"Unidentified",bubbles:!0,cancelable:!0});e.dispatchEvent(o);const n=new KeyboardEvent("keypress",{key:"Unidentified",code:"Unidentified",bubbles:!0,cancelable:!0});e.dispatchEvent(n);const r=new InputEvent("beforeinput",{inputType:"insertText",data:t,bubbles:!0,cancelable:!0});e.dispatchEvent(r);const i=new InputEvent("input",{inputType:"insertText",data:t,bubbles:!0,cancelable:!1});e.dispatchEvent(i);const a=new Event("change",{bubbles:!0});e.dispatchEvent(a);const s=new KeyboardEvent("keyup",{key:"Unidentified",code:"Unidentified",bubbles:!0,cancelable:!0});e.dispatchEvent(s)}catch(o){console.error("[Webpaper] Keyboard sequence dispatch failed:",o)}}function Lt(e,t){try{let o=e;for(;o;){const n=Object.keys(o),r=n.find(a=>a.startsWith("__reactFiber$")||a.startsWith("__reactEvents$")||a.startsWith("__reactContainer$")),i=n.find(a=>a.startsWith("__reactProps$")||a.startsWith("__reactEventHandlers$"));if(r||i){const a=r?o[r]:null,s=i?o[i]:null;if(s){if(typeof s.onChange=="function")try{s.onChange({target:e,currentTarget:e,type:"change",simulated:!0})}catch{}if(typeof s.onInput=="function")try{s.onInput({target:e,currentTarget:e,type:"input",simulated:!0})}catch{}}let l=a,c=0;for(;l&&c<10;){const p=l.memoizedProps;if(p){if(typeof p.onChange=="function")try{p.onChange({target:e,currentTarget:e,type:"change",simulated:!0})}catch{}if(typeof p.onInput=="function")try{p.onInput({target:e,currentTarget:e,type:"input",simulated:!0})}catch{}}l=l.return,c++}}o=o.parentElement}}catch(o){console.error("[Webpaper] React state synchronization failed:",o)}}function Xt(e,t){if(e.focus(),e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement){Bo(e,t),Lt(e);return}let o=!1;try{const n=window.getSelection();n&&n.rangeCount>0&&(n.getRangeAt(0).deleteContents(),o=document.execCommand("insertText",!1,t))}catch{}if(!o)try{o=document.execCommand("insertText",!1,t)}catch{o=!1}if(!o)try{const n=document.createTextNode(t),r=window.getSelection();if(r&&r.rangeCount>0){const i=r.getRangeAt(0);i.deleteContents(),i.insertNode(n),i.setStartAfter(n),i.setEndAfter(n),r.removeAllRanges(),r.addRange(i),o=!0}else e.appendChild(n),o=!0}catch{e.innerText=t,o=!0}qo(e,t),Lt(e)}async function Fo(e){try{return await navigator.clipboard.writeText(e),!0}catch{try{const t=document.createElement("textarea");t.value=e,t.style.cssText="position:fixed;left:-9999px;top:-9999px;opacity:0;",document.body.appendChild(t),t.select();const o=document.execCommand("copy");return document.body.removeChild(t),o}catch{return!1}}}function Bo(e,t){var r;const o=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,n=Object.getOwnPropertyDescriptor(o,"value");(r=n==null?void 0:n.set)==null||r.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}function _o(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}const At={name:"ChatGPT",supportsAttachmentCard:!0,detect(){const e=location.hostname;return e==="chatgpt.com"||e==="chat.openai.com"},getInput(){return document.querySelector("#prompt-textarea")??document.querySelector('[contenteditable="true"][data-placeholder]')??document.querySelector('textarea[data-id="root"]')},async injectText(e){const t=this.getInput();t&&await Pe(t,e)},getSendButton(){return document.querySelector('[data-testid="send-button"]')??document.querySelector('button[aria-label="Send prompt"]')??document.querySelector("form button:not([disabled])")},triggerSend(){var e,t;(t=(e=this.getSendButton)==null?void 0:e.call(this))==null||t.click()},getConversationContext(){const e=document.querySelectorAll("[data-message-author-role]");return Array.from(e).slice(-3).map(o=>{var i;const n=o.getAttribute("data-message-author-role"),r=((i=o.textContent)==null?void 0:i.slice(0,200))??"";return`${n}: ${r}`}).join(`
`)},getMessageList(){const e=document.querySelector('[data-message-author-role="user"]');if(!e)return null;let t=e.parentElement;for(;t&&t!==document.body;){const o=getComputedStyle(t).overflowY;if(o==="auto"||o==="scroll")return t;t=t.parentElement}return e.parentElement},isUserMessage(e){var t,o;return((t=e.getAttribute)==null?void 0:t.call(e,"data-message-author-role"))==="user"?!0:((o=e.querySelector)==null?void 0:o.call(e,'[data-message-author-role="user"]'))!=null},getUserMessageTextContainer(e){var t,o;return((t=e.getAttribute)==null?void 0:t.call(e,"data-message-author-role"))==="user"?e:((o=e.querySelector)==null?void 0:o.call(e,'[data-message-author-role="user"]'))??e}},zo={name:"Claude",supportsAttachmentCard:!0,detect(){return location.hostname==="claude.ai"},getInput(){return document.querySelector('[contenteditable="true"].ProseMirror')??document.querySelector('div[contenteditable="true"]')??document.querySelector(".input-area [contenteditable]")},async injectText(e){const t=this.getInput();t&&await Pe(t,e)},getSendButton(){return document.querySelector('button[aria-label="Send Message"]')??document.querySelector('button[aria-label="Send message"]')??document.querySelector("fieldset button:last-of-type")},triggerSend(){var e,t;(t=(e=this.getSendButton)==null?void 0:e.call(this))==null||t.click()},getConversationContext(){const e=document.querySelectorAll("[data-is-streaming], .font-claude-message, .font-user-message");return Array.from(e).slice(-3).map(o=>{var a;const r=o.classList.contains("font-claude-message")?"assistant":"user",i=((a=o.textContent)==null?void 0:a.slice(0,200))??"";return`${r}: ${i}`}).join(`
`)},getMessageList(){const e=document.querySelector(".font-user-message");if(!e)return null;let t=e.parentElement;for(;t&&t!==document.body;){const o=getComputedStyle(t).overflowY;if(o==="auto"||o==="scroll")return t;t=t.parentElement}return e.parentElement},isUserMessage(e){var t,o;return(t=e.classList)!=null&&t.contains("font-user-message")?!0:((o=e.querySelector)==null?void 0:o.call(e,".font-user-message"))!=null},getUserMessageTextContainer(e){var t,o;return(t=e.classList)!=null&&t.contains("font-user-message")?e:((o=e.querySelector)==null?void 0:o.call(e,".font-user-message"))??e}},No={name:"Gemini",detect(){return location.hostname==="gemini.google.com"},getInput(){const e=document.querySelector('[role="textbox"][contenteditable="true"]')??document.querySelector('rich-textarea [contenteditable="true"]')??document.querySelector(".input-area [contenteditable]")??document.querySelector('[contenteditable="true"]');if(e)return e;const t=document.querySelectorAll('rich-textarea, gemini-input-area, [class*="input"]');for(const o of t){const n=o.shadowRoot;if(!n)continue;const r=n.querySelector('[contenteditable="true"]');if(r)return r}return null},async injectText(e){const t=this.getInput();t&&await Pe(t,e)},getSendButton(){return document.querySelector('button[aria-label*="Send" i]')??document.querySelector("button.send-button")??document.querySelector('button[data-test-id*="send" i]')??document.querySelector('button[mattooltip="Send"]')},triggerSend(){var e,t;(t=(e=this.getSendButton)==null?void 0:e.call(this))==null||t.click()},getConversationContext(){const e=document.querySelectorAll("message-content, .conversation-container [data-message-id]");return Array.from(e).slice(-3).map(o=>{var n;return((n=o.textContent)==null?void 0:n.slice(0,200))??""}).join(`
`)},getMessageList(){return document.querySelector(".conversation-container")??null},isUserMessage(e){var t,o,n;return!!(e.tagName==="USER-QUERY"||(t=e.querySelector)!=null&&t.call(e,"user-query")||(n=(o=e.classList)==null?void 0:o.contains)!=null&&n.call(o,"user-query"))},getUserMessageTextContainer(e){var t;return((t=e.querySelector)==null?void 0:t.call(e,'.query-text, [class*="query-text"]'))??e}},we={name:"Grok",detect(){const e=location.hostname;return!!(e==="grok.com"||e==="www.grok.com"||(e==="x.com"||e==="twitter.com")&&(location.pathname.startsWith("/i/grok")||location.pathname.startsWith("/grok")))},getInput(){return document.querySelector('div[contenteditable="true"][role="textbox"]')??document.querySelector('[contenteditable="true"][data-placeholder]')??document.querySelector('main [contenteditable="true"]')??document.querySelector('[contenteditable="true"]')??document.querySelector('textarea[placeholder*="Ask" i]')??document.querySelector("textarea")},async injectText(e){const t=this.getInput();t&&await Pe(t,e)},getSendButton(){return document.querySelector('button[aria-label*="Send" i]')??document.querySelector('button[aria-label*="Submit" i]')??document.querySelector('button[data-testid*="send" i]')??document.querySelector('button[type="submit"]')??document.querySelector("form button:last-of-type")},triggerSend(){var e,t;(t=(e=this.getSendButton)==null?void 0:e.call(this))==null||t.click()},getConversationContext(){const e=document.querySelectorAll('[data-message-id], .message, [class*="message-content" i]');return Array.from(e).slice(-3).map(o=>{var n;return((n=o.textContent)==null?void 0:n.slice(0,200))??""}).join(`
`)}},It={name:"Perplexity",detect(){return location.hostname==="www.perplexity.ai"||location.hostname==="perplexity.ai"},getInput(){return document.querySelector('textarea[placeholder*="Ask"]')??document.querySelector("textarea")??document.querySelector('[contenteditable="true"]')},injectText(e){const t=this.getInput();t&&(t instanceof HTMLTextAreaElement?Ro(t,e):(t.focus(),document.execCommand("insertText",!1,e)))},triggerSend(){var t;const e=document.querySelector('button[aria-label="Submit"]')??document.querySelector('button[aria-label="Send"]')??((t=document.querySelector('button svg[data-icon="arrow-right"]'))==null?void 0:t.closest("button"));e==null||e.click()},getConversationContext(){const e=document.querySelectorAll(".prose");return Array.from(e).slice(-2).map(o=>{var n;return((n=o.textContent)==null?void 0:n.slice(0,200))??""}).join(`
`)}};function Ro(e,t){var n;const o=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value");(n=o==null?void 0:o.set)==null||n.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0}))}const Oo={name:"HuggingChat",detect(){return location.hostname==="huggingface.co"&&location.pathname.startsWith("/chat")},getInput(){return document.querySelector("textarea[placeholder]")},injectText(e){const t=this.getInput();t instanceof HTMLTextAreaElement&&Do(t,e)},triggerSend(){const e=document.querySelector('form button[type="submit"]');e==null||e.click()}};function Do(e,t){var n;const o=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value");(n=o==null?void 0:o.set)==null||n.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0}))}const le={name:"Generic",detect(){return je()>=50},getInput(){const e=document.querySelectorAll("textarea");for(const o of e)if(Je(o))return o;const t=document.querySelectorAll('[contenteditable="true"]');for(const o of t)if(Je(o))return o;return e[0]??null},injectText(e){var o;const t=this.getInput();if(t)if(t instanceof HTMLTextAreaElement){const n=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value");(o=n==null?void 0:n.set)==null||o.call(t,e),t.dispatchEvent(new Event("input",{bubbles:!0}))}else t.focus(),document.execCommand("insertText",!1,e)},triggerSend(){const e=['button[type="submit"]','button[aria-label*="send" i]','button[aria-label*="submit" i]','button svg[data-icon="paper-plane"]'];for(const t of e){const o=document.querySelector(t),n=(o==null?void 0:o.tagName)==="BUTTON"?o:o==null?void 0:o.closest("button");if(n){n.click();return}}}};function je(){let e=0;const t=document.querySelectorAll("textarea");for(const s of t)if(Je(s)){e+=30;break}document.querySelectorAll('[class*="chat" i], [class*="conversation" i], [class*="message" i], [id*="chat" i]').length>0&&(e+=20),document.querySelectorAll('[class*="typing" i], [class*="streaming" i], [class*="loading-dots" i]').length>0&&(e+=15),document.querySelectorAll('.markdown, .prose, [class*="markdown" i], pre > code').length>0&&(e+=10);const i=document.body.innerText.slice(0,5e3).toLowerCase(),a=["ai assistant","chatbot","powered by ai","ask me anything"];for(const s of a)if(i.includes(s)){e+=10;break}return e}function Je(e){var n;const t=e.closest("form")??((n=e.parentElement)==null?void 0:n.parentElement);if(!t)return!1;const o=t.querySelectorAll("button");for(const r of o){const i=(r.textContent+r.getAttribute("aria-label")+r.className).toLowerCase();if(i.includes("send")||i.includes("submit")||i.includes("arrow"))return!0}return!1}function Zt(e){const t=["[data-testid]","[data-feature-name]","[data-stid]","[id]","[class]","[aria-label]"];for(const o of t){const n=document.querySelectorAll(o);for(const r of n){const i=r.id+" "+r.className+" "+(r.getAttribute("data-testid")??"")+" "+(r.getAttribute("data-feature-name")??"")+" "+(r.getAttribute("data-stid")??"")+" "+(r.getAttribute("aria-label")??"");if(e.test(i))return!0}}return!1}const Po={...le,name:"Amazon Rufus",detect(){return Zt(/\brufus\b/i)?je()>=30||!!document.querySelector('textarea, [contenteditable="true"]'):!1}},jo={...le,name:"Expedia Romie",detect(){return Zt(/\bromie\b/i)?je()>=30||!!document.querySelector('textarea, [contenteditable="true"]'):!1}},Ho={...le,name:"NVIDIA Build",detect(){return je()>=30}};function z(e){const t=document.querySelector(e);try{return(t==null?void 0:t.contentDocument)??null}catch{return null}}const Wo={name:"Intercom",detect(){return!!document.querySelector("#intercom-container, .intercom-messenger-frame")},getInput(){const e=z(".intercom-messenger-frame iframe");return e?e.querySelector('[contenteditable="true"]')??e.querySelector("textarea"):document.querySelector('#intercom-container [contenteditable="true"]')},injectText(e){const t=this.getInput();t&&ce(t,e)},triggerSend(){const e=z(".intercom-messenger-frame iframe"),t=(e==null?void 0:e.querySelector('[aria-label="Send"]'))??document.querySelector('#intercom-container button[aria-label="Send"]');t==null||t.click()}},Go={name:"Drift",detect(){return!!document.querySelector("#drift-widget, #drift-frame")},getInput(){const e=z("#drift-frame");return(e==null?void 0:e.querySelector("textarea"))??(e==null?void 0:e.querySelector('[contenteditable="true"]'))??null},injectText(e){const t=this.getInput();t&&ce(t,e)},triggerSend(){const e=z("#drift-frame"),t=e==null?void 0:e.querySelector('button[type="submit"]');t==null||t.click()}},Vo={name:"Zendesk",detect(){return!!document.querySelector('iframe[title*="Zendesk"], #launcher, #webWidget')},getInput(){const e=z('iframe[title*="Zendesk"]');return(e==null?void 0:e.querySelector("textarea"))??(e==null?void 0:e.querySelector('[contenteditable="true"]'))??null},injectText(e){const t=this.getInput();t&&ce(t,e)},triggerSend(){const e=z('iframe[title*="Zendesk"]'),t=e==null?void 0:e.querySelector('button[type="submit"]');t==null||t.click()}},Uo={name:"Crisp",detect(){return!!document.querySelector(".crisp-client")},getInput(){return document.querySelector(".crisp-client textarea")??document.querySelector('.crisp-client [contenteditable="true"]')},injectText(e){const t=this.getInput();t&&ce(t,e)},triggerSend(){const e=document.querySelector('.crisp-client button[data-action="send"]');e==null||e.click()}},Yo={name:"Tidio",detect(){return!!document.querySelector("#tidio-chat, #tidio-chat-iframe")},getInput(){const e=z("#tidio-chat-iframe");return(e==null?void 0:e.querySelector("textarea"))??(e==null?void 0:e.querySelector('[contenteditable="true"]'))??null},injectText(e){const t=this.getInput();t&&ce(t,e)},triggerSend(){const e=z("#tidio-chat-iframe"),t=e==null?void 0:e.querySelector('button[type="submit"]');t==null||t.click()}},Ko={name:"HubSpot",detect(){return!!document.querySelector("#hubspot-messages-iframe-container")},getInput(){const e=z("#hubspot-messages-iframe-container iframe");return(e==null?void 0:e.querySelector("textarea"))??(e==null?void 0:e.querySelector('[contenteditable="true"]'))??null},injectText(e){const t=this.getInput();t&&ce(t,e)},triggerSend(){const e=z("#hubspot-messages-iframe-container iframe"),t=e==null?void 0:e.querySelector('button[type="submit"]');t==null||t.click()}};function ce(e,t){var o;if(e instanceof HTMLTextAreaElement){const n=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value");(o=n==null?void 0:n.set)==null||o.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0}))}else e.focus(),document.execCommand("insertText",!1,t)}const Xo=["amazon.com","www.amazon.com","smile.amazon.com","amazon.co.uk","www.amazon.co.uk","amazon.de","www.amazon.de","amazon.fr","www.amazon.fr","amazon.ca","www.amazon.ca","amazon.in","www.amazon.in","amazon.com.au","www.amazon.com.au","amazon.co.jp","www.amazon.co.jp","amazon.com.mx","www.amazon.com.mx","amazon.com.br","www.amazon.com.br","amazon.it","www.amazon.it","amazon.es","www.amazon.es","amazon.nl","www.amazon.nl"],Zo=["expedia.com","www.expedia.com","expedia.co.uk","www.expedia.co.uk","expedia.ca","www.expedia.ca","expedia.com.au","www.expedia.com.au","expedia.de","www.expedia.de","expedia.fr","www.expedia.fr"],Jo=["build.nvidia.com","api.nvidia.com"],lt={"chatgpt.com":At,"chat.openai.com":At,"claude.ai":zo,"gemini.google.com":No,"grok.com":we,"www.grok.com":we,"x.com":we,"twitter.com":we,"perplexity.ai":It,"www.perplexity.ai":It,"huggingface.co":Oo,...Object.fromEntries(Xo.map(e=>[e,Po])),...Object.fromEntries(Zo.map(e=>[e,jo])),...Object.fromEntries(Jo.map(e=>[e,Ho]))},ct=[{selector:"#intercom-container",adapter:Wo},{selector:"#drift-widget",adapter:Go},{selector:'iframe[title*="Zendesk"]',adapter:Vo},{selector:".crisp-client",adapter:Uo},{selector:"#tidio-chat",adapter:Yo},{selector:"#hubspot-messages-iframe-container",adapter:Ko}];function Jt(){const e=location.hostname,t=lt[e];if(t&&t.detect())return{type:"chatbot-detected",platform:t.name,confidence:100,hostname:e,adapter:t.name};for(const{selector:o,adapter:n}of ct)if(document.querySelector(o))return{type:"chatbot-detected",platform:n.name,confidence:90,hostname:e,adapter:n.name};return le.detect()?{type:"chatbot-detected",platform:"Generic",confidence:60,hostname:e,adapter:"Generic"}:null}function Qt(e){const t=lt[e.hostname];if(t&&t.name===e.adapter)return t;for(const{adapter:o}of ct)if(o.name===e.adapter)return o;return e.adapter==="Generic"?le:null}function Qo(e,t=1e4){let o,n;const r=new MutationObserver(()=>{clearTimeout(n),n=setTimeout(()=>{const a=location.hostname,s=lt[a];if(s&&s.detect()){i(),e({type:"chatbot-detected",platform:s.name,confidence:100,hostname:a,adapter:s.name});return}for(const{selector:l,adapter:c}of ct)if(document.querySelector(l)){i(),e({type:"chatbot-detected",platform:c.name,confidence:90,hostname:a,adapter:c.name});return}le.detect()&&(i(),e({type:"chatbot-detected",platform:"Generic",confidence:60,hostname:a,adapter:"Generic"}))},300)});r.observe(document.body,{childList:!0,subtree:!0}),o=setTimeout(()=>{i()},t);function i(){clearTimeout(o),clearTimeout(n),r.disconnect()}return i}const ye="surface-overlay-root";function Mt(e,t){var d,m;if(document.getElementById(ye))return;const o=document.createElement("div");o.id=ye,o.style.cssText="all: initial; position: fixed; z-index: 2147483647;";const n=o.attachShadow({mode:"open"});n.innerHTML=`
    <style>
      @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }

      :host {
        all: initial;
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', sans-serif;
        -webkit-font-smoothing: antialiased;
      }

      .srf-root {
        position: relative;
      }

      /* In-chat Surface toggle — rounded square (8px) per the brand guide's
       * "no fully-round pills" rule. Transparent fill, 1px #9E9E9E border,
       * inverts to black on hover (this IS a primary CTA in the chat UI).
       * No shadow, no scale. */
      .srf-fab {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        background: transparent;
        border: 1px solid #9E9E9E;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.2s ease, border-color 0.2s ease, opacity 0.2s ease;
        animation: fadeIn 0.2s ease-out;
        position: relative;
        user-select: none;
        padding: 0;
      }

      .srf-fab:hover {
        background: #000;
        border-color: #000;
      }

      .srf-fab svg {
        width: 16px;
        height: 19px;
        color: #586675;
        transition: color 0.2s ease;
      }

      .srf-fab:hover svg {
        color: #FFFFFF;
      }

      /* ARMED state — green dot indicator, no pulse (calm) */
      .srf-fab.armed .srf-status-dot {
        background: #34C759;
      }

      /* DISARMED state — dimmed and gray dot */
      .srf-fab.disarmed {
        opacity: 0.55;
      }

      .srf-fab.disarmed .srf-status-dot {
        background: #7A7F88;
      }

      .srf-fab.unauth {
        opacity: 0.45;
      }

      .srf-status-dot {
        position: absolute;
        bottom: -3px;
        right: -3px;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #34C759;
        border: 2px solid #FFFFFF;
      }

      /* ── Tooltip ── */

      .srf-tooltip {
        position: absolute;
        bottom: 44px;
        right: 0;
        background: #FFFFFF;
        color: #000;
        font-size: 12px;
        font-weight: 400;
        letter-spacing: 0.01em;
        padding: 10px 14px;
        border: 1px solid #9E9E9E;
        border-radius: 8px;
        white-space: nowrap;
        pointer-events: none;
        opacity: 0;
        transform: translateY(4px);
        transition: opacity 0.2s ease, transform 0.2s ease;
        line-height: 1.4;
      }

      .srf-fab:hover ~ .srf-tooltip,
      .srf-tooltip.visible {
        opacity: 1;
        transform: translateY(0);
      }

      .srf-tooltip.intro {
        opacity: 1;
        transform: translateY(0);
      }

      .srf-tooltip-strong {
        color: #000;
      }

      .srf-tooltip-dim {
        color: #6B6B70;
        font-weight: 400;
      }

      /* Dark chatbot backgrounds — keep the transparent fill, just brighten
       * the border so it stays visible. Hover still inverts to white (marketing
       * CTA pattern, inverted for dark surfaces). */
      @media (prefers-color-scheme: dark) {
        .srf-fab {
          background: transparent;
          border-color: #9E9E9E;
        }
        .srf-fab svg {
          color: #9FB0C4;
        }
        .srf-fab:hover {
          background: #FFF;
          border-color: #FFF;
        }
        .srf-fab:hover svg {
          color: #586675;
        }
        .srf-status-dot { border-color: transparent; }
        .srf-tooltip {
          background: #1C1C1E;
          color: #FFFFFF;
          border-color: #9E9E9E;
        }
        .srf-tooltip-strong { color: #FFFFFF; }
        .srf-tooltip-dim { color: #A4A4A4; }
      }
    </style>

    <div class="srf-root">
      <button
        class="srf-fab ${t.enabled?"armed":"disarmed"} ${t.signedIn?"":"unauth"}"
        id="srf-fab"
        title="Webpaper"
        aria-label="Webpaper arm/disarm"
      >
        <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="0" y="0" width="32" height="32" rx="8" fill="#232c3b"/>
          <rect x="8" y="5" width="7" height="4" fill="#f4f7fb"/>
          <rect x="19" y="5" width="7" height="4" fill="#f4f7fb"/>
          <rect x="10" y="6" width="3" height="3" fill="#e79bb6"/>
          <rect x="21" y="6" width="3" height="3" fill="#e79bb6"/>
          <rect x="6" y="9" width="20" height="17" rx="5" fill="#f4f7fb"/>
          <rect x="12" y="15" width="3" height="3" fill="#3b424c"/>
          <rect x="17" y="15" width="3" height="3" fill="#3b424c"/>
          <rect x="14.5" y="19" width="3" height="2.5" fill="#e79bb6"/>
          <rect x="9" y="19" width="3" height="2.5" fill="#ecaec0"/>
          <rect x="20" y="19" width="3" height="2.5" fill="#ecaec0"/>
        </svg>
        <span class="srf-status-dot"></span>
      </button>
      <div class="srf-tooltip ${t.signedIn?"intro":""}" id="srf-tooltip">
        ${Qe(t.enabled,t.signedIn)}
      </div>
    </div>
  `,document.body.appendChild(o);const r=n.getElementById("srf-fab"),i=n.getElementById("srf-tooltip");let a=t.enabled,s=!1;function l(){var T,q;const h=(q=(T=t.adapter).getSendButton)==null?void 0:q.call(T),f=t.adapter.getInput(),y=h??f;if(y){const $=y.getBoundingClientRect();if($.width>0||$.height>0){o.style.display="",o.style.right="",o.style.bottom="",h?(o.style.top=`${$.top+$.height/2-16}px`,o.style.left=`${$.left-40}px`):(o.style.top=`${$.top+6}px`,o.style.left=`${$.right-40}px`);return}}o.style.display="",o.style.top="",o.style.left="",o.style.right="24px",o.style.bottom="24px"}l();const c=new ResizeObserver(l),p=((m=(d=t.adapter).getSendButton)==null?void 0:m.call(d))??t.adapter.getInput();p&&c.observe(p),c.observe(document.documentElement),window.addEventListener("scroll",l,{passive:!0,capture:!0}),window.addEventListener("resize",l);const u=new MutationObserver(()=>{var f,y;const h=((y=(f=t.adapter).getSendButton)==null?void 0:y.call(f))??t.adapter.getInput();h&&h!==p&&(c.disconnect(),c.observe(h),c.observe(document.documentElement)),l()});u.observe(document.body,{childList:!0,subtree:!0}),o._cleanup=()=>{c.disconnect(),u.disconnect(),window.removeEventListener("scroll",l,{capture:!0}),window.removeEventListener("resize",l)},r.addEventListener("click",()=>{if(!t.signedIn){$t(i,'<span class="srf-tooltip-strong">Sign in to Webpaper</span><br><span class="srf-tooltip-dim">Click the extension icon in your browser</span>',3e3);return}a=!a,r.classList.toggle("armed",a),r.classList.toggle("disarmed",!a),t.onToggle(a),i.innerHTML=Qe(a,!0),$t(i,null,2200)}),r.addEventListener("mouseenter",()=>{s=!0,i.classList.add("visible")}),r.addEventListener("mouseleave",()=>{s=!1,setTimeout(()=>{!s&&!i.classList.contains("intro")&&i.classList.remove("visible")},100)}),t.signedIn&&setTimeout(()=>{i.classList.remove("intro"),s||i.classList.remove("visible")},4e3)}function Qe(e,t){return t?e?'<span class="srf-tooltip-strong">Armed — fires on next send</span><br><span class="srf-tooltip-dim">Click to disarm</span>':'<span class="srf-tooltip-strong">Disarmed</span><br><span class="srf-tooltip-dim">Click to arm for next send</span>':'<span class="srf-tooltip-strong">Webpaper</span><br><span class="srf-tooltip-dim">Sign in to share your identity</span>'}function $t(e,t,o){t&&(e.innerHTML=t),e.classList.add("visible"),setTimeout(()=>{e.classList.remove("visible")},o)}function dt(e){const t=document.getElementById(ye);if(!(t!=null&&t.shadowRoot))return;const o=t.shadowRoot.getElementById("srf-fab");if(!o)return;o.classList.toggle("armed",e),o.classList.toggle("disarmed",!e);const n=t.shadowRoot.getElementById("srf-tooltip");n&&(n.innerHTML=Qe(e,!0))}function en(e,t=2400){const o=document.getElementById(ye);if(!(o!=null&&o.shadowRoot))return;const n=o.shadowRoot.getElementById("srf-tooltip");n&&(n.innerHTML=e,n.classList.add("visible"),setTimeout(()=>n.classList.remove("visible"),t))}function tn(){const e=document.getElementById(ye);e&&e._cleanup&&e._cleanup(),e==null||e.remove()}function eo(e){var i;const t=e.readonly!==!1,o=document.createElement("span");o.setAttribute("data-srf-cards-container",e.id),o.style.display="inline-block",o.style.maxWidth="100%",o.style.verticalAlign="middle";const n=o.attachShadow({mode:"open"});n.innerHTML=un;const r=n.getElementById("list");for(let a=0;a<e.cards.length;a++){const s=e.cards[a];(i=s.content)!=null&&i.trim()&&r.appendChild(on(s,a,t))}return o}function on(e,t,o){const n=Yt(e.type),r=e.label??n.label,i=e.type==="biography",a=document.createElement("div");a.className="item";const s=document.createElement("button");s.type="button",s.className=`chip ${i?"marquee":""}`,s.setAttribute("data-srf-chip-type",e.type),s.style.setProperty("--accent",n.accent),s.style.setProperty("--enter-delay",`${t*40}ms`);const l=document.createElement("span");l.className="dot";const c=document.createElement("span");c.className="icon",c.innerHTML=Ft[e.type]??Ft.identity;const p=document.createElement("span");if(p.className="label",p.textContent=r,s.appendChild(l),s.appendChild(c),s.appendChild(p),!o&&n.removable){const m=document.createElement("span");m.className="close",m.setAttribute("role","button"),m.setAttribute("aria-label",`Detach ${r}`),m.innerHTML=dn,m.addEventListener("click",h=>{h.stopPropagation(),a.classList.add("removing"),setTimeout(()=>a.remove(),180)}),s.appendChild(m)}const u=document.createElement("div");u.className="body";let d=!1;return s.addEventListener("click",()=>{d||(u.appendChild(nn(e)),d=!0),a.classList.toggle("open")}),a.appendChild(s),a.appendChild(u),a}function nn(e){switch(e.type){case"biography":return rn(e.content);case"instructions":return an(e.content);case"interests":return qt(e.content,!1);case"connected-apps":return qt(e.content,!0);case"preferences":case"memory":case"calendar":return sn(e.content);case"projects":return ln(e.content);case"allergies":return cn(e.content);default:{const t=document.createElement("div");return t.className="body-text",t.textContent=e.content,t}}}function rn(e){const t=document.createElement("div");t.className="bio";const o=e.split(`
`),n={};let r=-1;for(let a=0;a<o.length;a++){const s=o[a];if(/^About\s*:/i.test(s.trim())||s.trim()==="About:"){r=a+1;break}const l=s.match(/^([A-Za-z]+)\s*:\s*(.+)$/);l&&(n[l[1].toLowerCase()]=l[2].trim())}if(n.name){const a=document.createElement("div");a.className="bio-name",a.textContent=n.name,t.appendChild(a)}const i=[];if(n.occupation&&i.push(n.occupation),n.location&&i.push(n.location),i.length){const a=document.createElement("div");a.className="bio-sub",a.textContent=i.join(" · "),t.appendChild(a)}if(r>-1){const a=o.slice(r).join(`
`).trim();if(a){const s=document.createElement("p");s.className="bio-about",s.textContent=a,t.appendChild(s)}}return t}function an(e){const t=document.createElement("blockquote");return t.className="instructions",t.textContent=e,t}function qt(e,t){const o=document.createElement("div");o.className="pills";const n=e.split(/[,\n]/).map(r=>r.trim()).filter(Boolean);for(const r of n){const i=document.createElement("span");i.className=t?"pill pill-app":"pill",i.textContent=r,o.appendChild(i)}return o}function sn(e){const t=document.createElement("ul");t.className="list";const o=e.split(`
`).map(n=>n.replace(/^[-•]\s*/,"").trim()).filter(Boolean);for(const n of o){const r=document.createElement("li");r.textContent=n,t.appendChild(r)}return t}function ln(e){const t=document.createElement("div");t.className="projects";const o=e.split(`
`).map(n=>n.replace(/^[-•]\s*/,"").trim()).filter(Boolean);for(const n of o){const r=document.createElement("div");r.className="proj";const i=n.indexOf(":");if(i>0){const a=document.createElement("span");a.className="proj-slug",a.textContent=n.slice(0,i).trim();const s=document.createElement("span");s.className="proj-desc",s.textContent=n.slice(i+1).trim(),r.appendChild(a),r.appendChild(s)}else r.textContent=n;t.appendChild(r)}return t}function cn(e){const t=document.createElement("ul");t.className="list allergies";const o=e.split(`
`).map(n=>n.replace(/^[-•]\s*/,"").trim()).filter(Boolean);for(const n of o){const r=document.createElement("li");r.textContent=n,t.appendChild(r)}return t}const dn='<svg viewBox="0 0 12 12" width="9" height="9" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 3 L9 9 M9 3 L3 9"/></svg>',Ft={biography:'<svg viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="6" r="3"/><path d="M2 14c0-3.3 2.7-6 6-6s6 2.7 6 6v.5H2V14z"/></svg>',projects:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2" y="3" width="12" height="10" rx="1.5"/><path d="M5 6h6 M5 9h6 M5 12h3"/></svg>',interests:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M8 13.5L2.5 8a3.5 3.5 0 0 1 5-5L8 3.5 8.5 3a3.5 3.5 0 0 1 5 5L8 13.5z"/></svg>',instructions:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M4 3v10 M4 3l4 4-4 4 M9 13h3"/></svg>',allergies:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M8 2L14 13H2L8 2z"/><path d="M8 7v3 M8 11.5v0"/></svg>',"connected-apps":'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2" y="2" width="5" height="5" rx="1"/><rect x="9" y="2" width="5" height="5" rx="1"/><rect x="2" y="9" width="5" height="5" rx="1"/><rect x="9" y="9" width="5" height="5" rx="1"/></svg>',calendar:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2" y="3" width="12" height="11" rx="1.5"/><path d="M2 6h12 M5 1.5v3 M11 1.5v3"/></svg>',memory:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M8 3a4 4 0 0 0-4 4v1a3 3 0 0 0 3 3h2a3 3 0 0 0 3-3V7a4 4 0 0 0-4-4z"/><path d="M8 11v3"/></svg>',preferences:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M3 5h10 M3 8h7 M3 11h10"/><circle cx="11" cy="5" r="1.5"/><circle cx="8" cy="8" r="1.5"/><circle cx="11" cy="11" r="1.5"/></svg>',identity:'<svg viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="6" r="3"/><path d="M2 14c0-3.3 2.7-6 6-6s6 2.7 6 6v.5H2V14z"/></svg>'},un=`
<style>
  :host {
    all: initial;
    display: inline-block;
    max-width: 100%;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    -webkit-font-smoothing: antialiased;
    line-height: 1.45;
  }
  * { box-sizing: border-box; }

  @keyframes mesh-drift {
    0%   { background-position:   0%   0%; }
    100% { background-position: 100% 100%; }
  }
  @keyframes chip-enter {
    from { opacity: 0; transform: translateY(3px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes chip-leave {
    to { opacity: 0; transform: translateY(2px) scale(0.94); }
  }

  #list {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    align-items: flex-start;
  }

  .item {
    display: inline-flex;
    flex-direction: column;
    min-width: 0;
    flex: 0 0 auto;
    max-width: 100%;
  }

  /* ── Chip ───────────────────────────────────────────────────────── */

  .chip {
    --accent: #586675;
    position: relative;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 28px;
    padding: 0 10px;
    border: 1px solid #d6d6db;
    border-radius: 999px;
    background: #fff;
    color: #1f1f24;
    font: inherit;
    font-size: 12px;
    line-height: 1;
    cursor: pointer;
    user-select: none;
    overflow: hidden;
    isolation: isolate;
    transition: border-color 0.15s ease, transform 0.15s ease;
    animation: chip-enter 0.22s cubic-bezier(0.2, 0.8, 0.2, 1) backwards;
    animation-delay: var(--enter-delay, 0ms);
  }
  .chip:hover { border-color: #1f1f24; transform: translateY(-1px); }
  .item.removing .chip { animation: chip-leave 0.18s ease forwards; }

  .dot {
    width: 6px; height: 6px;
    border-radius: 50%;
    background: var(--accent);
    flex-shrink: 0;
  }
  .icon {
    width: 12px; height: 12px;
    color: #6b6b70;
    flex-shrink: 0;
    display: inline-flex;
  }
  .icon svg { width: 100%; height: 100%; display: block; }

  .label {
    font-weight: 500;
    color: #1f1f24;
    white-space: nowrap;
  }
  .close {
    width: 18px; height: 18px;
    margin-left: 2px;
    border-radius: 50%;
    color: #9090a0;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: background 0.15s ease, color 0.15s ease;
  }
  .close:hover { background: rgba(0, 0, 0, 0.06); color: #1f1f24; }

  /* ── Marquee — Biography chip with the Surface mesh ───────────── */

  .chip.marquee {
    color: #fff;
    border-color: transparent;
    padding: 0 12px;
  }
  .chip.marquee::before {
    content: '';
    position: absolute;
    inset: 0;
    z-index: -1;
    pointer-events: none;
    background:
      radial-gradient(ellipse 65% 62% at 0%   15%, rgba(255, 110,  60, 0.95) 0%, transparent 65%),
      radial-gradient(ellipse 60% 62% at 100% 22%, rgba(140,  70, 240, 0.85) 0%, transparent 65%),
      radial-gradient(ellipse 65% 60% at 95%  92%, rgba( 50, 130, 255, 0.82) 0%, transparent 65%),
      radial-gradient(ellipse 55% 50% at 50%   0%, rgba(255, 140,  90, 0.78) 0%, transparent 65%),
      linear-gradient(135deg, #2a1c4a 0%, #4a1a3a 50%, #1a2a4a 100%);
    background-size: 200% 200%;
    animation: mesh-drift 9s ease-in-out infinite alternate;
    filter: blur(0.5px);
  }
  .chip.marquee .dot { background: #fff; }
  .chip.marquee .icon { color: rgba(255,255,255,0.95); }
  .chip.marquee .label { color: #fff; }
  .chip.marquee .close { color: rgba(255,255,255,0.7); }
  .chip.marquee .close:hover { background: rgba(255,255,255,0.18); color: #fff; }
  .chip.marquee:hover { transform: translateY(-1px); border-color: transparent; }

  /* ── Body (revealed when chip is clicked) ──────────────────────── */

  .body {
    display: none;
    margin-top: 6px;
    padding: 12px 14px;
    background: #fbfbfd;
    border: 1px solid #e5e5ea;
    border-left: 3px solid var(--accent, #586675);
    border-radius: 10px;
    color: #1f1f24;
    font-size: 13px;
    line-height: 1.55;
    max-width: min(420px, 100%);
    animation: chip-enter 0.22s ease;
  }
  .item.open .body { display: block; }

  /* ── Body renderers ─────────────────────────────────────────────── */

  .bio-name { font-size: 16px; font-weight: 500; color: #0d0d12; line-height: 1.2; letter-spacing: -0.01em; }
  .bio-sub { margin-top: 2px; color: #6b6b70; font-size: 12px; }
  .bio-about { margin: 10px 0 0; color: #2c2c33; font-size: 13px; line-height: 1.6; white-space: pre-wrap; }

  blockquote.instructions {
    margin: 0;
    padding: 0 0 0 10px;
    color: #2c2c33;
    font-style: italic;
    line-height: 1.6;
    white-space: pre-wrap;
  }

  .pills { display: flex; flex-wrap: wrap; gap: 6px; }
  .pill {
    display: inline-flex; align-items: center;
    height: 22px;
    padding: 0 10px;
    border: 1px solid #d6d6db;
    border-radius: 999px;
    background: #fff;
    color: #1f1f24;
    font-size: 12px;
    line-height: 1;
  }
  .pill-app {
    background: rgba(52, 199, 89, 0.08);
    border-color: rgba(52, 199, 89, 0.25);
    color: #1d6f3a;
  }

  ul.list { margin: 0; padding: 0; list-style: none; }
  ul.list li { padding: 5px 0; border-bottom: 1px solid rgba(0,0,0,0.05); color: #2c2c33; }
  ul.list li:last-child { border-bottom: none; }

  ul.list.allergies li { color: #b91c2a; padding-left: 14px; position: relative; }
  ul.list.allergies li::before {
    content: '';
    width: 6px; height: 6px; border-radius: 50%;
    background: #b91c2a;
    position: absolute; left: 0; top: 11px;
  }

  .projects { display: flex; flex-direction: column; gap: 6px; }
  .proj {
    display: flex; flex-direction: column;
    padding: 8px 10px;
    background: #fff;
    border: 1px solid #ececf0;
    border-radius: 6px;
  }
  .proj-slug { font-size: 12px; font-weight: 500; color: #0d0d12; }
  .proj-desc { margin-top: 2px; font-size: 12px; color: #6b6b70; line-height: 1.5; }

  /* ── Dark mode ──────────────────────────────────────────────────── */
  @media (prefers-color-scheme: dark) {
    .chip {
      background: #1c1c20;
      border-color: rgba(255, 255, 255, 0.14);
      color: #f0f0f3;
    }
    .chip:hover { border-color: rgba(255, 255, 255, 0.5); }
    .icon { color: rgba(255, 255, 255, 0.66); }
    .label { color: #f0f0f3; }
    .close { color: rgba(255, 255, 255, 0.5); }
    .close:hover { background: rgba(255, 255, 255, 0.1); color: #fff; }
    .body {
      background: #1c1c20;
      border-color: rgba(255, 255, 255, 0.08);
      color: #e8e8eb;
    }
    .bio-name { color: #fff; }
    .bio-sub { color: rgba(255, 255, 255, 0.5); }
    .bio-about { color: rgba(255, 255, 255, 0.85); }
    blockquote.instructions { color: rgba(255, 255, 255, 0.85); }
    .pill {
      background: rgba(255, 255, 255, 0.06);
      border-color: rgba(255, 255, 255, 0.14);
      color: #f0f0f3;
    }
    .pill-app {
      background: rgba(52, 199, 89, 0.14);
      border-color: rgba(52, 199, 89, 0.3);
      color: #65d38f;
    }
    ul.list li { color: #d4d4d8; border-bottom-color: rgba(255, 255, 255, 0.06); }
    ul.list.allergies li { color: #ff8a8a; }
    ul.list.allergies li::before { background: #ff8a8a; }
    .proj {
      background: rgba(255, 255, 255, 0.04);
      border-color: rgba(255, 255, 255, 0.08);
    }
    .proj-slug { color: #fff; }
    .proj-desc { color: rgba(255, 255, 255, 0.6); }
  }
</style>
<div id="list" role="list" aria-label="Webpaper profile cards"></div>
`,G=Q("watcher");let Me=null,Ee=!1;function Bt(){if(!Ee||!Me){G.warn("forceRescan called before watcher installed");return}Me()}function pn(e){if(Ee)return G.warn("installMessageWatcher called twice — ignoring"),()=>{};const t=document.body,o=new WeakSet,n=[];G.info("installed",{adapter:e.name}),He(t,"initial");let r=null;const i=c=>{r==null&&(r=window.setTimeout(()=>{r=null,He(t,c),l()},100))},a=c=>{for(const p of c){for(const u of Array.from(p.addedNodes)){if(!(u instanceof Element))continue;const d=oo(u);if(Ie(d)){i("added-with-markers");return}}if(p.type==="characterData"){const u=p.target.textContent??"";if(Ie(u)){i("chardata-with-markers");return}}p.addedNodes.length>0&&l()}},s=new MutationObserver(a);s.observe(t,{childList:!0,subtree:!0,characterData:!0}),n.push(s);const l=()=>{const c=no(t);for(const p of c){if(o.has(p))continue;o.add(p);const u=new MutationObserver(a);u.observe(p,{childList:!0,subtree:!0,characterData:!0}),n.push(u),i("new-shadow-root")}};return l(),Me=()=>He(t,"force-rescan"),Ee=!0,()=>{for(const c of n)c.disconnect();r!=null&&window.clearTimeout(r),Me=null,Ee=!1,G.info("teardown")}}function He(e,t){const o=oo(e);if(!Ie(o))return;const n=[e,...no(e)];let r=0;for(const i of n)r+=fn(i);r>0&&G.debug(`scan(${t}) processed ${r}`)}function fn(e){var l,c;const t=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),o=[],n=/CFG:START:([a-z0-9]+)/g,r=/CFG:END:([a-z0-9]+)/g;let i=t.nextNode();for(;i;){const p=i.data;n.lastIndex=0;let u;for(;(u=n.exec(p))!==null;)o.push({id:u[1],kind:"start",node:i,offset:u.index,endOffset:u.index+u[0].length});for(r.lastIndex=0;(u=r.exec(p))!==null;)o.push({id:u[1],kind:"end",node:i,offset:u.index,endOffset:u.index+u[0].length});i=t.nextNode()}const a=new Set;let s=0;for(let p=0;p<o.length;p++){if(a.has(p))continue;const u=o[p];if(u.kind!=="start")continue;let d=-1;for(let h=p+1;h<o.length;h++){if(a.has(h))continue;const f=o[h];if(f.kind==="end"&&f.id===u.id){d=h;break}}if(d===-1)continue;const m=o[d];a.add(p),a.add(d),!((c=(l=u.node.parentElement)==null?void 0:l.closest)!=null&&c.call(l,"[data-srf-cards-container]"))&&mn(u.id,u,m)&&s++}return s}function mn(e,t,o){try{const n=document.createRange();n.setStart(t.node,t.offset),n.setEnd(o.node,o.endOffset);const r=n.toString(),i=to(r);if(n.deleteContents(),i.length===0)return G.debug("no cards parsed from wrap, leaving range deleted",{id:e}),!0;const a=eo({cards:i,id:e,readonly:!0});return n.insertNode(a),!0}catch(n){return G.warn("replaceWithCards failed, fallback",{id:e,err:n}),hn(e,t,o)}}function hn(e,t,o){var n;try{const r=/⁣?CFG:START:[a-z0-9]+⁣?/g,i=/⁣?CFG:END:[a-z0-9]+⁣?/g,a=t.node.parentElement,s=o.node.parentElement;if(!a)return!1;let l="",c=a;const p=[];for(;c&&(l+=c.textContent??"",l+=`
`,p.push(c),c!==s);)c=c.nextElementSibling;l=l.replace(r,"").replace(i,"").trim();const u=to(l);for(const m of p)m.style.display="none";if(u.length===0)return!0;const d=eo({cards:u,id:e,readonly:!0});return(n=a.parentElement)==null||n.insertBefore(d,a),!0}catch(r){return G.error("fallback failed",{id:e,err:r}),!1}}function to(e){const t=[];for(const[r,i]of Object.entries(Lo)){if(!Ao(r))continue;const a=`[${i.promptSection}]`;let s=e.indexOf(a);for(;s!==-1;)t.push({type:r,start:s,bracketEnd:s+a.length}),s=e.indexOf(a,s+1)}t.sort((r,i)=>r.start-i.start);let o=-1;for(const r of["--- INSTRUCTIONS ---","---INSTRUCTIONS---","[OBSERVED BEHAVIOR]"]){const i=e.indexOf(r);i!==-1&&(o===-1||i<o)&&(o=i)}const n=[];for(let r=0;r<t.length;r++){const i=t[r];if(o!==-1&&i.start>=o)break;let a=r+1<t.length?t[r+1].start:e.length;o!==-1&&o<a&&(a=o);const s=e.slice(i.bracketEnd,a).trim();s&&n.push({type:i.type,content:s})}return n}function oo(e){const t=[],o=n=>{if(n.nodeType===Node.TEXT_NODE){t.push(n.data);return}if(n.nodeType===Node.ELEMENT_NODE){const r=n,i=r.shadowRoot;if(i)for(const a of Array.from(i.childNodes))o(a);for(const a of Array.from(r.childNodes))o(a);return}for(const r of Array.from(n.childNodes))o(r)};return o(e),t.join("")}function no(e){const t=[],o=n=>{if(n.nodeType===Node.ELEMENT_NODE){const r=n.shadowRoot;if(r){t.push(r);for(const i of Array.from(r.childNodes))o(i)}for(const i of Array.from(n.childNodes))o(i);return}for(const r of Array.from(n.childNodes))o(r)};return o(e),t}const gn=Q("inject"),bn="--- Surface IDENTITY ---";function yn(e){let t=!1;function o(a){if(!e.isEnabled()||t||!a)return!1;if(!e.getPrompt())return gn.warn("armed but no cached prompt — passing through"),!1;const l=_t(a);return!(!l.trim()||l.includes(bn)||Ie(l))}function n(a){var p;const s=e.getPrompt();if(!s)return!1;const l=_t(a),c=`${s}${l}`;return xn(a),Xt(a,c),(p=e.onAugmented)==null||p.call(e),setTimeout(()=>{var u,d;t=!0;try{const m=(d=(u=e.adapter).getSendButton)==null?void 0:d.call(u);m?m.click():e.adapter.triggerSend()}finally{setTimeout(()=>{t=!1},200)}setTimeout(Bt,500),setTimeout(Bt,1500)},60),!0}function r(a){if(a.key!=="Enter"||a.shiftKey||a.ctrlKey||a.metaKey||a.altKey||a.isComposing)return;const s=e.adapter.getInput();if(!s)return;const l=a.target;!s.contains(l)&&l!==s||o(s)&&(a.preventDefault(),a.stopPropagation(),a.stopImmediatePropagation(),n(s))}function i(a){var u,d;if(t)return;const s=a.target;if(!s)return;const l=s.closest("button");if(!l)return;const c=(d=(u=e.adapter).getSendButton)==null?void 0:d.call(u);if(!c||l!==c)return;const p=e.adapter.getInput();o(p)&&(a.preventDefault(),a.stopPropagation(),a.stopImmediatePropagation(),n(p))}return document.addEventListener("keydown",r,{capture:!0}),document.addEventListener("click",i,{capture:!0}),()=>{document.removeEventListener("keydown",r,{capture:!0}),document.removeEventListener("click",i,{capture:!0})}}function _t(e){return e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement?e.value:e.textContent??""}function xn(e){var n;if(e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement){const r=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,i=Object.getOwnPropertyDescriptor(r,"value");(n=i==null?void 0:i.set)==null||n.call(e,""),e.dispatchEvent(new Event("input",{bubbles:!0}));return}e.focus();const t=document.createRange();t.selectNodeContents(e);const o=window.getSelection();o==null||o.removeAllRanges(),o==null||o.addRange(t),document.execCommand("delete",!1)}const me=[],wn=200;function E(e,t,o){me.length>=wn&&me.shift(),me.push({ts:Date.now(),stage:e,message:t,detail:o})}function vn(){return[...me]}function kn(){me.length=0}const ro="srf-polished-root",et="data-srf-polished";function ao(){typeof document>"u"||!document.documentElement||(document.documentElement.classList.add(ro),document.documentElement.hasAttribute(et)||document.documentElement.setAttribute(et,"1"))}const de=/^(body|html|main|article|header|\[role="main"\])/i,Sn=/\bimg\b|\bvideo\b|\bpicture\b|\[data-srf-size\]/i,zt=/^\s*img\s*$/i,En=[{property:/^display$/i,value:/^none$/i,selector:de},{property:/^visibility$/i,value:/^hidden$/i,selector:de},{property:/^opacity$/i,value:/^0(\.0+)?$/i,selector:de},{property:/^pointer-events$/i,value:/^none$/i,selector:/^body/i},{property:/^font-size$/i,value:/^[0-7](\.\d+)?px$/i,selector:/^body/i},{property:/^font-size$/i,value:/^(4[8-9]|[5-9]\d|\d{3,})px$/i,selector:/^body/i},{property:/^position$/i,value:/^fixed$/i,selector:/^body/i},{property:/^transform$/i,value:/scale\s*\(\s*0\s*\)/i,selector:de},{property:/^(left|top)$/i,value:/^-\d{4,}px$/i,selector:de},{property:/^aspect-ratio$/i,value:/./i,selector:Sn},{property:/^display$/i,value:/^block$/i,selector:zt,onlyForCategories:["shopping"]},{property:/^width$/i,value:/^100%$/i,selector:zt,onlyForCategories:["shopping"]}];function We(e,t){let o=0;for(const r of e)if(r==="{"?o++:r==="}"&&o--,o<0)break;return o!==0&&(e=Cn(e)),(e.match(/\{/g)||[]).length>300&&(e=Tn(e,200)),io(e,t)}function Cn(e){let t=0,o=0;for(let n=0;n<e.length;n++)e[n]==="{"?t++:e[n]==="}"&&(t--,t===0&&(o=n+1));return e.slice(0,o)}function Tn(e,t){let o=0,n=0,r=0;for(let i=0;i<e.length;i++)if(e[i]==="{")r++,r===1&&o++;else if(e[i]==="}"&&(r--,r===0&&(n=i+1,o>=t)))break;return e.slice(0,n)}function io(e,t){const o=[];let n=0;for(;n<e.length;){if(e[n]==="/"&&e[n+1]==="*"){const p=e.indexOf("*/",n+2);if(p===-1)break;o.push(e.slice(n,p+2)),n=p+2;continue}const r=e.indexOf("{",n);if(r===-1){o.push(e.slice(n));break}const i=e.slice(n,r).trim();if(i.startsWith("@import")||i.startsWith("@charset")){const p=e.indexOf(";",n);if(p!==-1&&p<r){o.push(e.slice(n,p+1)),n=p+1;continue}}let a=1,s=r+1;for(;s<e.length&&a>0;)e[s]==="{"?a++:e[s]==="}"&&a--,s++;const l=e.slice(r+1,s-1),c=e.slice(n,s);if(i.startsWith("@media")||i.startsWith("@supports")){const p=io(l,t);o.push(`${i} {${p}}`)}else if(i.startsWith("@"))o.push(c);else{const p=Ln(i,l,t);p.trim()&&o.push(`${i} {${p}}`)}n=s}return o.join(`
`)}function Ln(e,t,o){const n=t.split(";"),r=[];for(const i of n){const a=i.trim();if(!a)continue;const s=a.indexOf(":");if(s===-1){r.push(i);continue}const l=a.slice(0,s).trim(),c=a.slice(s+1).trim().replace(/!important\s*$/,"").trim();let p=!1;for(const u of En)if(u.property.test(l)&&u.value.test(c)&&(!u.selector||u.selector.test(e))){if(u.onlyForCategories&&(!o||!u.onlyForCategories.includes(o)))continue;p=!0;break}p||r.push(i)}return r.join(";")}const An=`html.${ro}[${et}]`;function N(e,t=An){return so(e,t)}function so(e,t){const o=[];let n=0;const r=e.length;for(;n<r;){if(/\s/.test(e[n])){o.push(e[n]),n++;continue}if(e[n]==="/"&&e[n+1]==="*"){const f=e.indexOf("*/",n+2);if(f===-1){o.push(e.slice(n));break}o.push(e.slice(n,f+2)),n=f+2;continue}let i=-1,a=-1,s=n,l=null;for(;s<r;){const f=e[s];if(l)f===l&&e[s-1]!=="\\"&&(l=null);else if(f==='"'||f==="'")l=f;else if(f==="{"){i=s;break}else if(f===";"){a=s;break}else if(f==="/"&&e[s+1]==="*"){const y=e.indexOf("*/",s+2);if(y===-1){s=r;break}s=y+2;continue}s++}if(a!==-1&&(i===-1||a<i)){o.push(e.slice(n,a+1)),n=a+1;continue}if(i===-1){o.push(e.slice(n));break}const c=e.slice(n,i),p=c.trim();let u=1,d=i+1,m=null;for(;d<r&&u>0;){const f=e[d];m?f===m&&e[d-1]!=="\\"&&(m=null):f==='"'||f==="'"?m=f:f==="{"?u++:f==="}"&&u--,d++}const h=e.slice(i+1,d-1);if(/^@(media|supports|container|layer)\b/i.test(p))o.push(`${c}{${so(h,t)}}`);else if(p.startsWith("@"))o.push(`${c}{${h}}`);else{const f=In(p).map(T=>Mn(T,t)).join(", "),y=$n(h);o.push(`${f} {${y}}`)}n=d}return o.join("")}function In(e){const t=[];let o=0,n=null,r=0;for(let a=0;a<e.length;a++){const s=e[a];if(n){s===n&&e[a-1]!=="\\"&&(n=null);continue}if(s==='"'||s==="'"){n=s;continue}s==="("||s==="["?o++:s===")"||s==="]"?o--:s===","&&o===0&&(t.push(e.slice(r,a).trim()),r=a+1)}const i=e.slice(r).trim();return i&&t.push(i),t.length?t:[e.trim()]}function Mn(e,t){const o=e.trim();return o?o===":root"||o.startsWith(":root ")?t+o.slice(5):/^html\b/.test(o)?t+o.slice(4):`${t} ${o}`:t}function $n(e){const t=[];let o=0;const n=e.length;let r=0,i=0;const a=l=>{t.push(Nt(e.slice(i,l))),i=l+1};let s=null;for(;o<n;){const l=e[o];if(s){l===s&&e[o-1]!=="\\"&&(s=null),o++;continue}if(l==='"'||l==="'"){s=l,o++;continue}if(l==="/"&&e[o+1]==="*"){const c=e.indexOf("*/",o+2);if(c===-1){o=n;break}o=c+2;continue}if(l==="{"){r++,o++;continue}if(l==="}"){r--,o++;continue}if(l===";"&&r===0){a(o),t.push(";"),o++;continue}o++}return i<n&&t.push(Nt(e.slice(i))),t.join("")}function Nt(e){const t=e.trim();if(!t||!t.includes(":")||t.includes("{")||/!important\s*$/.test(t))return e;const o=e.match(/^(\s*)([\s\S]*?)(\s*)$/);return o?`${o[1]}${o[2]} !important${o[3]}`:`${e} !important`}const v={rules:"srf-polish-rules-styles",auto:"srf-polish-auto-styles",manual:"srf-polish-manual-styles"},qn=["arial","helvetica","times new roman","times","verdana","georgia","palatino","garamond","comic sans ms","impact","lucida console","tahoma","trebuchet ms","courier new","courier"];function Fn(){const e=new Set,t=document.querySelectorAll("body, h1, h2, h3, p, a, span, div, li, td, th, button, input"),o=Math.min(t.length,50);for(let n=0;n<o;n++){const r=getComputedStyle(t[n]).fontFamily.toLowerCase();for(const i of qn)if(r.includes(i)){e.add(i);break}}return e}function lo(e){const t=e.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);return t?.299*Number(t[1])+.587*Number(t[2])+.114*Number(t[3])<128:!1}const Bn=["inter","sf pro","roboto","open sans","lato","montserrat","poppins","nunito","raleway","source sans","dm sans","plus jakarta","manrope","geist","figtree","outfit"];function tt(e){const t=e.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);return t?[Number(t[1]),Number(t[2]),Number(t[3])]:null}function _n(){const e=getComputedStyle(document.body),t=e.backgroundColor,o=e.color,n=e.fontFamily,r=lo(t),i=n.toLowerCase(),a=Bn.some(f=>i.includes(f));let s=!1;const l=document.querySelectorAll('button, [role="button"], input[type="submit"]');for(let f=0;f<Math.min(l.length,5);f++)if(parseFloat(getComputedStyle(l[f]).borderRadius)>=4){s=!0;break}let c=!1;const p=document.querySelectorAll("a, button");for(let f=0;f<Math.min(p.length,5);f++){const y=getComputedStyle(p[f]).transitionDuration;if(y&&y!=="0s"&&y!=="0ms"){c=!0;break}}let u="";const d=document.querySelectorAll("a[href]");for(let f=0;f<Math.min(d.length,5);f++){const y=getComputedStyle(d[f]).color,T=tt(y);if(T){const q=.299*T[0]+.587*T[1]+.114*T[2];if(q>30&&q<230){u=y;break}}}const m=document.querySelector('main, article, [role="main"], .content, .container'),h=m?m.getBoundingClientRect().width:document.body.clientWidth;return{bgColor:t,textColor:o,accentColor:u,primaryFont:n,isModernFont:a,hasRoundedButtons:s,hasTransitions:c,avgContentWidth:h,isDark:r}}function zn(e,t){let o="";switch(e){case"education":o+=`article, .post, .content, .lesson, .text { max-width: 720px; margin-left: auto; margin-right: auto; }
`,o+=`blockquote { border-left: 3px solid rgba(99, 102, 241, 0.3); padding-left: 16px; margin-left: 0; font-style: italic; }
`,o+=`p + p { margin-top: 1.2em; }
`;break;case"shopping":o+=`[class*="card"], [class*="product"], [class*="item"] { transition: transform 0.2s ease, box-shadow 0.2s ease; }
`,o+=`[class*="card"]:hover, [class*="product"]:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
`;break;case"coding":o+=`pre, code, .code, .CodeMirror, .monaco-editor { font-family: 'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace !important; }
`,o+=`pre { border-radius: 8px; padding: 16px; }
`;break;case"finance":o+=`table { border-collapse: collapse; }
`,o+=`td, th { padding: 8px 12px; }
`;break;case"general_ai":o+=`[class*="message"], [class*="chat"], [class*="bubble"] { border-radius: 12px; }
`,o+=`[class*="avatar"], [class*="icon"] img { border-radius: 50%; }
`;break}return o}function Nn(e,t){const o=(t==null?void 0:t.isDark)??lo(getComputedStyle(document.body).backgroundColor),n=(t==null?void 0:t.isModernFont)&&!(e!=null&&e.trim()),r=(t==null?void 0:t.hasRoundedButtons)??!1,i=(t==null?void 0:t.hasTransitions)??!1,a=e&&e.trim()?`${e}, -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif`:"'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif";let s="";n||((!e||!e.trim())&&(s+=`@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
`),Fn().size>0&&(s+=`body { font-family: ${a}; }
`,s+=`h1, h2, h3, h4, h5, h6 { font-family: ${a}; letter-spacing: -0.02em; }
`)),s+=`body { line-height: 1.6; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
`;let l="";const c=tt((t==null?void 0:t.textColor)??getComputedStyle(document.body).color),p=tt((t==null?void 0:t.bgColor)??getComputedStyle(document.body).backgroundColor);o?c&&c[0]===255&&c[1]===255&&c[2]===255&&(l+=`body { color: #e2e8f0; }
`):(c&&c[0]===0&&c[1]===0&&c[2]===0&&(l+=`body { color: #1a1a2e; }
`),p&&p[0]===255&&p[1]===255&&p[2]===255&&(l+=`body { background-color: #fafafa; }
`)),l+=`::selection { background: rgba(99, 102, 241, 0.2); }
`;let u="";i||(u+=`a, button, input, select, textarea, [role="button"] { transition: all 0.15s ease; }
`),u+=`input:focus, textarea:focus, select:focus { outline: none; box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.15); }
`,u+=`::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: ${o?"rgba(255,255,255,0.1)":"rgba(0,0,0,0.12)"}; border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: ${o?"rgba(255,255,255,0.2)":"rgba(0,0,0,0.2)"}; }
`;let d="";return d+=`html { scroll-behavior: smooth; }
`,r||(d+=`button, [role="button"], input[type="submit"], input[type="button"] { border-radius: 6px; }
`,d+=`input:not([type="checkbox"]):not([type="radio"]), textarea, select { border-radius: 6px; }
`),d+=`img { border-radius: 4px; transition: transform 0.3s ease, box-shadow 0.3s ease; }
`,d+=`article img:hover, figure img:hover, .content img:hover { transform: scale(1.01); box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
`,d+=`[class*="card"]:hover, [class*="Card"]:hover, [class*="item"]:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.08); transition: transform 0.2s ease, box-shadow 0.2s ease; }
`,d+=`@keyframes srfFadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
`,d+=`main, article, [role="main"], .content, .container { animation: srfFadeIn 0.4s ease both; }
`,[s,l,u,d]}function Rn(e,t){const o=_n();if(E("tokens","Page design tokens scanned",JSON.stringify({font:o.primaryFont.split(",")[0].replace(/['"]/g,"").trim(),isModernFont:o.isModernFont,hasRoundedButtons:o.hasRoundedButtons,hasTransitions:o.hasTransitions,isDark:o.isDark,bgColor:o.bgColor,contentWidth:Math.round(o.avgContentWidth)})),document.getElementById(v.rules))return E("rules","Skipped — rules already applied"),{result:"already",tokens:o};const n=[];o.isModernFont&&n.push("fonts (already modern)"),o.hasRoundedButtons&&n.push("button radius (already rounded)"),o.hasTransitions&&n.push("transitions (already exist)"),E("rules",`Applying rules engine${n.length?`. Skipping: ${n.join(", ")}`:""}`,t?`Category: ${t}`:void 0);const r=Nn(e,o);t&&t!=="unknown"&&r.push(zn(t,o.isDark)),ao();const i=document.createElement("style");i.id=v.rules,i.textContent=`/* Surface Polish Rules Engine — zero AI, adaptive */
`,document.head.appendChild(i),i.textContent+=N(r[0]);let a=1;function s(){a<r.length&&(i.textContent+=N(r[a]),a++,a<r.length&&requestAnimationFrame(s))}return requestAnimationFrame(s),{result:"applied",tokens:o}}function On(){const e=document.body,t=e.querySelectorAll("*").length,o=e.querySelectorAll("[style]").length,n=e.querySelectorAll("img").length,r=e.querySelectorAll("iframe").length;let i=0,a=!1;for(const f of Array.from(e.querySelectorAll("*")))f.shadowRoot&&(i++,a=!0);const s=/^[a-z]{1,3}[A-Z_-][a-zA-Z0-9_-]{6,}$/;let l=0;const c=e.querySelectorAll("[class]"),p=Math.min(c.length,100);for(let f=0;f<p;f++){const y=c[f].className;if(typeof y=="string")for(const T of y.split(" "))s.test(T)&&l++}const u=!!document.getElementById("root")||!!document.getElementById("__next"),d=[],m=[];let h="high";return t<500?d.push("Simple page — great fit"):t<2e3?d.push("Medium page — should work well"):(m.push(`Large (${t} elements) — may truncate`),h="medium"),n>10&&d.push("Image-rich — polish will shine"),o>20&&(m.push(`${o} inline styles — some resist`),h==="high"&&(h="medium")),l>15&&(m.push("Hashed classes — fragile selectors"),h==="high"&&(h="medium")),u&&m.push("SPA — re-renders may revert"),a&&(m.push(`${i} shadow DOM — untouchable`),h="low"),r>2&&m.push(`${r} iframes — untouchable`),{insights:d,confidence:h,warnings:m,elementCount:t}}function ot(){const e=[];e.push("### VISUAL DESIGN SYSTEM SPEC (GROUND TRUTH)");const t=getComputedStyle(document.body),o=t.backgroundColor,n=t.color,r=Dn(o);e.push(`- **Theme Mode:** ${r?"Dark Mode":"Light Mode"}`),e.push(`- **Body Background:** ${o}`),e.push(`- **Body Text Color:** ${n}`);const i={};try{for(const d of Array.from(document.styleSheets))try{for(const m of Array.from(d.cssRules))if(m instanceof CSSStyleRule&&(m.selectorText===":root"||m.selectorText==="body"))for(let h=0;h<m.style.length;h++){const f=m.style[h];if(f.startsWith("--")){const y=f.toLowerCase();(y.includes("color")||y.includes("bg")||y.includes("text")||y.includes("accent")||y.includes("font")||y.includes("radius")||y.includes("spacing")||y.includes("gap"))&&(i[f]=m.style.getPropertyValue(f).trim())}}}catch{}}catch{}const a=Object.keys(i).slice(0,15);if(a.length>0){e.push("- **Active CSS Custom Variables:**");for(const d of a)e.push(`  - \`${d}\`: ${i[d]}`)}e.push(`
### TYPOGRAPHY STACK`);const s=document.querySelector("h1"),l=document.querySelector("p"),c=document.querySelector('button, [role="button"], input[type="submit"]');if(s){const d=getComputedStyle(s);e.push(`- **Headings (H1):** font-family: ${d.fontFamily} | font-size: ${d.fontSize} | font-weight: ${d.fontWeight} | line-height: ${d.lineHeight} | color: ${d.color}`)}if(l){const d=getComputedStyle(l);e.push(`- **Paragraphs (Body):** font-family: ${d.fontFamily} | font-size: ${d.fontSize} | font-weight: ${d.fontWeight} | line-height: ${d.lineHeight} | color: ${d.color}`)}if(c){const d=getComputedStyle(c);e.push(`- **Interactive (Buttons):** font-family: ${d.fontFamily} | font-size: ${d.fontSize} | font-weight: ${d.fontWeight}`)}if(e.push(`
### INTERACTIVE AESTHETICS`),c){const d=getComputedStyle(c);e.push(`- **Button Style:** bg: ${d.backgroundColor} | text: ${d.color} | border-radius: ${d.borderRadius} | border: ${d.border} | padding: ${d.padding} | shadow: ${d.boxShadow||"none"} | transition: ${d.transition||"none"}`)}else e.push("- **Button Style:** No button sampled.");e.push(`
### RESPONSIVE LAYOUT GEOMETRY & LANDMARKS`);const p=[{tag:"header",el:document.querySelector("header")},{tag:"nav",el:document.querySelector('nav, [role="navigation"]')},{tag:"main",el:document.querySelector('main, article, [role="main"]')},{tag:"aside",el:document.querySelector('aside, [class*="sidebar"]')},{tag:"footer",el:document.querySelector("footer")}];for(const d of p)if(d.el){const m=d.el.getBoundingClientRect(),h=getComputedStyle(d.el);e.push(`- **\`<${d.tag}>\` Element:**`),e.push(`  - Dimensions: ${Math.round(m.width)}px x ${Math.round(m.height)}px`),e.push(`  - Styling: display: ${h.display} | position: ${h.position} | padding: ${h.padding} | margin: ${h.margin} | gap: ${h.gap||"none"}`),h.display==="flex"?e.push(`  - Flex Direction: ${h.flexDirection}`):h.display==="grid"&&e.push(`  - Grid Columns: ${h.gridTemplateColumns}`)}let u=!1;try{const d=document.querySelectorAll("[class]");let m=0;const h=Math.min(d.length,50),f=[/^(bg|text|p|m|rounded|flex|grid|border|w|h|justify|items|gap)-[a-z0-9]/,/^hover:/,/^focus:/];for(let y=0;y<h;y++){const T=d[y].className;if(typeof T=="string")for(const q of T.split(/\s+/))f.some($=>$.test(q))&&m++}m>15&&(u=!0)}catch{}return e.push(`
### UTILITY FRAMEWORK DETECTION
- **Tailwind CSS Detected:** ${u?"Yes":"No"}`),e.join(`
`)}function Dn(e){const t=e.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);return t?.299*Number(t[1])+.587*Number(t[2])+.114*Number(t[3])<128:!1}function nt(){const e=document.body.cloneNode(!0),t=["script","style","svg","canvas","iframe","noscript","audio","template","object","embed","map","area"];for(const n of t){const r=e.getElementsByTagName(n);for(let i=r.length-1;i>=0;i--)r[i].remove()}e.querySelectorAll("#srf-polish-overlay, #surface-overlay-root, .srf-preview-bar-container").forEach(n=>n.remove());for(const n of Array.from(e.querySelectorAll("*"))){const r=n.tagName.toLowerCase(),i=[];for(const a of Array.from(n.attributes))(a.name.startsWith("data-")||a.name.startsWith("aria-")||a.name==="jsaction"||a.name==="jscontroller"||a.name==="jsmodel"||a.name==="jsname"||a.name==="tabindex")&&i.push(a.name),a.name==="src"&&a.value.startsWith("data:image")&&n.setAttribute("src","[data-img]"),a.name==="srcset"&&i.push("srcset");if(i.forEach(a=>n.removeAttribute(a)),r==="img"||r==="video"||r==="picture"){const a=n.getAttribute("src");let s=null;if(n.id?s=document.getElementById(n.id):a&&a!=="[data-img]"&&(s=document.querySelector(`[src="${CSS.escape(a)}"]`)),s){const l=s.getBoundingClientRect();l.width>0&&l.height>0&&n.setAttribute("data-srf-size",`${Math.round(l.width)}x${Math.round(l.height)}`)}}}return e.innerHTML}const Pn=new Set(["@font-face","@keyframes","@charset"]),jn=/^srf-|^wp-/;function Hn(e=4e4){const t=[],o=new Set;let n=0,r=!1;for(const a of Array.from(document.styleSheets)){const s=a.ownerNode;if(s instanceof Element){const c=s.getAttribute("id")??"";if(jn.test(c))continue}let l;try{l=a.cssRules}catch{n++;continue}for(const c of Array.from(l)){const p=c.cssText.trim(),u=p.match(/^(@[\w-]+)/);u&&Pn.has(u[1])||o.has(p)||(o.add(p),p.includes("--")&&(r=!0),t.push(p))}}const i=t.join(`
`).slice(0,e);return{rules:i,ruleCount:t.length,sizeChars:i.length,crossOriginSkipped:n,hasCustomProps:r}}function ve(e){const t=window.getComputedStyle(e);return t.display!=="none"&&t.visibility!=="hidden"&&t.opacity!=="0"}function ue(e,t=200){return(e??"").replace(/\s+/g," ").trim().slice(0,t)}function Wn(){var s;const e=[];document.querySelectorAll("h1,h2,h3,h4").forEach(l=>{if(!ve(l))return;const c=ue(l.textContent,120);c&&e.push({level:parseInt(l.tagName[1]),text:c})});const t=[];document.querySelectorAll("p").forEach(l=>{if(!ve(l))return;const c=ue(l.textContent,180);c.length>30&&t.push(c)});const o=[],n=new Set;document.querySelectorAll('nav a, header a, [role="navigation"] a').forEach(l=>{if(!ve(l))return;const c=ue(l.textContent,60);c&&!n.has(c)&&(n.add(c),o.push(c))});const r=[],i=new Set;document.querySelectorAll('button, a[class*="btn"], a[class*="cta"], [class*="button"], input[type="submit"]').forEach(l=>{if(!ve(l))return;const c=ue(l.textContent||l.value,80);c&&!i.has(c)&&(i.add(c),r.push(c))});const a=[];return document.querySelectorAll("img[alt]").forEach(l=>{const c=ue(l.alt,60);c&&a.push(c)}),{title:document.title,description:((s=document.querySelector('meta[name="description"]'))==null?void 0:s.getAttribute("content"))??"",url:location.href,headings:e.slice(0,12),paragraphs:t.slice(0,6),navLinks:o.slice(0,12),ctas:r.slice(0,8),imageAlts:a.slice(0,6)}}function Gn(e){const t=[];return t.push(`URL: ${e.url}`),e.title&&t.push(`TITLE: ${e.title}`),e.description&&t.push(`DESC: ${e.description}`),e.headings.length&&(t.push("HEADINGS:"),e.headings.forEach(o=>t.push(`  H${o.level}: ${o.text}`))),e.paragraphs.length&&(t.push("COPY:"),e.paragraphs.forEach(o=>t.push(`  — ${o}`))),e.navLinks.length&&t.push(`NAV: ${e.navLinks.join(" | ")}`),e.ctas.length&&t.push(`CTAs: ${e.ctas.join(" | ")}`),t.join(`
`)}const Vn=new Set(["SCRIPT","STYLE","NOSCRIPT","IFRAME","SVG","CANVAS","AUDIO","VIDEO","TEMPLATE","OBJECT","EMBED"]),Un=new Set(["data-reactid","data-react-checksum","jsaction","jscontroller","jsname","jsmodel","aria-describedby","tabindex","autocomplete"]);function Yn(e=3e4){const t=document.body.cloneNode(!0);return t.querySelectorAll(Array.from(Vn).join(",")).forEach(o=>o.remove()),t.querySelectorAll("*").forEach(o=>{for(const n of Array.from(o.attributes))(Un.has(n.name)||n.name.startsWith("data-")&&n.name!=="data-srf-size")&&o.removeAttribute(n.name);if(o.childNodes.length===1&&o.childNodes[0].nodeType===Node.TEXT_NODE){const n=o.childNodes[0];n.data.length>120&&(n.data=n.data.slice(0,100)+"…")}}),t.innerHTML.slice(0,e)}function co(e){const{includeDOM:t=!0,cssMaxChars:o=35e3,domMaxChars:n=25e3}=e,r=Hn(o),i=Wn(),a=[];if(a.push(`### PAGE CONTENT
${Gn(i)}`),a.push(`### FULL STYLESHEET (${r.ruleCount} rules, ${r.crossOriginSkipped} cross-origin sheets skipped)
\`\`\`css
${r.rules}
\`\`\``),t){const s=Yn(n);a.push(`### DOM STRUCTURE
\`\`\`html
${s}
\`\`\``)}return a.join(`

`)}const _=[{rules:"",auto:"",manual:""}];let I=0;function P(){const e={rules:ae(v.rules),auto:ae(v.auto),manual:ae(v.manual)};if(I>=0){const t=_[I];if(t.rules===e.rules&&t.auto===e.auto&&t.manual===e.manual)return}_.length=I+1,_.push(e),I=_.length-1}function uo(){return I<=0?!1:(I--,ut(_[I]),!0)}function Kn(){return I>=_.length-1?!1:(I++,ut(_[I]),!0)}function pe(){return{position:I+1,total:_.length,canBack:I>0,canForward:I<_.length-1}}function rt(){I=0,ut(_[0])}function Rt(){const e=ae(v.manual),t=ae(v.auto),o=ae(v.rules);return e?"manual":t?"auto":o?"rules":"unpolished"}function j(e){let t=document.getElementById(e);return t||(t=document.createElement("style"),t.id=e,document.head.appendChild(t)),t}function ae(e){var t;return((t=document.getElementById(e))==null?void 0:t.textContent)??""}function ut(e){Ge(v.rules,e.rules),Ge(v.auto,e.auto),Ge(v.manual,e.manual)}function Ge(e,t){let o=document.getElementById(e);t?(o||(o=document.createElement("style"),o.id=e,document.head.appendChild(o)),o.textContent=t):o&&o.remove()}const xe="srf-polish-overlay-root";let Y=0,Ce=null;function po(){let e=document.getElementById(xe);if(e&&e.shadowRoot)return e.shadowRoot;e=document.createElement("div"),e.id=xe,e.style.cssText="all: initial; position: fixed; z-index: 2147483646; bottom: 24px; left: 24px; pointer-events: none;";const t=e.attachShadow({mode:"open"});return t.innerHTML=`
    <style>
      @keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes fadeOut { from { opacity: 1; transform: translateY(0); } to { opacity: 0; transform: translateY(6px); } }
      @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
      @keyframes progressFill { from { width: 0%; } to { width: 100%; } }
      @keyframes checkPop { 0% { transform: scale(0); opacity: 0; } 60% { transform: scale(1.2); } 100% { transform: scale(1); opacity: 1; } }
      @keyframes scanLine {
        0% { top: 0; opacity: 0; }
        10% { opacity: 1; }
        90% { opacity: 1; }
        100% { top: 100%; opacity: 0; }
      }

      :host {
        all: initial;
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', sans-serif;
        -webkit-font-smoothing: antialiased;
      }

      /* Scan line that sweeps the viewport */
      .scan-line {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 2px;
        background: linear-gradient(90deg, transparent, rgba(99, 102, 241, 0.4), transparent);
        animation: scanLine 1.2s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        pointer-events: none;
        z-index: 2147483647;
        display: none;
      }
      .scan-line.active { display: block; }

      /* Main card */
      .card {
        display: none;
        align-items: center;
        gap: 10px;
        background: #FFFFFF;
        border: 1px solid #9E9E9E;
        border-radius: 8px;
        padding: 12px 16px;
        pointer-events: auto;
        animation: fadeIn 0.2s cubic-bezier(0.25, 0.1, 0.25, 1);
        font-size: 13px;
        color: #363636;
        max-width: 260px;
        transition: all 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
        overflow: hidden;
      }
      .card.visible { display: flex; }
      .card.fading { animation: fadeOut 0.25s cubic-bezier(0.25, 0.1, 0.25, 1) forwards; }
      .card.error { border-color: #FF3B30; }
      .card.success { border-color: #34C759; }

      /* Pill mode — shrinks when AI is streaming and page is already transforming */
      .card.pill {
        padding: 8px 14px;
        max-width: 180px;
        border-color: rgba(99, 102, 241, 0.3);
        background: rgba(255, 255, 255, 0.92);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
      }

      /* Progress bar */
      .progress-track {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 2px;
        background: rgba(0, 0, 0, 0.04);
        overflow: hidden;
      }
      .progress-bar {
        height: 100%;
        background: rgba(99, 102, 241, 0.5);
        border-radius: 1px;
        width: 0%;
        transition: width 0.3s ease;
      }

      /* Pulsing dot for pill mode */
      .dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: rgb(99, 102, 241);
        animation: pulse 1.5s ease-in-out infinite;
        flex-shrink: 0;
        display: none;
      }
      .pill .dot { display: block; }

      /* Checkmark for completion */
      .check {
        width: 16px;
        height: 16px;
        flex-shrink: 0;
        display: none;
      }
      .check.pop {
        display: block;
        animation: checkPop 0.3s cubic-bezier(0.25, 0.1, 0.25, 1) forwards;
      }

      .spinner {
        width: 14px;
        height: 14px;
        border: 1px solid #E5E5EA;
        border-top-color: #363636;
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
        flex-shrink: 0;
      }
      @keyframes spin { to { transform: rotate(360deg); } }

      .title { font-weight: 400; letter-spacing: 0.01em; color: #000; white-space: nowrap; }
      .subtitle { color: #6B6B70; font-size: 12px; margin-top: 2px; letter-spacing: 0.01em; }

      @media (prefers-color-scheme: dark) {
        .card {
          background: #1C1C1E;
          border-color: #636366;
          color: #FFFFFF;
        }
        .card.pill {
          background: rgba(28, 28, 30, 0.92);
          border-color: rgba(99, 102, 241, 0.3);
        }
        .title { color: #FFFFFF; }
        .subtitle { color: #A4A4A4; }
        .spinner { border-color: #38383A; border-top-color: #FFFFFF; }
        .progress-track { background: rgba(255, 255, 255, 0.04); }
      }
    </style>

    <div class="scan-line" id="scanLine"></div>
    <div class="card" id="card">
      <div class="spinner" id="spinner"></div>
      <div class="dot" id="dot"></div>
      <svg class="check" id="check" viewBox="0 0 16 16" fill="none">
        <circle cx="8" cy="8" r="7.5" stroke="#34C759" stroke-width="1"/>
        <path d="M5 8.5L7 10.5L11 6" stroke="#34C759" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <div>
        <div class="title" id="title">Analyzing page</div>
        <div class="subtitle" id="subtitle"></div>
      </div>
      <div class="progress-track"><div class="progress-bar" id="progress"></div></div>
    </div>
  `,document.body.appendChild(e),t}function $e(e="Streaming styles…"){const t=po(),o=t.getElementById("card"),n=t.getElementById("title"),r=t.getElementById("subtitle"),i=t.getElementById("spinner"),a=t.getElementById("dot"),s=t.getElementById("check"),l=t.getElementById("scanLine"),c=t.getElementById("progress");!o||!n||!r||!i||!l||!c||!a||!s||(pt(),o.classList.remove("fading","error","success","pill"),s.classList.remove("pop"),Y=1,l.classList.add("active"),o.classList.add("visible"),i.style.display="",n.textContent="Analyzing page",r.textContent="",c.style.width="15%",Ce=setTimeout(()=>{Y<2&&(Y=2,l.classList.remove("active"),n.textContent="Applying styles",r.textContent=e,c.style.width="45%")},300),setTimeout(()=>{Y<3&&qe()},1500))}function qe(){const e=document.getElementById(xe);if(!(e!=null&&e.shadowRoot))return;const t=e.shadowRoot.getElementById("card"),o=e.shadowRoot.getElementById("spinner"),n=e.shadowRoot.getElementById("progress");!t||!o||!n||(Y=3,t.classList.add("pill"),o.style.display="none",n.style.width="70%")}function Ve(e){const t=document.getElementById(xe);if(!(t!=null&&t.shadowRoot))return;const o=t.shadowRoot.getElementById("subtitle");o&&(o.textContent=e)}function B(){const e=document.getElementById(xe);if(!(e!=null&&e.shadowRoot))return;const t=e.shadowRoot.getElementById("card"),o=e.shadowRoot.getElementById("scanLine");t&&(pt(),Y=0,o==null||o.classList.remove("active"),t.classList.add("fading"),setTimeout(()=>{t.classList.remove("visible","fading","pill")},250))}function R(e,t=""){const o=po(),n=o.getElementById("card"),r=o.getElementById("title"),i=o.getElementById("subtitle"),a=o.getElementById("spinner"),s=o.getElementById("check"),l=o.getElementById("progress");if(!(!n||!r||!i||!a||!s||!l))if(pt(),n.classList.remove("fading","pill"),n.classList.add("visible"),a.style.display="none",Y=4,e==="cached")n.classList.remove("error"),n.classList.add("success"),s.classList.add("pop"),r.textContent="Polished",i.textContent=t||"From cache",l.style.width="100%",setTimeout(()=>B(),1500);else if(e==="ai")n.classList.remove("error"),n.classList.add("success"),s.classList.add("pop"),r.textContent="Polished",i.textContent=t||"Personalized for you",l.style.width="100%",setTimeout(()=>B(),1500);else{n.classList.remove("success"),n.classList.add("error"),r.textContent="Polish failed",i.textContent=t||"Your page was not modified",i.style.whiteSpace="normal",i.style.maxWidth="260px",l.style.width="0%";const c=()=>{n.removeEventListener("click",c),B()};n.addEventListener("click",c),n.style.cursor="pointer",n.title="Click to dismiss"}}function pt(){Ce&&(clearTimeout(Ce),Ce=null)}const Xn=["chrome:","chrome-extension:","file:","about:","edge:"];let Ot=!1;function Dt(e){var u;const t=["background-color","color","border","border-radius","padding","font-family","font-size","font-weight","text-decoration","cursor","display","letter-spacing","text-transform","box-shadow","transition"],n=window.getComputedStyle(e).backgroundColor;if(!(n==="rgba(0, 0, 0, 0)"||n==="transparent"||n===""))return;const i=e.tagName.toLowerCase(),a=new Set(((u=e.className)==null?void 0:u.toString().split(/\s+/).filter(Boolean))??[]),s=Array.from(document.querySelectorAll(i)).filter(d=>d!==e&&!e.contains(d));if(s.length===0)return;const l=s.map(d=>{var f;const m=new Set(((f=d.className)==null?void 0:f.toString().split(/\s+/).filter(Boolean))??[]),h=[...a].filter(y=>m.has(y)).length;return{c:d,overlap:h}}).sort((d,m)=>m.overlap-d.overlap);if(l[0].overlap===0)return;const c=window.getComputedStyle(l[0].c),p=e;for(const d of t){const m=c.getPropertyValue(d).trim();m&&m!=="none"&&m!=="auto"&&!m.startsWith("rgba(0, 0, 0, 0)")&&p.style.setProperty(d,m)}}async function ft(e=!1){if(Ot&&!e||(Ot=!0,Xn.includes(location.protocol))||!location.hostname)return;ao(),await Qn();const{srf_polish_always_on:t,srf_polish_prefs:o,srf_blocklist:n}=await chrome.storage.local.get(["srf_polish_always_on","srf_polish_prefs","srf_blocklist"]);if(t!==!0)return;if(Array.isArray(n)&&n.includes(location.hostname)){chrome.runtime.sendMessage({type:"telemetry-event",payload:{kind:"polish_blocked",hostname:location.hostname,ts:Date.now(),sessionId:Ue()}});return}if(!e){D="webpaper-clean",_e(),$e("Personalizing for you…"),setTimeout(()=>qe(),400),Fe(85e3,"auto-clean on load");const d=co({includeDOM:!0,cssMaxChars:12e3,domMaxChars:2e4});chrome.runtime.sendMessage({type:"polish-run-manual",payload:{url:location.href,dom:d,mode:"webpaper-clean",personalise:!1}}).catch(()=>{B(),U()});return}const r=o??{},i=J(location.hostname),{result:a,tokens:s}=Rn(r.fonts,i);a==="applied"&&(P(),chrome.runtime.sendMessage({type:"telemetry-event",payload:{kind:"polish_rules_applied",hostname:location.hostname,ts:Date.now(),sessionId:Ue()}}));const l=ot(),c=nt(),p=`${l}

### FULL WEBPAGE DOM
\`\`\`html
${c}
\`\`\``;let u=null;try{u=await chrome.runtime.sendMessage({type:"polish-get-cache",payload:{hostname:location.hostname}})}catch{return}if(u!=null&&u.css){E("cache",`Cache HIT for ${location.hostname}`,`${u.css.length} chars of cached CSS`);const d=j(v.auto);d.textContent=N(u.css),P(),R("cached"),chrome.runtime.sendMessage({type:"telemetry-event",payload:{kind:"polish_cache_hit",hostname:location.hostname,ts:Date.now(),sessionId:Ue()}}),Le("kept");return}E("cache",`Cache MISS for ${location.hostname} — requesting AI polish`),_e(),$e("Streaming styles from Claude…"),Fe(55e3,"no response from service worker within 55s"),chrome.runtime.sendMessage({type:"polish-auto-polish",payload:{hostname:location.hostname,url:location.href,dom:p}})}let Te=null;function Fe(e,t){U(),Te=setTimeout(()=>{E("info",`Overlay watchdog fired: ${t}`),B(),R("error","Polish timed out — no response")},e)}function U(){Te!==null&&(clearTimeout(Te),Te=null)}let at=!1,it=!1,D="optimise";const Be=new Map;let ie=null;function fo(){for(const[e,t]of Be){if(!t)continue;const o=j(e);o.textContent=(o.textContent??"")+t}Be.clear()}function Zn(){if(!at){const e=document.getElementById(v.auto);e&&(e.textContent??"").includes("}")&&(at=!0,qe())}if(!it){const e=document.getElementById(v.manual);e&&(e.textContent??"").includes("}")&&(it=!0,qe())}}function Pt(e,t){t&&(Be.set(e,(Be.get(e)??"")+t),ie===null&&(ie=requestAnimationFrame(()=>{ie=null,fo(),Zn()})))}function jt(){ie!==null&&(cancelAnimationFrame(ie),ie=null),fo()}function Jn(){chrome.runtime.onMessage.addListener((e,t,o)=>{var n,r,i,a,s,l,c,p,u,d,m,h,f,y,T,q,$,gt,bt,yt,xt,wt,vt,kt,St,Et,Ct,Tt;if(!((r=(n=e==null?void 0:e.type)==null?void 0:n.startsWith)!=null&&r.call(n,"polish-"))&&!((a=(i=e==null?void 0:e.type)==null?void 0:i.startsWith)!=null&&a.call(i,"webpaper-")))return!1;if(e.type==="polish-devlog-entry"){const g=((s=e.payload)==null?void 0:s.stage)??"info",x=((l=e.payload)==null?void 0:l.message)??"";return E(g,x,(c=e.payload)==null?void 0:c.detail),g==="ai-request"&&(x.includes("Pass 1")?Ve("Analyzing page…"):x.includes("Pass 2")?Ve("Generating styles…"):x.includes("Variations")&&Ve(`Generating ${((d=(u=(p=e.payload)==null?void 0:p.detail)==null?void 0:u.match(/(\d+)x/))==null?void 0:d[1])??"N"} in parallel…`)),!1}if(e.type==="polish-auto-polish-css")return Pt(v.auto,((m=e.payload)==null?void 0:m.chunk)??""),!1;if(e.type==="polish-css-chunk")return Pt(v.manual,((h=e.payload)==null?void 0:h.chunk)??""),!1;if(e.type==="polish-auto-polish-done"){U(),jt();const g=j(v.auto),x=(g.textContent??"").length,w=We(g.textContent??"",J(location.hostname));g.textContent=N(w);const b=(g.textContent??"").length;return E("ai-done",`Auto-polish complete: ${x} chars raw → ${b} chars after validator`,x!==b?`Validator stripped ${x-b} chars`:"Validator: nothing stripped"),at=!1,B(),P(),R("ai"),Le("kept"),!1}if(e.type==="polish-done"){U(),jt();const g=j(v.manual),x=g.textContent??"",w=x.length;if(E("info",`polish-done fired. Manual layer has ${w} chars before sanitize.`),x.trim()){const C=We(x,J(location.hostname));g.textContent=N(C)}E("ai-done",`Manual polish (${D}) complete: ${w} chars → ${((f=g.textContent)==null?void 0:f.length)??0} after boost`),E("info","Generated CSS",x.substring(0,500)+(w>500?"…":"")),it=!1,B(),P();const b=((T=(y=document.getElementById(v.manual))==null?void 0:y.textContent)==null?void 0:T.length)??0;return E("info",`After takeSnapshot: manual layer has ${b} chars`),R("ai"),Le("kept"),D!=="redesign"&&D!=="minimise"&&D!=="prompt"&&er(),D==="minimise"&&x.trim()&&chrome.runtime.sendMessage({type:"webpaper-clean-done",payload:{css:x,url:location.href,title:document.title}}).catch(()=>{}),!1}if(e.type==="polish-error")return U(),B(),R("error",((q=e.payload)==null?void 0:q.error)??""),!1;if(e.type==="polish-run-variations"){const g=Math.min(Math.max((($=e.payload)==null?void 0:$.count)??3,2),5),x=((gt=e.payload)==null?void 0:gt.mode)??"redesign";D=x,_e(),$e(`Generating ${g} variations…`),Fe(12e4,`variations (${x} x${g}) timeout`);const w=ot(),b=nt(),C=`${w}

### FULL WEBPAGE DOM
\`\`\`html
${b}
\`\`\``;return chrome.runtime.sendMessage({type:"polish-run-variations-bg",payload:{url:location.href,dom:C,mode:x,count:g,personalise:((bt=e.payload)==null?void 0:bt.personalise)??!1,fixDescription:(yt=e.payload)==null?void 0:yt.fixDescription}}),o({success:!0}),!1}if(e.type==="polish-variation-ready"){const g=j(v.manual),x=((xt=e.payload)==null?void 0:xt.css)??"";return g.textContent=x?N(x):"",P(),E("info",`Variation ${((wt=e.payload)==null?void 0:wt.index)??"?"}/${((vt=e.payload)==null?void 0:vt.total)??"?"} applied`,`${(((kt=e.payload)==null?void 0:kt.css)??"").length} chars`),!1}if(e.type==="polish-variations-done")return U(),B(),R("ai",`${((St=e.payload)==null?void 0:St.count)??"?"} variations ready — use Undo/Redo to flip through them`),Le("kept"),!1;if(e.type==="polish-start-manual"){const g=((Et=e.payload)==null?void 0:Et.mode)??"optimise";E("info",`polish-start-manual received: mode=${g}`),D=g,_e(),$e(`${g[0].toUpperCase()+g.slice(1)}ing page…`),Fe(125e3,`manual polish (${g}) timeout`);const x=ot(),w=nt();let b;return g==="prompt"||g==="webpaper-clean"?b=co({includeDOM:!0,cssMaxChars:12e3,domMaxChars:2e4}):b=`${x}

### FULL WEBPAGE DOM
\`\`\`html
${w}
\`\`\``,E("info",`DOM prepared: ${b.length} chars`),chrome.runtime.sendMessage({type:"polish-run-manual",payload:{url:location.href,dom:b,mode:g,personalise:((Ct=e.payload)==null?void 0:Ct.personalise)??!1,fixDescription:(Tt=e.payload)==null?void 0:Tt.fixDescription}}),o({success:!0}),!1}if(e.type==="webpaper-apply"){U();const{css:g,mutations:x}=e.payload;if(g!=null&&g.trim()){const b=j(v.manual),C=We(g,J(location.hostname));b.textContent=N((b.textContent??"")+`
`+C)}const w=[];if(Array.isArray(x)&&x.length>0)for(const b of x)try{const C=document.querySelector(b.selector);if(!C){w.push({op:b.op,selector:b.selector,ok:!1,reason:"selector matched nothing"});continue}if(b.op==="insert"&&b.html){C.insertAdjacentHTML(b.where??"beforeend",b.html);const ee=b.where??"beforeend",te=C.children,oe=ee==="afterbegin"?te[0]:ee==="beforeend"?te[te.length-1]:null;oe&&Dt(oe),w.push({op:b.op,selector:b.selector,ok:!0})}else b.op==="text"&&b.content!==void 0?(C.textContent=b.content,w.push({op:b.op,selector:b.selector,ok:!0})):b.op==="remove"?(C.remove(),w.push({op:b.op,selector:b.selector,ok:!0})):b.op==="attr"&&b.attr&&(C.setAttribute(b.attr,b.value??""),w.push({op:b.op,selector:b.selector,ok:!0}))}catch(C){w.push({op:b.op,selector:b.selector,ok:!1,reason:String(C)})}return P(),B(),R("ai"),chrome.runtime.sendMessage({type:"webpaper-mutation-results",payload:{mutations:w,cssApplied:!!(g!=null&&g.trim())}}).catch(()=>{}),o({ok:!0}),!1}if(e.type==="polish-apply-mutations"){const{css:g,mutations:x}=e.payload;if(g!=null&&g.trim()){const w=j(v.manual);w.textContent=N(g)}if(Array.isArray(x))for(const w of x)try{const b=document.querySelector(w.selector);if(!b)continue;if(w.op==="insert"&&w.html){const C=b.childElementCount;b.insertAdjacentHTML(w.where??"beforeend",w.html);const ee=b.children,te=w.where??"beforeend",oe=te==="afterbegin"?ee[0]??null:te==="beforeend"?ee[ee.length-1]??null:null;oe&&oe.className&&b.childElementCount>C&&Dt(oe)}else w.op==="text"&&w.content!==void 0?b.textContent=w.content:w.op==="remove"?b.remove():w.op==="attr"&&w.attr&&b.setAttribute(w.attr,w.value??"")}catch{}return P(),o({ok:!0}),!1}if(e.type==="polish-remove-now")return rt(),o({ok:!0}),!1;if(e.type==="polish-apply-now")return ft(!0),o({ok:!0}),!1;if(e.type==="polish-history-back"){const g=uo(),x=pe();return x.position===1&&chrome.runtime.sendMessage({type:"polish-log-taste",payload:{hostname:location.hostname,action:"undone"}}),o({ok:g,...x}),!1}if(e.type==="polish-history-forward"){const g=Kn();return o({ok:g,...pe()}),!1}if(e.type==="polish-get-history-state")return o(pe()),!1;if(e.type==="polish-get-page-status")return o({status:Rt(),...pe()}),!1;if(e.type==="polish-analyze-page")return o(On()),!1;if(e.type==="polish-reset")return E("reset","User reset to original"),rt(),o({ok:!0,...pe(),status:Rt()}),!1;if(e.type==="polish-get-devlog")return o({log:vn()}),!1;if(e.type==="polish-capture-snapshot")return(async()=>{try{const{captureSnapshot:g}=await Kt(async()=>{const{captureSnapshot:w}=await import("./snapshot-capture-Dc_gV2El.js");return{captureSnapshot:w}},__vite__mapDeps([0,1,2,3,4])),x=g();o({success:!0,snapshot:x})}catch(g){o({success:!1,error:g instanceof Error?g.message:String(g)})}})(),!0;if(e.type==="polish-get-share-css"){const g=document.getElementById(v.manual),x=document.getElementById(v.auto),w=(g==null?void 0:g.textContent)??"",b=(x==null?void 0:x.textContent)??"",C=w.trim()||b.trim()||"";return o({css:C}),!1}return e.type==="polish-clear-devlog"&&(kn(),o({ok:!0})),!1})}async function Qn(){if(location.hash.includes("srf-polish="))try{const{readShareFromHash:e}=await Kt(async()=>{const{readShareFromHash:n}=await import("./share-encoder-Bm__IQjr.js");return{readShareFromHash:n}},[]),t=await e(location.hash);if(!(t!=null&&t.css))return;E("info",`Shared polish detected in URL${t.mode?` (${t.mode})`:""}`,`${t.css.length} chars`);const o=j(v.manual);o.textContent=N(t.css),P(),R("ai","Shared polish applied");try{const n=location.href.split("#")[0];history.replaceState(null,"",n)}catch{}}catch(e){E("info","Shared polish decode failed",e instanceof Error?e.message:String(e))}}let ke=null;function Ue(){return ke||(ke=crypto.randomUUID(),ke)}function Le(e){setTimeout(()=>{var o;const t=document.getElementById(v.auto);t&&(((o=t.textContent)==null?void 0:o.length)??0)>0&&chrome.runtime.sendMessage({type:"polish-log-taste",payload:{hostname:location.hostname,action:e}})},3e4)}let Ae=0;function _e(){Ae=document.body.scrollHeight}function er(){setTimeout(()=>{let e=0;const t=[document.querySelector("h1"),document.querySelector("p"),document.querySelector("button"),document.querySelector("a"),document.querySelector("main")??document.querySelector("article")].filter(Boolean);for(const i of t){const a=getComputedStyle(i),s=i.getBoundingClientRect();(a.visibility==="hidden"||a.opacity==="0"||a.display==="none"||s.left<-1e3||s.top<-1e3)&&e++}if(e>=2){Ye("Content hidden — polish reverted");return}const o=getComputedStyle(document.body),n=o.color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/),r=o.backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);if(n&&r){const i=.2126*(+n[1]/255)+.7152*(+n[2]/255)+.0722*(+n[3]/255),a=.2126*(+r[1]/255)+.7152*(+r[2]/255)+.0722*(+r[3]/255),s=Math.max(i,a)+.05,l=Math.min(i,a)+.05;if(s/l<2){Ye("Low contrast — polish reverted");return}}if(Ae>0){const i=document.body.scrollHeight;if(Math.abs(i-Ae)/Ae>1.5){Ye("Layout broken — polish reverted");return}}},2e3)}function Ye(e){E("rollback",`Auto-rollback triggered: ${e}`),uo(),R("error",e),chrome.runtime.sendMessage({type:"polish-log-taste",payload:{hostname:location.hostname,action:"undone"}})}let M=null,L=null,H=null,W=null,Ke=null;const tr=`
  #srf-grok-x-toggle {
    position: fixed;
    right: 24px;
    bottom: 24px;
    width: 56px;
    height: 56px;
    border-radius: 50%;
    background-color: #000000;
    color: #ffffff;
    border: 1px solid #2f3336;
    cursor: pointer;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: transform 0.2s ease, background-color 0.2s ease;
    z-index: 2147483645;
  }
  #srf-grok-x-toggle:hover {
    transform: scale(1.08);
    background-color: #15181c;
  }
  #srf-grok-x-toggle svg {
    width: 22px;
    height: 22px;
    fill: currentColor;
  }

  #srf-grok-x-drawer {
    position: fixed;
    top: 0;
    right: -420px;
    width: 400px;
    height: 100vh;
    background-color: #000000;
    color: #e7e9ea;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    box-shadow: -4px 0 24px rgba(0, 0, 0, 0.5);
    transition: right 0.35s cubic-bezier(0.16, 1, 0.3, 1);
    z-index: 2147483646;
    display: flex;
    flex-direction: column;
    border-left: 1px solid #2f3336;
    box-sizing: border-box;
    text-align: left;
  }
  #srf-grok-x-drawer.open {
    right: 0;
  }

  .grok-x-header {
    padding: 16px;
    border-bottom: 1px solid #2f3336;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .grok-x-title-area {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .grok-x-title {
    font-size: 20px;
    font-weight: 800;
    margin: 0;
    letter-spacing: -0.4px;
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .grok-x-brain-badge {
    font-size: 10px;
    background: linear-gradient(135deg, #1d9bf0, #8ecdf8);
    color: #ffffff;
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: bold;
    text-transform: uppercase;
  }
  .grok-x-close-btn {
    background: none;
    border: none;
    color: #71767b;
    cursor: pointer;
    padding: 8px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.2s, color 0.2s;
  }
  .grok-x-close-btn:hover {
    background-color: rgba(239, 243, 244, 0.1);
    color: #e7e9ea;
  }

  .grok-x-content {
    flex: 1;
    overflow-y: auto;
    padding: 12px 16px;
    display: flex;
    flex-direction: column;
    gap: 16px;
  }

  .grok-x-tweet-card {
    border-bottom: 1px solid #2f3336;
    padding-bottom: 16px;
    display: flex;
    gap: 12px;
  }
  .grok-x-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background-color: #1d9bf0;
    color: #ffffff;
    font-weight: bold;
    font-size: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    user-select: none;
  }
  .grok-x-tweet-body {
    flex: 1;
  }
  .grok-x-tweet-header {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 4px;
    margin-bottom: 4px;
  }
  .grok-x-author-name {
    font-weight: 700;
    color: #e7e9ea;
    font-size: 15px;
  }
  .grok-x-author-name:hover {
    text-decoration: underline;
    cursor: pointer;
  }
  .grok-x-verified-icon {
    width: 14px;
    height: 14px;
    fill: #1d9bf0;
    display: inline-block;
  }
  .grok-x-author-handle {
    color: #71767b;
    font-size: 14px;
  }
  .grok-x-dot {
    color: #71767b;
    font-size: 12px;
  }
  .grok-x-timestamp {
    color: #71767b;
    font-size: 14px;
  }
  .grok-x-tweet-text {
    font-size: 15px;
    line-height: 20px;
    color: #e7e9ea;
    white-space: pre-wrap;
    word-break: break-word;
    margin-bottom: 12px;
  }

  .grok-x-actions {
    display: flex;
    justify-content: space-between;
    max-width: 320px;
    color: #71767b;
    font-size: 13px;
  }
  .grok-x-action {
    display: flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;
    transition: color 0.15s ease;
    background: none;
    border: none;
    padding: 4px;
    color: #71767b;
  }
  .grok-x-action svg {
    width: 16px;
    height: 16px;
    fill: currentColor;
  }
  .grok-x-action:hover.reply { color: #1d9bf0; }
  .grok-x-action:hover.retweet { color: #00ba7c; }
  .grok-x-action:hover.like { color: #f91880; }
  .grok-x-action:hover.views { color: #1d9bf0; }
  .grok-x-action.active.like { color: #f91880; font-weight: bold; }
  .grok-x-action.active.retweet { color: #00ba7c; font-weight: bold; }

  .grok-x-cn-card {
    border: 1px solid #2f3336;
    border-radius: 12px;
    padding: 16px;
    background-color: #15181c;
  }
  .grok-x-cn-header {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
    font-weight: 700;
    color: #e7e9ea;
    margin-bottom: 8px;
  }
  .grok-x-cn-header svg {
    width: 16px;
    height: 16px;
    fill: #e7e9ea;
  }
  .grok-x-cn-text {
    font-size: 13px;
    line-height: 18px;
    color: #e7e9ea;
    margin-bottom: 12px;
  }
  .grok-x-cn-sources-title {
    font-size: 11px;
    font-weight: 700;
    color: #71767b;
    margin-bottom: 4px;
    text-transform: uppercase;
  }
  .grok-x-cn-source {
    font-size: 11px;
    color: #1d9bf0;
    text-decoration: none;
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    margin-bottom: 2px;
  }
  .grok-x-cn-source:hover {
    text-decoration: underline;
  }

  .grok-x-footer {
    padding: 16px;
    border-top: 1px solid #2f3336;
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .grok-x-inject-btn {
    width: 100%;
    padding: 12px;
    border-radius: 9999px;
    background-color: #e7e9ea;
    color: #0f1419;
    font-weight: 700;
    font-size: 15px;
    border: none;
    cursor: pointer;
    transition: background-color 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
  }
  .grok-x-inject-btn:hover {
    background-color: #d7dbdc;
  }
  .grok-x-inject-btn:active {
    transform: scale(0.98);
  }

  /* Inline embedded styles */
  .srf-grok-x-inline-wrapper {
    margin: 24px 0;
    padding: 20px;
    border: 1px solid #2f3336;
    border-radius: 16px;
    background-color: #000000;
    color: #e7e9ea;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    max-width: 100%;
    box-sizing: border-box;
    animation: grokFadeIn 0.3s ease;
  }
  @keyframes grokFadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .srf-grok-x-inline-wrapper .grok-x-tweet-card:last-child {
    border-bottom: none;
    padding-bottom: 0;
  }

  /* Light Theme Syncing */
  body.srf-light-theme #srf-grok-x-toggle {
    background-color: #ffffff;
    color: #0f1419;
    border-color: #eff3f4;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
  }
  body.srf-light-theme #srf-grok-x-toggle:hover {
    background-color: #f7f9f9;
  }
  body.srf-light-theme #srf-grok-x-drawer {
    background-color: #ffffff;
    color: #0f1419;
    border-left-color: #eff3f4;
    box-shadow: -4px 0 24px rgba(0, 0, 0, 0.08);
  }
  body.srf-light-theme .grok-x-header {
    border-bottom-color: #eff3f4;
  }
  body.srf-light-theme .grok-x-close-btn {
    color: #536471;
  }
  body.srf-light-theme .grok-x-close-btn:hover {
    background-color: rgba(15, 20, 25, 0.1);
    color: #0f1419;
  }
  body.srf-light-theme .grok-x-tweet-card {
    border-bottom-color: #eff3f4;
  }
  body.srf-light-theme .grok-x-author-name {
    color: #0f1419;
  }
  body.srf-light-theme .grok-x-author-handle,
  body.srf-light-theme .grok-x-dot,
  body.srf-light-theme .grok-x-timestamp {
    color: #536471;
  }
  body.srf-light-theme .grok-x-tweet-text {
    color: #0f1419;
  }
  body.srf-light-theme .grok-x-actions {
    color: #536471;
  }
  body.srf-light-theme .grok-x-action {
    color: #536471;
  }
  body.srf-light-theme .grok-x-cn-card {
    border-color: #eff3f4;
    background-color: #f7f9f9;
  }
  body.srf-light-theme .grok-x-cn-header {
    color: #0f1419;
  }
  body.srf-light-theme .grok-x-cn-header svg {
    fill: #0f1419;
  }
  body.srf-light-theme .grok-x-cn-text {
    color: #0f1419;
  }
  body.srf-light-theme .grok-x-cn-sources-title {
    color: #536471;
  }
  body.srf-light-theme .grok-x-footer {
    border-top-color: #eff3f4;
  }
  body.srf-light-theme .grok-x-inject-btn {
    background-color: #0f1419;
    color: #ffffff;
  }
  body.srf-light-theme .grok-x-inject-btn:hover {
    background-color: #272c30;
  }
  body.srf-light-theme .srf-grok-x-inline-wrapper {
    background-color: #ffffff;
    color: #0f1419;
    border-color: #eff3f4;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
  }
`,or='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path></svg>',nr='<svg class="grok-x-verified-icon" viewBox="0 0 24 24"><path d="M22.5 12.5c0-1.58-.875-2.95-2.148-3.6.154-.435.238-.905.238-1.4 0-2.21-1.71-3.99-3.818-3.99-.48 0-.941.1-1.358.275C14.77 2.57 13.5 1.75 12 1.75s-2.77.82-3.412 2.035c-.417-.175-.878-.275-1.358-.275-2.108 0-3.818 1.78-3.818 3.99 0 .495.084.965.238 1.4-1.273.65-2.148 2.02-2.148 3.6 0 1.58.875 2.95 2.148 3.6-.154.435-.238.905-.238 1.4 0 2.21 1.71 3.99 3.818 3.99.48 0 .941-.1 1.358-.275C9.23 21.43 10.5 22.25 12 22.25s2.77-.82 3.412-2.035c.417.175.878.275 1.358.275 2.108 0 3.818-1.78 3.818-3.99 0-.495-.084-.965-.238-1.4 1.273-.65 2.148-2.02 2.148-3.6zm-12.72 4.18l-3.32-3.56 1.43-1.42 1.83 1.96 4.79-5.12 1.43 1.41-6.16 6.73z"></path></svg>',rr='<svg viewBox="0 0 24 24"><path d="M19 4H5c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-1 12H6v-2h12v2zm0-4H6V8h12v4z"></path></svg>',ar='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"></path></svg>',ir='<svg viewBox="0 0 24 24"><path d="M1.751 10c0-4.42 3.584-8 8.005-8h4.366c4.49 0 8.129 3.64 8.129 8.13 0 2.96-1.57 5.57-3.93 7.02v2.74c0 .83-.98 1.28-1.63.77l-3.47-2.7c-.43.08-.88.13-1.34.13h-2.12c-4.42 0-8.005-3.58-8.005-8.02zm8.005-6c-3.317 0-6.005 2.69-6.005 6 0 3.32 2.688 6 6.005 6h2.12c.51 0 1.01-.06 1.5-.18l.26-.06 2.36 1.83v-1.72l.14-.1c2.1-1.32 3.36-3.64 3.36-6.1 0-3.38-2.75-6.13-6.13-6.13H9.756z"></path></svg>',sr='<svg viewBox="0 0 24 24"><path d="M4.5 3.88l4.432 4.14-1.364 1.46L5.5 7.55V16c0 1.1.898 2 2 2h7.5v2H7.5c-2.209 0-4-1.79-4-4V7.55L1.432 9.48.068 8.02 4.5 3.88zM16.5 6H9V4h7.5c2.209 0 4 1.79 4 4v8.45l2.068-1.93 1.364 1.46-4.432 4.14-4.432-4.14 1.364-1.46 2.068 1.93V8c0-1.1-.898-2-2-2z"></path></svg>',lr='<svg viewBox="0 0 24 24"><path d="M16.697 5.5c-1.222-.06-2.679.69-3.89 2.26L12 8.782l-.807-1.02c-1.211-1.57-2.668-2.32-3.89-2.26-2.73.13-4.502 2.47-4.502 5.6 0 4.17 4.103 8.33 8.78 11.42l.419.28.419-.28c4.677-3.09 8.78-7.25 8.78-11.42 0-3.13-1.772-5.47-4.502-5.6zM12 20.46c-4.062-2.7-7.502-6.38-7.502-9.36 0-2.3 1.173-3.6 2.702-3.68.805-.04 1.836.48 2.766 1.83l2.034 2.58 2.034-2.58c.93-1.35 1.961-1.87 2.766-1.83 1.529.08 2.702 1.38 2.702 3.68 0 2.98-3.44 6.66-7.502 9.36z"></path></svg>',cr='<svg viewBox="0 0 24 24"><path d="M8.75 21V3h2v18h-2zM18 21V9h2v12h-2zM4 21v-6h2v6H4zm9.375 0v-9h2v9h-2z"></path></svg>';async function mo(){var e;try{const{srf_enabled:t,srf_active_brain:o}=await chrome.storage.local.get(["srf_enabled","srf_active_brain"]);if(t===!1||o!=="grok"){ho(),Ht();return}if(Ht(),M&&L)return;const n=await chrome.runtime.sendMessage({type:"srf-fetch-x-content",payload:{url:location.href,title:document.title,description:((e=document.querySelector('meta[name="description"]'))==null?void 0:e.getAttribute("content"))||""}});if(!n||!n.success||!n.content){console.warn("[Grok X] Failed to generate related X content.");return}W=n.content;const i=getComputedStyle(document.body).backgroundColor;hr(i)?document.body.classList.remove("srf-light-theme"):document.body.classList.add("srf-light-theme"),H||(H=document.createElement("style"),H.id="srf-grok-x-styles",H.textContent=tr,document.head.appendChild(H)),dr(),ur()}catch(t){console.error("[Grok X] Failed to bootstrap:",t)}}function ho(){L&&(L.remove(),L=null),M&&(M.remove(),M=null),H&&(H.remove(),H=null),document.querySelectorAll(".srf-grok-x-inline-wrapper").forEach(e=>e.remove()),W=null}function Ht(){Ke||(Ke=e=>{("srf_enabled"in e||"srf_active_brain"in e)&&mo()},chrome.storage.onChanged.addListener(Ke))}function dr(){document.getElementById("srf-grok-x-toggle")||(L=document.createElement("button"),L.id="srf-grok-x-toggle",L.title="Grok X-Feed",L.innerHTML=or,L.addEventListener("click",e=>{e.stopPropagation(),ze()}),document.body.appendChild(L))}function ur(){if(document.getElementById("srf-grok-x-drawer"))return;M=document.createElement("div"),M.id="srf-grok-x-drawer";const e=`
    <div class="grok-x-header">
      <div class="grok-x-title-area">
        <h2 class="grok-x-title">X Feed <span class="grok-x-brain-badge">Grok</span></h2>
      </div>
      <button class="grok-x-close-btn" id="srf-grok-close-drawer" title="Close">
        ${ar}
      </button>
    </div>
  `;let t="";if(W){if(W.communityNote){const n=W.communityNote,r=n.sources.map(i=>`<a class="grok-x-cn-source" href="${i.split(" ")[0]}" target="_blank" rel="noopener">${i}</a>`).join("");t+=`
        <div class="grok-x-cn-card">
          <div class="grok-x-cn-header">
            ${rr}
            <span>Readers added context</span>
          </div>
          <div class="grok-x-cn-text">${n.content}</div>
          <div class="grok-x-cn-sources-title">Sources</div>
          ${r}
        </div>
      `}t+=W.tweets.map(n=>go(n)).join("")}const o=`
    <div class="grok-x-footer">
      <button class="grok-x-inject-btn" id="srf-grok-inject-inline">
        <span>Inject Into Site Layout</span>
      </button>
    </div>
  `;M.innerHTML=`
    ${e}
    <div class="grok-x-content">
      ${t}
    </div>
    ${o}
  `,pr(M),document.body.appendChild(M)}function go(e){const t=e.verified?nr:"";return`
    <div class="grok-x-tweet-card" data-tweet-id="${e.id}">
      <div class="grok-x-avatar">${e.authorAvatar}</div>
      <div class="grok-x-tweet-body">
        <div class="grok-x-tweet-header">
          <span class="grok-x-author-name">${e.authorName}</span>
          ${t}
          <span class="grok-x-author-handle">@${e.authorHandle}</span>
          <span class="grok-x-dot">·</span>
          <span class="grok-x-timestamp">${e.timestamp}</span>
        </div>
        <div class="grok-x-tweet-text">${e.content}</div>
        <div class="grok-x-actions">
          <button class="grok-x-action reply" title="Reply">
            ${ir}
            <span>${e.replies}</span>
          </button>
          <button class="grok-x-action retweet" title="Repost">
            ${sr}
            <span>${e.retweets}</span>
          </button>
          <button class="grok-x-action like" title="Like">
            ${lr}
            <span>${e.likes}</span>
          </button>
          <button class="grok-x-action views" title="Views">
            ${cr}
            <span>${e.views}</span>
          </button>
        </div>
      </div>
    </div>
  `}function pr(e){var t,o;(t=e.querySelector("#srf-grok-close-drawer"))==null||t.addEventListener("click",()=>{ze(!1)}),e.querySelectorAll(".grok-x-tweet-card").forEach(n=>{const r=n.querySelector(".grok-x-action.like");r==null||r.addEventListener("click",()=>{const a=r.querySelector("span");if(a){const s=r.classList.contains("active");let l=parseInt(a.textContent||"0");s?(r.classList.remove("active"),l--):(r.classList.add("active"),l++),a.textContent=l.toString()}});const i=n.querySelector(".grok-x-action.retweet");i==null||i.addEventListener("click",()=>{const a=i.querySelector("span");if(a){const s=i.classList.contains("active");let l=parseInt(a.textContent||"0");s?(i.classList.remove("active"),l--):(i.classList.add("active"),l++),a.textContent=l.toString()}})}),(o=e.querySelector("#srf-grok-inject-inline"))==null||o.addEventListener("click",()=>{fr()})}function ze(e){if(!M)return;const t=M.classList.contains("open");(e!==void 0?e:!t)?(M.classList.add("open"),L&&(L.style.transform="scale(0) rotate(90deg)",L.style.opacity="0")):(M.classList.remove("open"),L&&(L.style.transform="scale(1) rotate(0deg)",L.style.opacity="1"))}function fr(){if(!W)return;const t=[document.querySelector("main p:nth-of-type(3)"),document.querySelector("article p:nth-of-type(3)"),document.querySelector("p:nth-of-type(4)"),document.querySelector("#mw-content-text p:nth-of-type(3)"),document.querySelector(".wiki p:nth-of-type(2)"),document.querySelector("main p:nth-of-type(1)"),document.querySelector("body p:nth-of-type(3)")].filter(Boolean)[0];if(!t){console.warn("[Grok X] Could not find a suitable layout element to inject tweets inline.");return}const o=t.nextElementSibling;if(o&&o.classList.contains("srf-grok-x-inline-wrapper")){ze(!1);return}const n=document.createElement("div");n.className="srf-grok-x-inline-wrapper";const r=W.tweets.slice(0,2).map(i=>go(i)).join("");n.innerHTML=`
    <div style="font-size: 13px; font-weight: 700; color: #71767b; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between;">
      <span>PROMOTED CONTEXT BY GROK</span>
      <span style="font-size: 10px; background: rgba(29, 155, 240, 0.15); color: #1d9bf0; padding: 2px 6px; border-radius: 4px;">TWITTER / X</span>
    </div>
    ${r}
  `,mr(n),t.insertAdjacentElement("afterend",n),ze(!1)}function mr(e){e.querySelectorAll(".grok-x-tweet-card").forEach(t=>{const o=t.querySelector(".grok-x-action.like");o==null||o.addEventListener("click",()=>{const r=o.querySelector("span");if(r){const i=o.classList.contains("active");let a=parseInt(r.textContent||"0");i?(o.classList.remove("active"),a--):(o.classList.add("active"),a++),r.textContent=a.toString()}});const n=t.querySelector(".grok-x-action.retweet");n==null||n.addEventListener("click",()=>{const r=n.querySelector("span");if(r){const i=n.classList.contains("active");let a=parseInt(r.textContent||"0");i?(n.classList.remove("active"),a--):(n.classList.add("active"),a++),r.textContent=a.toString()}})})}function hr(e){const t=e.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);return t?.299*Number(t[1])+.587*Number(t[2])+.114*Number(t[3])<128:!1}const bo="surface-onboarding-guide";let fe=null;async function gr(){var r;const e=await chrome.runtime.sendMessage({type:"onboarding-get-state"}),t=e==null?void 0:e.payload;if(!t||t.completed||!t.startedAt)return;const o=location.hostname.replace(/^www\./,""),n=Io.find(i=>o===i.domain||o.endsWith(`.${i.domain}`));n&&((r=t.visitedSites)!=null&&r.includes(n.domain)&&document.getElementById(bo)||(br(n),await chrome.runtime.sendMessage({type:"onboarding-mark-visited",payload:{domain:n.domain}})))}function br(e){fe&&(fe.remove(),fe=null);const t=document.createElement("div");t.id=bo;const o=t.attachShadow({mode:"closed"}),n={"profile-injection":"Profile Injection","widget-detection":"Widget Detection","category-filtering":"Category Filtering","calendar-aware":"Calendar Aware","dev-context":"Developer Context",education:"Education Mode","design-taste":"Design Taste"};o.innerHTML=`
    <style>
      :host {
        all: initial;
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
      }

      .guide {
        position: fixed;
        bottom: 24px;
        right: 24px;
        width: 360px;
        background: #FFFFFF;
        border: 1px solid #9E9E9E;
        border-radius: 16px;
        padding: 0;
        z-index: 2147483647;
        animation: slideUp 0.35s cubic-bezier(0.25, 0.1, 0.25, 1) both;
        overflow: hidden;
      }

      @keyframes slideUp {
        from { opacity: 0; transform: translateY(16px); }
        to   { opacity: 1; transform: translateY(0); }
      }

      @keyframes fadeOut {
        from { opacity: 1; transform: translateY(0); }
        to   { opacity: 0; transform: translateY(8px); }
      }

      .guide.dismissing {
        animation: fadeOut 0.2s ease forwards;
      }

      /* Header gradient bar */
      .guide-header {
        background: linear-gradient(135deg,
          rgba(255, 130, 80, 0.12) 0%,
          rgba(140, 80, 240, 0.10) 50%,
          rgba(60, 140, 255, 0.08) 100%);
        padding: 16px 20px 12px;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
      }

      .guide-header-left {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }

      .guide-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 10px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #6B6B70;
        padding: 3px 8px;
        border-radius: 4px;
        border: 1px solid #E5E5EA;
        background: rgba(255, 255, 255, 0.7);
        width: fit-content;
      }

      .guide-badge-dot {
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background: #34C759;
      }

      .guide-site-name {
        font-size: 18px;
        font-weight: 500;
        color: #000;
        line-height: 1.2;
      }

      .guide-close {
        background: none;
        border: none;
        width: 28px;
        height: 28px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6B6B70;
        transition: all 0.15s ease;
        flex-shrink: 0;
        margin-top: -2px;
      }

      .guide-close:hover {
        background: rgba(0, 0, 0, 0.06);
        color: #000;
      }

      /* Body */
      .guide-body {
        padding: 16px 20px 20px;
      }

      .guide-text {
        font-size: 13px;
        line-height: 1.6;
        color: #363636;
        margin-bottom: 16px;
      }

      .guide-demo-label {
        font-size: 11px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        color: #7A7F88;
        margin-bottom: 6px;
      }

      .guide-demo-desc {
        font-size: 12px;
        line-height: 1.5;
        color: #6B6B70;
        padding: 10px 14px;
        background: #F4F4F7;
        border-radius: 8px;
        border: 1px solid #E5E5EA;
        margin-bottom: 16px;
      }

      /* Actions */
      .guide-actions {
        display: flex;
        gap: 8px;
      }

      .guide-btn {
        flex: 1;
        padding: 10px 16px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 500;
        font-family: inherit;
        cursor: pointer;
        transition: opacity 0.15s ease;
        text-align: center;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
      }

      .guide-btn-primary {
        background: #000;
        color: #FFF;
        border: 1px solid #000;
      }

      .guide-btn-primary:hover {
        opacity: 0.85;
      }

      .guide-btn-secondary {
        background: transparent;
        color: #6B6B70;
        border: 1px solid #E5E5EA;
      }

      .guide-btn-secondary:hover {
        border-color: #9E9E9E;
        color: #000;
      }

      /* Taste voting (for design sites) */
      .guide-taste {
        display: flex;
        gap: 8px;
        margin-top: 12px;
      }

      .guide-taste-btn {
        flex: 1;
        padding: 10px 16px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 500;
        font-family: inherit;
        cursor: pointer;
        transition: all 0.15s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        background: transparent;
        border: 1px solid #E5E5EA;
        color: #6B6B70;
      }

      .guide-taste-btn:hover {
        border-color: #9E9E9E;
        color: #000;
      }

      .guide-taste-btn.love:hover {
        border-color: #34C759;
        color: #34C759;
      }

      .guide-taste-btn.pass:hover {
        border-color: #9E9E9E;
      }

      .guide-taste-btn.voted {
        border-color: #34C759;
        background: rgba(52, 199, 89, 0.08);
        color: #34C759;
      }
    </style>

    <div class="guide">
      <div class="guide-header">
        <div class="guide-header-left">
          <span class="guide-badge">
            <span class="guide-badge-dot"></span>
            ${n[e.demo]??e.demo}
          </span>
          <span class="guide-site-name">${e.name}</span>
        </div>
        <button class="guide-close" id="close">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>

      <div class="guide-body">
        <div class="guide-text">${e.guide}</div>

        <div class="guide-demo-label">What Webpaper does here</div>
        <div class="guide-demo-desc">${e.pitch}</div>

        ${e.demo==="design-taste"?`
          <div class="guide-demo-label">Rate this design</div>
          <div class="guide-taste">
            <button class="guide-taste-btn love" id="vote-love">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
              </svg>
              Love it
            </button>
            <button class="guide-taste-btn pass" id="vote-pass">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
              Not for me
            </button>
          </div>
        `:`
          <div class="guide-actions">
            <button class="guide-btn guide-btn-primary" id="dismiss">Got it</button>
          </div>
        `}
      </div>
    </div>
  `,document.body.appendChild(t),fe=t;const r=o.getElementById("close"),i=o.getElementById("dismiss"),a=o.getElementById("vote-love"),s=o.getElementById("vote-pass"),l=()=>{const c=o.querySelector(".guide");c&&(c.classList.add("dismissing"),setTimeout(()=>{t.remove(),fe=null},200))};r==null||r.addEventListener("click",l),i==null||i.addEventListener("click",l),a==null||a.addEventListener("click",async()=>{a.classList.add("voted"),s==null||s.classList.remove("voted"),await chrome.runtime.sendMessage({type:"onboarding-taste-vote",payload:{domain:e.domain,vote:"love"}}),await chrome.runtime.sendMessage({type:"polish-add-liked-site",payload:{hostname:e.domain,title:e.name}}),setTimeout(l,800)}),s==null||s.addEventListener("click",async()=>{s.classList.add("voted"),a==null||a.classList.remove("voted"),await chrome.runtime.sendMessage({type:"onboarding-taste-vote",payload:{domain:e.domain,vote:"pass"}}),setTimeout(l,600)})}const Ne=Q("autofill"),yr=["name","given-name","family-name","email","street-address","address-level1","address-level2","country","organization","organization-title","bday","url"],xr={fname:"given-name",firstname:"given-name","first-name":"given-name",lname:"family-name",lastname:"family-name","last-name":"family-name",surname:"family-name",email:"email",mail:"email","e-mail":"email",fullname:"name","full-name":"name",name:"name",city:"address-level2",town:"address-level2",state:"address-level1",region:"address-level1",province:"address-level1",country:"country",company:"organization",org:"organization",employer:"organization",title:"organization-title",role:"organization-title","job-title":"organization-title",street:"street-address",address:"street-address"};let F=null,he=null,Se=null,Wt=0;const wr=6e4;async function vr(){location.protocol==="chrome-extension:"||location.protocol==="chrome:"||!await kr()||(document.addEventListener("focusin",Sr,{capture:!0}),document.addEventListener("focusout",Er,{capture:!0}),Ne.info("installed",{host:location.hostname}))}async function kr(){try{const e=`srf_autofill_${location.hostname}`,{[e]:t}=await chrome.storage.local.get(e);return t===!0}catch{return!1}}function Sr(e){const t=e.target;if(t&&(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)){if(!yo(t))return;he=t,Tr(t)}}function Er(){setTimeout(()=>{document.activeElement!==F&&(Re(),he=null)},150)}function yo(e){const t=(e.getAttribute("autocomplete")??"").toLowerCase().trim();if(t&&yr.includes(t))return t;const o=(e.name||e.id||e.getAttribute("placeholder")||"").toLowerCase();if(!o)return null;for(const[n,r]of Object.entries(xr))if(o.includes(n))return r;return null}async function Cr(){if(Se&&Date.now()-Wt<wr)return Se;try{const e=await chrome.runtime.sendMessage({type:"autofill-get-fields"});return Se=(e==null?void 0:e.payload)??null,Wt=Date.now(),Se}catch(e){return Ne.warn("view fetch failed",e),null}}function Tr(e,t){Re();const o=e.getBoundingClientRect();F=document.createElement("div"),F.setAttribute("data-srf-autofill-pill",""),F.style.cssText=`
    all: initial;
    position: fixed;
    z-index: 2147483647;
    top: ${o.top-32}px;
    left: ${o.left}px;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    font-size: 12px;
    color: #fff;
    background: #000;
    border: 1px solid #000;
    border-radius: 6px;
    padding: 5px 10px;
    cursor: pointer;
    user-select: none;
    line-height: 1.2;
  `,F.textContent="Fill from Webpaper",F.addEventListener("mousedown",n=>{n.preventDefault(),n.stopPropagation(),Lr()}),document.body.appendChild(F)}function Re(){F&&(F.remove(),F=null)}async function Lr(e){const t=await Cr();if(!t){Ne.warn("no profile view — aborting fill"),Re();return}const n=(he==null?void 0:he.closest("form"))??document;let r=0;const i=n.querySelectorAll("input, textarea");for(const a of i){const s=yo(a);if(!s)continue;const l=t[s];l&&(a.value&&a.value.trim().length>0||(Ar(a,String(l)),r++))}Ne.info("filled",{count:r,host:location.hostname}),Re()}function Ar(e,t){var r;const o=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,n=Object.getOwnPropertyDescriptor(o,"value");(r=n==null?void 0:n.set)==null||r.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}const xo=Q("light-dom"),Ir=["firstName","city","occupation"];async function Mr(){if(location.protocol==="chrome-extension:"||location.protocol==="chrome:"||!await $r())return;const t=await qr();if(!t)return;Gt(document,t),Vt(document,t);let o=[],n=!1;const r=()=>{n=!1;const a=o;o=[];for(const s of a)Gt(s,t),Vt(s,t)};new MutationObserver(a=>{for(const s of a)for(const l of Array.from(s.addedNodes))l.nodeType===Node.ELEMENT_NODE&&o.push(l);o.length&&!n&&(n=!0,setTimeout(r,200))}).observe(document.body,{childList:!0,subtree:!0}),xo.info("installed",{host:location.hostname})}async function $r(){try{const e=`srf_lightdom_${location.hostname}`,{[e]:t}=await chrome.storage.local.get(e);return t===!0}catch{return!1}}async function qr(){try{const e=await chrome.runtime.sendMessage({type:"lightdom-get-tokens"});return(e==null?void 0:e.payload)??null}catch(e){return xo.warn("view fetch failed",e),null}}function Gt(e,t){var n;const o=(n=e.querySelectorAll)==null?void 0:n.call(e,"[data-srf-token]");if(o)for(const r of Array.from(o)){const i=r.getAttribute("data-srf-token")??"";if(!wo(i))continue;const a=t[i];a&&r.getAttribute("data-srf-applied")!=="1"&&(r.textContent=a,r.setAttribute("data-srf-applied","1"))}}function Vt(e,t){var i;const o=document.createTreeWalker(e,NodeFilter.SHOW_COMMENT),n=[];let r=o.nextNode();for(;r;){const s=r.data.trim().match(/^cfg:([a-zA-Z]+)$/);s&&wo(s[1])&&n.push({node:r,key:s[1]}),r=o.nextNode()}for(const{node:a,key:s}of n){const l=t[s];if(!l)continue;const c=document.createTextNode(l);(i=a.parentNode)==null||i.replaceChild(c,a)}}function wo(e){return Ir.includes(e)}const Oe=Q("preview-bar"),vo="surface-preview-bar";let se=null;async function mt(e){se&&se();const t=await Br();if(Oe.info("install",{count:t.length,host:location.hostname}),t.length===0){Oe.debug("no cards to preview, skipping bar");return}const o=zr(t,e);se=Rr(o,e.adapter)}function Fr(){var e;se&&(se(),se=null),(e=document.getElementById(vo))==null||e.remove()}async function Br(){var e;try{const t=await chrome.runtime.sendMessage({type:"get-active-cards",payload:{host:location.hostname}}),o=(e=t==null?void 0:t.payload)==null?void 0:e.cards;return Array.isArray(o)?o:[]}catch(t){return Oe.warn("fetch failed",t),[]}}async function _r(e){try{await chrome.runtime.sendMessage({type:"set-card-attached",payload:{host:location.hostname,cardType:e,attached:!1}})}catch(t){Oe.warn("detach failed",{type:e,err:t})}}function zr(e,t){const o=document.createElement("div");o.id=vo,o.style.position="fixed",o.style.zIndex="2147483646",o.style.left="0",o.style.top="0";const n=o.attachShadow({mode:"open"});n.innerHTML=Or;const r=n.getElementById("list");for(let i=0;i<e.length;i++)r.appendChild(Nr(e[i],i,o,t));return document.body.appendChild(o),o}function Nr(e,t,o,n){const r=Yt(e.type),i=e.label??r.label,a=e.type==="biography",s=document.createElement("div");s.className="item";const l=document.createElement("button");l.type="button",l.className=`chip ${a?"marquee":""}`,l.style.setProperty("--accent",r.accent),l.style.setProperty("--enter-delay",`${t*40}ms`);const c=document.createElement("span");c.className="dot";const p=document.createElement("span");p.className="label",p.textContent=i;const u=document.createElement("span");u.className="close",u.setAttribute("role","button"),u.setAttribute("aria-label",`Detach ${i}`),u.innerHTML='<svg viewBox="0 0 12 12" width="9" height="9" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 3 L9 9 M9 3 L3 9"/></svg>',l.appendChild(c),l.appendChild(p),l.appendChild(u);let d=!1;const m=document.createElement("div");return m.className="body",l.addEventListener("click",h=>{if(!h.target.closest(".close")){if(!d){const f=document.createElement("div");f.className="body-text",f.textContent=e.content,m.appendChild(f),d=!0}s.classList.toggle("open")}}),u.addEventListener("click",async h=>{h.stopPropagation(),s.classList.add("removing"),setTimeout(async()=>{var y;s.remove(),await _r(e.type),await n.onChange();const f=(y=o.shadowRoot)==null?void 0:y.getElementById("list");f&&f.children.length===0&&(o.style.display="none")},180)}),s.appendChild(l),s.appendChild(m),s}function Rr(e,t){const o=()=>{const l=t.getInput();let c=!1;if(l){const p=l.getBoundingClientRect();let u=l,d=l;for(let h=0;h<6&&u&&(u=u.parentElement,!!u);h++){const f=u.getBoundingClientRect();if(f.width>p.width*1.05&&f.width>=280){d=u;break}}const m=d.getBoundingClientRect();m.width>=200&&m.top>0&&m.top<window.innerHeight&&(e.style.display="",e.style.transform="",e.style.right="",e.style.bottom="",e.style.maxWidth="",e.style.left=`${Math.max(8,m.left)}px`,e.style.top=`${Math.max(8,m.top-52)}px`,e.style.width=`${Math.min(m.width,720)}px`,c=!0)}c||(e.style.display="",e.style.left="50%",e.style.right="",e.style.top="",e.style.bottom="24px",e.style.transform="translateX(-50%)",e.style.maxWidth="min(720px, calc(100vw - 32px))",e.style.width="auto")};o();const n=new ResizeObserver(o),r=t.getInput();r&&n.observe(r),n.observe(document.documentElement);const i=()=>o(),a=()=>o();window.addEventListener("scroll",i,{passive:!0,capture:!0}),window.addEventListener("resize",a);const s=new MutationObserver(o);return s.observe(document.body,{childList:!0,subtree:!0}),()=>{n.disconnect(),s.disconnect(),window.removeEventListener("scroll",i,{capture:!0}),window.removeEventListener("resize",a),e.remove()}}const Or=`
<style>
  :host {
    all: initial;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    -webkit-font-smoothing: antialiased;
  }
  * { box-sizing: border-box; }

  @keyframes mesh-drift {
    0%   { background-position:   0%   0%; }
    100% { background-position: 100% 100%; }
  }
  @keyframes fade-in {
    from { opacity: 0; transform: translateY(2px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes chip-enter {
    from { opacity: 0; transform: translateY(3px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes chip-leave {
    to { opacity: 0; transform: translateY(2px) scale(0.94); }
  }

  .bar {
    position: relative;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 10px;
    background: rgba(255, 255, 255, 0.96);
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    border: 1px solid #d6d6db;
    border-radius: 14px;
    overflow: hidden;
    isolation: isolate;
    animation: fade-in 0.22s ease;
  }
  .bar::before {
    content: '';
    position: absolute;
    inset: 0;
    z-index: -1;
    pointer-events: none;
    background:
      radial-gradient(ellipse 60% 60% at 0%   0%,   rgba(255, 130,  80, 0.16) 0%, transparent 60%),
      radial-gradient(ellipse 60% 60% at 100% 0%,   rgba(140,  80, 240, 0.14) 0%, transparent 60%),
      radial-gradient(ellipse 60% 60% at 50% 100%,  rgba( 60, 140, 255, 0.14) 0%, transparent 60%);
    background-size: 200% 200%;
    animation: mesh-drift 12s ease-in-out infinite alternate;
    filter: blur(14px);
  }

  .label-pre {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 10px;
    color: #6b6b70;
    padding: 0 6px 0 4px;
    white-space: nowrap;
    flex-shrink: 0;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    font-weight: 500;
  }
  .label-pre::after {
    content: '';
    width: 1px;
    height: 14px;
    background: rgba(0, 0, 0, 0.1);
    margin-left: 4px;
  }

  #list {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    flex: 1 1 auto;
    min-width: 0;
    align-items: center;
  }

  .item {
    display: inline-flex;
    flex-direction: column;
    min-width: 0;
    flex: 0 0 auto;
  }

  .chip {
    --accent: #586675;
    position: relative;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 28px;
    padding: 0 6px 0 10px;
    border: 1px solid #d6d6db;
    border-radius: 999px;
    background: #fff;
    color: #1f1f24;
    font: inherit;
    font-size: 12px;
    line-height: 1;
    cursor: pointer;
    user-select: none;
    overflow: hidden;
    isolation: isolate;
    transition: border-color 0.15s ease, transform 0.15s ease;
    animation: chip-enter 0.2s cubic-bezier(0.2, 0.8, 0.2, 1) backwards;
    animation-delay: var(--enter-delay, 0ms);
  }
  .chip:hover { border-color: #1f1f24; transform: translateY(-1px); }
  .item.removing .chip { animation: chip-leave 0.18s ease forwards; }

  .dot {
    width: 6px; height: 6px;
    border-radius: 50%;
    background: var(--accent);
    flex-shrink: 0;
  }
  .label {
    font-weight: 500;
    color: #1f1f24;
    white-space: nowrap;
  }
  .close {
    width: 18px; height: 18px;
    margin-left: 2px;
    border-radius: 50%;
    color: #9090a0;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: background 0.15s ease, color 0.15s ease;
  }
  .close:hover { background: rgba(0, 0, 0, 0.06); color: #1f1f24; }

  /* Marquee — biography chip with full Surface mesh */
  .chip.marquee {
    color: #fff;
    border-color: transparent;
  }
  .chip.marquee::before {
    content: '';
    position: absolute;
    inset: 0;
    z-index: -1;
    pointer-events: none;
    background:
      radial-gradient(ellipse 65% 62% at 0%   15%, rgba(255, 110,  60, 0.95) 0%, transparent 65%),
      radial-gradient(ellipse 60% 62% at 100% 22%, rgba(140,  70, 240, 0.85) 0%, transparent 65%),
      radial-gradient(ellipse 65% 60% at 95%  92%, rgba( 50, 130, 255, 0.82) 0%, transparent 65%),
      radial-gradient(ellipse 55% 50% at 50%   0%, rgba(255, 140,  90, 0.78) 0%, transparent 65%),
      linear-gradient(135deg, #2a1c4a 0%, #4a1a3a 50%, #1a2a4a 100%);
    background-size: 200% 200%;
    animation: mesh-drift 9s ease-in-out infinite alternate;
  }
  .chip.marquee .dot { background: #fff; }
  .chip.marquee .label { color: #fff; }
  .chip.marquee .close { color: rgba(255,255,255,0.7); }
  .chip.marquee .close:hover { background: rgba(255,255,255,0.18); color: #fff; }
  .chip.marquee:hover { border-color: transparent; }

  /* Body — revealed when chip clicked */
  .body {
    display: none;
    margin-top: 6px;
    padding: 8px 10px;
    background: rgba(255, 255, 255, 0.92);
    border: 1px solid #d6d6db;
    border-left: 3px solid var(--accent, #586675);
    border-radius: 8px;
    font-size: 12px;
    color: #2c2c33;
    line-height: 1.5;
    max-width: 320px;
    white-space: pre-wrap;
    animation: fade-in 0.18s ease;
  }
  .item.open .body { display: block; }

  @media (prefers-color-scheme: dark) {
    .bar {
      background: rgba(23, 23, 27, 0.92);
      border-color: rgba(255, 255, 255, 0.14);
    }
    .label-pre { color: rgba(255, 255, 255, 0.55); }
    .label-pre::after { background: rgba(255, 255, 255, 0.1); }
    .chip {
      background: rgba(255, 255, 255, 0.06);
      border-color: rgba(255, 255, 255, 0.16);
      color: #f0f0f3;
    }
    .chip:hover { border-color: rgba(255, 255, 255, 0.5); }
    .label { color: #f0f0f3; }
    .close { color: rgba(255, 255, 255, 0.55); }
    .close:hover { background: rgba(255, 255, 255, 0.1); color: #fff; }
    .body {
      background: rgba(28, 28, 32, 0.92);
      border-color: rgba(255, 255, 255, 0.1);
      color: rgba(255, 255, 255, 0.85);
    }
  }
</style>
<div class="bar" role="toolbar" aria-label="Webpaper profile cards — click × to detach before sending">
  <span class="label-pre">Sending</span>
  <div id="list"></div>
</div>
`,K="srf-highlight",X="srf-highlight-secondary",Ut="srf-highlight-styles",Dr=`
.${K}, .${X} {
  background: transparent;
  position: relative;
  border-radius: 2px;
  transition: background 0.2s;
}
.${K} {
  background: rgba(255, 220, 50, 0.4);
  outline: 1.5px solid rgba(220, 180, 0, 0.5);
  outline-offset: 1px;
}
.${X} {
  background: rgba(100, 160, 255, 0.2);
  outline: 1.5px solid rgba(80, 130, 220, 0.35);
  outline-offset: 1px;
}
.${K}::after, .${X}::after {
  content: attr(data-srf-reason);
  position: absolute;
  bottom: calc(100% + 4px);
  left: 0;
  background: #1a1a1a;
  color: #fff;
  font-size: 11px;
  line-height: 1.4;
  padding: 4px 8px;
  border-radius: 5px;
  white-space: nowrap;
  max-width: 240px;
  overflow: hidden;
  text-overflow: ellipsis;
  pointer-events: none;
  opacity: 0;
  transform: translateY(3px);
  transition: opacity 0.15s, transform 0.15s;
  z-index: 2147483647;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}
.${K}:hover::after, .${X}:hover::after {
  opacity: 1;
  transform: translateY(0);
}
`;function ht(){if(document.getElementById(Ut))return;const e=document.createElement("style");e.id=Ut,e.textContent=Dr,document.head.appendChild(e)}function ko(){document.querySelectorAll(`.${K}, .${X}`).forEach(e=>{const t=e.parentNode;if(t){for(;e.firstChild;)t.insertBefore(e.firstChild,e);t.removeChild(e),t.normalize()}})}const So=new Set(["SCRIPT","STYLE","NOSCRIPT","IFRAME","TEXTAREA","INPUT","SELECT","CODE","PRE"]);function Pr(e,t,o,n){if(t.length<6)return!1;const r=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode(a){const s=a.parentElement;if(!s||s.classList.contains(K)||s.classList.contains(X)||So.has(s.tagName))return NodeFilter.FILTER_REJECT;const l=window.getComputedStyle(s);return l.display==="none"||l.visibility==="hidden"?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}});let i;for(;i=r.nextNode();){const s=(i.textContent??"").indexOf(t);if(s===-1)continue;const l=document.createElement("mark");l.className=o,l.setAttribute("data-srf-reason",n);const c=document.createRange();return c.setStart(i,s),c.setEnd(i,s+t.length),c.surroundContents(l),!0}return!1}function jr(e){ht();let t=0;for(const o of e){const n=o.relevance==="primary"?K:X;Pr(document.body,o.text,n,o.reason)&&t++}return t}function Hr(e=15e3){var i;const t=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(a){const s=a.parentElement;if(!s||So.has(s.tagName))return NodeFilter.FILTER_REJECT;const l=window.getComputedStyle(s);return l.display==="none"||l.visibility==="hidden"?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),o=[];let n=0,r;for(;(r=t.nextNode())&&n<e;){const a=((i=r.textContent)==null?void 0:i.trim())??"";a.length>1&&(o.push(a),n+=a.length)}return o.join(" ").slice(0,e)}const ne=Q("image-video");let re=null,Xe=!1;async function Wr(){if(re)return re;const{srf_image_video_enabled:e}=await chrome.storage.local.get("srf_image_video_enabled");if(e!==!0)return ne.info("Image→Video enhancer disabled via flag (srf_image_video_enabled !== true)"),()=>{};Xe=!0,ne.info("Image→Video enhancer ENABLED — starting isolated module");const t=[],o=()=>{Xe&&(ne.info(`Tearing down Image→Video enhancer. Restoring ${t.length} images...`),t.length=0,Xe=!1,re=null,ne.info("Image→Video enhancer fully torn down — page should be back to original state"))};return re=o,ne.info("Image→Video enhancer skeleton installed (no changes yet — safe)"),o}try{chrome.storage.onChanged.addListener(e=>{"srf_image_video_enabled"in e&&e.srf_image_video_enabled.newValue!==!0&&re&&(ne.info("srf_image_video_enabled turned off — tearing down"),re())})}catch{}const S=Q("main");let k=null,A=null,Z=null,O=!0,ge=null,be=null,Ze=null;async function Eo(){if((await chrome.storage.local.get("srf_enabled")).srf_enabled===!1){S.info("Extension initially disabled via master switch — skipping content injection");return}const t=Jt();if(t){await st(t);return}Qo(async o=>{(await chrome.storage.local.get("srf_enabled")).srf_enabled!==!1&&await st(o)},12e4)}async function st(e){var o;A=e,k=Qt(e),chrome.runtime.sendMessage({type:"chatbot-detected",payload:e}),De("detect",e.hostname,{platform:e.platform,category:J(e.hostname),meta:{confidence:e.confidence,detectedType:e.adapter==="Generic"?"heuristic":e.confidence>=90?"known":"widget"}}),e.adapter==="Generic"&&De("new_chatbot_candidate",e.hostname,{platform:e.platform,meta:{detectedType:"heuristic"}});const t=await chrome.runtime.sendMessage({type:"get-auth-state"});if(!((o=t==null?void 0:t.payload)!=null&&o.authenticated)){Mt(e,{enabled:!1,signedIn:!1,adapter:k,onToggle:()=>{}});return}O=!0,!be&&k&&(be=pn(k)),await V(),Mt(e,{enabled:O,signedIn:!0,adapter:k,onToggle:Vr}),Gr(),await mt({adapter:k,onChange:async()=>{await V()}})}async function V(){var o;if(!A||!k)return;const e=J(A.hostname),t=await chrome.runtime.sendMessage({type:"get-meta-prompt",payload:{hostname:A.hostname,category:e}});Z=((o=t==null?void 0:t.payload)==null?void 0:o.prompt)??null,Z?S.info("prompt cached",{bytes:Z.length,sections:t.payload.sections}):S.warn("no prompt cached — interceptor will pass through")}function Gr(){ge||k&&(ge=yn({adapter:k,getPrompt:()=>Z,isEnabled:()=>O,onAugmented:()=>{O=!1,dt(!1),en('<span class="srf-tooltip-strong">Profile sent</span><br><span class="srf-tooltip-dim">Disarmed — click to re-arm</span>',2800),A&&k&&De("fire",A.hostname,{platform:k.name,category:J(A.hostname),meta:{promptBytes:(Z==null?void 0:Z.length)??0,compiled:!1}})}}))}async function Vr(e){O=e,dt(e),A&&k&&De(e?"arm":"disarm",A.hostname,{platform:k.name,meta:e?void 0:{reason:"manual"}}),e&&await V()}function De(e,t,o={}){try{Ze||(Ze=crypto.randomUUID());const n={kind:e,hostname:t,platform:o.platform,category:o.category,ts:Date.now(),sessionId:Ze,meta:o.meta};chrome.runtime.sendMessage({type:"telemetry-event",payload:n})}catch(n){S.warn("telemetry emit failed",n)}}chrome.runtime.onMessage.addListener((e,t,o)=>{var n;return(e==null?void 0:e.type)==="inject-prompt"?(Ur((n=e.payload)==null?void 0:n.prompt).then(o),!0):(e==null?void 0:e.type)==="auto-inject-toggled"?(O=e.payload.enabled,dt(O),O&&V(),o({success:!0}),!1):(e==null?void 0:e.type)==="get-armed-state"?(o({armed:O}),!1):(e==null?void 0:e.type)==="srf-teardown"?(Co(),o({success:!0}),!1):((e==null?void 0:e.type)==="cards-prefs-changed"&&(k&&A&&(V(),mt({adapter:k,onChange:async()=>{await V()}})),o({success:!0})),!1)});function Co(){ge&&(ge(),ge=null),be&&(be(),be=null),Fr(),tn();try{rt()}catch(e){S.warn("Failed to reset styles on teardown",e)}try{ho()}catch(e){S.warn("Failed to teardown Grok X-Feed",e)}S.info("teardown complete")}async function Ur(e){if(!e)return{success:!1,error:"no prompt"};if(!k){const r=Jt();r&&(A=r,k=Qt(r))}if(!k)return{success:!1,error:"no adapter — chatbot not detected"};const t=k.getInput();if(!t)return{success:!1,error:"input field not found"};const o=t instanceof HTMLTextAreaElement?t.value:t.textContent??"",n=o?`${e}

---

${o}`:e;try{return await k.injectText(n),{success:!0,supportsAttachmentCard:k.supportsAttachmentCard??!1,platform:k.name}}catch(r){return{success:!1,error:r instanceof Error?r.message:String(r)}}}try{chrome.storage.onChanged.addListener(async e=>{if("srf_enabled"in e&&(e.srf_enabled.newValue!==!1?(S.info("Master switch turned ON — re-initializing extension content scripts"),A?await st(A):await Eo(),ft(!0).catch(r=>S.warn("auto-polish restoration failed",r))):(S.info("Master switch turned OFF — tearing down extension content scripts"),Co())),!k||!A)return;`srf_card_prefs_${A.hostname.replace(/^www\./,"")}`in e&&(V(),mt({adapter:k,onChange:async()=>{await V()}}))})}catch{}Jn();Eo().catch(e=>S.error("init",e));ft().catch(e=>S.warn("auto-polish",e));gr().catch(e=>S.warn("onboarding guide",e));vr().catch(e=>S.warn("autofill",e));Mr().catch(e=>S.warn("light-dom",e));mo().catch(e=>S.warn("grok-x-feed",e));async function To(){var o;const e=await chrome.storage.local.get(["srf_enabled","srf_highlight_enabled"]);if(e.srf_enabled===!1||e.srf_highlight_enabled===!1||A)return;const t=Hr();if(t.trim()){ko(),ht();try{const n=await chrome.runtime.sendMessage({type:"surface-analyze-page",payload:{pageText:t,pageUrl:location.href}});if((o=n==null?void 0:n.targets)!=null&&o.length){const r=jr(n.targets);S.info("Webpaper highlights applied",{count:r,total:n.targets.length})}}catch(n){S.warn("Webpaper highlights failed",n)}}}chrome.runtime.onMessage.addListener((e,t,o)=>{if(e.type==="surface-clear-highlights"){ko(),o({success:!0});return}if(e.type==="surface-run-highlights")return To().then(()=>o({success:!0})).catch(()=>o({success:!1})),!0});ht();setTimeout(()=>{To().catch(e=>S.warn("Webpaper highlights init",e))},1500);Wr().catch(e=>S.warn("image-video enhancer failed to start",e));export{v as S};
