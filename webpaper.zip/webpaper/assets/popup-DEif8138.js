import{i as f,r as l,a as b,c as q,b as W,g as U,x as Y,o as k,w as G,d as i,t as m,n as v}from"./icons-CbjupgSZ.js";import{g as J,_ as Z,a as K,c as Q}from"./card-types-u4cCMT4q.js";var ee=Object.defineProperty,te=Object.getOwnPropertyDescriptor,M=(e,t,r,a)=>{for(var s=a>1?void 0:a?te(t,r):t,n=e.length-1,o;n>=0;n--)(o=e[n])&&(s=(a?o(t,r,s):o(s))||s);return a&&s&&ee(t,r,s),s};const T=[{id:"claude",label:"Claude",url:"https://claude.ai",icon:q},{id:"chatgpt",label:"ChatGPT",url:"https://chatgpt.com",icon:W},{id:"gemini",label:"Gemini",url:"https://gemini.google.com",icon:U},{id:"grok",label:"Grok",url:"https://grok.com",icon:Y}];let $=class extends b{constructor(){super(...arguments),this.step="grant",this.loading=!1,this.error="",this.provider=T[0]}async connectedCallback(){super.connectedCallback();const e=await chrome.runtime.sendMessage({type:"get-auth-state"}),t=e==null?void 0:e.payload;t!=null&&t.provider&&(this.provider=T.find(r=>r.id===t.provider)??this.provider),t!=null&&t.Surfaced&&!t.loggedIn&&(this.step="login")}async handleConnect(e){var t;this.provider=T.find(r=>r.id===e)??this.provider,this.loading=!0,this.error="";try{const r=await chrome.runtime.sendMessage({type:"request-claude-permission",payload:{provider:e}});if(!r.granted){this.error=`Permission was denied. Webpaper needs access to ${this.provider.label} to read your session.`;return}(t=r.authState)!=null&&t.loggedIn?this.dispatchEvent(new CustomEvent("authenticated",{bubbles:!0,composed:!0})):this.step="login"}catch{this.error="Something went wrong. Try again."}finally{this.loading=!1}}openProvider(){chrome.tabs.create({url:this.provider.url})}async checkSession(){this.loading=!0,this.error="";try{const e=await chrome.runtime.sendMessage({type:"get-auth-state"}),t=e==null?void 0:e.payload;t!=null&&t.loggedIn?this.dispatchEvent(new CustomEvent("authenticated",{bubbles:!0,composed:!0})):this.error=`Not signed in yet — sign in to ${this.provider.label} and come back.`}finally{this.loading=!1}}render(){return i`
      <div class="brand">${k(G)}</div>

      ${this.step==="grant"?this.renderGrant():this.renderLogin()}

      <p class="how-it-works">
        <strong>How it works:</strong> Webpaper rides on your existing AI session via browser cookies.
        If you already use Claude, ChatGPT, Gemini, or Grok, there's nothing more to pay —
        no API key, no new subscription. Nothing is ever sent to us; the page, your prompt,
        and your own AI session are the whole loop.
      </p>
    `}renderGrant(){return i`
      <h1 class="hero-title">Connect your AI</h1>
      <p class="hero-subtitle">
        Webpaper works with the AI you already use. Pick a provider and grant access
        to its tab — it reads your existing session, never your password.
      </p>

      <div class="provider-grid">
        ${T.map(e=>i`
          <button
            class="provider-btn ${e.id==="claude"?"recommended":""}"
            ?disabled=${this.loading}
            @click=${()=>this.handleConnect(e.id)}
          >
            ${k(e.icon)}
            <span>${this.loading&&this.provider.id===e.id?"Connecting…":e.label}</span>
            ${e.id==="claude"?i`<span class="rec-tag">fully supported</span>`:""}
          </button>
        `)}
      </div>

      ${this.error?i`<p class="error">${this.error}</p>`:""}
    `}renderLogin(){return i`
      <h1 class="hero-title">Sign in to ${this.provider.label}</h1>
      <p class="hero-subtitle">
        Webpaper has access, but you're not signed in to ${this.provider.label} yet.
        Sign in, then come back here.
      </p>

      <div class="status-pill waiting">
        <span class="dot"></span>
        Waiting for ${this.provider.label} sign-in
      </div>

      <button class="open-claude-btn" @click=${this.openProvider}>
        Open ${this.provider.label} to sign in →
      </button>

      <button class="check-btn" ?disabled=${this.loading} @click=${this.checkSession}>
        ${this.loading?"Checking…":"I've signed in — continue"}
      </button>

      ${this.error?i`<p class="error">${this.error}</p>`:""}
    `}};$.styles=f`
    :host {
      display: block;
      padding: 32px 24px 28px;
      text-align: center;
      animation: fadeUp 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
    }
    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(8px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    .brand {
      display: flex;
      justify-content: center;
      margin-bottom: 28px;
    }
    .brand svg { height: 28px; width: auto; }
    .hero-title {
      font-size: 18px;
      font-weight: 600;
      color: #1a1a1a;
      margin: 0 0 8px;
    }
    .hero-subtitle {
      font-size: 13px;
      color: #6b7280;
      margin: 0 0 28px;
      line-height: 1.6;
    }
    .connect-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      width: 100%;
      padding: 12px;
      background: #1a1a1a;
      color: #fff;
      border: none;
      border-radius: 9px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.15s;
    }
    .connect-btn:hover:not(:disabled) { background: #374151; }
    .connect-btn:disabled { opacity: 0.5; cursor: default; }
    .connect-btn svg { width: 18px; height: 18px; }

    .provider-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 4px;
    }
    .provider-btn {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 14px 8px;
      background: #fff;
      border: 1.5px solid #e5e7eb;
      border-radius: 10px;
      font-size: 13px;
      font-weight: 500;
      color: #1a1a1a;
      cursor: pointer;
      font-family: inherit;
      transition: border-color 0.15s, background 0.15s;
    }
    .provider-btn:hover:not(:disabled) { border-color: #232c3b; background: #fafafa; }
    .provider-btn:disabled { opacity: 0.5; cursor: default; }
    .provider-btn svg { width: 22px; height: 22px; color: #232c3b; }
    .provider-btn.recommended { border-color: #232c3b; }
    .rec-tag {
      font-size: 9px;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #e79bb6;
    }
    .status-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 500;
      margin-bottom: 20px;
    }
    .status-pill.waiting {
      background: #fef3c7;
      color: #92400e;
    }
    .status-pill.ok {
      background: #d1fae5;
      color: #065f46;
    }
    .dot {
      width: 7px; height: 7px;
      border-radius: 50%;
      background: currentColor;
    }
    .open-claude-btn {
      width: 100%;
      padding: 12px;
      border: 1.5px solid #e5e7eb;
      background: #fff;
      border-radius: 9px;
      font-size: 14px;
      font-weight: 500;
      color: #374151;
      cursor: pointer;
      margin-bottom: 12px;
      transition: border-color 0.15s;
    }
    .open-claude-btn:hover { border-color: #586675; }
    .check-btn {
      width: 100%;
      padding: 12px;
      background: #1a1a1a;
      color: #fff;
      border: none;
      border-radius: 9px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.15s;
    }
    .check-btn:hover { background: #374151; }
    .check-btn:disabled { opacity: 0.5; }
    .error {
      font-size: 12px;
      color: #ef4444;
      margin-top: 8px;
    }
    .how-it-works {
      margin-top: 20px;
      font-size: 11px;
      color: #9ca3af;
      line-height: 1.6;
    }
    .how-it-works strong { color: #6b7280; }
  `;M([l()],$.prototype,"step",2);M([l()],$.prototype,"loading",2);M([l()],$.prototype,"error",2);M([l()],$.prototype,"provider",2);$=M([m("ext-auth")],$);var re=Object.defineProperty,ae=Object.getOwnPropertyDescriptor,S=(e,t,r,a)=>{for(var s=a>1?void 0:a?ae(t,r):t,n=e.length-1,o;n>=0;n--)(o=e[n])&&(s=(a?o(t,r,s):o(s))||s);return a&&s&&re(t,r,s),s};const se=[{key:"identity",label:"Your info",description:"Name, email, location, occupation"},{key:"preferences",label:"Preferences",description:""},{key:"memories",label:"Memories",description:""},{key:"calendar",label:"Calendar",description:""},{key:"gmail",label:"Gmail",description:""},{key:"drive",label:"Drive",description:""},{key:"documents",label:"Documents",description:""}];let E=class extends b{constructor(){super(...arguments),this.domain="",this.category="unknown",this.manifest=null,this.sections={identity:!0,preferences:!1,memories:!1,calendar:!1,gmail:!1,drive:!1,documents:!1}}connectedCallback(){super.connectedCallback(),this.loadPermissions()}async loadPermissions(){const e=await chrome.runtime.sendMessage({type:"get-site-permissions",payload:{domain:this.domain}});if(e!=null&&e.payload)this.sections={...this.sections,...e.payload.sections};else{const t=J(this.category);for(const r of t)this.sections={...this.sections,[r]:!0}}}getDescription(e){var t,r,a,s,n,o,p,h,w;if(e.description)return e.description;if(!this.manifest)return"";switch(e.key){case"preferences":return`${((t=this.manifest.preferences)==null?void 0:t.count)??0} preferences`;case"memories":{const B=Object.values(this.manifest.agents??{}).reduce((g,A)=>g+A.memory_count,0),D=Object.keys(this.manifest.agents??{}).length;return`${B} facts across ${D} agents`}case"calendar":return(a=(r=this.manifest.integrations)==null?void 0:r.calendar)!=null&&a.connected?`${this.manifest.integrations.calendar.event_count} upcoming events`:"Not connected";case"gmail":return(n=(s=this.manifest.integrations)==null?void 0:s.gmail)!=null&&n.connected?`${this.manifest.integrations.gmail.ranked_count} indexed emails`:"Not connected";case"drive":return(p=(o=this.manifest.integrations)==null?void 0:o.drive)!=null&&p.connected?"Connected":"Not connected";case"documents":return(w=(h=this.manifest.integrations)==null?void 0:h.notion)!=null&&w.connected?"Connected":"Not connected";default:return""}}toggleSection(e){this.sections={...this.sections,[e]:!this.sections[e]},this.savePermissions()}async savePermissions(){const e={domain:this.domain,sections:this.sections,lastUpdated:Date.now()};await chrome.runtime.sendMessage({type:"update-site-permissions",payload:e}),this.dispatchEvent(new CustomEvent("permissions-changed",{detail:e,bubbles:!0,composed:!0}))}render(){return i`
      <div class="heading">Sharing with this site</div>
      <div class="section-list">
        ${se.map(e=>i`
          <div class="section-row">
            <div class="section-info">
              <span class="section-label">${e.label}</span>
              <span class="section-desc">${this.getDescription(e)}</span>
            </div>
            <label class="toggle">
              <input
                type="checkbox"
                .checked=${this.sections[e.key]}
                @change=${()=>this.toggleSection(e.key)}
              />
              <span class="toggle-track"></span>
              <span class="toggle-thumb"></span>
            </label>
          </div>
        `)}
      </div>
    `}};E.styles=f`
    :host {
      display: block;
    }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(6px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .section-list {
      display: flex;
      flex-direction: column;
      animation: fadeUp 0.2s cubic-bezier(0.25, 0.1, 0.25, 1);
    }

    .section-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 20px;
      transition: background 0.12s ease;
    }

    .section-row:hover {
      background: rgba(0, 0, 0, 0.015);
    }

    .section-info {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .section-label {
      font-size: 14px;
      color: var(--srf-text-interactive, #000);
      font-weight: 400;
      letter-spacing: 0.01em;
    }

    .section-desc {
      font-size: 12px;
      color: var(--srf-text-tertiary, #7A7F88);
      letter-spacing: 0.01em;
    }

    /* iOS-style toggle: 36x20, D1D1D6 off, 34C759 on, cubic-bezier easing */
    .toggle {
      position: relative;
      width: 36px;
      height: 20px;
      flex-shrink: 0;
    }

    .toggle input {
      opacity: 0;
      width: 0;
      height: 0;
      position: absolute;
    }

    .toggle-track {
      position: absolute;
      inset: 0;
      background: #D1D1D6;
      border-radius: 10px;
      cursor: pointer;
      transition: background 0.25s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .toggle input:checked + .toggle-track {
      background: #000;
    }

    .toggle-thumb {
      position: absolute;
      top: 2px;
      left: 2px;
      width: 16px;
      height: 16px;
      background: #FFFFFF;
      border-radius: 50%;
      transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
      pointer-events: none;
    }

    .toggle input:checked ~ .toggle-thumb {
      transform: translateX(16px);
    }

    .heading {
      padding: 14px 20px 6px;
      font-size: 13px;
      letter-spacing: 0.01em;
      font-weight: 400;
      color: var(--srf-text, #363636);
    }
  `;S([v({type:String})],E.prototype,"domain",2);S([v({type:String})],E.prototype,"category",2);S([v({attribute:!1})],E.prototype,"manifest",2);S([l()],E.prototype,"sections",2);E=S([m("ext-permissions")],E);var ie=Object.defineProperty,oe=Object.getOwnPropertyDescriptor,H=(e,t,r,a)=>{for(var s=a>1?void 0:a?oe(t,r):t,n=e.length-1,o;n>=0;n--)(o=e[n])&&(s=(a?o(t,r,s):o(s))||s);return a&&s&&ie(t,r,s),s};let O=class extends b{constructor(){super(...arguments),this.prompt=""}render(){return i`
      <div class="preview-label">Preview</div>
      <div class="preview-container">
        ${this.prompt?i`<pre>${this.prompt}</pre>`:i`<div class="empty">No prompt generated yet. Toggle sections above and click "Share with chatbot".</div>`}
      </div>
    `}};O.styles=f`
    :host {
      display: block;
      padding: 12px 20px;
      animation: fadeUp 0.2s cubic-bezier(0.25, 0.1, 0.25, 1);
    }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(6px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .preview-container {
      background: var(--srf-bg-input, #F4F4F7);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: var(--srf-radius-md, 6px);
      padding: 12px 14px;
      max-height: 200px;
      overflow-y: auto;
    }

    .preview-label {
      font-size: 13px;
      font-weight: 400;
      letter-spacing: 0.01em;
      color: var(--srf-text, #363636);
      margin-bottom: 8px;
    }

    pre {
      font-family: var(--srf-font-mono, 'IBM Plex Mono', ui-monospace, monospace);
      font-size: 11px;
      color: var(--srf-text-secondary, #6B6B70);
      white-space: pre-wrap;
      word-break: break-word;
      line-height: 1.5;
      margin: 0;
    }

    .empty {
      color: var(--srf-text-tertiary, #7A7F88);
      font-size: 12px;
    }
  `;H([v({type:String})],O.prototype,"prompt",2);O=H([m("ext-preview")],O);var ne=Object.defineProperty,le=Object.getOwnPropertyDescriptor,N=(e,t,r,a)=>{for(var s=a>1?void 0:a?le(t,r):t,n=e.length-1,o;n>=0;n--)(o=e[n])&&(s=(a?o(t,r,s):o(s))||s);return a&&s&&ne(t,r,s),s};let C=class extends b{constructor(){super(...arguments),this.status=null,this.loading=!0,this.pollInterval=null}connectedCallback(){super.connectedCallback(),this.refresh(),this.pollInterval=window.setInterval(()=>this.refresh(),1e4)}disconnectedCallback(){super.disconnectedCallback(),this.pollInterval!=null&&(window.clearInterval(this.pollInterval),this.pollInterval=null)}async refresh(){try{const e=await chrome.runtime.sendMessage({type:"claude-session-status"});this.status=(e==null?void 0:e.payload)??null}catch(e){console.warn("[Webpaper] Failed to get claude session status:",e)}this.loading=!1}async handleClick(){if(this.status){if(this.status.error==="no-permission"){try{await chrome.permissions.request({origins:["https://claude.ai/*"]})&&await this.refresh()}catch(e){console.warn("[Webpaper] Permission request failed:",e)}return}if(this.status.error==="no-cookie"||this.status.error==="not-logged-in"){chrome.tabs.create({url:"https://claude.ai"});return}}}render(){return this.loading?i`<span class="pill"><span class="dot unavailable"></span><span class="label">Checking…</span></span>`:this.status?this.status.loggedIn?i`
        <span class="pill connected">
          <span class="dot connected"></span>
          <span class="label">Connected</span>
        </span>
      `:this.status.error==="no-permission"?i`
        <span class="pill actionable" @click=${this.handleClick} title="Click to enable smart features">
          <span class="dot needs-perm"></span>
          <span class="label">Enable smart features</span>
        </span>
      `:this.status.error==="no-cookie"||this.status.error==="not-logged-in"?i`
        <span class="pill actionable" @click=${this.handleClick} title="Click to sign in to your AI">
          <span class="dot needs-signin"></span>
          <span class="label">Sign in to your AI</span>
        </span>
      `:i`
      <span class="pill">
        <span class="dot unavailable"></span>
        <span class="label">Unavailable</span>
      </span>
    `:i`<span class="pill"><span class="dot unavailable"></span><span class="label">Unavailable</span></span>`}};C.styles=f`
    :host {
      display: inline-flex;
      align-items: center;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    .pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 10px;
      border-radius: var(--srf-radius-sm, 4px);
      font-size: 11px;
      font-weight: 400;
      font-family: inherit;
      letter-spacing: 0.01em;
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      background: transparent;
      cursor: default;
      transition: all 0.2s ease;
      animation: fadeIn 0.2s ease-out;
    }

    .pill.actionable {
      cursor: pointer;
    }

    .pill.actionable:hover {
      background: #000;
      color: #FFF;
      border-color: #000;
    }

    .dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      flex-shrink: 0;
    }

    .dot.connected { background: var(--srf-success, #34C759); }
    .dot.needs-signin,
    .dot.needs-perm { background: var(--srf-text, #363636); }
    .dot.unavailable { background: var(--srf-text-tertiary, #7A7F88); }

    .label {
      color: var(--srf-text-interactive, #000);
      white-space: nowrap;
    }

    .pill.actionable:hover .label {
      color: #FFF;
    }
  `;N([l()],C.prototype,"status",2);N([l()],C.prototype,"loading",2);C=N([m("ext-runtime-status")],C);var ce=Object.defineProperty,de=Object.getOwnPropertyDescriptor,j=(e,t,r,a)=>{for(var s=a>1?void 0:a?de(t,r):t,n=e.length-1,o;n>=0;n--)(o=e[n])&&(s=(a?o(t,r,s):o(s))||s);return a&&s&&ce(t,r,s),s};let _=class extends b{constructor(){super(...arguments),this.events=[],this.summary=null,this.refreshTick=0}connectedCallback(){super.connectedCallback(),this.loadData()}async loadData(){const e=await chrome.runtime.sendMessage({type:"telemetry-get-recent",payload:{limit:20}}),t=await chrome.runtime.sendMessage({type:"telemetry-get-summary"});this.events=(e==null?void 0:e.payload)??[],this.summary=(t==null?void 0:t.payload)??null}async toggleOptOut(e){const t=e.target.checked;await chrome.runtime.sendMessage({type:"telemetry-set-optout",payload:{optedOut:!t}}),await this.loadData()}async flushNow(){await chrome.runtime.sendMessage({type:"telemetry-flush-now"}),await this.loadData()}async refresh(){this.refreshTick++,await this.loadData()}formatTime(e){const t=new Date(e);return`${String(t.getHours()).padStart(2,"0")}:${String(t.getMinutes()).padStart(2,"0")}:${String(t.getSeconds()).padStart(2,"0")}`}render(){const e=this.summary?!this.summary.optedOut:!0;return i`
      <div class="header">
        <span class="label">Telemetry (local)</span>
        <label class="optout">
          <input
            type="checkbox"
            .checked=${e}
            @change=${this.toggleOptOut}
          />
          Opt in
        </label>
      </div>

      ${this.summary?i`
            <div class="summary">
              <span><strong>${this.summary.totalEvents}</strong> buffered</span>
              <span><strong>${Object.keys(this.summary.platformBreakdown).length}</strong> sites</span>
              <span>
                ${this.summary.lastFlushTs?`last flush ${new Date(this.summary.lastFlushTs).toLocaleTimeString()}`:"not flushed"}
              </span>
            </div>
          `:""}

      ${this.events.length===0?i`<div class="empty">No events yet — visit a chatbot to see activity</div>`:i`
            <div class="events">
              ${this.events.map(t=>i`
                  <div class="event">
                    <span class="event-time">${this.formatTime(t.ts)}</span>
                    <span class="event-kind ${t.kind}">${t.kind}</span>
                    <span class="event-host">${t.hostname}</span>
                  </div>
                `)}
            </div>
          `}

      <div class="actions">
        <button class="btn" @click=${this.refresh}>Refresh</button>
        <button class="btn" @click=${this.flushNow}>Flush now</button>
      </div>

      <div class="hint">
        We log only <strong>hostnames and event kinds</strong> — never your messages or profile content.
        Events are batched and sent to Webpaper to improve integrations.
      </div>
    `}};_.styles=f`
    :host {
      display: block;
      padding: 14px 20px;
      border-top: 1px solid var(--srf-border-inner, #E5E5EA);
      animation: fadeUp 0.2s var(--srf-ease, cubic-bezier(0.25, 0.1, 0.25, 1));
    }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(4px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 10px;
    }

    .label {
      font-size: 13px;
      font-weight: 400;
      letter-spacing: 0.01em;
      color: var(--srf-text, #363636);
    }

    .optout {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      color: var(--srf-text-secondary, #6B6B70);
      cursor: pointer;
    }

    .optout input {
      accent-color: var(--srf-text, #363636);
    }

    .summary {
      display: flex;
      gap: 12px;
      font-size: 11px;
      color: var(--srf-text-secondary, #6B6B70);
      margin-bottom: 10px;
      padding: 8px 10px;
      background: transparent;
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: var(--srf-radius-sm, 4px);
    }

    .summary strong {
      color: var(--srf-text-interactive, #000);
      font-weight: 500;
    }

    .events {
      max-height: 180px;
      overflow-y: auto;
      background: var(--srf-bg-input, #F4F4F7);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: var(--srf-radius-md, 6px);
      padding: 8px;
    }

    .event {
      display: flex;
      gap: 8px;
      padding: 4px 0;
      font-size: 11px;
      font-family: var(--srf-font-mono, 'IBM Plex Mono', ui-monospace, monospace);
      border-bottom: 1px solid var(--srf-border-inner, #E5E5EA);
    }

    .event:last-child {
      border-bottom: none;
    }

    .event-time {
      color: var(--srf-text-tertiary, #7A7F88);
      width: 58px;
      flex-shrink: 0;
    }

    .event-kind {
      color: var(--srf-text, #363636);
      font-weight: 400;
      width: 70px;
      flex-shrink: 0;
    }

    .event-kind.fire { color: var(--srf-success, #34C759); }
    .event-kind.disarm { color: var(--srf-text-tertiary, #7A7F88); }

    .event-host {
      color: var(--srf-text-secondary, #6B6B70);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .empty {
      color: var(--srf-text-tertiary, #7A7F88);
      font-size: 12px;
      text-align: center;
      padding: 16px 0;
    }

    .actions {
      display: flex;
      gap: 8px;
      margin-top: 10px;
    }

    .btn {
      background: transparent;
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: var(--srf-radius-sm, 4px);
      padding: 6px 12px;
      font-size: 11px;
      font-family: inherit;
      color: var(--srf-text-interactive, #000);
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .btn:hover {
      background: #000;
      color: #FFF;
      border-color: #000;
    }

    .hint {
      font-size: 11px;
      color: var(--srf-text-tertiary, #7A7F88);
      line-height: 1.5;
      margin-top: 8px;
      letter-spacing: 0.01em;
    }
  `;j([l()],_.prototype,"events",2);j([l()],_.prototype,"summary",2);j([l()],_.prototype,"refreshTick",2);_=j([m("ext-telemetry")],_);var pe=Object.defineProperty,he=Object.getOwnPropertyDescriptor,L=(e,t,r,a)=>{for(var s=a>1?void 0:a?he(t,r):t,n=e.length-1,o;n>=0;n--)(o=e[n])&&(s=(a?o(t,r,s):o(s))||s);return a&&s&&pe(t,r,s),s};let P=class extends b{constructor(){super(...arguments),this.domain="",this.autofillEnabled=!1,this.lightDomEnabled=!1}async connectedCallback(){if(super.connectedCallback(),!this.domain)return;const{[`srf_autofill_${this.domain}`]:e,[`srf_lightdom_${this.domain}`]:t}=await chrome.storage.local.get([`srf_autofill_${this.domain}`,`srf_lightdom_${this.domain}`]);this.autofillEnabled=e===!0,this.lightDomEnabled=t===!0}async toggleAutofill(){this.autofillEnabled=!this.autofillEnabled,await chrome.storage.local.set({[`srf_autofill_${this.domain}`]:this.autofillEnabled})}async toggleLightDom(){this.lightDomEnabled=!this.lightDomEnabled,await chrome.storage.local.set({[`srf_lightdom_${this.domain}`]:this.lightDomEnabled})}render(){return this.domain?i`
      <details>
        <summary>
          <span>Experimental</span>
          <span style="flex:1"></span>
          <span class="caret">›</span>
        </summary>
        <div class="row">
          <div>
            <div class="row-label">Autofill on this site</div>
            <div class="row-desc">Show a fill pill on form fields. Click to fill.</div>
          </div>
          <label class="ios-toggle">
            <input type="checkbox" .checked=${this.autofillEnabled} @change=${this.toggleAutofill} />
            <span class="track"></span>
            <span class="thumb"></span>
          </label>
        </div>
        <div class="row">
          <div>
            <div class="row-label">In-page personalisation</div>
            <div class="row-desc">Replace data-srf-token markers with your name / city.</div>
          </div>
          <label class="ios-toggle">
            <input type="checkbox" .checked=${this.lightDomEnabled} @change=${this.toggleLightDom} />
            <span class="track"></span>
            <span class="thumb"></span>
          </label>
        </div>
      </details>
    `:i``}};P.styles=f`
    :host {
      display: block;
      border-top: 1px solid #E5E5EA;
      padding: 12px 20px;
    }
    summary {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      list-style: none;
      user-select: none;
      font-size: 12px;
      color: #7A7F88;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      font-weight: 500;
    }
    summary::-webkit-details-marker { display: none; }
    .caret { font-size: 14px; transition: transform 0.2s ease; }
    details[open] .caret { transform: rotate(90deg); }

    .row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 0;
      gap: 12px;
      border-top: 1px solid #E5E5EA;
    }
    .row:first-child { border-top: none; margin-top: 8px; }
    .row-label {
      font-size: 13px;
      color: #363636;
    }
    .row-desc {
      font-size: 11px;
      color: #6B6B70;
      margin-top: 2px;
    }
    .ios-toggle {
      position: relative;
      width: 36px;
      height: 22px;
      flex-shrink: 0;
      cursor: pointer;
    }
    .ios-toggle input { opacity: 0; width: 0; height: 0; position: absolute; }
    .track {
      position: absolute; inset: 0;
      background: #D1D1D6;
      border-radius: 11px;
      transition: background 0.2s ease;
    }
    .ios-toggle input:checked + .track { background: #000; }
    .thumb {
      position: absolute; top: 2px; left: 2px;
      width: 18px; height: 18px;
      background: #FFF;
      border-radius: 50%;
      transition: transform 0.2s ease;
    }
    .ios-toggle input:checked ~ .thumb { transform: translateX(14px); }
  `;L([v({type:String})],P.prototype,"domain",2);L([l()],P.prototype,"autofillEnabled",2);L([l()],P.prototype,"lightDomEnabled",2);P=L([m("ext-experimental")],P);var ge=Object.defineProperty,ue=Object.getOwnPropertyDescriptor,V=(e,t,r,a)=>{for(var s=a>1?void 0:a?ue(t,r):t,n=e.length-1,o;n>=0;n--)(o=e[n])&&(s=(a?o(t,r,s):o(s))||s);return a&&s&&ge(t,r,s),s};let I=class extends b{constructor(){super(...arguments),this.entries=[]}async connectedCallback(){super.connectedCallback(),await this.refresh()}async refresh(){var r;const e=await chrome.runtime.sendMessage({type:"get-recent-logs",payload:{limit:50}}),t=((r=e==null?void 0:e.payload)==null?void 0:r.entries)??[];this.entries=t.filter(a=>a.level==="warn"||a.level==="error").slice(-30)}async clear(){const{clearLogs:e}=await Z(async()=>{const{clearLogs:t}=await import("./logger-DShRSVht.js");return{clearLogs:t}},[]);await e(),this.entries=[]}render(){const e=this.entries.filter(t=>t.level==="error").length;return i`
      <details @toggle=${t=>t.target.open&&this.refresh()}>
        <summary>
          <span>Recent errors</span>
          ${e>0?i`<span class="badge">${e}</span>`:""}
          <span style="flex:1"></span>
          <span class="caret">›</span>
        </summary>
        <div class="body">
          ${this.entries.length===0?i`<div class="empty">No recent errors. Things are quiet.</div>`:this.entries.map(t=>i`
                  <div class="row ${t.level}">
                    [${new Date(t.ts).toLocaleTimeString()}]
                    [${t.feature}]
                    ${t.msg}
                  </div>
                `)}
        </div>
        <div class="actions">
          <button class="clear" @click=${()=>this.clear()}>Clear</button>
        </div>
      </details>
    `}};I.styles=f`
    :host {
      display: block;
      border-top: 1px solid #E5E5EA;
      padding: 12px 20px;
    }
    summary {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      list-style: none;
      user-select: none;
      font-size: 12px;
      color: #7A7F88;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      font-weight: 500;
    }
    summary::-webkit-details-marker { display: none; }
    .badge {
      font-size: 10px;
      background: rgba(255, 59, 48, 0.12);
      color: #FF3B30;
      padding: 1px 6px;
      border-radius: 4px;
      text-transform: none;
      letter-spacing: 0;
    }
    .caret { font-size: 14px; transition: transform 0.2s ease; }
    details[open] .caret { transform: rotate(90deg); }

    .body {
      margin-top: 8px;
      max-height: 200px;
      overflow-y: auto;
      font-family: 'IBM Plex Mono', ui-monospace, monospace;
      font-size: 11px;
      background: #F4F4F7;
      border: 1px solid #E5E5EA;
      border-radius: 6px;
      padding: 8px;
      color: #363636;
      line-height: 1.5;
    }
    .row { padding: 2px 0; word-break: break-word; }
    .row.warn { color: #B7791F; }
    .row.error { color: #C53030; }
    .empty { color: #7A7F88; padding: 8px 0; }
    .actions {
      display: flex;
      justify-content: flex-end;
      margin-top: 6px;
    }
    .clear {
      background: transparent;
      border: 1px solid #E5E5EA;
      border-radius: 4px;
      padding: 3px 10px;
      font-size: 11px;
      cursor: pointer;
      color: #6B6B70;
    }
    .clear:hover { border-color: #9E9E9E; color: #000; }
  `;V([l()],I.prototype,"entries",2);I=V([m("ext-error-log")],I);var fe=Object.defineProperty,be=Object.getOwnPropertyDescriptor,R=(e,t,r,a)=>{for(var s=a>1?void 0:a?be(t,r):t,n=e.length-1,o;n>=0;n--)(o=e[n])&&(s=(a?o(t,r,s):o(s))||s);return a&&s&&fe(t,r,s),s};let z=class extends b{constructor(){super(...arguments),this.domain="",this.alwaysOn=!1,this.state="idle"}async connectedCallback(){if(super.connectedCallback(),!this.domain)return;const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(e!=null&&e.id)try{const t=await chrome.tabs.sendMessage(e.id,{type:"polish-get-page-status"});((t==null?void 0:t.status)==="manual"||(t==null?void 0:t.status)==="auto")&&(this.state="cleaned")}catch{}}async clean(){var r,a;if(this.state==="running")return;if(this.state==="cleaned")return this.restore();this.state="running";const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(e!=null&&e.id)){this.state="idle";return}const t=()=>chrome.tabs.sendMessage(e.id,{type:"polish-start-manual",payload:{mode:"webpaper-clean"}});try{await t()}catch{try{const n=((a=(r=chrome.runtime.getManifest().content_scripts)==null?void 0:r[0])==null?void 0:a.js)??[];if(n.length===0)throw new Error("no content scripts");await chrome.scripting.executeScript({target:{tabId:e.id},files:n}),await new Promise(o=>setTimeout(o,250)),await t()}catch{this.state="idle";return}}setTimeout(()=>{this.state==="running"&&(this.state="cleaned")},6e3)}async restore(){const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(e!=null&&e.id)try{await chrome.tabs.sendMessage(e.id,{type:"polish-history-back"}),this.state="idle"}catch{this.state="idle"}}render(){return this.state==="cleaned"?i`
        <button class="button restore" @click=${this.restore}>
          <span class="stack">
            <span class="label">Restore page</span>
            <span class="sub">Bring back what was hidden</span>
          </span>
          <span class="arrow">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round">
              <path d="M9.5 4 L4 8 L9.5 12" />
            </svg>
          </span>
        </button>
      `:i`
      <button
        class="button ${this.state==="running"?"running":""}"
        ?disabled=${this.state==="running"}
        @click=${this.clean}
      >
        <span class="stack">
          <span class="label">${this.state==="running"?"Personalizing…":this.alwaysOn?"Refire":"Personalize this page"}</span>
          <span class="sub">${this.state==="running"?"Redesigning for you…":this.alwaysOn?"Run the personalization pass again":"Redesign this page for you"}</span>
        </span>
        <span class="arrow">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round">
            <path d="M3 8h10 M9 4l4 4-4 4" />
          </svg>
        </span>
      </button>
    `}};z.styles=f`
    :host {
      display: block;
      padding: 14px 20px 4px;
    }
    .button {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      width: 100%;
      padding: 14px 16px 14px 18px;
      background: #000;
      color: #fff;
      border: 1px solid #000;
      border-radius: 12px;
      cursor: pointer;
      font-family: inherit;
      text-align: left;
      overflow: hidden;
      isolation: isolate;
      transition: transform 0.18s ease, border-color 0.18s ease;
    }
    .button:hover { transform: translateY(-1px); }
    .button:active { transform: translateY(0); }
    .button:disabled { opacity: 0.7; cursor: progress; }

    /* Mesh gradient sweeps in on hover. Keeps the button calm by default
     * but signals "headline action" the moment you reach for it. */
    .button::before {
      content: '';
      position: absolute;
      inset: 0;
      z-index: -1;
      pointer-events: none;
      opacity: 0;
      background:
        radial-gradient(ellipse 60% 60% at 0%   30%, rgba(255, 130, 80, 0.7) 0%, transparent 60%),
        radial-gradient(ellipse 55% 65% at 100% 30%, rgba(140, 80, 240, 0.6) 0%, transparent 60%),
        radial-gradient(ellipse 60% 60% at 50% 100%, rgba(60, 140, 255, 0.6) 0%, transparent 60%);
      background-size: 180% 180%;
      transition: opacity 0.3s ease, background-position 6s ease;
    }
    .button:hover::before {
      opacity: 1;
      background-position: 100% 100%;
    }

    /* Subtle progress sweep while running */
    @keyframes sweep {
      0%   { background-position: -200% 0; }
      100% { background-position:  200% 0; }
    }
    .button.running::after {
      content: '';
      position: absolute;
      inset: 0;
      z-index: -1;
      background: linear-gradient(90deg,
        transparent 0%,
        rgba(255, 255, 255, 0.18) 50%,
        transparent 100%);
      background-size: 200% 100%;
      animation: sweep 1.2s linear infinite;
    }

    .stack {
      display: flex;
      flex-direction: column;
      gap: 2px;
      min-width: 0;
    }
    .label {
      font-size: 14px;
      font-weight: 500;
      letter-spacing: -0.005em;
      line-height: 1.2;
    }
    .sub {
      font-size: 11px;
      color: rgba(255, 255, 255, 0.65);
      line-height: 1.3;
    }
    .arrow {
      flex-shrink: 0;
      width: 28px; height: 28px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.12);
      display: flex; align-items: center; justify-content: center;
      transition: background 0.18s ease;
    }
    .button:hover .arrow { background: rgba(255, 255, 255, 0.22); }
    .arrow svg { width: 14px; height: 14px; }

    /* Restore variant: invert the colour story so it reads as "you can go back". */
    .button.restore {
      background: #fff;
      color: #1f1f24;
      border-color: #d6d6db;
    }
    .button.restore .sub { color: #6b6b70; }
    .button.restore .arrow {
      background: rgba(0, 0, 0, 0.05);
      color: #1f1f24;
    }
    .button.restore::before { display: none; }
  `;R([v({type:String})],z.prototype,"domain",2);R([v({type:Boolean})],z.prototype,"alwaysOn",2);R([l()],z.prototype,"state",2);z=R([m("ext-clean-action")],z);var me=Object.defineProperty,ve=Object.getOwnPropertyDescriptor,F=(e,t,r,a)=>{for(var s=a>1?void 0:a?ve(t,r):t,n=e.length-1,o;n>=0;n--)(o=e[n])&&(s=(a?o(t,r,s):o(s))||s);return a&&s&&me(t,r,s),s};let y=class extends b{constructor(){super(...arguments),this.domain="",this.cards=[],this.prefs={},this.loaded=!1,this.expandedType=null,this.leavingTypes=new Set}async connectedCallback(){if(super.connectedCallback(),!this.domain){this.loaded=!0;return}await this.refresh(),this.storageListener=e=>{const t=`srf_card_prefs_${this.domain}`;if(e[t]){const r=e[t].newValue??{};this.prefs={...r}}},chrome.storage.onChanged.addListener(this.storageListener)}disconnectedCallback(){super.disconnectedCallback(),this.storageListener&&chrome.storage.onChanged.removeListener(this.storageListener)}updated(e){e.has("domain")&&this.domain&&this.refresh()}async refresh(){var e,t;try{const r=await chrome.runtime.sendMessage({type:"get-all-cards",payload:{host:this.domain}}),a=((e=r==null?void 0:r.payload)==null?void 0:e.cards)??[],s=((t=r==null?void 0:r.payload)==null?void 0:t.prefs)??{};this.cards=a,this.prefs=s}catch{this.cards=[],this.prefs={}}this.loaded=!0}isAttached(e){return this.prefs[e]===!0}async sendCard(e,t){t.stopPropagation(),!this.leavingTypes.has(e)&&(this.leavingTypes=new Set([...this.leavingTypes,e]),this.expandedType=null,setTimeout(()=>{chrome.runtime.sendMessage({type:"set-card-attached",payload:{host:this.domain,cardType:e,attached:!0}})},200))}toggleExpand(e){this.expandedType=this.expandedType===e?null:e}render(){if(!this.loaded)return i`<div class="empty-loading">Loading cards…</div>`;if(!this.domain)return i`<div class="empty">No active site detected.</div>`;const e=this.cards.filter(t=>!this.isAttached(t.type));return this.cards.length===0?i`
        <div class="empty">
          No cards yet — fill out your profile at
          <a href="#" @click=${t=>{t.preventDefault(),chrome.tabs.create({url:"https://webpaper.app/me"})}}>webpaper.app/me</a>
          and they'll show up here.
        </div>
      `:i`
      <div class="header">
        <span class="title">Available on ${this.domain}</span>
        <span class="count">${e.length}</span>
        <span class="hint">${e.length===0?"all sent to chat":"click Send to attach"}</span>
      </div>
      ${e.length===0?i`<div class="empty">Every card is in the chat. Click × on a chip in the chat to bring one back here.</div>`:i`<div class="cards">${e.map((t,r)=>this.renderCard(t,r))}</div>`}
    `}renderCard(e,t){const r=K(e.type),a=e.label??r.label,s=xe(e),n=e.type==="biography",o=this.expandedType===e.type,p=this.leavingTypes.has(e.type);return i`
      <div
        class="card-wrap ${p?"leaving":""}"
        style="--enter-delay: ${t*30}ms"
      >
        <div
          class="card ${n?"marquee":""} ${o?"expanded":""}"
          style="--accent: ${r.accent}"
          @click=${()=>this.toggleExpand(e.type)}
          role="button"
          aria-expanded=${o}
          aria-label="${a} — click to read"
        >
          <span class="dot"></span>
          <span class="icon">${ye(e.type)}</span>
          <div class="body">
            <span class="label">${a}</span>
            <span class="preview">${s}</span>
          </div>
          <button
            class="send"
            type="button"
            @click=${h=>this.sendCard(e.type,h)}
            aria-label="Send ${a} to chat"
          >
            Send
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
              <path d="M3 8 L13 8 M9 4 L13 8 L9 12"/>
            </svg>
          </button>
        </div>
        ${o?i`<div class="content">${this.renderContent(e)}</div>`:""}
      </div>
    `}renderContent(e){const t=e.content||"";switch(e.type){case"biography":return this.renderBiography(t);case"instructions":return i`<blockquote class="content-instructions">${t}</blockquote>`;case"interests":case"connected-apps":{const r=t.split(/[,\n]/).map(a=>a.trim()).filter(Boolean);return i`
          <div class="content-pills">
            ${r.map(a=>i`<span class="content-pill ${e.type==="connected-apps"?"app":""}">${a}</span>`)}
          </div>
        `}case"preferences":case"memory":case"calendar":{const r=t.split(`
`).map(a=>a.replace(/^[-•]\s*/,"").trim()).filter(Boolean);return i`<ul class="content-list">${r.map(a=>i`<li>${a}</li>`)}</ul>`}case"projects":{const r=t.split(`
`).map(a=>a.replace(/^[-•]\s*/,"").trim()).filter(Boolean);return i`
          <div class="content-projects">
            ${r.map(a=>{const s=a.indexOf(":");return s>0?i`<div class="content-proj"><span class="content-proj-slug">${a.slice(0,s).trim()}</span><span class="content-proj-desc">${a.slice(s+1).trim()}</span></div>`:i`<div class="content-proj">${a}</div>`})}
          </div>
        `}case"allergies":{const r=t.split(`
`).map(a=>a.replace(/^[-•]\s*/,"").trim()).filter(Boolean);return i`<ul class="content-list content-allergies">${r.map(a=>i`<li>${a}</li>`)}</ul>`}default:return i`<div class="content-text">${t}</div>`}}renderBiography(e){const t=e.split(`
`),r={};let a=-1;for(let o=0;o<t.length;o++){const p=t[o];if(/^About\s*:/i.test(p.trim())||p.trim()==="About:"){a=o+1;break}const h=p.match(/^([A-Za-z]+)\s*:\s*(.+)$/);h&&(r[h[1].toLowerCase()]=h[2].trim())}const s=[];r.occupation&&s.push(r.occupation),r.location&&s.push(r.location);const n=a>-1?t.slice(a).join(`
`).trim():"";return i`
      <div>
        ${r.name?i`<div class="content-bio-name">${r.name}</div>`:""}
        ${s.length?i`<div class="content-bio-sub">${s.join(" · ")}</div>`:""}
        ${n?i`<p class="content-bio-about">${n}</p>`:""}
      </div>
    `}};y.styles=f`
    :host {
      display: block;
      padding: 14px 20px 18px;
      font-family: inherit;
      animation: fade-in 0.22s cubic-bezier(0.25, 0.1, 0.25, 1);
    }

    @keyframes fade-in {
      from { opacity: 0; transform: translateY(4px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    @keyframes mesh-drift {
      0%   { background-position:   0%   0%; }
      100% { background-position: 100% 100%; }
    }
    @keyframes card-enter {
      from { opacity: 0; transform: translateY(6px) scale(0.97); }
      to   { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes card-leave {
      to { opacity: 0; transform: translateX(20px) scale(0.92); }
    }

    .header {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 10px;
    }
    .title {
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      font-weight: 500;
      color: #6b6b70;
    }
    .count {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 18px;
      height: 18px;
      padding: 0 6px;
      border-radius: 999px;
      font-size: 10px;
      color: #6b6b70;
      background: rgba(0, 0, 0, 0.06);
    }
    .hint {
      flex: 1;
      text-align: right;
      font-size: 11px;
      color: #9090a0;
    }

    .cards { display: flex; flex-direction: column; gap: 6px; }

    /* ── Card row ─────────────────────────────────────────────────── */

    .card-wrap {
      display: flex;
      flex-direction: column;
      animation: card-enter 0.26s cubic-bezier(0.2, 0.8, 0.2, 1) backwards;
      animation-delay: var(--enter-delay, 0ms);
    }
    .card-wrap.leaving { animation: card-leave 0.22s ease forwards; pointer-events: none; }

    .card {
      --accent: #586675;
      position: relative;
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 6px 10px 12px;
      border: 1px solid #d6d6db;
      border-radius: 10px;
      background: #fff;
      color: #1f1f24;
      cursor: pointer;
      user-select: none;
      overflow: hidden;
      isolation: isolate;
      transition: border-color 0.18s ease, transform 0.18s ease;
    }
    .card:hover { border-color: #1f1f24; transform: translateY(-1px); }

    .dot { width: 8px; height: 8px; border-radius: 50%; background: var(--accent); flex-shrink: 0; }
    .icon { width: 14px; height: 14px; color: #6b6b70; flex-shrink: 0; display: inline-flex; }
    .icon svg { width: 100%; height: 100%; display: block; }

    .body {
      flex: 1 1 auto;
      min-width: 0;
      display: flex;
      flex-direction: column;
      gap: 1px;
    }
    .label {
      font-size: 13px;
      font-weight: 500;
      color: #1f1f24;
      letter-spacing: 0.005em;
      line-height: 1.2;
    }
    .preview {
      font-size: 11px;
      color: #6b6b70;
      line-height: 1.35;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    /* Send action — the primary CTA, always visible. */
    .send {
      flex-shrink: 0;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      height: 28px;
      padding: 0 10px 0 12px;
      border: none;
      border-radius: 999px;
      background: #000;
      color: #fff;
      font: inherit;
      font-size: 11px;
      font-weight: 500;
      cursor: pointer;
      transition: transform 0.15s ease, opacity 0.15s ease;
    }
    .send:hover { transform: translateY(-1px); }
    .send svg { width: 12px; height: 12px; }

    /* ── Marquee — biography card ──────────────────────────────────── */

    .card.marquee {
      color: #fff;
      border-color: transparent;
    }
    .card.marquee::before {
      content: '';
      position: absolute;
      inset: 0;
      z-index: -1;
      pointer-events: none;
      background:
        radial-gradient(ellipse 65% 62% at 0%   15%, rgba(255, 110,  60, 0.95) 0%, transparent 65%),
        radial-gradient(ellipse 60% 62% at 100% 22%, rgba(140,  70, 240, 0.85) 0%, transparent 65%),
        radial-gradient(ellipse 65% 60% at 95%  92%, rgba( 50, 130, 255, 0.82) 0%, transparent 65%),
        radial-gradient(ellipse 55% 50% at 50%   0%, rgba(255, 140,  90, 0.78) 0%, transparent 65%),
        linear-gradient(135deg, #2a1c4a 0%, #4a1a3a 50%, #1a2a4a 100%);
      background-size: 200% 200%;
      animation: mesh-drift 9s ease-in-out infinite alternate;
    }
    .card.marquee .dot { background: #fff; }
    .card.marquee .icon { color: rgba(255,255,255,0.95); }
    .card.marquee .label { color: #fff; }
    .card.marquee .preview { color: rgba(255,255,255,0.78); }
    .card.marquee .send { background: #fff; color: #1f1f24; }
    .card.marquee:hover { border-color: transparent; }

    /* ── Read panel (expanded content) ─────────────────────────────── */

    .card.expanded { border-bottom-left-radius: 0; border-bottom-right-radius: 0; border-bottom-color: transparent; }

    .content {
      padding: 12px 14px 14px;
      border: 1px solid #d6d6db;
      border-top: none;
      border-left-width: 3px;
      border-left-color: var(--accent, #586675);
      border-bottom-left-radius: 10px;
      border-bottom-right-radius: 10px;
      background: #fbfbfd;
      color: #2c2c33;
      font-size: 12px;
      line-height: 1.55;
      animation: card-enter 0.22s ease;
    }

    .content-text { white-space: pre-wrap; }

    .content-instructions {
      margin: 0;
      padding: 0 0 0 10px;
      color: #2c2c33;
      font-style: italic;
      line-height: 1.55;
      white-space: pre-wrap;
    }

    .content-pills { display: flex; flex-wrap: wrap; gap: 5px; }
    .content-pill {
      display: inline-flex;
      align-items: center;
      height: 22px;
      padding: 0 9px;
      border-radius: 999px;
      border: 1px solid #d6d6db;
      background: #fff;
      font-size: 11px;
      color: #1f1f24;
    }
    .content-pill.app {
      background: rgba(52, 199, 89, 0.08);
      border-color: rgba(52, 199, 89, 0.25);
      color: #1d6f3a;
    }

    ul.content-list { margin: 0; padding: 0; list-style: none; }
    ul.content-list li {
      padding: 5px 0;
      border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }
    ul.content-list li:last-child { border-bottom: none; }
    ul.content-allergies li {
      color: #b91c2a;
      padding-left: 14px;
      position: relative;
    }
    ul.content-allergies li::before {
      content: '';
      width: 6px; height: 6px;
      border-radius: 50%;
      background: #b91c2a;
      position: absolute;
      left: 0; top: 11px;
    }

    .content-projects { display: flex; flex-direction: column; gap: 5px; }
    .content-proj {
      display: flex;
      flex-direction: column;
      padding: 6px 9px;
      border: 1px solid #ececf0;
      border-radius: 6px;
      background: #fff;
    }
    .content-proj-slug { font-size: 12px; font-weight: 500; color: #0d0d12; }
    .content-proj-desc { font-size: 11px; color: #6b6b70; margin-top: 1px; }

    .content-bio-name { font-size: 15px; font-weight: 500; color: #0d0d12; line-height: 1.2; letter-spacing: -0.005em; }
    .content-bio-sub { font-size: 11px; color: #6b6b70; margin-top: 2px; }
    .content-bio-about { margin: 8px 0 0; font-size: 12px; color: #2c2c33; line-height: 1.55; white-space: pre-wrap; }

    /* ── Empty / loading states ────────────────────────────────────── */

    .empty {
      padding: 18px 14px;
      border: 1px dashed #d6d6db;
      border-radius: 10px;
      background: rgba(0, 0, 0, 0.015);
      font-size: 12px;
      color: #6b6b70;
      text-align: center;
      line-height: 1.5;
    }
    .empty-loading {
      padding: 30px 14px;
      text-align: center;
      color: #9090a0;
      font-size: 12px;
    }

    /* ── Dark mode ──────────────────────────────────────────────────── */

    @media (prefers-color-scheme: dark) {
      .title { color: rgba(255, 255, 255, 0.55); }
      .count { background: rgba(255, 255, 255, 0.08); color: rgba(255, 255, 255, 0.65); }
      .hint { color: rgba(255, 255, 255, 0.35); }

      .card {
        background: #1c1c20;
        border-color: rgba(255, 255, 255, 0.14);
        color: #f0f0f3;
      }
      .card:hover { border-color: rgba(255, 255, 255, 0.5); }
      .icon { color: rgba(255, 255, 255, 0.55); }
      .label { color: #f0f0f3; }
      .preview { color: rgba(255, 255, 255, 0.55); }

      .send { background: #fff; color: #1f1f24; }
      .send:hover { background: #f0f0f3; }

      .content {
        background: rgba(255, 255, 255, 0.03);
        border-color: rgba(255, 255, 255, 0.1);
        color: rgba(255, 255, 255, 0.85);
      }
      .content-pill {
        background: rgba(255, 255, 255, 0.06);
        border-color: rgba(255, 255, 255, 0.14);
        color: #f0f0f3;
      }
      .content-pill.app {
        background: rgba(52, 199, 89, 0.14);
        border-color: rgba(52, 199, 89, 0.3);
        color: #65d38f;
      }
      ul.content-list li { border-bottom-color: rgba(255, 255, 255, 0.06); }
      ul.content-allergies li { color: #ff8a8a; }
      ul.content-allergies li::before { background: #ff8a8a; }
      .content-proj { background: rgba(255, 255, 255, 0.04); border-color: rgba(255, 255, 255, 0.08); }
      .content-proj-slug { color: #fff; }
      .content-proj-desc { color: rgba(255, 255, 255, 0.6); }
      .content-bio-name { color: #fff; }
      .content-bio-sub { color: rgba(255, 255, 255, 0.5); }
      .content-bio-about { color: rgba(255, 255, 255, 0.85); }
      .content-instructions { color: rgba(255, 255, 255, 0.85); }

      .empty {
        border-color: rgba(255, 255, 255, 0.12);
        background: rgba(255, 255, 255, 0.02);
        color: rgba(255, 255, 255, 0.55);
      }
    }
  `;F([v({type:String})],y.prototype,"domain",2);F([l()],y.prototype,"cards",2);F([l()],y.prototype,"prefs",2);F([l()],y.prototype,"loaded",2);F([l()],y.prototype,"expandedType",2);F([l()],y.prototype,"leavingTypes",2);y=F([m("ext-card-hub")],y);function xe(e){const t=(e.content||"").replace(/\s+/g," ").trim();return t.length>80?t.slice(0,78)+"…":t}function ye(e){const t={biography:'<svg viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="6" r="3"/><path d="M2 14c0-3.3 2.7-6 6-6s6 2.7 6 6v.5H2V14z"/></svg>',projects:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2" y="3" width="12" height="10" rx="1.5"/><path d="M5 6h6 M5 9h6 M5 12h3"/></svg>',interests:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M8 13.5L2.5 8a3.5 3.5 0 0 1 5-5L8 3.5 8.5 3a3.5 3.5 0 0 1 5 5L8 13.5z"/></svg>',instructions:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M4 3v10 M4 3l4 4-4 4 M9 13h3"/></svg>',allergies:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M8 2L14 13H2L8 2z"/><path d="M8 7v3 M8 11.5v0"/></svg>',"connected-apps":'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2" y="2" width="5" height="5" rx="1"/><rect x="9" y="2" width="5" height="5" rx="1"/><rect x="2" y="9" width="5" height="5" rx="1"/><rect x="9" y="9" width="5" height="5" rx="1"/></svg>',calendar:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2" y="3" width="12" height="11" rx="1.5"/><path d="M2 6h12 M5 1.5v3 M11 1.5v3"/></svg>',memory:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M8 3a4 4 0 0 0-4 4v1a3 3 0 0 0 3 3h2a3 3 0 0 0 3-3V7a4 4 0 0 0-4-4z"/><path d="M8 11v3"/></svg>',preferences:'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M3 5h10 M3 8h7 M3 11h10"/><circle cx="11" cy="5" r="1.5"/><circle cx="8" cy="8" r="1.5"/><circle cx="11" cy="11" r="1.5"/></svg>',identity:'<svg viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="6" r="3"/><path d="M2 14c0-3.3 2.7-6 6-6s6 2.7 6 6v.5H2V14z"/></svg>'},r=document.createElement("span");return r.innerHTML=t[e]??t.identity,r}var we=Object.defineProperty,ke=Object.getOwnPropertyDescriptor,x=(e,t,r,a)=>{for(var s=a>1?void 0:a?ke(t,r):t,n=e.length-1,o;n>=0;n--)(o=e[n])&&(s=(a?o(t,r,s):o(s))||s);return a&&s&&we(t,r,s),s};let u=class extends b{constructor(){super(...arguments),this.profile=null,this.domain="",this.saved=!1,this.memoryDoc="",this.name="",this.occupation="",this.location="",this.bio="",this.interests=""}firstUpdated(){this.loadFromProfile()}updated(e){e.has("profile")&&this.loadFromProfile()}loadFromProfile(){var t,r,a;const e=((t=this.profile)==null?void 0:t.identity)??{};this.name=e.name??"",this.occupation=e.occupation??"",this.location=e.location??"",this.bio=e.bio??"",this.interests=((r=e.interests)==null?void 0:r.join(", "))??"",this.memoryDoc=((a=this.profile)==null?void 0:a.memoryDocument)??""}async saveProfile(){var t;const e={identity:{...((t=this.profile)==null?void 0:t.identity)??{},name:this.name||void 0,occupation:this.occupation||void 0,location:this.location||void 0,bio:this.bio||void 0,interests:this.interests?this.interests.split(",").map(r=>r.trim()).filter(Boolean):void 0},memoryDocument:this.memoryDoc};await chrome.runtime.sendMessage({type:"save-profile",payload:e}),this.profile=e,this.saved=!0,setTimeout(()=>{this.saved=!1},1800)}handleFileImport(e){var a;const t=(a=e.target.files)==null?void 0:a[0];if(!t)return;const r=new FileReader;r.onload=()=>{typeof r.result=="string"&&(this.memoryDoc=r.result,this.saveProfile())},r.readAsText(t)}render(){return i`
      <div class="section">
        <p class="section-title">Identity</p>

        <div class="field-row">
          <label>Name</label>
          <input type="text" placeholder="Your name" .value=${this.name}
            @input=${e=>{this.name=e.target.value}}
            @blur=${this.saveProfile} />
        </div>
        <div class="field-row">
          <label>Occupation</label>
          <input type="text" placeholder="e.g. Software engineer" .value=${this.occupation}
            @input=${e=>{this.occupation=e.target.value}}
            @blur=${this.saveProfile} />
        </div>
        <div class="field-row">
          <label>Location</label>
          <input type="text" placeholder="e.g. Sydney, Australia" .value=${this.location}
            @input=${e=>{this.location=e.target.value}}
            @blur=${this.saveProfile} />
        </div>
        <div class="field-row">
          <label>Interests (comma-separated)</label>
          <input type="text" placeholder="e.g. cycling, design, espresso" .value=${this.interests}
            @input=${e=>{this.interests=e.target.value}}
            @blur=${this.saveProfile} />
        </div>
        <div class="field-row">
          <label>Short bio</label>
          <textarea placeholder="A short description of who you are…" .value=${this.bio}
            @input=${e=>{this.bio=e.target.value}}
            @blur=${this.saveProfile}></textarea>
        </div>
      </div>

      <div class="section">
        <p class="section-title">Memory Document</p>
        <textarea class="memory-doc"
          placeholder="Paste your agent memory, preferences, or any notes you want AI models to know about you…"
          .value=${this.memoryDoc}
          @input=${e=>{this.memoryDoc=e.target.value}}
          @blur=${this.saveProfile}
        ></textarea>

        <div class="memory-actions">
          <label>
            <button class="import-btn" @click=${()=>{var e;return(e=this.renderRoot.querySelector("input[type=file]"))==null?void 0:e.click()}}>
              Import file (.md / .txt)
            </button>
            <input type="file" accept=".md,.txt,text/plain,text/markdown"
              @change=${this.handleFileImport} />
          </label>
          <button class="import-btn" @click=${this.pasteMem}>
            Paste from clipboard
          </button>
        </div>

        <div class="save-indicator">${this.saved?"Saved ✓":""}</div>
      </div>
    `}async pasteMem(){try{const e=await navigator.clipboard.readText();e&&(this.memoryDoc=e,await this.saveProfile())}catch{}}};u.styles=f`
    :host {
      display: block;
      animation: fadeUp 0.22s cubic-bezier(0.25, 0.1, 0.25, 1);
    }
    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(4px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    .section {
      padding: 16px 20px;
      border-bottom: 1px solid #f0f0f0;
    }
    .section-title {
      font-size: 11px;
      font-weight: 600;
      color: #9ca3af;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      margin: 0 0 12px;
    }
    .field-row {
      display: flex;
      flex-direction: column;
      gap: 4px;
      margin-bottom: 10px;
    }
    .field-row:last-child { margin-bottom: 0; }
    label {
      font-size: 11px;
      font-weight: 500;
      color: #6b7280;
    }
    input[type="text"], textarea {
      width: 100%;
      box-sizing: border-box;
      padding: 8px 10px;
      font-size: 13px;
      border: 1.5px solid #e5e7eb;
      border-radius: 7px;
      background: #fafafa;
      color: #1a1a1a;
      font-family: inherit;
      outline: none;
      resize: vertical;
      transition: border-color 0.15s;
    }
    input[type="text"]:focus, textarea:focus {
      border-color: #586675;
      background: #fff;
    }
    textarea { min-height: 80px; }
    textarea.memory-doc { min-height: 160px; font-family: 'SF Mono', 'Fira Code', monospace; font-size: 12px; line-height: 1.6; }

    .memory-actions {
      display: flex;
      gap: 8px;
      margin-top: 10px;
    }
    .import-btn {
      flex: 1;
      padding: 8px;
      font-size: 12px;
      font-weight: 500;
      border: 1.5px solid #e5e7eb;
      border-radius: 7px;
      background: #fff;
      color: #374151;
      cursor: pointer;
      transition: border-color 0.15s, background 0.15s;
    }
    .import-btn:hover {
      border-color: #586675;
      background: #f8f9fa;
    }
    .save-indicator {
      font-size: 11px;
      color: #34c759;
      height: 16px;
      text-align: right;
      margin-top: 4px;
    }
    input[type="file"] { display: none; }
  `;x([v({attribute:!1})],u.prototype,"profile",2);x([v({type:String})],u.prototype,"domain",2);x([l()],u.prototype,"saved",2);x([l()],u.prototype,"memoryDoc",2);x([l()],u.prototype,"name",2);x([l()],u.prototype,"occupation",2);x([l()],u.prototype,"location",2);x([l()],u.prototype,"bio",2);x([l()],u.prototype,"interests",2);u=x([m("profile-tab")],u);var $e=Object.defineProperty,Ee=Object.getOwnPropertyDescriptor,d=(e,t,r,a)=>{for(var s=a>1?void 0:a?Ee(t,r):t,n=e.length-1,o;n>=0;n--)(o=e[n])&&(s=(a?o(t,r,s):o(s))||s);return a&&s&&$e(t,r,s),s};const Fe=`Transform this entire page into GLORIOUS MAOIST CHINESE AESTHETIC. This should be visually striking and funny.

CSS — apply all of these:
- Import font: @import url('https://fonts.googleapis.com/css2?family=Ma+Shan+Zheng&display=swap')
- Apply Ma Shan Zheng to body and all text elements
- Background: deep revolutionary red (#8b0000) with dark sections (#1a0000)
- All text: gold (#ffd700) or bright yellow-gold
- Headings: add ★ before and after using ::before and ::after pseudo-elements (content: '★ ' and ' ★')
- Buttons and CTAs: red background (#cc0000), gold border (2px solid #ffd700), gold text
- Links: gold color, no underline, red on hover
- Borders and dividers: gold (#ffd700) at 40% opacity
- Add a fixed bottom-right watermark: '为人民服务' in 22px gold Ma Shan Zheng font, z-index 9999, opacity 0.8
- Navigation: dark red background, gold text, gold bottom border
- Cards and panels: dark red background (#3d0000), gold border

DOM mutations — replace text content in key elements:
- Any button or link that says "Buy", "Purchase", "Checkout" → "Requisition for the People"
- Any element that says "Add to Cart" → "Contribute to the Collective"
- Any element with "Sale" → "Party Allocation"
- Any element with "Subscribe" → "Pledge Allegiance"
- Any element with "Login" or "Sign in" → "Report to Command"
- Any element with "Premium" → "Vanguard Tier"
- Insert a propaganda banner after the main heading: a red div with gold text reading "SERVE THE PEOPLE · 为人民服务 · THE REVOLUTION IS NOT A DINNER PARTY"

Make it genuinely funny and visually coherent. Lean hard into the aesthetic.`;let c=class extends b{constructor(){super(...arguments),this.authState=null,this.loading=!0,this.domain="",this.category="unknown",this.chatbotDetected=!1,this.manifest=null,this.profile=null,this.previewPrompt="",this.statusMessage="",this.statusType="",this.sharing=!1,this.autoInjectEnabled=!0,this.instructions="",this.instructionsDirty=!1,this.instructionsSaving=!1,this.activeTab="webpaper",this.webpaperPrompt="",this.webpaperRunning=!1,this.webpaperReview=null,this.userInstructions="",this.preFillEnabled=!0,this.deepPersonalisationEnabled=!1,this.autoCleanEnabled=!1,this.alwaysOn=!1,this.preferenceMode="combined",this.revealedStats=null,this.revealedSummary="",this.cfgEnabled=!0,this.cfgActiveBrain="claude",this.cfgMediaPreferences="",this.mediaPrefsDirty=!1,this.profileProvider=null,this._reviewListener=null}connectedCallback(){super.connectedCallback(),this.init(),this.addEventListener("authenticated",()=>this.init()),this._reviewListener=e=>{if((e==null?void 0:e.type)==="webpaper-review"&&e.payload){const t=e.payload;this.webpaperReview=t,this.webpaperRunning=!1,this.activeTab!=="webpaper"&&(this.activeTab="webpaper")}},chrome.runtime.onMessage.addListener(this._reviewListener)}disconnectedCallback(){super.disconnectedCallback(),this._reviewListener&&chrome.runtime.onMessage.removeListener(this._reviewListener),this.webpaperPrompt&&chrome.storage.local.set({srf_wp_prompt:this.webpaperPrompt})}async init(){var p,h,w,B,D;const e=await chrome.runtime.sendMessage({type:"get-auth-state"});this.authState=(e==null?void 0:e.payload)??null;const[t]=await chrome.tabs.query({active:!0,currentWindow:!0});if(t!=null&&t.url)try{const g=new URL(t.url);this.domain=g.hostname.replace(/^www\./,""),this.category=Q(this.domain)}catch{this.domain=""}if(t!=null&&t.id)try{const[g]=await chrome.scripting.executeScript({target:{tabId:t.id},func:()=>!!document.getElementById("surface-overlay-root")});this.chatbotDetected=(g==null?void 0:g.result)??!1}catch{this.chatbotDetected=!1}this.activeTab="webpaper";const r=await chrome.storage.local.get(["srf_enabled","srf_active_brain","srf_media_preferences","srf_profile_provider","srf_user_instructions","srf_prefill_enabled","srf_deep_personalisation","srf_auto_clean","srf_polish_always_on","srf_wp_prompt","srf_last_review"]);this.cfgEnabled=r.srf_enabled===!0,this.alwaysOn=this.cfgEnabled,this.cfgActiveBrain=r.srf_active_brain??"claude",this.cfgMediaPreferences=r.srf_media_preferences??"",this.profileProvider=r.srf_profile_provider??null,this.userInstructions=r.srf_user_instructions??"",this.preFillEnabled=r.srf_prefill_enabled!==!1,this.deepPersonalisationEnabled=r.srf_deep_personalisation===!0,this.autoCleanEnabled=r.srf_auto_clean===!0,this.alwaysOn=r.srf_polish_always_on===!0,r.srf_wp_prompt&&!this.webpaperPrompt&&(this.webpaperPrompt=r.srf_wp_prompt??""),r.srf_last_review&&!this.webpaperReview&&(this.webpaperReview=r.srf_last_review);const a=await chrome.runtime.sendMessage({type:"get-profile"});this.profile=(a==null?void 0:a.payload)??null,this.instructions=((h=(p=this.profile)==null?void 0:p.identity)==null?void 0:h.instructions)??"";const s=await chrome.runtime.sendMessage({type:"get-preference-mode"});this.preferenceMode=((w=s==null?void 0:s.payload)==null?void 0:w.mode)??"combined";const n=await chrome.runtime.sendMessage({type:"get-revealed-stats"});this.revealedStats=(n==null?void 0:n.payload)??null;const o=await chrome.runtime.sendMessage({type:"get-revealed-summary"});if(this.revealedSummary=((B=o==null?void 0:o.payload)==null?void 0:B.summary)??"",t!=null&&t.id)try{const g=await chrome.tabs.sendMessage(t.id,{type:"get-armed-state"});this.autoInjectEnabled=(g==null?void 0:g.armed)??!0}catch{this.autoInjectEnabled=!0}if(this.loading=!1,(D=this.authState)!=null&&D.Surfaced)try{const g=await chrome.runtime.sendMessage({type:"onboarding-get-state"}),A=g==null?void 0:g.payload;if(A&&!A.completed&&!A.startedAt){const X=chrome.runtime.getURL("src/onboarding/onboarding.html");chrome.tabs.create({url:X})}}catch{}}async setPreferenceMode(e){var r;this.preferenceMode=e,await chrome.runtime.sendMessage({type:"set-preference-mode",payload:{mode:e}});const t=await chrome.runtime.sendMessage({type:"get-revealed-summary"});this.revealedSummary=((r=t==null?void 0:t.payload)==null?void 0:r.summary)??""}_updateDialSlider(){var a,s;const e=(a=this.shadowRoot)==null?void 0:a.getElementById("pref-dial-track"),t=(s=this.shadowRoot)==null?void 0:s.getElementById("pref-dial-slider");if(!e||!t)return;const r=e.querySelector(".pref-dial-option.active");if(!r){t.style.width="0";return}t.style.left=`${r.offsetLeft}px`,t.style.width=`${r.offsetWidth}px`}updated(){this._updateDialSlider()}async saveInstructions(){if(!this.instructionsDirty)return;this.instructionsSaving=!0;const e=await chrome.runtime.sendMessage({type:"save-instructions",payload:{instructions:this.instructions}});this.instructionsSaving=!1,e!=null&&e.success?this.instructionsDirty=!1:(this.statusMessage=`Failed to save: ${(e==null?void 0:e.error)??"unknown error"}`,this.statusType="error")}async handleAutoInjectToggle(){this.autoInjectEnabled=!this.autoInjectEnabled,await chrome.runtime.sendMessage({type:"set-auto-inject",payload:{domain:this.domain,enabled:this.autoInjectEnabled}});const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(e!=null&&e.id)try{await chrome.tabs.sendMessage(e.id,{type:"auto-inject-toggled",payload:{domain:this.domain,enabled:this.autoInjectEnabled}})}catch{}}async handleShare(){var s,n,o;this.statusMessage="",this.statusType="",this.sharing=!0;const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(e!=null&&e.id)){this.sharing=!1;return}const t=await chrome.runtime.sendMessage({type:"get-meta-prompt",payload:{hostname:this.domain,category:this.category}});if(!((s=t==null?void 0:t.payload)!=null&&s.prompt)){this.statusMessage="Failed to generate profile context",this.statusType="error",this.sharing=!1;return}this.previewPrompt=t.payload.prompt;const r=async()=>chrome.tabs.sendMessage(e.id,{type:"inject-prompt",payload:{prompt:t.payload.prompt}});let a;try{a=await r()}catch{try{const h=((o=(n=chrome.runtime.getManifest().content_scripts)==null?void 0:n[0])==null?void 0:o.js)??[];if(h.length===0)throw new Error("no content_scripts in manifest");await chrome.scripting.executeScript({target:{tabId:e.id},files:h}),await new Promise(w=>setTimeout(w,300)),a=await r()}catch(p){const h=p instanceof Error?p.message:String(p);this.statusMessage=`Could not load content script: ${h}`,this.statusType="error",this.sharing=!1;return}}if(a!=null&&a.success){if(a!=null&&a.supportsAttachmentCard){const h=navigator.platform.toUpperCase().includes("MAC")?"⌘V":"Ctrl+V";this.statusMessage=`Injected. Press ${h} in the chat for an attachment card.`}else this.statusMessage="Profile shared";this.statusType="success"}else{const p=(a==null?void 0:a.error)??"unknown reason";this.statusMessage=`Could not inject: ${p}`,this.statusType="error"}this.sharing=!1}async handleReplayTour(){await chrome.runtime.sendMessage({type:"onboarding-reset"});const e=chrome.runtime.getURL("src/onboarding/onboarding.html");chrome.tabs.create({url:e})}async handleSignOut(){await chrome.runtime.sendMessage({type:"sign-out"}),this.authState=null,this.manifest=null,this.profileProvider=null,this.activeTab="brain"}async toggleMasterSwitch(){this.cfgEnabled=!this.cfgEnabled,this.alwaysOn=this.cfgEnabled,await chrome.storage.local.set({srf_enabled:this.cfgEnabled}),await chrome.runtime.sendMessage({type:"polish-set-always-on",payload:{enabled:this.alwaysOn}});const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(e!=null&&e.id)try{await chrome.tabs.sendMessage(e.id,{type:"auto-inject-toggled",payload:{domain:this.domain,enabled:this.cfgEnabled&&this.autoInjectEnabled}})}catch{}}async selectBrain(e){this.cfgActiveBrain=e,await chrome.storage.local.set({srf_active_brain:e})}getCardStatus(e){var s;const t=e==="gemini"?"google":e,r=((s=this.authState)==null?void 0:s.Surfaced)&&this.profileProvider===t,a=this.cfgActiveBrain===e;return r&&a?i`<span class="brain-card-status active-status">Active</span>`:r?i`<span class="brain-card-status connected-status">Connected</span>`:i`<span class="brain-card-status unlinked-status">Link Account</span>`}async saveMediaPreferences(){if(!this.mediaPrefsDirty)return;await chrome.storage.local.set({srf_media_preferences:this.cfgMediaPreferences}),this.mediaPrefsDirty=!1;const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(e!=null&&e.id)try{await chrome.tabs.sendMessage(e.id,{type:"cards-prefs-changed"})}catch{}}async firePreset(e){if(this.webpaperRunning)return;const[t]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(t!=null&&t.id))return;this.webpaperRunning=!0,chrome.tabs.sendMessage(t.id,{type:"polish-start-manual",payload:{mode:"prompt",fixDescription:e,personalise:!1}}).catch(()=>{});const r=a=>{(a.type==="polish-done"||a.type==="polish-error"||a.type==="webpaper-review")&&(this.webpaperRunning=!1,chrome.runtime.onMessage.removeListener(r))};chrome.runtime.onMessage.addListener(r)}async runWebpaperPrompt(){const e=this.webpaperPrompt.trim();if(!e||this.webpaperRunning)return;const[t]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(t!=null&&t.id))return;this.webpaperRunning=!0,chrome.tabs.sendMessage(t.id,{type:"polish-start-manual",payload:{mode:"prompt",fixDescription:e,personalise:!1}}).catch(()=>{});const r=a=>{(a.type==="polish-done"||a.type==="polish-error")&&(this.webpaperRunning=!1,chrome.runtime.onMessage.removeListener(r))};chrome.runtime.onMessage.addListener(r)}renderWebpaperTab(){const e=this.webpaperReview;return i`
      <div class="wp-prompt-wrap">
        <textarea
          class="wp-prompt"
          placeholder="Tell webpaper what to do…
e.g. 'Add SVG art to the middle of the page'
or 'Change the headline to say Hello World'
or 'Redesign this page in a dark editorial style'"
          .value=${this.webpaperPrompt}
          @input=${t=>{this.webpaperPrompt=t.target.value}}
          @blur=${()=>chrome.storage.local.set({srf_wp_prompt:this.webpaperPrompt})}
          @keydown=${t=>{t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),this.runWebpaperPrompt())}}
        ></textarea>
        <div class="wp-presets">
          <button class="wp-preset-btn" ?disabled=${this.webpaperRunning}
            @click=${()=>void this.firePreset(Fe)}
            title="Turn everything red, gold, and Maoist">
            🌶 Chinese Mode
          </button>
        </div>

        ${this.webpaperRunning?i`<div class="wp-running">running…</div>`:i`<div class="wp-hint">Enter to run · Shift+Enter for new line</div>`}

        ${e?i`
          <div class="wp-review ${e.mode==="clean"?"clean":""}">
            <div class="wp-review-header">
              <span class="wp-review-icon">${e.mode==="clean"?"—":"+"}</span>
              <span class="wp-review-label">${e.mode==="clean"?"what was cleared":"claude's notes"}</span>
              ${e.durationMs>0?i`<span class="wp-review-meta">${(e.durationMs/1e3).toFixed(1)}s${e.cssLen>0?` · ${e.cssLen}ch`:""}${e.mutationCount>0?` · ${e.mutationCount}×`:""}</span>`:""}
            </div>
            <p class="wp-review-text">${e.text}</p>
            <div class="wp-review-footer">
              <button class="wp-review-dismiss" @click=${()=>{this.webpaperReview=null,chrome.storage.local.remove("srf_last_review")}}>dismiss</button>
            </div>
          </div>
        `:""}
      </div>
    `}renderBrainTab(){var t;const e=!((t=this.authState)!=null&&t.Surfaced)||!this.profileProvider;return i`
      <div class="brain-tab">
        <div class="brain-title-section">
          <h3 class="brain-section-title">Active AI Brain</h3>
          <p class="brain-section-desc">Select the brain of the chatbot you are currently prompting. The Meta-Prompt will optimize itself automatically for this LLM.</p>
        </div>

        ${e?i`
          <div class="auth-prompt-banner">
            <span class="auth-prompt-icon">💡</span>
            <div class="auth-prompt-text">
              Link a provider account below using secure OAuth to unlock your profile context, instructions, and settings sync.
            </div>
          </div>
        `:""}

        <div class="brain-grid">
          <!-- Claude Card -->
          <div class="brain-card claude ${this.cfgActiveBrain==="claude"?"active":""}" @click=${()=>this.selectBrain("claude")}>
            <div class="brain-card-header">
              <div class="brain-card-icon claude">${k(q)}</div>
              <span class="brain-card-name">Claude</span>
              ${this.getCardStatus("claude")}
            </div>
            <div class="brain-card-strength">Overall Performance</div>
            <div class="brain-card-detail">Exceptional reasoning, programming, and complex analysis.</div>
          </div>

          <!-- Grok Card -->
          <div class="brain-card grok ${this.cfgActiveBrain==="grok"?"active":""}" @click=${()=>this.selectBrain("grok")}>
            <div class="brain-card-header">
              <div class="brain-card-icon grok">${k(Y)}</div>
              <span class="brain-card-name">Grok</span>
              ${this.getCardStatus("grok")}
            </div>
            <div class="brain-card-strength">Imagine & Twitter</div>
            <div class="brain-card-detail">Real-time Twitter/X insights and creative generation.</div>
          </div>

          <!-- Gemini Card -->
          <div class="brain-card gemini ${this.cfgActiveBrain==="gemini"?"active":""}" @click=${()=>this.selectBrain("gemini")}>
            <div class="brain-card-header">
              <div class="brain-card-icon gemini">${k(U)}</div>
              <span class="brain-card-name">Gemini</span>
              ${this.getCardStatus("gemini")}
            </div>
            <div class="brain-card-strength">Speed & Context</div>
            <div class="brain-card-detail">Lightning-fast processing and ultra-deep context window.</div>
          </div>

          <!-- ChatGPT Card -->
          <div class="brain-card chatgpt ${this.cfgActiveBrain==="chatgpt"?"active":""}" @click=${()=>this.selectBrain("chatgpt")}>
            <div class="brain-card-header">
              <div class="brain-card-icon chatgpt">${k(W)}</div>
              <span class="brain-card-name">ChatGPT</span>
              ${this.getCardStatus("chatgpt")}
            </div>
            <div class="brain-card-strength">DALL-E Images</div>
            <div class="brain-card-detail">Stunning image creations and general helpfulness.</div>
          </div>
        </div>

        <div class="media-section">
          <div class="media-header">
            <span class="media-label">Media Generation Preferences</span>
          </div>
          <textarea
            class="media-textarea"
            placeholder="e.g. cinematic, 8k, photorealistic, vector art, anime style..."
            .value=${this.cfgMediaPreferences}
            @input=${r=>{this.cfgMediaPreferences=r.target.value,this.mediaPrefsDirty=!0}}
            @blur=${()=>this.saveMediaPreferences()}
          ></textarea>
          <div class="media-hint">
            Saved automatically. Guides images & video creation constraints across models.
          </div>
        </div>
      </div>
    `}render(){var e,t,r;return this.loading?i`<div class="loading"><span class="spinner"></span></div>`:!((e=this.authState)!=null&&e.Surfaced)||!((t=this.authState)!=null&&t.loggedIn)?i`<ext-auth @authenticated=${()=>this.init()}></ext-auth>`:i`
      <div class="header">
        <a class="brand" href="https://webpaper.app" target="_blank" rel="noopener">
          ${k(G)}
          <span class="beta-badge">beta 0.0.1</span>
        </a>
        <div class="header-actions">
          <div class="master-toggle ${this.cfgEnabled?"active":""}" @click=${this.toggleMasterSwitch} role="switch" aria-checked="${this.cfgEnabled}">
            <div class="master-toggle-slider"></div>
            <span class="master-toggle-label ${this.cfgEnabled?"":"active"}">Off</span>
            <span class="master-toggle-label ${this.cfgEnabled?"active":""}">On</span>
          </div>
          ${(r=this.authState)!=null&&r.Surfaced?i`
            <button class="sign-out" @click=${this.handleSignOut}>Sign out</button>
          `:""}
        </div>
      </div>

      <div class="site-info">
        <div class="site-domain">${this.domain||"No site"}</div>
        <div class="site-status">
          ${this.chatbotDetected?i`<span class="dot green"></span> Chatbot detected <span class="category-badge">${this.category}</span>`:i`<span class="dot gray"></span> No chatbot detected`}
        </div>
      </div>

      <ext-clean-action .domain=${this.domain} .alwaysOn=${this.alwaysOn}></ext-clean-action>

      <div class="tabs">
        <button
          class="tab ${this.activeTab==="webpaper"?"active":""}"
          @click=${()=>this.activeTab="webpaper"}
        >Webpaper</button>
        <button
          class="tab ${this.activeTab==="brain"?"active":""}"
          @click=${()=>this.activeTab="brain"}
        >Brain</button>
        <button
          class="tab ${this.activeTab==="settings"?"active":""}"
          @click=${()=>this.activeTab="settings"}
        >Settings</button>
      </div>

      ${this.activeTab==="webpaper"?this.renderWebpaperTab():this.activeTab==="brain"?this.renderBrainTab():this.renderSettingsTab()}

      <div class="footer">
        <a href="https://webpaper.app/me" target="_blank">Manage profile</a>
        <span class="sep">|</span>
        <a href="https://webpaper.app" target="_blank">webpaper.app</a>
      </div>
    `}renderSettingsTab(){return i`
      <div class="settings-section">
        <div class="settings-label">About you</div>
        <textarea
          class="instructions-textarea"
          rows="5"
          placeholder="Tell webpaper who you are. Name, interests, occupation, preferences, anything you want pages and AI to know about you. The more specific, the better the personalization."
          .value=${this.userInstructions}
          @input=${e=>{this.userInstructions=e.target.value}}
          @blur=${()=>chrome.storage.local.set({srf_user_instructions:this.userInstructions})}
        ></textarea>
        <div class="instructions-hint">Saved automatically. Used for personalisation and AI context.</div>
      </div>

      <div class="settings-section">
        <div class="settings-label">Page behaviour</div>

        <div class="settings-row">
          <div class="settings-row-info">
            <div class="settings-row-title">Pre-fill</div>
            <div class="settings-row-desc">Auto-inject your name, email, and details into form fields</div>
          </div>
          <label class="ios-toggle">
            <input type="checkbox" .checked=${this.preFillEnabled}
              @change=${e=>{this.preFillEnabled=e.target.checked,chrome.storage.local.set({srf_prefill_enabled:this.preFillEnabled})}} />
            <span class="ios-toggle-track"></span>
            <span class="ios-toggle-thumb"></span>
          </label>
        </div>

        <div class="settings-row">
          <div class="settings-row-info">
            <div class="settings-row-title">Deep personalisation</div>
            <div class="settings-row-desc">Rewrite page text to use your name and details directly</div>
          </div>
          <label class="ios-toggle">
            <input type="checkbox" .checked=${this.deepPersonalisationEnabled}
              @change=${e=>{this.deepPersonalisationEnabled=e.target.checked,chrome.storage.local.set({srf_deep_personalisation:this.deepPersonalisationEnabled})}} />
            <span class="ios-toggle-track"></span>
            <span class="ios-toggle-thumb"></span>
          </label>
        </div>

        <div class="settings-row">
          <div class="settings-row-info">
            <div class="settings-row-title">Clean mode</div>
            <div class="settings-row-desc">Automatically strip ads, cookie banners, and spam on every page</div>
          </div>
          <label class="ios-toggle">
            <input type="checkbox" .checked=${this.autoCleanEnabled}
              @change=${e=>{this.autoCleanEnabled=e.target.checked,chrome.storage.local.set({srf_auto_clean:this.autoCleanEnabled})}} />
            <span class="ios-toggle-track"></span>
            <span class="ios-toggle-thumb"></span>
          </label>
        </div>
      </div>

      <ext-experimental .domain=${this.domain}></ext-experimental>
    `}renderPreferenceDial(){const e=this.preferenceMode,t=this.revealedStats,r=t&&t.totalFires>=3;return i`
      <div class="pref-dial">
        <div class="pref-dial-header">
          <span class="pref-dial-label">Preferences</span>
          <span class="pref-dial-hint">What gets injected</span>
        </div>

        <div class="pref-dial-track" id="pref-dial-track" role="radiogroup" aria-label="Preference mode">
          <span class="pref-dial-slider" id="pref-dial-slider"></span>
          <button
            class="pref-dial-option ${e==="stated"?"active":""}"
            @click=${()=>this.setPreferenceMode("stated")}
            role="radio"
            aria-checked=${e==="stated"}
          >Stated</button>
          <button
            class="pref-dial-option ${e==="combined"?"active":""}"
            @click=${()=>this.setPreferenceMode("combined")}
            role="radio"
            aria-checked=${e==="combined"}
          >Both</button>
          <button
            class="pref-dial-option ${e==="anon"?"active":""}"
            @click=${()=>this.setPreferenceMode("anon")}
            role="radio"
            aria-checked=${e==="anon"}
          >Anon</button>
          <button
            class="pref-dial-option ${e==="off"?"active":""}"
            @click=${()=>this.setPreferenceMode("off")}
            role="radio"
            aria-checked=${e==="off"}
          >Off</button>
        </div>

        ${e==="combined"?i`
              <div class="revealed-preview">
                ${r?this.revealedSummary?this.revealedSummary:i`<span class="revealed-preview-empty">Still learning — keep using chatbots and we'll refine this.</span>`:i`<span class="revealed-preview-empty">Not enough activity yet. The summary appears after ${3-((t==null?void 0:t.totalFires)??0)} more profile shares.</span>`}
                ${t&&t.totalFires>0?i`
                      <div class="revealed-stats-row">
                        <span><strong>${t.totalFires}</strong> fires</span>
                        <span><strong>${t.uniqueHosts}</strong> sites</span>
                        ${t.spanDays>0?i`<span><strong>${t.spanDays}</strong> d span</span>`:""}
                      </div>
                    `:""}
              </div>
            `:e==="stated"?i`<div class="revealed-preview"><span class="revealed-preview-empty">Only your typed profile (bio, instructions) will be shared. Observed behavior is ignored.</span></div>`:e==="anon"?i`<div class="revealed-preview"><span class="revealed-preview-empty">Anonymous mode. Only explicit instructions are shared — no name, email, or personal info. Ad blocking and third-party cookie blocking are active.</span></div>`:i`<div class="revealed-preview"><span class="revealed-preview-empty">Profile injection is fully disabled. Your messages send without any Webpaper context.</span></div>`}
      </div>
    `}};c.styles=f`
    :host {
      display: block;
      width: 360px;
      background: transparent;
      color: var(--srf-text, #363636);
      font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', sans-serif;
    }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(4px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    /* ── Header ── */

    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 14px 20px;
      border-bottom: 1px solid var(--srf-border-inner, #E5E5EA);
    }

    /* The brand is the canonical 156×33 lockup SVG, sized to 20px tall per
     * surface's .nav-logo rule. Rendered inside an <a> so clicking it
     * opens surface. No box, no border, no label — the lockup IS the
     * label. */
    .brand {
      display: flex;
      align-items: center;
      text-decoration: none;
      color: inherit;
    }

    .brand svg {
      height: 20px;
      width: auto;
      display: block;
    }

    .beta-badge {
      margin-left: 7px;
      font-size: 9px;
      font-weight: 600;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      color: #e79bb6;
      border: 1px solid rgba(231, 155, 182, 0.4);
      border-radius: 999px;
      padding: 1px 6px;
      white-space: nowrap;
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    /* ── Sign out — utility button, ghost hover (border+text only, no fill) ── */

    .sign-out {
      background: transparent;
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: var(--srf-radius-sm, 4px);
      color: var(--srf-text-secondary, #6B6B70);
      font-size: 11px;
      font-weight: 400;
      cursor: pointer;
      font-family: inherit;
      padding: 4px 10px;
      transition: border-color 0.2s ease, color 0.2s ease;
    }

    .sign-out:hover {
      border-color: var(--srf-border, #9E9E9E);
      color: #000;
    }

    /* ── Tabs ── */

    .tabs {
      display: flex;
      border-bottom: 1px solid var(--srf-border-inner, #E5E5EA);
    }

    .tab {
      flex: 1;
      padding: 10px 0;
      background: transparent;
      border: none;
      border-bottom: 1px solid transparent;
      font-size: 13px;
      font-weight: 400;
      font-family: inherit;
      color: var(--srf-text-inactive, rgba(0, 0, 0, 0.35));
      cursor: pointer;
      transition: color 0.2s ease, border-color 0.2s ease;
    }

    .tab:hover {
      color: var(--srf-text, #363636);
    }

    .tab.active {
      color: var(--srf-text-interactive, #000);
      border-bottom-color: #000;
    }

    /* ── Site info ── */

    .site-info {
      padding: 14px 20px;
      border-bottom: 1px solid var(--srf-border-inner, #E5E5EA);
      animation: fadeUp 0.2s var(--srf-ease, cubic-bezier(0.25, 0.1, 0.25, 1));
    }

    .site-domain {
      font-size: 14px;
      font-weight: 400;
      color: var(--srf-text-interactive, #000);
    }

    .site-status {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      font-weight: 400;
      letter-spacing: 0.01em;
      color: var(--srf-text-secondary, #6B6B70);
      margin-top: 4px;
    }

    .site-status .dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      flex-shrink: 0;
    }

    .site-status .dot.green { background: var(--srf-success, #34C759); }
    .site-status .dot.gray { background: var(--srf-text-tertiary, #7A7F88); }

    .category-badge {
      font-size: 11px;
      color: var(--srf-text-secondary, #6B6B70);
      background: transparent;
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: var(--srf-radius-sm, 4px);
      padding: 1px 6px;
      margin-left: 4px;
    }

    /* ── Preference dial ── */

    .pref-dial {
      padding: 14px 20px;
      border-bottom: 1px solid var(--srf-border-inner, #E5E5EA);
      animation: fadeUp 0.2s var(--srf-ease, cubic-bezier(0.25, 0.1, 0.25, 1));
    }

    .pref-dial-header {
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      margin-bottom: 8px;
    }

    .pref-dial-label {
      font-size: 13px;
      font-weight: 400;
      letter-spacing: 0.01em;
      color: var(--srf-text, #363636);
    }

    .pref-dial-hint {
      font-size: 12px;
      font-weight: 400;
      letter-spacing: 0.01em;
      color: var(--srf-text-secondary, #6B6B70);
    }

    /* Sliding pill toggle — canonical .card-toggle pattern from
     * surface landing. Buttons sit on a transparent 8px-rounded
     * track with 3px padding. A separate transparent slider (outlined
     * with --border-color) absolutely positioned underneath animates
     * its left + width independently on 0.25s cubic-bezier(0.4,0,0.2,1).
     * This is the brand's signature interaction. */
    .pref-dial-track {
      position: relative;
      display: flex;
      padding: 3px;
      background: transparent;
      border-radius: var(--srf-radius-lg, 8px);
    }

    .pref-dial-slider {
      position: absolute;
      top: 3px;
      left: 3px;
      height: calc(100% - 6px);
      width: 0;
      background: transparent;
      border: 1px solid var(--srf-border, #9E9E9E);
      border-radius: var(--srf-radius-md, 6px);
      transition: left 0.25s cubic-bezier(0.4, 0, 0.2, 1),
                  width 0.25s cubic-bezier(0.4, 0, 0.2, 1);
      z-index: 0;
      pointer-events: none;
    }

    .pref-dial-option {
      flex: 1;
      position: relative;
      z-index: 1;
      padding: 6px 10px;
      background: transparent;
      border: none;
      border-radius: var(--srf-radius-md, 6px);
      color: rgba(0, 0, 0, 0.35);
      font-size: 12px;
      font-weight: 500;
      letter-spacing: 0.01em;
      font-family: inherit;
      cursor: pointer;
      white-space: nowrap;
      transition: color 0.2s ease;
    }

    .pref-dial-option:hover {
      color: rgba(0, 0, 0, 0.7);
    }

    .pref-dial-option.active {
      color: #000;
    }

    .revealed-preview {
      margin-top: 10px;
      padding: 10px 12px;
      background: var(--srf-bg-input, #F4F4F7);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: var(--srf-radius-md, 6px);
      font-size: 12px;
      color: var(--srf-text-secondary, #6B6B70);
      line-height: 1.5;
    }

    .revealed-preview-empty {
      color: var(--srf-text-tertiary, #7A7F88);
    }

    .revealed-stats-row {
      display: flex;
      gap: 12px;
      margin-top: 6px;
      font-size: 11px;
      color: var(--srf-text-tertiary, #7A7F88);
      font-family: var(--srf-font-mono, 'IBM Plex Mono', ui-monospace, monospace);
    }

    .revealed-stats-row strong {
      color: var(--srf-text-secondary, #6B6B70);
      font-weight: 500;
    }

    /* ── Advanced disclosure (per-site permission toggles) ── */

    .advanced-disclosure {
      border-top: 1px solid var(--srf-border-inner, #E5E5EA);
      border-bottom: 1px solid var(--srf-border-inner, #E5E5EA);
    }

    .advanced-summary {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 12px 20px;
      cursor: pointer;
      list-style: none;
      user-select: none;
      transition: background 0.15s ease;
    }
    .advanced-summary::-webkit-details-marker { display: none; }
    .advanced-summary:hover { background: var(--srf-bg-input, #F4F4F7); }

    .advanced-label {
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--srf-text-tertiary, #7A7F88);
      font-weight: 500;
    }

    .advanced-hint {
      font-size: 12px;
      color: var(--srf-text-secondary, #6B6B70);
      flex: 1;
    }

    .advanced-caret {
      font-size: 16px;
      color: var(--srf-text-tertiary, #7A7F88);
      transition: transform 0.2s ease;
      line-height: 1;
    }
    details[open] .advanced-caret { transform: rotate(90deg); }

    .advanced-body {
      padding: 4px 20px 14px;
      animation: fadeUp 0.2s cubic-bezier(0.25, 0.1, 0.25, 1);
    }

    .advanced-note {
      font-size: 12px;
      color: var(--srf-text-secondary, #6B6B70);
      line-height: 1.5;
      padding: 10px 12px;
      background: var(--srf-bg-input, #F4F4F7);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: 6px;
      margin-bottom: 10px;
    }

    /* ── Instructions ── */

    .instructions-section {
      padding: 14px 20px;
      border-top: 1px solid var(--srf-border-inner, #E5E5EA);
    }

    .instructions-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 8px;
    }

    .instructions-label {
      font-size: 13px;
      font-weight: 400;
      letter-spacing: 0.01em;
      color: var(--srf-text, #363636);
    }

    .instructions-save {
      background: transparent;
      color: var(--srf-text-interactive, #000);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: var(--srf-radius-sm, 4px);
      font-size: 11px;
      font-weight: 400;
      font-family: inherit;
      padding: 4px 10px;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .instructions-save:hover {
      background: #000;
      color: #FFF;
      border-color: #000;
    }

    .instructions-save:disabled {
      opacity: 0.35;
      cursor: not-allowed;
      background: transparent;
      color: var(--srf-text-inactive, rgba(0, 0, 0, 0.35));
      border-color: var(--srf-border-inner, #E5E5EA);
    }

    /* ── Webpaper on/off toggle ── */
    .wp-toggle-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 14px 0 16px;
      border-bottom: 1px solid var(--srf-border-inner, #E5E5EA);
      margin-bottom: 14px;
    }
    .wp-toggle-info { flex: 1; }
    .wp-toggle-label {
      font-size: 14px;
      font-weight: 500;
      color: var(--srf-text, #363636);
      letter-spacing: 0.01em;
    }
    .wp-toggle-desc {
      font-size: 11px;
      color: var(--srf-text-tertiary, #9A9BA0);
      margin-top: 2px;
    }

    /* ── Webpaper review note ── */
    .wp-review {
      margin-top: 12px;
      padding: 14px 16px;
      background: #fff;
      border-radius: 14px;
      border: 1px solid #EBEBEF;
      box-shadow: 0 1px 4px rgba(0,0,0,0.05), 0 0 0 1px rgba(0,0,0,0.03);
      display: flex;
      flex-direction: column;
      gap: 8px;
      animation: reviewIn 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
    }
    @keyframes reviewIn {
      from { opacity: 0; transform: translateY(6px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    .wp-review.clean {
      border-color: #E0EDE8;
      background: #F8FDFB;
    }
    .wp-review-header {
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .wp-review-icon {
      font-size: 12px;
      line-height: 1;
      flex-shrink: 0;
    }
    .wp-review-label {
      font-size: 11px;
      font-family: 'JetBrains Mono', monospace;
      letter-spacing: 0.09em;
      text-transform: uppercase;
      color: #9A9BA0;
      flex: 1;
    }
    .wp-review-meta {
      font-size: 11px;
      color: #B8B9C2;
      font-family: 'JetBrains Mono', monospace;
    }
    .wp-review-text {
      font-size: 13.5px;
      line-height: 1.6;
      color: #2A2A30;
      margin: 0;
      font-style: italic;
    }
    .wp-review-footer {
      display: flex;
      justify-content: flex-end;
    }
    .wp-review-dismiss {
      background: none;
      border: none;
      font-size: 11px;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      color: #C0C0C8;
      cursor: pointer;
      padding: 2px 4px;
      font-family: 'JetBrains Mono', monospace;
      transition: color 0.15s;
    }
    .wp-review-dismiss:hover { color: #7A7A85; }

    /* ── Webpaper prompt bar ── */
    .wp-prompt-wrap {
      display: flex;
      flex-direction: column;
      gap: 10px;
      padding: 14px 20px 16px;
    }
    .wp-prompt {
      width: 100%;
      min-height: 88px;
      padding: 14px 16px;
      border: 1.5px solid var(--srf-border-inner, #E5E5EA);
      border-radius: 16px;
      background: var(--srf-bg-input, #F4F4F7);
      color: var(--srf-text, #363636);
      font-size: 14px;
      font-family: inherit;
      line-height: 1.55;
      resize: none;
      outline: none;
      transition: border-color 0.18s ease, box-shadow 0.18s ease;
      box-sizing: border-box;
    }
    .wp-prompt:focus {
      border-color: #000;
      box-shadow: 0 0 0 3px rgba(0,0,0,0.07);
      background: #fff;
    }
    .wp-prompt::placeholder {
      color: #B8BAC0;
    }
    .wp-hint {
      font-size: 11px;
      color: var(--srf-text-tertiary, #9A9BA0);
      text-align: right;
    }
    .wp-presets {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 8px;
    }
    .wp-preset-btn {
      font-family: inherit;
      font-size: 11px;
      padding: 5px 10px;
      border-radius: 20px;
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      background: transparent;
      color: var(--srf-text-secondary, #6B6B70);
      cursor: pointer;
      transition: all 0.15s ease;
      white-space: nowrap;
    }
    .wp-preset-btn:hover:not(:disabled) {
      border-color: var(--srf-border, #9E9E9E);
      color: var(--srf-text, #363636);
      background: var(--srf-bg-input, #F4F4F7);
    }
    .wp-preset-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .wp-running {
      font-size: 12px;
      color: var(--srf-text-secondary, #6B6B70);
      text-align: center;
      padding: 6px 0;
      animation: wp-pulse 1.4s ease-in-out infinite;
    }
    @keyframes wp-pulse {
      0%, 100% { opacity: 0.5; }
      50% { opacity: 1; }
    }

    /* ── Settings tab ── */
    .settings-section {
      padding: 14px 20px;
      border-bottom: 1px solid var(--srf-border-inner, #E5E5EA);
    }
    .settings-section:last-child { border-bottom: none; }
    .settings-label {
      font-size: 11px;
      font-family: 'JetBrains Mono', monospace;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--srf-text-tertiary, #9A9BA0);
      margin-bottom: 10px;
    }
    .settings-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 10px 0;
      border-top: 1px solid var(--srf-border-inner, #E5E5EA);
    }
    .settings-row:first-of-type { border-top: none; }
    .settings-row-info { flex: 1; }
    .settings-row-title {
      font-size: 13px;
      font-weight: 500;
      color: var(--srf-text, #363636);
      letter-spacing: 0.01em;
    }
    .settings-row-desc {
      font-size: 11px;
      color: var(--srf-text-tertiary, #9A9BA0);
      margin-top: 2px;
      line-height: 1.4;
    }

    .instructions-textarea {
      width: 100%;
      min-height: 64px;
      max-height: 160px;
      background: var(--srf-bg-input, #F4F4F7);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: var(--srf-radius-md, 6px);
      color: var(--srf-text, #363636);
      font-size: 13px;
      font-family: inherit;
      letter-spacing: 0.01em;
      padding: 10px 12px;
      outline: none;
      resize: vertical;
      transition: border-color 0.2s ease;
      line-height: 1.5;
    }

    .instructions-textarea:focus {
      border-color: var(--srf-accent, #007AFF);
    }

    .instructions-textarea::placeholder {
      color: var(--srf-text-tertiary, #7A7F88);
    }

    .instructions-hint {
      font-size: 11px;
      color: var(--srf-text-tertiary, #7A7F88);
      margin-top: 6px;
      line-height: 1.5;
    }

    /* ── Auto-share row ── */

    .auto-share {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 14px 20px;
      border-top: 1px solid var(--srf-border-inner, #E5E5EA);
      gap: 14px;
    }

    .auto-share-info {
      display: flex;
      flex-direction: column;
      gap: 2px;
      flex: 1;
      min-width: 0;
    }

    .auto-share-label {
      font-size: 13px;
      font-weight: 400;
      letter-spacing: 0.01em;
      color: var(--srf-text-interactive, #000);
    }

    .auto-share-desc {
      font-size: 12px;
      font-weight: 400;
      color: var(--srf-text-secondary, #6B6B70);
      line-height: 1.4;
    }

    /* iOS-style toggle — kept for functional clarity, but without the
     * thumb shadow that the brand guide bans. */
    .ios-toggle {
      position: relative;
      width: 40px;
      height: 24px;
      flex-shrink: 0;
      cursor: pointer;
    }

    .ios-toggle input {
      opacity: 0;
      width: 0;
      height: 0;
      position: absolute;
    }

    .ios-toggle-track {
      position: absolute;
      inset: 0;
      background: #D1D1D6;
      border-radius: 12px;
      cursor: pointer;
      transition: background 0.25s var(--srf-ease-toggle, cubic-bezier(0.4, 0, 0.2, 1));
    }

    .ios-toggle input:checked + .ios-toggle-track {
      background: #000;
    }

    .ios-toggle input:disabled + .ios-toggle-track {
      opacity: 0.35;
      cursor: not-allowed;
    }

    .ios-toggle-thumb {
      position: absolute;
      top: 2px;
      left: 2px;
      width: 20px;
      height: 20px;
      background: #FFFFFF;
      border-radius: 50%;
      transition: transform 0.25s var(--srf-ease-toggle, cubic-bezier(0.4, 0, 0.2, 1));
      pointer-events: none;
    }

    .ios-toggle input:checked ~ .ios-toggle-thumb {
      transform: translateX(16px);
    }

    /* ── Footer ── */

    .footer {
      padding: 12px 20px;
      border-top: 1px solid var(--srf-border-inner, #E5E5EA);
      text-align: center;
    }

    .footer a {
      color: var(--srf-text-secondary, #6B6B70);
      font-size: 12px;
      font-weight: 400;
      letter-spacing: 0.01em;
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .footer a:hover {
      color: var(--srf-accent, #007AFF);
    }

    .footer .sep {
      color: var(--srf-border-inner, #E5E5EA);
      margin: 0 6px;
    }

    /* ── Status + loading ── */

    .status-msg {
      padding: 8px 20px;
      font-size: 12px;
      text-align: center;
      animation: fadeUp 0.2s var(--srf-ease, cubic-bezier(0.25, 0.1, 0.25, 1));
    }

    .status-msg.success {
      color: var(--srf-success, #34C759);
    }

    .status-msg.error {
      color: var(--srf-error, #FF3B30);
    }

    .loading {
      padding: 40px 20px;
      text-align: center;
      color: var(--srf-text-tertiary, #7A7F88);
    }

    .spinner {
      display: inline-block;
      width: 16px;
      height: 16px;
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-top-color: var(--srf-text, #363636);
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    /* ── Master Toggle ── */
    .master-toggle {
      display: flex;
      align-items: center;
      background: var(--srf-bg-input, #F4F4F7);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: 12px;
      padding: 2px;
      position: relative;
      cursor: pointer;
      user-select: none;
      width: 130px;
      height: 24px;
      box-sizing: border-box;
    }

    .master-toggle-slider {
      position: absolute;
      top: 1px;
      left: 1px;
      bottom: 1px;
      width: calc(50% - 1px);
      background: #FFFFFF;
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: 10px;
      transition: transform 0.2s cubic-bezier(0.25, 0.1, 0.25, 1);
      z-index: 1;
      pointer-events: none;
    }

    .master-toggle.active .master-toggle-slider {
      transform: translateX(100%);
      border-color: #9E9E9E;
    }

    .master-toggle-label {
      flex: 1;
      text-align: center;
      font-size: 11px;
      font-weight: 500;
      z-index: 2;
      color: rgba(0, 0, 0, 0.35);
      transition: color 0.2s ease;
      line-height: 20px;
    }

    .master-toggle-label.active {
      color: #000000;
      font-weight: 600;
    }

    /* ── Active Brain Tab ── */
    .brain-tab {
      padding: 16px 20px;
      animation: fadeUp 0.2s var(--srf-ease, cubic-bezier(0.25, 0.1, 0.25, 1));
    }

    .brain-title-section {
      margin-bottom: 14px;
      text-align: left;
    }

    .brain-section-title {
      font-size: 13px;
      font-weight: 600;
      color: #000;
      margin: 0 0 3px;
    }

    .brain-section-desc {
      font-size: 11px;
      line-height: 1.4;
      color: var(--srf-text-secondary, #6B6B70);
      margin: 0;
    }

    .brain-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
      margin-bottom: 16px;
    }

    .brain-card {
      background: #FFFFFF;
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: 10px;
      padding: 10px;
      text-align: left;
      cursor: pointer;
      transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
      display: flex;
      flex-direction: column;
      gap: 4px;
      box-sizing: border-box;
    }

    .brain-card:hover {
      border-color: #9E9E9E;
      transform: translateY(-1px);
    }

    .brain-card.active {
      border-width: 1px;
      background: #FFFFFF;
    }

    .brain-card.claude.active {
      border-color: #D97706;
      box-shadow: 0 0 12px rgba(217, 119, 6, 0.25), 0 0 0 1px #D97706;
    }
    .brain-card.grok.active {
      border-color: #000000;
      box-shadow: 0 0 12px rgba(0, 0, 0, 0.25), 0 0 0 1px #000000;
    }
    .brain-card.gemini.active {
      border-color: #4285F4;
      box-shadow: 0 0 12px rgba(66, 133, 244, 0.25), 0 0 0 1px #4285F4;
    }
    .brain-card.chatgpt.active {
      border-color: #10B981;
      box-shadow: 0 0 12px rgba(16, 185, 129, 0.25), 0 0 0 1px #10B981;
    }

    .brain-card-header {
      display: flex;
      align-items: center;
      gap: 6px;
      position: relative;
    }

    .brain-card-icon {
      width: 18px;
      height: 18px;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      font-weight: 600;
      flex-shrink: 0;
    }

    .brain-card-icon.claude { background: #FBF0DF; color: #D97706; }
    .brain-card-icon.grok { background: #000000; color: #FFFFFF; }
    .brain-card-icon.gemini { background: #E8F0FE; color: #4285F4; }
    .brain-card-icon.chatgpt { background: #E6F4EA; color: #10B981; }

    .brain-card-icon svg {
      width: 12px;
      height: 12px;
      display: block;
    }

    .brain-card-name {
      font-size: 12px;
      font-weight: 600;
      color: #1C1C1E;
    }

    .brain-card-status {
      margin-left: auto;
      font-size: 9px;
      font-weight: 600;
      letter-spacing: 0.03em;
      padding: 2px 4px;
      border-radius: 4px;
      text-transform: uppercase;
    }
    
    .brain-card.claude .brain-card-status.active-status { color: #D97706; background: #FBF0DF; }
    .brain-card.grok .brain-card-status.active-status { color: #FFFFFF; background: #000000; }
    .brain-card.gemini .brain-card-status.active-status { color: #4285F4; background: #E8F0FE; }
    .brain-card.chatgpt .brain-card-status.active-status { color: #10B981; background: #E6F4EA; }
    
    .brain-card.claude .brain-card-status.connected-status { color: #D97706; background: rgba(217, 119, 6, 0.08); }
    .brain-card.grok .brain-card-status.connected-status { color: #000000; background: rgba(0, 0, 0, 0.08); }
    .brain-card.gemini .brain-card-status.connected-status { color: #4285F4; background: rgba(66, 133, 244, 0.08); }
    .brain-card.chatgpt .brain-card-status.connected-status { color: #10B981; background: rgba(16, 185, 129, 0.08); }
    
    .brain-card-status.unlinked-status {
      color: var(--srf-text-secondary, #6B6B70);
      background: var(--srf-bg-input, #F4F4F7);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
    }

    .auth-prompt-banner {
      display: flex;
      align-items: flex-start;
      gap: 10px;
      padding: 10px 12px;
      background: rgba(0, 122, 255, 0.04);
      border: 1px solid rgba(0, 122, 255, 0.15);
      border-radius: 8px;
      margin-bottom: 14px;
      text-align: left;
    }
    
    .auth-prompt-icon {
      font-size: 14px;
      line-height: 1;
      margin-top: 1px;
    }
    
    .auth-prompt-text {
      font-size: 11px;
      line-height: 1.4;
      color: var(--srf-text-secondary, #6B6B70);
    }

    .brain-card-strength {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.02em;
      text-transform: uppercase;
      margin-top: 2px;
    }
    .brain-card.claude .brain-card-strength { color: #B45309; }
    .brain-card.grok .brain-card-strength { color: #1C1C1E; }
    .brain-card.gemini .brain-card-strength { color: #1A73E8; }
    .brain-card.chatgpt .brain-card-strength { color: #059669; }

    .brain-card-detail {
      font-size: 11px;
      line-height: 1.4;
      color: var(--srf-text-secondary, #6B6B70);
    }

    /* ── Media Section ── */
    .media-section {
      border-top: 1px solid var(--srf-border-inner, #E5E5EA);
      padding-top: 14px;
      text-align: left;
    }

    .media-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 6px;
    }

    .media-label {
      font-size: 12px;
      font-weight: 500;
      color: var(--srf-text, #363636);
    }

    .media-textarea {
      width: 100%;
      min-height: 48px;
      max-height: 100px;
      background: var(--srf-bg-input, #F4F4F7);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: 6px;
      color: var(--srf-text, #363636);
      font-size: 12px;
      font-family: inherit;
      padding: 6px 8px;
      outline: none;
      resize: vertical;
      transition: border-color 0.2s ease;
      line-height: 1.4;
      box-sizing: border-box;
    }

    .media-textarea:focus {
      border-color: var(--srf-accent, #007AFF);
    }

    .media-textarea::placeholder {
      color: var(--srf-text-tertiary, #7A7F88);
    }

    .media-hint {
      font-size: 11px;
      color: var(--srf-text-tertiary, #7A7F88);
      margin-top: 4px;
      line-height: 1.4;
    }
  `;d([l()],c.prototype,"authState",2);d([l()],c.prototype,"loading",2);d([l()],c.prototype,"domain",2);d([l()],c.prototype,"category",2);d([l()],c.prototype,"chatbotDetected",2);d([l()],c.prototype,"manifest",2);d([l()],c.prototype,"profile",2);d([l()],c.prototype,"previewPrompt",2);d([l()],c.prototype,"statusMessage",2);d([l()],c.prototype,"statusType",2);d([l()],c.prototype,"sharing",2);d([l()],c.prototype,"autoInjectEnabled",2);d([l()],c.prototype,"instructions",2);d([l()],c.prototype,"instructionsDirty",2);d([l()],c.prototype,"instructionsSaving",2);d([l()],c.prototype,"activeTab",2);d([l()],c.prototype,"webpaperPrompt",2);d([l()],c.prototype,"webpaperRunning",2);d([l()],c.prototype,"webpaperReview",2);d([l()],c.prototype,"userInstructions",2);d([l()],c.prototype,"preFillEnabled",2);d([l()],c.prototype,"deepPersonalisationEnabled",2);d([l()],c.prototype,"autoCleanEnabled",2);d([l()],c.prototype,"alwaysOn",2);d([l()],c.prototype,"preferenceMode",2);d([l()],c.prototype,"revealedStats",2);d([l()],c.prototype,"revealedSummary",2);d([l()],c.prototype,"cfgEnabled",2);d([l()],c.prototype,"cfgActiveBrain",2);d([l()],c.prototype,"cfgMediaPreferences",2);d([l()],c.prototype,"mediaPrefsDirty",2);d([l()],c.prototype,"profileProvider",2);c=d([m("srf-popup")],c);
