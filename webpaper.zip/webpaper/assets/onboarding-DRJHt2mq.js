import{i as v,r as c,a as h,o as m,w as g,d as s,t as x}from"./icons-CbjupgSZ.js";import{O as r,S as d,a as u}from"./onboarding-types-BOQBz6-q.js";var b=Object.defineProperty,y=Object.getOwnPropertyDescriptor,l=(e,t,a,n)=>{for(var i=n>1?void 0:n?y(t,a):t,p=e.length-1,f;p>=0;p--)(f=e[p])&&(i=(n?f(t,a,i):f(i))||i);return n&&i&&b(t,a,i),i};let o=class extends h{constructor(){super(...arguments),this.step="welcome",this.onboardingState=null,this.visitedSites=new Set,this.tasteVotes={},this.visitBanner="",this.howItWorksSlide=0}connectedCallback(){super.connectedCallback(),this.loadState()}async loadState(){const e=await chrome.runtime.sendMessage({type:"onboarding-get-state"});if(e!=null&&e.payload){this.onboardingState=e.payload,this.visitedSites=new Set(e.payload.visitedSites??[]),this.tasteVotes=e.payload.tasteVotes??{};const t=e.payload.currentStep??0;t<r.length&&(this.step=r[t])}await chrome.runtime.sendMessage({type:"onboarding-mark-started"})}get stepIndex(){return r.indexOf(this.step)}get progressPct(){return(this.stepIndex+1)/r.length*100}async goToStep(e){this.step=e;const t=r.indexOf(e);await chrome.runtime.sendMessage({type:"onboarding-update-step",payload:{step:t}}),window.scrollTo({top:0,behavior:"smooth"})}next(){const e=this.stepIndex;e<r.length-1&&this.goToStep(r[e+1])}prev(){const e=this.stepIndex;e>0&&this.goToStep(r[e-1])}async visitSite(e){window.open(e.url,"_blank"),this.visitedSites=new Set([...this.visitedSites,e.domain]),await chrome.runtime.sendMessage({type:"onboarding-mark-visited",payload:{domain:e.domain}}),this.visitBanner=`Opened ${e.name} — the Webpaper overlay will guide you there`,setTimeout(()=>{this.visitBanner=""},4e3)}async voteTaste(e,t){if(this.tasteVotes={...this.tasteVotes,[e]:t},await chrome.runtime.sendMessage({type:"onboarding-taste-vote",payload:{domain:e,vote:t}}),t==="love"){const a=d.find(n=>n.domain===e);await chrome.runtime.sendMessage({type:"polish-add-liked-site",payload:{hostname:e,title:a==null?void 0:a.name}})}}async finishOnboarding(){await chrome.runtime.sendMessage({type:"onboarding-complete"}),window.close()}render(){return s`
      <div class="progress">
        <div class="progress-fill" style="width: ${this.progressPct}%"></div>
      </div>

      <div class="page">
        <div class="brand animate-in">${m(g)}</div>
        <div class="step-label animate-in">
          ${this.step==="welcome"?"Welcome":this.step==="how-it-works"?"How it works":this.step==="safari"?`Site safari — ${this.visitedSites.size} of ${d.length} visited`:this.step==="taste"?"Design preferences":"All set"}
        </div>

        ${this.step==="welcome"?this.renderWelcome():this.step==="how-it-works"?this.renderHowItWorks():this.step==="safari"?this.renderSafari():this.step==="taste"?this.renderTaste():this.renderComplete()}

        ${this.step!=="welcome"&&this.step!=="complete"?this.renderNav():""}
      </div>

      ${this.visitBanner?s`
        <div class="visit-banner">
          <span class="visit-banner-dot"></span>
          ${this.visitBanner}
        </div>
      `:""}
    `}renderWelcome(){return s`
      <div class="welcome">
        <h1 class="welcome-title animate-in">Welcome to Webpaper</h1>
        <p class="welcome-subtitle animate-in-delayed">
          Your identity layer for every AI. Stop repeating yourself —
          let's show you how it works and what you like.
        </p>

        <div class="welcome-features animate-in-delayed-2">
          <div class="welcome-feature">
            <div class="welcome-feature-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
              </svg>
            </div>
            <span class="welcome-feature-label">One profile, every AI</span>
          </div>
          <div class="welcome-feature">
            <div class="welcome-feature-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
              </svg>
            </div>
            <span class="welcome-feature-label">Smart category filtering</span>
          </div>
          <div class="welcome-feature">
            <div class="welcome-feature-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>
              </svg>
            </div>
            <span class="welcome-feature-label">CSS Polish for the web</span>
          </div>
          <div class="welcome-feature">
            <div class="welcome-feature-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              </svg>
            </div>
            <span class="welcome-feature-label">Ad block and privacy</span>
          </div>
        </div>

        <div class="animate-in-delayed-3" style="display: flex; flex-direction: column; gap: 12px; align-items: center;">
          <button class="btn-primary" @click=${()=>this.goToStep("how-it-works")}>
            Start the tour
          </button>
          <button class="btn-ghost" @click=${()=>this.goToStep("complete")}>
            Skip — I'll explore on my own
          </button>
        </div>
      </div>
    `}renderHowItWorks(){return s`
      <div class="how-it-works">
        <h2 class="section-title animate-in">Four things to know</h2>
        <p class="section-subtitle animate-in-delayed">
          Webpaper works silently in the background. Here's what's happening under the hood.
        </p>

        <div class="feature-cards">
          <div class="feature-card animate-in" style="animation-delay: 0.1s;">
            <div class="feature-card-number">1</div>
            <div class="feature-card-content">
              <div class="feature-card-title">Your profile auto-attaches</div>
              <div class="feature-card-desc">
                When you send a message to any AI chatbot, Webpaper intercepts the send
                and prepends your identity — name, bio, preferences, and instructions.
                The AI reads it before your message, so it already knows who you are.
              </div>
              <div class="feature-card-visual">
<span class="highlight">--- USER IDENTITY ---</span>
Name: Connor
Occupation: Founder at Webpaper
Instructions: Be concise, skip preamble
Preferences: TypeScript, dark mode, metric
<span class="highlight">--- END ---</span>

Hey, can you help me debug this auth flow?</div>
            </div>
          </div>

          <div class="feature-card animate-in" style="animation-delay: 0.2s;">
            <div class="feature-card-number">2</div>
            <div class="feature-card-content">
              <div class="feature-card-title">Smart filtering by site category</div>
              <div class="feature-card-desc">
                Not every site gets everything. Shopping sites see your style preferences
                but never payment info. Finance sites get minimal identity. Coding sites
                get your tech stack. It's automatic — no manual configuration needed.
              </div>
              <div class="feature-card-visual"><span class="highlight">Shopping</span> → preferences, interests, bio
<span class="highlight">Finance</span>  → name only (minimal PII)
<span class="highlight">Travel</span>   → preferences, calendar, location
<span class="highlight">Coding</span>   → identity, preferences, memories
<span class="highlight">AI Chat</span>  → full profile (your choice)</div>
            </div>
          </div>

          <div class="feature-card animate-in" style="animation-delay: 0.3s;">
            <div class="feature-card-number">3</div>
            <div class="feature-card-content">
              <div class="feature-card-title">The web, polished</div>
              <div class="feature-card-desc">
                Webpaper uses AI to generate CSS improvements for every website you visit.
                Better spacing, improved contrast, cleaner typography — tailored to your
                aesthetic preferences. You'll build those preferences in a moment.
              </div>
            </div>
          </div>

          <div class="feature-card animate-in" style="animation-delay: 0.4s;">
            <div class="feature-card-number">4</div>
            <div class="feature-card-content">
              <div class="feature-card-title">Privacy and ad blocking built in</div>
              <div class="feature-card-desc">
                Switch to Anonymous mode and Webpaper becomes a privacy shield.
                Your personal info stays hidden — only explicit instructions reach AI.
                Ad networks and trackers are blocked at the network level, and
                third-party cookies are stripped from every cross-site request.
              </div>
              <div class="feature-card-visual"><span class="highlight">Anon mode</span>   → instructions only, zero identity
<span class="highlight">Ad block</span>   → 70+ ad/tracker domains blocked
<span class="highlight">Cookies</span>   → third-party cookies stripped
<span class="highlight">Polish</span>    → still active (no data leaves)</div>
            </div>
          </div>
        </div>
      </div>
    `}renderSafari(){return s`
      <div class="safari">
        <h2 class="section-title animate-in">Site safari</h2>
        <p class="section-subtitle animate-in-delayed">
          Visit these sites to see Webpaper in action. Click any card to open it —
          the extension will show you what it detects.
        </p>

        <div class="safari-progress animate-in-delayed">
          <span class="safari-progress-count">${this.visitedSites.size}</span>
          of ${d.length} visited
        </div>

        ${u.map(e=>s`
          <div class="safari-group">
            <div class="safari-group-header">
              <span class="safari-group-label">${e.label}</span>
              <span class="safari-group-desc">${e.description}</span>
            </div>
            <div class="safari-grid">
              ${e.sites.map(t=>s`
                <div
                  class="safari-card ${this.visitedSites.has(t.domain)?"visited":""}"
                  @click=${()=>this.visitSite(t)}
                >
                  <div class="safari-card-name">${t.name}</div>
                  <div class="safari-card-domain">${t.domain}</div>
                  ${t.aesthetic?s`<span class="safari-card-badge">${t.aesthetic}</span>`:""}
                  <div class="safari-card-pitch">${t.pitch}</div>
                </div>
              `)}
            </div>
          </div>
        `)}
      </div>
    `}renderTaste(){const e=d.filter(a=>a.demo==="design-taste"),t=e.filter(a=>this.tasteVotes[a.domain]==="love").map(a=>a.aesthetic).filter(Boolean);return s`
      <div class="taste">
        <h2 class="section-title animate-in">What's your style?</h2>
        <p class="section-subtitle animate-in-delayed">
          Rate these design aesthetics. Your votes train the CSS Polish feature —
          so every website you visit gets styled to your taste.
        </p>

        <div class="taste-cards">
          ${e.map((a,n)=>{const i=this.tasteVotes[a.domain];return s`
              <div class="taste-card ${i?`voted-${i}`:""}" style="animation: fadeUp 0.3s var(--srf-ease) ${n*.08}s both;">
                <div class="taste-card-info">
                  <div class="taste-card-name">${a.name}</div>
                  <span class="taste-card-aesthetic">${a.aesthetic}</span>
                  <div class="taste-card-pitch">${a.pitch}</div>
                </div>
                <div class="taste-actions">
                  <button
                    class="taste-btn love ${i==="love"?"active":""}"
                    @click=${()=>this.voteTaste(a.domain,"love")}
                    title="Love this style"
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="${i==="love"?"currentColor":"none"}" stroke="currentColor" stroke-width="1.5">
                      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                    </svg>
                  </button>
                  <button
                    class="taste-btn pass ${i==="pass"?"active":""}"
                    @click=${()=>this.voteTaste(a.domain,"pass")}
                    title="Not my style"
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">
                      <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                  </button>
                </div>
              </div>
            `})}
        </div>

        ${t.length>0?s`
          <div class="taste-summary animate-in">
            <div class="taste-summary-label">Your design profile</div>
            <div class="taste-summary-text">
              Based on your picks, you gravitate toward
              ${t.length===1?s`<strong>${t[0]}</strong> design.`:s`${t.slice(0,-1).map(a=>s`<strong>${a}</strong>, `)} and <strong>${t[t.length-1]}</strong> design.`}
              The Polish feature will use this to shape how every website looks for you.
            </div>
            <div class="taste-pills">
              ${t.map(a=>s`<span class="taste-pill">${a}</span>`)}
            </div>
          </div>
        `:""}
      </div>
    `}renderComplete(){const t=d.filter(a=>a.demo==="design-taste").filter(a=>this.tasteVotes[a.domain]==="love").length;return s`
      <div class="complete">
        <div class="complete-check animate-in">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
        </div>

        <h2 class="section-title animate-in-delayed">You're all set</h2>
        <p class="section-subtitle animate-in-delayed-2">
          Webpaper is ready. Your profile will auto-attach on every chatbot,
          and Polish will style the web to your taste.
        </p>

        <div class="complete-stats animate-in-delayed-2">
          <div class="complete-stat">
            <span class="complete-stat-value">${this.visitedSites.size}</span>
            <span class="complete-stat-label">sites visited</span>
          </div>
          <div class="complete-stat">
            <span class="complete-stat-value">${t}</span>
            <span class="complete-stat-label">styles loved</span>
          </div>
          <div class="complete-stat">
            <span class="complete-stat-value">${d.filter(a=>a.demo==="profile-injection").length}</span>
            <span class="complete-stat-label">AI chatbots supported</span>
          </div>
        </div>

        <div style="display: flex; flex-direction: column; gap: 12px; align-items: center;" class="animate-in-delayed-3">
          <button class="btn-primary" @click=${this.finishOnboarding}>
            Close and start using Webpaper
          </button>

          <div class="complete-links">
            <a class="complete-link" href="https://webpaper.app/me" target="_blank">Manage profile</a>
            <span style="color: var(--srf-border-inner, #E5E5EA);">|</span>
            <a class="complete-link" href="https://webpaper.app" target="_blank">webpaper.app</a>
          </div>
        </div>
      </div>
    `}renderNav(){return s`
      <div class="nav animate-in">
        <button
          class="btn-secondary"
          @click=${()=>this.prev()}
          style="padding: 10px 24px; font-size: 14px;"
        >Back</button>

        <div class="nav-step-dots">
          ${r.map((e,t)=>s`
            <span class="nav-dot ${t===this.stepIndex?"active":t<this.stepIndex?"done":""}"></span>
          `)}
        </div>

        ${this.step==="taste"?s`<button class="btn-primary" @click=${()=>this.goToStep("complete")} style="padding: 10px 24px; font-size: 14px;">Finish</button>`:s`<button class="btn-primary" @click=${()=>this.next()} style="padding: 10px 24px; font-size: 14px;">Next</button>`}
      </div>
    `}};o.styles=v`
    :host {
      display: block;
      width: 100%;
      min-height: 100vh;
    }

    /* ── Layout ── */

    .page {
      max-width: 720px;
      margin: 0 auto;
      padding: 60px 32px 80px;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    /* ── Progress bar ── */

    .progress {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: var(--srf-border-inner, #E5E5EA);
      z-index: 100;
    }

    .progress-fill {
      height: 100%;
      background: var(--srf-text-interactive, #000);
      transition: width 0.5s var(--srf-ease, cubic-bezier(0.25, 0.1, 0.25, 1));
    }

    /* ── Brand ── */

    .brand {
      display: flex;
      justify-content: center;
      margin-bottom: 16px;
    }

    .brand svg {
      height: 24px;
      width: auto;
      display: block;
    }

    .step-label {
      text-align: center;
      font-size: 11px;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      color: var(--srf-text-tertiary, #7A7F88);
      margin-bottom: 48px;
    }

    /* ── Animations ── */

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(12px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to   { opacity: 1; }
    }

    @keyframes slideInRight {
      from { opacity: 0; transform: translateX(30px); }
      to   { opacity: 1; transform: translateX(0); }
    }

    @keyframes shimmer {
      from { background-position: 100% 0; }
      to   { background-position:   0% 0; }
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }

    @keyframes scaleIn {
      from { opacity: 0; transform: scale(0.9); }
      to   { opacity: 1; transform: scale(1); }
    }

    .animate-in {
      animation: fadeUp 0.4s var(--srf-ease, cubic-bezier(0.25, 0.1, 0.25, 1)) both;
    }

    .animate-in-delayed {
      animation: fadeUp 0.4s var(--srf-ease) 0.15s both;
    }

    .animate-in-delayed-2 {
      animation: fadeUp 0.4s var(--srf-ease) 0.3s both;
    }

    .animate-in-delayed-3 {
      animation: fadeUp 0.4s var(--srf-ease) 0.45s both;
    }

    /* ── Welcome Step ── */

    .welcome {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding-bottom: 60px;
    }

    .welcome-title {
      font-size: 48px;
      font-weight: 400;
      line-height: 1.1;
      letter-spacing: -0.02em;
      margin-bottom: 16px;
      background: linear-gradient(90deg,
        #000 0%, #000 30%,
        #F97316 40%, #EF4444 44%, #A855F7 48%, #F472B6 52%, #22D3EE 56%,
        #000 65%, #000 100%);
      background-size: 300% 100%;
      background-position: 100% 0;
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
      animation: shimmer 2.5s ease-out forwards;
    }

    .welcome-subtitle {
      font-size: 18px;
      font-weight: 400;
      line-height: 1.5;
      color: var(--srf-text-secondary, #6B6B70);
      max-width: 420px;
      margin-bottom: 40px;
    }

    .welcome-features {
      display: flex;
      gap: 32px;
      margin-bottom: 48px;
    }

    .welcome-feature {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      max-width: 160px;
    }

    .welcome-feature-icon {
      width: 48px;
      height: 48px;
      border-radius: 12px;
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      color: var(--srf-text-interactive, #000);
    }

    .welcome-feature-label {
      font-size: 13px;
      font-weight: 400;
      color: var(--srf-text-secondary, #6B6B70);
      text-align: center;
      line-height: 1.4;
    }

    /* ── How It Works Step ── */

    .how-it-works {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .section-title {
      font-size: 36px;
      font-weight: 400;
      letter-spacing: -0.02em;
      text-align: center;
      margin-bottom: 8px;
      color: var(--srf-text-interactive, #000);
    }

    .section-subtitle {
      font-size: 16px;
      font-weight: 400;
      color: var(--srf-text-secondary, #6B6B70);
      text-align: center;
      margin-bottom: 48px;
      max-width: 480px;
    }

    .feature-cards {
      display: flex;
      flex-direction: column;
      gap: 20px;
      width: 100%;
      max-width: 600px;
    }

    .feature-card {
      background: transparent;
      border: 1px solid var(--srf-border, #9E9E9E);
      border-radius: var(--srf-radius-xl, 12px);
      padding: 24px;
      display: flex;
      gap: 20px;
      align-items: flex-start;
    }

    .feature-card-number {
      flex-shrink: 0;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      border: 1px solid var(--srf-border, #9E9E9E);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      font-weight: 500;
      color: var(--srf-text-interactive, #000);
      font-family: var(--srf-font-mono, 'IBM Plex Mono', ui-monospace, monospace);
    }

    .feature-card-content {
      flex: 1;
      min-width: 0;
    }

    .feature-card-title {
      font-size: 16px;
      font-weight: 500;
      color: var(--srf-text-interactive, #000);
      margin-bottom: 4px;
    }

    .feature-card-desc {
      font-size: 14px;
      font-weight: 400;
      color: var(--srf-text-secondary, #6B6B70);
      line-height: 1.5;
    }

    .feature-card-visual {
      margin-top: 12px;
      padding: 12px 16px;
      background: var(--srf-bg-input, #F4F4F7);
      border-radius: var(--srf-radius-lg, 8px);
      font-family: var(--srf-font-mono, 'IBM Plex Mono', ui-monospace, monospace);
      font-size: 12px;
      color: var(--srf-text-secondary, #6B6B70);
      line-height: 1.6;
      white-space: pre-wrap;
    }

    .feature-card-visual .highlight {
      color: var(--srf-text-interactive, #000);
      font-weight: 500;
    }

    /* ── Safari Step ── */

    .safari {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .safari-progress {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 8px;
      font-size: 13px;
      color: var(--srf-text-secondary, #6B6B70);
    }

    .safari-progress-count {
      font-family: var(--srf-font-mono, 'IBM Plex Mono', ui-monospace, monospace);
      font-weight: 500;
      color: var(--srf-text-interactive, #000);
    }

    .safari-group {
      width: 100%;
      max-width: 640px;
      margin-bottom: 32px;
      animation: fadeUp 0.3s var(--srf-ease) both;
    }

    .safari-group-header {
      display: flex;
      align-items: baseline;
      gap: 12px;
      margin-bottom: 12px;
      padding-bottom: 8px;
      border-bottom: 1px solid var(--srf-border-inner, #E5E5EA);
    }

    .safari-group-label {
      font-size: 13px;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--srf-text-interactive, #000);
    }

    .safari-group-desc {
      font-size: 13px;
      font-weight: 400;
      color: var(--srf-text-tertiary, #7A7F88);
    }

    .safari-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }

    .safari-card {
      background: transparent;
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: var(--srf-radius-xl, 12px);
      padding: 16px;
      cursor: pointer;
      transition: border-color 0.2s ease, transform 0.15s ease;
      position: relative;
      overflow: hidden;
    }

    .safari-card:hover {
      border-color: var(--srf-border, #9E9E9E);
    }

    .safari-card.visited {
      border-color: var(--srf-success, #34C759);
    }

    .safari-card.visited::after {
      content: '';
      position: absolute;
      top: 10px;
      right: 10px;
      width: 18px;
      height: 18px;
      border-radius: 50%;
      background: var(--srf-success, #34C759);
      background-image: url("data:image/svg+xml,%3Csvg width='10' height='8' viewBox='0 0 10 8' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 4L3.5 6.5L9 1' stroke='white' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: center;
    }

    .safari-card-name {
      font-size: 15px;
      font-weight: 500;
      color: var(--srf-text-interactive, #000);
      margin-bottom: 2px;
    }

    .safari-card-domain {
      font-size: 11px;
      font-family: var(--srf-font-mono, 'IBM Plex Mono', ui-monospace, monospace);
      color: var(--srf-text-tertiary, #7A7F88);
      margin-bottom: 8px;
    }

    .safari-card-pitch {
      font-size: 13px;
      font-weight: 400;
      color: var(--srf-text-secondary, #6B6B70);
      line-height: 1.4;
    }

    .safari-card-badge {
      display: inline-block;
      font-size: 10px;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      padding: 2px 6px;
      border-radius: var(--srf-radius-sm, 4px);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      color: var(--srf-text-secondary, #6B6B70);
      margin-bottom: 8px;
    }

    /* ── Taste Step (Design Preference Rating) ── */

    .taste {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .taste-cards {
      display: flex;
      flex-direction: column;
      gap: 16px;
      width: 100%;
      max-width: 560px;
    }

    .taste-card {
      background: transparent;
      border: 1px solid var(--srf-border, #9E9E9E);
      border-radius: var(--srf-radius-xl, 12px);
      padding: 24px;
      display: flex;
      align-items: center;
      gap: 20px;
      transition: border-color 0.2s ease;
    }

    .taste-card.voted-love {
      border-color: var(--srf-success, #34C759);
    }

    .taste-card.voted-pass {
      border-color: var(--srf-border-inner, #E5E5EA);
      opacity: 0.6;
    }

    .taste-card-info {
      flex: 1;
      min-width: 0;
    }

    .taste-card-name {
      font-size: 16px;
      font-weight: 500;
      color: var(--srf-text-interactive, #000);
      margin-bottom: 2px;
    }

    .taste-card-aesthetic {
      display: inline-block;
      font-size: 11px;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      padding: 2px 8px;
      border-radius: var(--srf-radius-sm, 4px);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      color: var(--srf-text-secondary, #6B6B70);
      margin-bottom: 6px;
    }

    .taste-card-pitch {
      font-size: 13px;
      color: var(--srf-text-secondary, #6B6B70);
      line-height: 1.4;
    }

    .taste-actions {
      display: flex;
      gap: 8px;
      flex-shrink: 0;
    }

    .taste-btn {
      width: 44px;
      height: 44px;
      border-radius: 50%;
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      background: transparent;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      transition: all 0.2s ease;
      color: var(--srf-text-secondary, #6B6B70);
    }

    .taste-btn:hover {
      border-color: var(--srf-border, #9E9E9E);
    }

    .taste-btn.love {
      color: var(--srf-text-interactive, #000);
    }

    .taste-btn.love:hover,
    .taste-btn.love.active {
      background: var(--srf-success, #34C759);
      border-color: var(--srf-success, #34C759);
      color: #FFF;
    }

    .taste-btn.pass:hover,
    .taste-btn.pass.active {
      background: var(--srf-border-inner, #E5E5EA);
      border-color: var(--srf-border-inner, #E5E5EA);
      color: var(--srf-text-secondary, #6B6B70);
    }

    .taste-summary {
      margin-top: 24px;
      padding: 16px 20px;
      background: var(--srf-bg-input, #F4F4F7);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: var(--srf-radius-xl, 12px);
      max-width: 560px;
      width: 100%;
    }

    .taste-summary-label {
      font-size: 11px;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--srf-text-tertiary, #7A7F88);
      margin-bottom: 6px;
    }

    .taste-summary-text {
      font-size: 14px;
      color: var(--srf-text, #363636);
      line-height: 1.5;
    }

    .taste-pills {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 8px;
    }

    .taste-pill {
      font-size: 12px;
      padding: 4px 10px;
      border-radius: 100px;
      border: 1px solid var(--srf-success, #34C759);
      color: var(--srf-success, #34C759);
      font-weight: 500;
    }

    /* ── Complete Step ── */

    .complete {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding-bottom: 60px;
    }

    .complete-check {
      width: 72px;
      height: 72px;
      border-radius: 50%;
      border: 2px solid var(--srf-success, #34C759);
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 24px;
      animation: scaleIn 0.4s var(--srf-ease) both;
    }

    .complete-check svg {
      width: 32px;
      height: 32px;
      color: var(--srf-success, #34C759);
    }

    .complete-stats {
      display: flex;
      gap: 32px;
      margin: 32px 0;
    }

    .complete-stat {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
    }

    .complete-stat-value {
      font-size: 28px;
      font-weight: 400;
      letter-spacing: -0.02em;
      color: var(--srf-text-interactive, #000);
      font-family: var(--srf-font-mono, 'IBM Plex Mono', ui-monospace, monospace);
    }

    .complete-stat-label {
      font-size: 12px;
      color: var(--srf-text-tertiary, #7A7F88);
    }

    .complete-links {
      display: flex;
      gap: 12px;
      margin-top: 16px;
    }

    .complete-link {
      font-size: 13px;
      color: var(--srf-text-secondary, #6B6B70);
      text-decoration: none;
      border-bottom: 1px solid transparent;
      transition: all 0.2s ease;
      cursor: pointer;
      background: none;
      border: none;
      font-family: inherit;
      padding: 0;
    }

    .complete-link:hover {
      color: var(--srf-accent, #007AFF);
      border-bottom-color: var(--srf-accent, #007AFF);
    }

    /* ── Buttons ── */

    .btn-primary {
      background: var(--srf-text-interactive, #000);
      color: #FFFFFF;
      border: 1px solid var(--srf-text-interactive, #000);
      border-radius: var(--srf-radius-lg, 8px);
      padding: 14px 32px;
      font-size: 15px;
      font-weight: 500;
      font-family: inherit;
      letter-spacing: 0.01em;
      cursor: pointer;
      transition: opacity 0.2s ease;
    }

    .btn-primary:hover {
      opacity: 0.85;
    }

    .btn-secondary {
      background: transparent;
      color: var(--srf-text-secondary, #6B6B70);
      border: 1px solid var(--srf-border-inner, #E5E5EA);
      border-radius: var(--srf-radius-lg, 8px);
      padding: 14px 32px;
      font-size: 15px;
      font-weight: 400;
      font-family: inherit;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .btn-secondary:hover {
      border-color: var(--srf-border, #9E9E9E);
      color: var(--srf-text-interactive, #000);
    }

    .btn-ghost {
      background: none;
      border: none;
      color: var(--srf-text-tertiary, #7A7F88);
      font-size: 13px;
      font-family: inherit;
      cursor: pointer;
      padding: 8px 16px;
      transition: color 0.2s ease;
    }

    .btn-ghost:hover {
      color: var(--srf-text-interactive, #000);
    }

    /* ── Navigation ── */

    .nav {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-top: 48px;
      padding-top: 24px;
      border-top: 1px solid var(--srf-border-inner, #E5E5EA);
      width: 100%;
      max-width: 640px;
    }

    .nav-step-dots {
      display: flex;
      gap: 6px;
    }

    .nav-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--srf-border-inner, #E5E5EA);
      transition: all 0.3s ease;
    }

    .nav-dot.active {
      background: var(--srf-text-interactive, #000);
      width: 20px;
      border-radius: 3px;
    }

    .nav-dot.done {
      background: var(--srf-success, #34C759);
    }

    /* ── Visit banner (shown when a site is opened) ── */

    .visit-banner {
      position: fixed;
      bottom: 24px;
      left: 50%;
      transform: translateX(-50%);
      background: var(--srf-text-interactive, #000);
      color: #FFF;
      padding: 12px 24px;
      border-radius: 100px;
      font-size: 13px;
      font-weight: 500;
      z-index: 200;
      animation: fadeUp 0.3s var(--srf-ease) both;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .visit-banner-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--srf-success, #34C759);
      animation: pulse 1.5s ease-in-out infinite;
    }
  `;l([c()],o.prototype,"step",2);l([c()],o.prototype,"onboardingState",2);l([c()],o.prototype,"visitedSites",2);l([c()],o.prototype,"tasteVotes",2);l([c()],o.prototype,"visitBanner",2);l([c()],o.prototype,"howItWorksSlide",2);o=l([x("srf-onboarding")],o);
