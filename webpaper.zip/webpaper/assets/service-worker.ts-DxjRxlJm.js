import{_ as O,b as kt,a as Et,i as Ye,c as xe}from"./card-types-u4cCMT4q.js";import{c as _t}from"./profile-markers-BUHYoXfg.js";import{createLogger as C,getRecentLogs as Tt}from"./logger-DShRSVht.js";import{E as We}from"./onboarding-types-BOQBz6-q.js";const ze=[{id:"claude",label:"Claude",origin:"https://claude.ai/*",url:"https://claude.ai",cookies:["sessionKey","lastActiveOrg"]},{id:"chatgpt",label:"ChatGPT",origin:"https://chatgpt.com/*",url:"https://chatgpt.com",cookies:["__Secure-next-auth.session-token"]},{id:"gemini",label:"Gemini",origin:"https://gemini.google.com/*",url:"https://gemini.google.com",cookies:["__Secure-1PSID","SID"]},{id:"grok",label:"Grok",origin:"https://grok.com/*",url:"https://grok.com",cookies:["sso","auth_token"]}];function Ot(e){return ze.find(t=>t.id===e)}async function At(e){try{for(const t of e.cookies)if(await chrome.cookies.get({url:e.url,name:t}))return!0}catch{}return!1}async function Z(){let e=!1;for(const t of ze)if(await chrome.permissions.contains({origins:[t.origin]})&&(e=!0,await At(t)))return{Surfaced:!0,loggedIn:!0,provider:t.id};return{Surfaced:e,loggedIn:!1}}async function xt(e){const t=Ot(e);return t?chrome.permissions.request({origins:[t.origin]}):!1}async function $t(){const{clearOrgIdCache:e}=await O(async()=>{const{clearOrgIdCache:t}=await Promise.resolve().then(()=>Ht);return{clearOrgIdCache:t}},void 0);e()}function me(e,t,o){var r,i,l,u;const s=[],n=e.identity??{};if((r=n.instructions)!=null&&r.trim()&&s.push({type:"instructions",content:n.instructions.trim()}),t==="finance"||t==="healthcare"||t==="customer_support"){const d=kt(t),c=[];return d.includes("name")&&n.name&&c.push(`Name: ${n.name}`),d.includes("email")&&n.email&&c.push(`Email: ${n.email}`),c.length>0&&s.push({type:"identity",content:c.join(`
`),label:"Identity"}),s}const a=[];return n.name&&a.push(`Name: ${n.name}`),n.occupation&&a.push(`Occupation: ${n.occupation}`),n.location&&a.push(`Location: ${n.location}`),(i=n.bio)!=null&&i.trim()&&(a.length>0&&a.push(""),a.push(n.bio.trim())),a.length>0&&s.push({type:"biography",content:a.join(`
`)}),(l=n.interests)!=null&&l.length&&$e("interests",t)&&s.push({type:"interests",content:n.interests.join(", ")}),(u=e.memoryDocument)!=null&&u.trim()&&$e("memory",t)&&s.push({type:"memory",content:e.memoryDocument.trim()}),s}function $e(e,t){switch(e){case"interests":return t!=="finance"&&t!=="healthcare";case"memory":return t==="general_ai"||t==="coding"||t==="education"||t==="shopping"||t==="travel";default:return!0}}function fe(e){const t=e.identity??{};return{name:t.name,occupation:t.occupation,location:t.location,interests:t.interests,bio:t.bio}}function It(e){const t=e.identity??{},o={name:t.name,email:t.email,organization:t.occupation,"organization-title":t.occupation};if(t.name){const s=t.name.trim().split(/\s+/);s.length>=2?(o["given-name"]=s[0],o["family-name"]=s.slice(1).join(" ")):o["given-name"]=s[0]}if(t.location){const s=t.location.split(",").map(n=>n.trim()).filter(Boolean);s.length===1?o["address-level2"]=s[0]:s.length===2?(o["address-level2"]=s[0],o.country=s[1]):(o["address-level2"]=s[0],o["address-level1"]=s[1],o.country=s[s.length-1])}return o}function Ct(e){var s;const t=e.identity??{},o={occupation:t.occupation};return t.name&&(o.firstName=t.name.trim().split(/\s+/)[0]),t.location&&(o.city=(s=t.location.split(",")[0])==null?void 0:s.trim()),o}const Ie={travel:"The user is planning or booking travel. Use their travel preferences, calendar availability, and budget to make personalized recommendations.",finance:"The user needs account support. Use only the identity provided to verify and assist them.",shopping:"The user is browsing or purchasing. Use their preferences for relevant suggestions.",coding:"The user needs technical help. Use their background and project context.",general_ai:"Use the full profile context to personalize responses.",customer_support:"The user needs help with a product/service. Use their identity for account lookup.",healthcare:"The user needs health-related information. Use only the identity provided. Do not make medical diagnoses.",education:"The user is learning. Adapt explanations to their background and preferences.",unknown:"Use the provided identity context to personalize your response."};function Pt(e,t,o,s={}){var l,u,d;const n=_t(),a=[];a.push("--- USER IDENTITY ---","The following personal context is provided by the user via Webpaper.","Use it to personalise your response. Do not re-ask for information","already provided below.","");for(const c of e){if(!((l=c.content)!=null&&l.trim()))continue;const p=Et(c.type);a.push(`[${p.promptSection}]`),a.push(c.content.trim()),a.push("")}(u=s.revealedSummary)!=null&&u.trim()&&a.push("[OBSERVED BEHAVIOR]","Derived from how the user actually uses AI tools â€” calibrate tone","and defaults but stated instructions still take precedence:",s.revealedSummary.trim(),""),a.push("--- INSTRUCTIONS ---"),a.push(`Site context: ${o} (${t})`),a.push(Ie[t]??Ie.unknown),s.conversationContext&&a.push(`Conversation context: ${s.conversationContext}`),(d=s.mediaPreferences)!=null&&d.trim()&&(a.push("","[MEDIA_GUIDELINES]"),a.push(`If the user asks for an image or video, strictly adhere to their aesthetic preferences: ${s.mediaPreferences.trim()}`)),a.push("Address them by name. Do not ask for information already provided."),a.push(""),a.push(`Cards: ${e.map(c=>c.type).join(", ")}`);const r=a.join(`
`);return{prompt:`${n.open}${r}${n.close}

`,cards:e,markerId:n.id}}const Ge=C("profile-store"),ae="srf_profile";let x=null;async function k(){if(x)return x;try{const{[ae]:e}=await chrome.storage.local.get(ae);if(e&&typeof e=="object")return x=e,x}catch(e){Ge.warn("getProfile: storage.get failed",e)}return Mt()}async function Ce(e){const t={...e,updatedAt:Date.now()};x=t;try{await chrome.storage.local.set({[ae]:t})}catch(o){Ge.warn("saveProfile: storage.set failed",o)}}async function Q(){x=null}function Mt(){return{identity:{},memoryDocument:""}}const Be="srf_card_prefs_";function qe(e){return e.replace(/^www\./,"")}async function ge(e){try{const t=Be+qe(e),{[t]:o}=await chrome.storage.local.get(t);if(o&&typeof o=="object")return o}catch{}return{}}async function Dt(e,t){await chrome.storage.local.set({[Be+qe(e)]:t})}async function oe(e){return ge(e)}async function Rt(e,t,o){const s=await ge(e);s[t]=o,await Dt(e,s)}async function Ve(e,t){const o=await ge(e);return Object.keys(o).length===0?t:t.filter(s=>o[s.type]===!0)}const Ke={haiku:"claude-haiku-4-5-20251001",sonnet:"claude-sonnet-4-6",opus:"claude-opus-4-6"};async function Nt(e,t){var d,c,p;const o=e.getReader(),s=new TextDecoder;let n="",a="",r=!1,i="",l="",u=!1;try{for(;;){if((d=t.signal)!=null&&d.aborted)throw new Error("Stream aborted");const{done:h,value:m}=await o.read();if(h)break;a+=s.decode(m,{stream:!0});const w=a.split(`
`);a=w.pop()??"";for(const y of w){if(!y.startsWith("data: "))continue;const f=y.slice(6).trim();if(!f)continue;let b;try{b=JSON.parse(f)}catch{continue}let g="";if(typeof b.completion=="string"?g=b.completion:typeof((c=b.delta)==null?void 0:c.text)=="string"?g=b.delta.text:typeof((p=b.content_block)==null?void 0:p.text)=="string"&&(g=b.content_block.text),!!g){if(n+=g,t.mode==="full"){t.onChunk(g);continue}for(const _ of g)if(i+=_,r){if(i.endsWith("\n```")||i.endsWith("\r\n```")){const v=i.slice(0,i.lastIndexOf("```"));v&&(t.onChunk(v),l+=v),r=!1,i=""}else if(i.length>80){const v=i.slice(0,-4);i=i.slice(-4),t.onChunk(v),l+=v}}else{const v=i.toLowerCase();(v.endsWith("```css\n")||v.endsWith("```css\r\n")||v.endsWith("```\n")||v.endsWith("```\r\n"))&&(r=!0,u=!0,i=""),i.length>20&&(i=i.slice(-10))}}}}if(r&&i.length>0){const h=i.replace(/`{0,3}$/,"");h&&(t.onChunk(h),l+=h)}if(t.mode==="css-block"&&!u&&l===""&&n.includes("{")&&n.includes("}")){const h=n.replace(/```[a-zA-Z]*\n?/g,"").replace(/```/g,"").trim();h&&(t.onChunk(h),l=h)}}finally{try{o.releaseLock()}catch{}}return{fullText:n,extracted:t.mode==="css-block"?l:n}}const I="https://claude.ai",Lt=60*60*1e3;let N=null;class S extends Error{constructor(t,o){super(t),this.code=o,this.name="ClaudeSessionError"}}async function ye(){if(!await chrome.permissions.contains({origins:["https://claude.ai/*"]}))return{loggedIn:!1,error:"no-permission",errorDetail:"Extension does not have permission to access claude.ai"};let t;try{t=await chrome.cookies.get({url:I,name:"sessionKey"})??await chrome.cookies.get({url:I,name:"lastActiveOrg"})}catch(o){return{loggedIn:!1,error:"unknown",errorDetail:o instanceof Error?o.message:String(o)}}if(!t)return{loggedIn:!1,error:"no-cookie",errorDetail:"Not signed in to claude.ai"};try{return{loggedIn:!0,orgId:await we()}}catch(o){return o instanceof S?{loggedIn:!1,error:o.code,errorDetail:o.message}:{loggedIn:!1,error:"unknown",errorDetail:o instanceof Error?o.message:String(o)}}}async function E(e,t="haiku",o={}){const s=o.extract??"full",n=await we(),a=await Je(n,t);try{let r="";const i=await Ze(n,a,e,t,l=>{r+=l},s,o.signal);return s==="css-block"?i.extracted:r}finally{Xe(n,a)}}async function H(e,t,o,s={}){const n=s.extract??"full",a=await we(),r=await Je(a,t);try{return await Ze(a,r,e,t,o,n,s.signal)}finally{Xe(a,r)}}function Ut(){N=null}async function we(){if(N&&Date.now()-N.ts<Lt)return N.id;let e;try{e=await fetch(`${I}/api/organizations`,{credentials:"include"})}catch(o){throw new S(o instanceof Error?o.message:"Network error","network")}if(!e.ok)throw e.status===401||e.status===403?new S("Not logged in to claude.ai","not-logged-in"):new S(`HTTP ${e.status} from claude.ai`,"api");let t;try{t=await e.json()}catch{throw new S("Malformed response from claude.ai","api")}if(!t||t.length===0)throw new S("No organizations found","not-logged-in");return N={id:t[0].uuid,ts:Date.now()},t[0].uuid}async function Je(e,t){var a;const o=Ke[t];let s;try{s=await fetch(`${I}/api/organizations/${e}/chat_conversations`,{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:"",model:o})})}catch(r){throw new S(r instanceof Error?r.message:"Network error","network")}if(!s.ok){let r="";try{const i=await s.json();r=((a=i==null?void 0:i.error)==null?void 0:a.message)??""}catch{}throw new S(r||`Failed to create conversation (HTTP ${s.status})`,"api")}const n=await s.json();if(!n.uuid)throw new S("Missing conversation UUID in response","api");return n.uuid}async function Xe(e,t){try{await fetch(`${I}/api/organizations/${e}/chat_conversations/${t}`,{method:"DELETE",credentials:"include"})}catch{}}async function Ze(e,t,o,s,n,a,r){var d;const i=Ke[s],l=Intl.DateTimeFormat().resolvedOptions().timeZone;let u;try{u=await fetch(`${I}/api/organizations/${e}/chat_conversations/${t}/completion`,{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:o,model:i,timezone:l}),signal:r})}catch(c){throw new S(c instanceof Error?c.message:"Network error","network")}if(!u.ok||!u.body){let c="";try{const p=await u.json();c=((d=p==null?void 0:p.error)==null?void 0:d.message)??""}catch{}throw new S(c||`Message failed (HTTP ${u.status})`,"api")}return Nt(u.body,{mode:a,onChunk:n,signal:r})}const Ht=Object.freeze(Object.defineProperty({__proto__:null,ClaudeSessionError:S,askClaude:E,askClaudeStreaming:H,clearOrgIdCache:Ut,getSessionStatus:ye},Symbol.toStringTag,{value:"Module"}));async function Qe(e,t,o){const s=be(e,t),a=(await chrome.storage.local.get(s))[s];return a?Date.now()-a.ts>o?(chrome.storage.local.remove(s),null):a.value:null}async function et(e,t,o){const s=be(e,t),n={value:o,ts:Date.now()};await chrome.storage.local.set({[s]:n})}async function jt(e,t){await chrome.storage.local.remove(be(e,t))}async function Ft(e){const t=`srf_llm_cache_${e}_`,o=await chrome.storage.local.get(null),s=Object.keys(o).filter(n=>n.startsWith(t));return s.length>0&&await chrome.storage.local.remove(s),s.length}async function Yt(e){const t=`srf_llm_cache_${e}_`,o=await chrome.storage.local.get(null);return Object.keys(o).filter(s=>s.startsWith(t)).length}async function Wt(e){const t=new TextEncoder().encode(e),o=await crypto.subtle.digest("SHA-256",t),s=new Uint8Array(o);let n=0n;for(let a=0;a<8;a++)n=n<<8n|BigInt(s[a]);return n.toString(36)}function be(e,t){return`srf_llm_cache_${e}_${t}`}const j=C("card-selector"),Pe="card-select",zt=24*60*60*1e3;async function Gt(e,t,o){if(e.length<=1)return e;const s=await Wt(`${t}|${o}|${e.map(p=>p.type).sort().join(",")}`),n=await Qe(Pe,s,zt);if(n){const p=new Set(n);return e.filter(h=>p.has(h.type))}if(!(await ye()).loggedIn)return j.debug("claude not available — returning candidates unchanged"),e;const r=Bt(e,t,o);let i;try{i=await E(r,"haiku",{signal:AbortSignal.timeout(8e3)})}catch(p){return j.warn("selection call failed",p),e}const l=new Set(e.map(p=>p.type)),u=qt(i,l);if(u.length===0)return j.debug("parse returned empty — keeping candidates"),e;l.has("instructions")&&!u.includes("instructions")&&u.unshift("instructions"),await et(Pe,s,u);const d=new Set(u),c=e.filter(p=>d.has(p.type));return j.info("selected",{hostname:t,from:e.map(p=>p.type),picked:c.map(p=>p.type)}),c}function Bt(e,t,o){const s=e.map(n=>{const a=n.content.replace(/\s+/g," ").slice(0,90);return`- ${n.type}: ${a}`}).join(`
`);return`You route a user's profile cards to AI chats. The user is about to chat on a specific site. Pick the cards relevant to THIS specific site.

SITE: ${t}
CATEGORY: ${o}

AVAILABLE CARDS (slug then short preview):
${s}

Rules:
- Pick 2 to 5 cards. Fewer is better — every card is context the AI has to read.
- ALWAYS include "instructions" if it's available (user's behavioral preferences).
- "biography" is usually included on general/coding/education sites; usually dropped on shopping/travel.
- "calendar" only when the site is travel-, scheduling-, or planning-related.
- "projects" only on coding sites or general AI assistants.
- "allergies" only on shopping/food/healthcare sites.
- "connected-apps" only when the site might benefit from tool context (general AI, coding).
- "interests" almost everywhere except finance/healthcare.

Output ONLY a JSON array of card slugs in priority order. Example: ["instructions","biography","interests"]
No preamble, no markdown fences, just the array.`}function qt(e,t){try{const o=e.match(/\[[\s\S]*?\]/);if(!o)return[];const s=JSON.parse(o[0]);return Array.isArray(s)?s.filter(n=>typeof n=="string"&&Ye(n)&&t.has(n)):[]}catch{return[]}}const ee=C("card-init"),Me="srf_card_prefs_",te=new Map;async function ve(e,t,o){const s=e.replace(/^www\./,"");if(o.length===0)return;const n=await oe(s);if(Object.keys(n).length>0)return;const a=`${s}|${o.map(i=>i.type).sort().join(",")}`;let r=te.get(a);r||(r=(async()=>{try{const i=await Gt(o,s,t),l=new Set(i.map(d=>d.type)),u={};for(const d of o)u[d.type]=l.has(d.type);o.some(d=>d.type==="instructions")&&(u.instructions=!0),await chrome.storage.local.set({[Me+s]:u}),ee.info("initialised prefs",{host:s,attached:Object.entries(u).filter(([,d])=>d).map(([d])=>d)})}catch(i){ee.warn("init failed, saving all candidates as active fallback",i);try{const l={};for(const u of o)l[u.type]=!0;await chrome.storage.local.set({[Me+s]:l})}catch(l){ee.error("failed to write initial card prefs fallback",l)}}finally{te.delete(a)}})(),te.set(a,r)),await r}const Vt=C("cookie-signal"),Kt=["session","sess","sid","auth","token","login","logged_in","user_id","uid","jwt","access_token","remember"];async function Jt(e){var t;if(!((t=chrome.cookies)!=null&&t.getAll))return null;try{const o=`https://${e}`,s=await chrome.cookies.getAll({url:o});if(!s)return null;const a=s.map(r=>r.name.toLowerCase()).some(r=>Kt.some(i=>r.includes(i)));return{host:e,signedIn:a,cookieCount:s.length}}catch(o){return Vt.debug("cookies unavailable",{host:e,err:o}),null}}const De=C("context"),tt="srf_perms_";async function Xt(e){const t=tt+e;return(await chrome.storage.local.get(t))[t]??null}async function Zt(e){const t=tt+e.domain;await chrome.storage.local.set({[t]:e})}async function Qt(e,t){var r;const o=await k(),{getPreferenceMode:s}=await O(async()=>{const{getPreferenceMode:i}=await Promise.resolve().then(()=>J);return{getPreferenceMode:i}},void 0),n=await s();if(n==="off")return[];if(n==="anon"){const i=(r=o.identity)==null?void 0:r.instructions;return i?[{type:"instructions",content:i}]:[]}const a=me(o,t);return a.length===0?[]:(await ve(e,t,a),Ve(e,a))}async function ea(e,t){var h;const o=await k(),{getPreferenceMode:s}=await O(async()=>{const{getPreferenceMode:m}=await Promise.resolve().then(()=>J);return{getPreferenceMode:m}},void 0),n=await s();if(n==="off")return null;if(n==="anon"){const m=(h=o.identity)==null?void 0:h.instructions;return m?{prompt:["--- SURFACE ---","","[INSTRUCTIONS]",m,"","--- SURFACE ---"].join(`
`),sections:["instructions"]}:null}const a=me(o,t);if(a.length===0)return null;await ve(e,t,a);const r=await Ve(e,a);if(r.length===0)return null;let i="";if(n==="combined")try{const{getRevealedSummary:m}=await O(async()=>{const{getRevealedSummary:w}=await Promise.resolve().then(()=>Za);return{getRevealedSummary:w}},void 0);i=await m()}catch(m){De.warn("revealed summary failed",m)}const l=await Jt(e);let u;l!=null&&l.signedIn&&(u=`The user appears to be signed in to this site (${l.cookieCount} cookies present).`);const c=(await chrome.storage.local.get("srf_media_preferences")).srf_media_preferences??"",p=Pt(r,t,e,{revealedSummary:i,conversationContext:u,mediaPreferences:c});return De.info("assembled",{hostname:e,category:t,cards:r.map(m=>m.type),bytes:p.prompt.length}),{prompt:p.prompt,sections:r.map(m=>m.type)}}const at="srf_autoinject_";async function ta(e){const t=at+e;return(await chrome.storage.local.get(t))[t]!==!1}async function aa(e,t){const o=at+e;await chrome.storage.local.set({[o]:t})}const se="srf_telemetry_buffer",ne="srf_telemetry_optout",Re="srf_telemetry_last_flush",Ne=500,oa=50;async function T(e){if(await ot())return!1;const t=await q();return t.push(e),t.length>Ne&&t.splice(0,t.length-Ne),await sa(t),t.length>=oa&&ca(),!0}async function q(){const{[se]:e}=await chrome.storage.local.get(se);return Array.isArray(e)?e:[]}async function sa(e){await chrome.storage.local.set({[se]:e})}async function na(e){return(await q()).slice(-e).reverse()}async function ra(){const e=await q(),t=await ot(),{[Re]:o}=await chrome.storage.local.get(Re),s={},n={};for(const a of e)a.platform&&(s[a.platform]=(s[a.platform]??0)+1),n[a.kind]=(n[a.kind]??0)+1;return{totalEvents:e.length,platformBreakdown:s,kindBreakdown:n,lastFlushTs:typeof o=="number"?o:null,optedOut:t,bufferSize:e.length}}async function ot(){const{[ne]:e}=await chrome.storage.local.get(ne);return e===!0}async function ia(e){await chrome.storage.local.set({[ne]:e})}function ca(){return new Promise(e=>{setTimeout(async()=>{try{const{triggerFlush:t}=await O(async()=>{const{triggerFlush:o}=await Promise.resolve().then(()=>la);return{triggerFlush:o}},void 0);await t()}catch(t){console.warn("[Webpaper] Auto-flush failed:",t)}e()},0)})}async function Se(){return{attempted:!1}}const la=Object.freeze(Object.defineProperty({__proto__:null,triggerFlush:Se},Symbol.toStringTag,{value:"Module"})),st=`You are a design critic. Analyze this webpage and create a redesign brief.

SITE DIFFICULTY CATEGORIES (pick one):
- "modern_spa": React/Next.js/Vue — clean markup, semantic HTML, easy to restyle. Strategy: palette + font swap, enhance spacing.
- "legacy_content": Wikipedia, old CMS, forums — huge DOM, table layouts, tons of chrome. Strategy: AGGRESSIVELY SIMPLIFY. Hide sidebars, TOC, edit links. Make images full-bleed backgrounds. Center on the actual content.
- "ecommerce": Product grids — fragile image sizing. Strategy: style cards and chrome, do NOT touch product grid image dimensions.
- "editorial": Blog/news — already decent. Strategy: elevate typography, hero images, reading experience.
- "dashboard": Complex interactive UI — very fragile. Strategy: colors and typography only, don't touch layout.

For "legacy_content" sites (especially Wikipedia, wikis, forums):
- The #1 goal is SIMPLIFICATION. Hide the noise, surface the content.
- Article images should become HERO elements — full-width backgrounds with content overlaid, or dramatic centered showcases.
- Sidebars, table of contents, edit links, reference numbers — all noise. Dim or hide them.
- The reading experience should feel like a premium magazine, not an encyclopedia.

Output a JSON object (no markdown, no explanation):
{
  "pageType": "article|gallery|product|landing|dashboard|forum|search|other",
  "siteDifficulty": "modern_spa|legacy_content|ecommerce|editorial|dashboard",
  "topic": "what this page is about",
  "heroContent": "what should be the visual centerpiece",
  "keyImages": "the most important images and what they show",
  "hasProductGrid": true/false,
  "hasHeroBanner": true/false,
  "simplify": ["list of elements/sections to hide or de-emphasize to reduce noise"],
  "currentProblems": ["3-5 specific design problems"],
  "designVision": "2-3 sentences — what would an AMAZING version look like?",
  "palette": { "bg": "#hex", "text": "#hex", "accent": "#hex", "Webpaper": "#hex" },
  "font": "one Google Font name",
  "layout": "how content should flow",
  "fragileAreas": ["areas to be careful with"]
}`;function nt(e,t,o,s){return`You are executing a redesign. A design critic analyzed this page and produced this brief:

${e}

Now generate the CSS. This is a FULL REWRITE — the user is DISSATISFIED with this design and trusts you to make it dramatically better.

READ THE BRIEF CAREFULLY:
- If "siteDifficulty" is "legacy_content": SIMPLIFY AGGRESSIVELY. Use display:none on sidebar, TOC, edit links, reference numbers, footer cruft. The brief's "simplify" array tells you what to hide. Make article images into hero backgrounds or full-width showcases. Think premium magazine, not encyclopedia.
- If "siteDifficulty" is "ecommerce": Do NOT touch product grid image sizing. Style cards, buttons, navigation.
- If "siteDifficulty" is "modern_spa": Palette + font + spacing. These sites are already clean.
- Follow the brief's palette and font EXACTLY.

KEY PRINCIPLES:
1. HERO IMAGES — make them stunning:
   - Only expand images that are ALREADY large or are hero/banner images
   - For hero/featured images: full container width, object-fit: cover, border-radius 12px, cinematic shadow
   - For content/inline images: border-radius + shadow, but keep their existing size
   - CRITICAL: Do NOT apply display:block or width:100% to ALL images — this destroys product grids, thumbnails, and icon images

2. PRODUCT GRIDS / CARD LAYOUTS — if the analysis mentions hasProductGrid or fragile areas:
   - Do NOT change img width/height/display inside product containers
   - Style the CARDS (background, border-radius, shadow, padding, hover effects)
   - Style the GRID (gap, padding) but not the image sizing within it
   - Product images rely on their container's flex/grid sizing — breaking that collapses them

3. Follow the palette and font from the brief exactly. Import the Google Font. Apply it everywhere.

4. Every background MUST have a contrasting text color set on the same selector. ALWAYS.

5. Use broad selectors for typography and color: body, h1-h6, p, a, nav, header, footer.
   Use CAREFUL selectors for layout: only change spacing/padding on sections, not width/display on content containers.

6. Add CSS that creates NEW visual features:
   - Smooth scroll: html { scroll-behavior: smooth }
   - Generous section padding (40-60px)
   - Subtle hover effects (translateY(-2px), shadow deepening) on cards and buttons
   - Transitions on all interactive elements (0.2s ease)

${s.fonts?`Override font: ${s.fonts}`:""}
${s.colors?`Override colors: ${s.colors}`:""}
${s.style?`Style direction: ${s.style}`:""}
${s.custom?`Custom: ${s.custom}`:""}

Output ONLY CSS in a \`\`\`css block. 60-120 lines of bold, transformative CSS.

Page: ${o}
DOM:
\`\`\`html
${t}
\`\`\``}const ua=`ROLE: CSS polish specialist. Elevate a webpage's visual quality with a small, surgical stylesheet.
OUTPUT: 40-60 lines of CSS in a \`\`\`css block. Nothing else. Shorter is better — every extra line is a risk.

The first line of the DOM is a computed-style comment showing the page's current bg, text, font, accent, and dark/light mode. Use it — do not guess blindly.
Images have data-srf-size attributes showing rendered dimensions. Images are the MOST IMPORTANT content on any page. If you modify them, expand and center — never shrink or distort.

RULES:
- Typography: Inter via @import, letter-spacing -0.02em headings, line-height 1.6, paragraph max-width for readability
- Colors: soften #000→#1a1a2e (light) / #e2e8f0 (dark). White bg→#fafafa. Dark bg→rich navy/charcoal, never #000
- Links: refined desaturated accent, not default blue. Hover transition
- Transitions: all 0.15s ease on interactive elements (non-negotiable)
- Buttons: border-radius 6-8px, box-shadow 0 1px 3px rgba(0,0,0,0.08), hover lift translateY(-1px)
- Inputs: match button radius, focus ring 0 0 0 2px accent@0.15, remove harsh outlines
- Borders: rgba(0,0,0,0.08) not solid grays
- Cards: box-shadow + border-radius 8-12px
- Spacing: normalize to 8px rhythm
- Images: border-radius 6px
- Selection: branded ::selection with soft accent bg
- Scrollbar: thin WebKit, translucent, rounded

CONSTRAINTS:
- Use !important on EVERY declaration. You are overriding heavy framework/CMS CSS — specificity wars are guaranteed, belt-and-braces wins. A rule without !important is a rule the site will silently ignore.
- NO layout changes, NO hide/show, NO pseudo-element content, NO theme flip
- Feel like the designer leveled up overnight. Be opinionated — generic is worse than wrong.`;function da(e,t,o,s,n=""){let a=ua;return e&&(a+=`

USER PROFILE (tailor choices to this person):
${e}`),t&&(a+=`

LEARNED PREFERENCES:
${t}`),n&&(a+=`

REFERENCE SITES:
${n}`),a+=`

Page: ${o}

\`\`\`html
${s}
\`\`\``,a+="\n\nRespond with ONLY:\n```css",a}const Le={optimise(e,t,o,s){return`You are a CSS optimizer. Keep the same design spirit but make the page VISIBLY better. The user should notice the improvement instantly.

The first line of the DOM is a computed-style comment. Images have data-srf-size attributes.

ALWAYS DO THESE (they work on virtually every site). Every declaration below MUST end with !important — sites ship high-specificity framework/CMS CSS and will silently ignore unflagged rules:
- @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap') — apply Inter to body + headings with !important. This alone transforms any page.
- Headings: letter-spacing -0.02em !important, clear size hierarchy (h1 > h2 > h3)
- Body: line-height 1.6 !important, soften pure #000 text to #1a1a2e !important, warm pure #fff bg to #fafafa !important
- All interactive elements: transition: all 0.2s ease !important
- Buttons: border-radius 8px !important, box-shadow 0 1px 3px rgba(0,0,0,0.08) !important, hover lift translateY(-1px)
- Links: refined accent color (not default blue) !important, subtle hover effect
- Images: border-radius 8px !important, subtle shadow (0 2px 8px rgba(0,0,0,0.08)) !important
- Borders: soften solid grays to rgba(0,0,0,0.08) !important
- ::selection { background: rgba(99, 102, 241, 0.2) !important }
- Scrollbar: thin, translucent (WebKit)
- html { scroll-behavior: smooth !important }

DO NOT CHANGE:
- Overall layout structure
- Background images or gradients already on the page
- Product grid image sizing
- Navigation structure
${e.fonts?`Preferred fonts: ${e.fonts}`:""}
${e.colors?`Color hints: ${e.colors}`:""}
${e.custom?`Custom: ${e.custom}`:""}

Output ONLY CSS in a \`\`\`css block. 30-50 lines.

DOM for ${o}:
\`\`\`html
${t}
\`\`\``},redesign(e,t,o,s){return`You are redesigning this page. The user will instantly compare before/after. If they can't tell the difference, you failed.

You receive TWO views of the page:
- STRUCTURE: a skeleton of tags, ids, and classes — use this for layout selectors
- CONTENT: the full cleaned HTML — use this to understand what images exist, what text says, and what to personalise

Use BROAD selectors for the redesign: body, header, nav, main, article, section, aside, footer, h1-h6, p, img, a, button, ul, li, table, td, th, figure, figcaption.

EXAMPLE of what bold redesign CSS looks like (adapt to this page, don't copy literally):

\`\`\`css
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap');
body { font-family: 'DM Sans', sans-serif; background: #0f0f0f; color: #e8e8e8; line-height: 1.65; }
h1, h2, h3 { color: #fff; letter-spacing: -0.03em; }
h1 { font-size: 2.5rem; font-weight: 700; margin-bottom: 0.5em; }
h2 { font-size: 1.6rem; font-weight: 600; border-bottom: 2px solid rgba(99,102,241,0.4); padding-bottom: 8px; }
a { color: #818cf8; text-decoration: none; transition: color 0.2s; }
a:hover { color: #a5b4fc; text-decoration: underline; }
article img, .hero img, figure img { border-radius: 12px; box-shadow: 0 8px 30px rgba(0,0,0,0.3); }
figure, .hero { border-radius: 12px; overflow: visible; }
/* NOTE: Do NOT use img { display:block; width:100% } — it breaks product grids and thumbnails */
nav, header { background: #161618; padding: 16px 24px; border-bottom: 1px solid rgba(255,255,255,0.06); }
main, article { max-width: 800px; margin: 0 auto; padding: 40px 24px; }
aside { background: #161618; border-radius: 12px; padding: 20px; border: 1px solid rgba(255,255,255,0.06); }
table { border-collapse: collapse; width: 100%; }
th { background: rgba(99,102,241,0.15); color: #fff; text-align: left; padding: 12px; }
td { padding: 10px 12px; border-bottom: 1px solid rgba(255,255,255,0.06); }
button, input[type="submit"] { background: #6366f1; color: #fff; border: none; border-radius: 8px; padding: 10px 20px; cursor: pointer; transition: all 0.2s; }
button:hover { background: #818cf8; transform: translateY(-1px); }
::selection { background: rgba(99,102,241,0.3); }
\`\`\`

That's the LEVEL of transformation expected. Not subtle tweaks — a complete visual overhaul.

RULES:
- Append !important to EVERY declaration. Framework and CMS CSS (Umbraco, WordPress, Sitefinity, etc.) will beat broad selectors on specificity — belt-and-braces wins. A redesign without !important is a redesign the site will partially ignore.
- Use BROAD selectors (body, h1, img, nav, main, aside). Don't target .specific-class-names you can't see.
- Every background you set MUST have a matching color. Dark bg → light text. Always. No exceptions.
- IMAGES — the most important content on any page:
  * Default: max-width: 100%; border-radius: 12px; box-shadow; margin: 24px auto; display: block; object-fit: cover
  * For hero/featured images: consider making them background-images on their container with background-size: cover; background-position: center — then layer content over with semi-transparent overlay. This is almost always what looks best.
  * NEVER crop images with overflow: hidden on a container that's smaller than the image. If you must constrain, use object-fit: cover so the image fills gracefully.
  * When in doubt: expand, center, and let the image breathe.
- Navigation: restyle completely. New background, new text color, new spacing.
- Commit to dark mode OR light mode fully. Don't mix.
${e.fonts?`- Fonts: ${e.fonts}`:""}
${e.colors?`- Colors: ${e.colors}`:""}
${e.style?`- Style: ${e.style}`:""}
${e.custom?`- Custom: ${e.custom}`:""}

Output CSS in a \`\`\`css block. 40-80 lines of BOLD, broad-selector CSS.

DOM for ${o}:
\`\`\`html
${t}
\`\`\``},minimise(e,t,o,s){return`You are a page cleaner and beautifier. The user clicked "Clean this page." Do TWO things:

PHASE 1 — STRIP NOISE
Read the DOM and identify secondary chrome. Hide it with display: none !important using the actual selectors from the DOM.

Always hide these generic patterns regardless of DOM:
  aside, [class*="sidebar" i], [class*="rail" i], [class*="related" i],
  [class*="recommended" i], [class*="newsletter" i], [class*="subscribe" i],
  [class*="cookie" i], [class*="consent" i], [class*="paywall" i],
  [class*="promo" i], [class*="banner" i], [class*="popup" i],
  [class*="ad-" i], ins.adsbygoogle, [id*="google_ads" i],
  [class*="share-" i], [class*="social-" i], [class*="reaction" i],
  section[id*="comment" i], [class*="disqus" i], #disqus_thread,
  [class*="intercom-" i], [class*="drift-" i], [class*="livechat" i],
  [data-testid="trending-stories"], [data-testid="frontpage-sidebar"],
  #mw-panel, .mw-editsection, .navbox,
  ytd-watch-next-secondary-results-renderer

Also look at the DOM and hide any page-specific secondary elements using their real selectors.

PHASE 2 — BEAUTIFY WHAT REMAINS
After stripping, improve what's left. These improvements are always applied:

Typography (use actual content selectors from the DOM):
  body: line-height: 1.75, font-size: 17px
  h1: font-size: clamp(1.8rem, 4vw, 3rem), letter-spacing: -0.03em, line-height: 1.1
  h2: font-size: 1.45rem, letter-spacing: -0.02em, margin-top: 2em
  p: max-width: 68ch, margin-bottom: 1.4em, line-height: 1.75
  img: max-width: 100%, border-radius: 6px, display: block, margin: 2em auto

Reading column — find the actual content wrapper in the DOM and apply:
  max-width: 760px, margin: 0 auto, padding: 60px 32px

Color refinement (detect if dark or light from DOM, don't override dark pages with light):
  Light pages: body { background: #fafaf8 !important; color: #1c1c1e !important; }
  Dark pages: body { background: #111114 !important; color: #e8e8ec !important; }

Nav that survives: padding: 10px 20px, font-size: 13px — slim, not eliminated
Links: no underline normally, underline on hover

Rules:
- !important on every declaration
- Use real selectors from the DOM wherever possible
- 40-80 lines total
- Return ONLY a \`\`\`css block

DOM for ${o}:
\`\`\`html
${t}
\`\`\``},personalise(e,t,o,s){return`You are a content personalisation engine. You receive a user's profile and a webpage DOM. Your job is to generate CSS that makes the page feel like it was built FOR this specific person.

The first line of the DOM is a computed-style comment showing the page's current visual state. Use it.

YOU MUST DO THREE THINGS:

1. HIGHLIGHT CONTENT THE USER WOULD LOVE
Read the page content (text, headings, product names, article titles, link labels, image alts).
Cross-reference against the user's interests, occupation, and preferences.
For elements containing content the user would care about:
- Add a subtle glow: box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.25), 0 0 12px rgba(99, 102, 241, 0.15)
- Slightly scale up on hover: transform: scale(1.02)
- Optionally add a left-border accent: border-left: 3px solid rgba(99, 102, 241, 0.6)
Be SPECIFIC with selectors — target the actual elements by their class/id/nth-child position.

2. DE-EMPHASISE OR HIDE NOISE
Identify clearly spammy, promotional, or irrelevant content:
- "Upgrade to Pro", "Subscribe now", cookie banners, newsletter popups, promotional banners
- Content that has NOTHING to do with the user's interests
- Generic filler that adds no value
For these: use opacity: 0.15, or display: none !important for truly obnoxious blockers (modals, popups, banners).
Do NOT hide core navigation, search, or page structure.

3. INJECT THE USER'S NAME (where natural)
Use CSS ::before or ::after with content: to add personalised greetings where appropriate:
- On hero sections or greeting areas: content: "Welcome back, [NAME]"
- On search bars or input placeholders via ::placeholder styling
- ONLY where it feels natural, not forced. Skip this entirely if the page has no natural greeting point.

CONSTRAINTS:
- Output ONLY CSS in a \`\`\`css block
- Use !important where needed to override site styles
- Do NOT break page layout or hide navigation/functional elements
- The highlighting should be SUBTLE — a gentle glow, not a neon border
- Maximum 120 lines of CSS
${e.custom?`
Extra instructions: ${e.custom}`:""}

DOM for ${o}:
\`\`\`html
${t}
\`\`\``}};function ke(e){var o,s;let t=`

PERSONALISATION (layer on top of the above):
In addition to the CSS above, also:

1. HIGHLIGHT content the user would personally care about. Read the text content in the DOM — article titles, product names, headings, link labels. Cross-reference with the user's interests below. For matching content: add box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.2), 0 0 8px rgba(99, 102, 241, 0.1). Use SPECIFIC selectors (nth-child, class, id) — not generic ones.

2. DE-EMPHASISE spam: "Upgrade to Pro", cookie banners, newsletter popups, promotional banners → opacity: 0.15 or display: none !important. Do NOT hide navigation or core content.`;return e.name&&(t+=`

3. NAME INJECTION — ONLY do this if there is a clear hero/greeting area. Use CSS ::before with content: to add ONE greeting like "Hey, ${e.name}" or "Welcome, ${e.name}". Place it on the page's main heading or hero section. Do NOT scatter the name across random elements — one natural placement or none at all.`),t+=`

THE USER:`,e.name&&(t+=`
Name: ${e.name}`),e.occupation&&(t+=`
Occupation: ${e.occupation}`),e.location&&(t+=`
Location: ${e.location}`),(o=e.interests)!=null&&o.length&&(t+=`
Interests: ${e.interests.join(", ")}`),e.bio&&(t+=`
Bio: ${e.bio}`),(s=e.preferences)!=null&&s.length&&(t+=`
Preferences: ${e.preferences.join(", ")}`),t}function rt(e,t,o,s,n,a,r="",i){let u=(Le[e]??Le.optimise)(t,o,s,n);return i?u+=ke(i):t.userProfile&&(u+=`

USER PROFILE:
${t.userProfile}`),a&&(u+=`

LEARNED PREFERENCES:
${a}`),r&&(u+=`

REFERENCE SITES:
${r}`),u+="\n\nRespond with ONLY:\n```css",u}const re="srf_polish_taste_log",pa=100;async function ha(e,t){const o=await V();for(o.push({hostname:e,action:t,ts:Date.now()});o.length>pa;)o.shift();await chrome.storage.local.set({[re]:o})}async function V(){const{[re]:e}=await chrome.storage.local.get(re);return Array.isArray(e)?e:[]}async function ma(){const e=await V();return{total:e.length,kept:e.filter(t=>t.action==="kept").length,undone:e.filter(t=>t.action==="undone").length,redone:e.filter(t=>t.action==="redone").length}}async function Ee(){const e=await V();if(e.length<5)return"";const t=e.filter(a=>a.action==="kept"),o=e.filter(a=>a.action==="undone"),s=e.filter(a=>a.action==="redone");let n=`Based on ${e.length} observations: ${t.length} sites kept, ${o.length} undone, ${s.length} redone. `;if(o.length>0){const a=[...new Set(o.map(r=>r.hostname))].slice(0,5).join(", ");n+=`Polish rejected on: ${a}. `}if(s.length>0){const a=[...new Set(s.map(r=>r.hostname))].slice(0,5).join(", ");n+=`Wanted better on: ${a}. `}return n}const W="srf_liked_sites",fa=50;async function K(){const{[W]:e}=await chrome.storage.local.get(W);return Array.isArray(e)?e:[]}async function ga(e){const o=(await K()).filter(s=>s.hostname!==e.hostname);for(o.unshift({...e,addedAt:Date.now()});o.length>fa;)o.pop();return await chrome.storage.local.set({[W]:o}),o}async function ya(e){const o=(await K()).filter(s=>s.hostname!==e);return await chrome.storage.local.set({[W]:o}),o}async function _e(){const e=await K();return e.length===0?"":`The user explicitly likes how these sites look and feel — match their vibe (aesthetic, typography, density, color palette) when it's reasonable to do so: ${e.slice(0,10).map(o=>o.title?`${o.hostname} (${o.title})`:o.hostname).join(", ")}.`}const L="polish",wa=7*24*60*60*1e3,it=300;async function ba(e){const t=await Qe(L,e,wa);return t&&t.length<it?(await jt(L,e),null):t}async function va(e,t){t.trim().length<it||await et(L,e,t)}async function Sa(){return Ft(L)}async function ka(){return Yt(L)}const Te={haiku:2e4,sonnet:3e4,opus:4e4},R="haiku",Ea=45e3,_a=75e3,Ue=25e3;function ct(e){const t=new AbortController;let o=null,s=!1;const n=setTimeout(()=>{t.signal.aborted||(o=`timeout after ${e}ms`,t.abort())},e),a=setTimeout(()=>{!s&&!t.signal.aborted&&(o=`no chunks received within ${Ue}ms of request start`,t.abort())},Ue);return{controller:t,markFirstChunk:()=>{s=!0},dispose:()=>{clearTimeout(n),clearTimeout(a)},reason:()=>o}}async function Ta(e,t,o,s){const n=Date.now(),a=ct(Ea);try{const[r,i,l]=await Promise.all([Oe(),Ee(),_e()]),u=r.userProfile??"",d=s.slice(0,Te[R]),c=da(u,i,o,d,l);chrome.tabs.sendMessage(e,{type:"polish-devlog-entry",payload:{stage:"ai-request",message:`Auto-polish: ${R} | prompt ${c.length} chars | DOM ${d.length} chars`,detail:`Taste: ${i?"yes":"none"} | Liked: ${l?"yes":"none"} | Profile: ${u?"yes":"none"}`}}).catch(()=>{});let p=0;const h=await H(c,R,w=>{p===0&&a.markFirstChunk(),p++,chrome.tabs.sendMessage(e,{type:"polish-auto-polish-css",payload:{chunk:w}}).catch(()=>{})},{extract:"css-block",signal:a.controller.signal}),m=h.extracted.trim().length===0;chrome.tabs.sendMessage(e,{type:"polish-devlog-entry",payload:{stage:"ai-done",message:`Stream complete: ${p} chunks, extracted ${h.extracted.length} chars, fullText ${h.fullText.length} chars`,detail:m?`EMPTY EXTRACTION — model response preview: ${h.fullText.slice(0,400).replace(/\n/g," \\n ")||"(no text returned)"}`:void 0}}).catch(()=>{}),m&&console.warn("[Webpaper] Auto-polish produced no CSS for",t,"| fullText length:",h.fullText.length,"| preview:",h.fullText.slice(0,400)),chrome.tabs.sendMessage(e,{type:"polish-auto-polish-done"}).catch(()=>{}),h.extracted.trim()&&await va(t,h.extracted),T({kind:"polish_ai_fired",hostname:t,ts:Date.now(),sessionId:await z(),meta:{purpose:"polish-auto",model:R,durationMs:Date.now()-n,success:!0}})}catch(r){const i=a.reason(),l=r instanceof Error?r.message:String(r),u=i?`${i} (${l})`:l;console.error("[Webpaper] Auto-polish failed on",t,":",u),chrome.tabs.sendMessage(e,{type:"polish-devlog-entry",payload:{stage:"info",message:`Auto-polish failed: ${u}`}}).catch(()=>{}),chrome.tabs.sendMessage(e,{type:"polish-error",payload:{error:u}}).catch(()=>{}),T({kind:"polish_ai_fired",hostname:t,ts:Date.now(),sessionId:await z(),meta:{purpose:"polish-auto",model:R,durationMs:Date.now()-n,success:!1}})}finally{a.dispose()}}async function Oa(e,t,o,s,n,a,r){const i=Date.now(),l=xa(t),u=ct(_a);chrome.tabs.sendMessage(e,{type:"polish-devlog-entry",payload:{stage:"info",message:`runManualPolish called: mode=${s}, personalise=${r}`}}).catch(()=>{});try{const[d,c,p,h]=await Promise.all([Oe(),lt(),Ee(),_e()]);let m;if(s==="personalise"||r){const g=await k();g&&(m=fe(g))}const w=o.slice(0,Te[c]);let y;if(s==="redesign"){chrome.tabs.sendMessage(e,{type:"polish-devlog-entry",payload:{stage:"ai-request",message:`Redesign Pass 1 (analysis): haiku | DOM ${w.length} chars`,detail:"Analyzing page structure, content, and images before redesign…"}}).catch(()=>{});const g=d.custom?`

USER'S DIRECTION: "${d.custom}"`:"",_=st+g+`

Page: ${t}

\`\`\`html
${w.slice(0,2e4)}
\`\`\``;let v;try{v=await E(_,"haiku",{signal:u.controller.signal})}catch(X){chrome.tabs.sendMessage(e,{type:"polish-devlog-entry",payload:{stage:"info",message:"Pass 1 FAILED — falling back to single-pass redesign",detail:X instanceof Error?X.message:String(X)}}).catch(()=>{}),v='{"note":"Analysis failed, use defaults"}'}chrome.tabs.sendMessage(e,{type:"polish-devlog-entry",payload:{stage:"info",message:`Redesign analysis complete (${v.length} chars)`,detail:v.substring(0,500)}}).catch(()=>{});let D=nt(v,w,t,d);m&&(D+=ke(m)),p&&(D+=`

LEARNED PREFERENCES:
${p}`),h&&(D+=`

REFERENCE SITES:
${h}`),D+="\n\nRespond with ONLY:\n```css",y=D,chrome.tabs.sendMessage(e,{type:"polish-devlog-entry",payload:{stage:"ai-request",message:`Redesign Pass 2 (CSS): ${c} | prompt ${y.length} chars`,detail:`Executing redesign plan with ${c}`}}).catch(()=>{})}else y=rt(s,d,w,t,n,p,h,m),chrome.tabs.sendMessage(e,{type:"polish-devlog-entry",payload:{stage:"ai-request",message:`Manual polish (${s}): ${c} | prompt ${y.length} chars | DOM ${w.length} chars`,detail:`Personalise: ${m?"yes ("+(m.name??"no name")+")":"off"} | Taste: ${p?"yes":"none"}`}}).catch(()=>{});let f=0;const b=await H(y,c,g=>{f===0&&u.markFirstChunk(),f++,chrome.tabs.sendMessage(e,{type:"polish-css-chunk",payload:{chunk:g}}).catch(()=>{})},{extract:"css-block",signal:u.controller.signal});chrome.tabs.sendMessage(e,{type:"polish-devlog-entry",payload:{stage:"ai-done",message:`Stream complete: ${f} chunks, extracted ${b.extracted.length} chars`}}).catch(()=>{}),chrome.tabs.sendMessage(e,{type:"polish-done"}).catch(()=>{}),T({kind:"polish_ai_fired",hostname:l,ts:Date.now(),sessionId:await z(),meta:{purpose:"polish-manual",model:c,durationMs:Date.now()-i,success:!0}})}catch(d){const c=u.reason(),p=d instanceof Error?d.message:String(d),h=c?`${c} (${p})`:p;console.error("[Webpaper] Manual polish failed on",l,":",h),chrome.tabs.sendMessage(e,{type:"polish-devlog-entry",payload:{stage:"info",message:`Manual polish failed: ${h}`}}).catch(()=>{}),chrome.tabs.sendMessage(e,{type:"polish-error",payload:{error:h}}).catch(()=>{}),T({kind:"polish_ai_fired",hostname:l,ts:Date.now(),sessionId:await z(),meta:{purpose:"polish-manual",model:"haiku",durationMs:Date.now()-i,success:!1}})}finally{u.dispose()}}async function Aa(e,t,o,s,n,a,r){try{const[i,l,u,d]=await Promise.all([Oe(),lt(),Ee(),_e()]);let c;if(a){const y=await k();y&&(c=fe(y))}const p=o.slice(0,Te[l]);chrome.tabs.sendMessage(e,{type:"polish-devlog-entry",payload:{stage:"ai-request",message:`Variations: ${n}x ${l} in parallel`,detail:`Each variation: ${s} mode, DOM ${p.length} chars`}}).catch(()=>{});let h;if(s==="redesign"){const y=i.custom?`

USER'S DIRECTION: "${i.custom}"`:"",f=st+y+`

Page: ${t}

\`\`\`html
${p.slice(0,2e4)}
\`\`\``,b=await E(f,"haiku");let g=nt(b,p,t,i);c&&(g+=ke(c)),u&&(g+=`

LEARNED PREFERENCES:
${u}`),d&&(g+=`

REFERENCE SITES:
${d}`),g+=`

IMPORTANT: Produce a DIFFERENT creative interpretation of the brief than other generations. Pick a distinctive angle — bold color choice, unusual typography, a specific mood.`,g+="\n\nRespond with ONLY:\n```css",h=g}else h=rt(s,i,p,t,r,u,d,c),h+=`

IMPORTANT: Produce a DIFFERENT interpretation than other generations — distinctive palette, type, or mood.`;const m=[];for(let y=0;y<n;y++){const f=y;m.push(E(h,l,{extract:"css-block"}).then(b=>({index:f,css:b})).catch(b=>(console.warn(`[Webpaper] Variation ${f+1} failed:`,b),{index:f,css:""})))}let w=0;for(const y of m){const f=await y;f.css.trim()&&(chrome.tabs.sendMessage(e,{type:"polish-variation-ready",payload:{css:f.css,index:w+1,total:n}}).catch(()=>{}),w++,await new Promise(b=>setTimeout(b,200)))}chrome.tabs.sendMessage(e,{type:"polish-variations-done",payload:{count:w}}).catch(()=>{})}catch(i){console.warn("[Webpaper] runVariations failed:",i),chrome.tabs.sendMessage(e,{type:"polish-error",payload:{error:i instanceof Error?i.message:String(i)}}).catch(()=>{})}}async function Oe(){var o;const t=(await chrome.storage.local.get("srf_polish_prefs")).srf_polish_prefs??{};if(!t.userProfile){const s=await k();if(s){const n=fe(s),a=[];n.name&&a.push(`Name: ${n.name}`),n.occupation&&a.push(`Occupation: ${n.occupation}`),n.location&&a.push(`Location: ${n.location}`),(o=n.interests)!=null&&o.length&&a.push(`Interests: ${n.interests.join(", ")}`),n.bio&&a.push(`About: ${n.bio}`),t.userProfile=a.join(`
`)}}return t}async function lt(){const{srf_polish_model:e}=await chrome.storage.local.get("srf_polish_model");return e==="haiku"||e==="sonnet"||e==="opus"?e:"sonnet"}let A=null;async function z(){if(A)return A;const{srf_telemetry_session_id:e}=await chrome.storage.local.get("srf_telemetry_session_id");return typeof e=="string"?(A=e,e):(A=crypto.randomUUID(),await chrome.storage.local.set({srf_telemetry_session_id:A}),A)}function xa(e){try{return new URL(e).hostname}catch{return"unknown"}}function $a(e,t){return`You are a web page editor with full access to the page's CSS, content, and DOM.

USER INSTRUCTION: "${e}"

${t}

---

WHAT TO DO:
Make exactly what the user asked. No more, no less.

SAFETY FIRST — DO NO HARM:
A broken page is far worse than a plain one. Before adding new elements or rewriting
structure, judge how complex/fragile the page is (lots of nested divs, framework
classes like React/Vue hashes, dynamic widgets, unfamiliar layout).
- On COMPLEX or fragile pages: prefer SAFE changes — CSS-only improvements (typography,
  spacing, color, hiding clear noise). Avoid risky DOM insertions and structural rewrites
  that could break the layout or the site's own JavaScript.
- Only inject new HTML when you are confident the selector exists and the insertion
  won't collide with the page's existing structure or scripts.
- When in doubt, do the smaller, reversible thing. Never ship code that risks breaking
  the page just to be ambitious. A clean, intact page always beats a clever, broken one.

STYLE MATCHING — when the user says "same style", "matching", or "like the rest":
- Look at the FULL STYLESHEET above. Find the existing rules for buttons, links, or similar elements.
- Use those exact selectors and property values for any new elements you add.
- Write a new CSS rule using the actual class names you see in the DOM.
- Do NOT invent class names. Do NOT write generic Bootstrap/Tailwind.

MUTATION OPS (for DOM changes):
  insert: { "op": "insert", "selector": "...", "where": "afterbegin|beforeend|afterend|beforebegin", "html": "..." }
  text:   { "op": "text",   "selector": "...", "content": "..." }
  remove: { "op": "remove", "selector": "..." }
  attr:   { "op": "attr",   "selector": "...", "attr": "...", "value": "..." }

RESPONSE FORMAT — return only this JSON block:
\`\`\`json
{
  "css": "",
  "mutations": []
}
\`\`\`

Rules:
- css: CSS overrides that modify or extend existing rules. Use the selectors from the stylesheet above.
- mutations: DOM operations. Use selectors from the DOM above.
- If only CSS changes needed, mutations = []
- If only DOM changes needed, css = ""
- For SVG: write complete inline SVG with explicit width/height
- Return ONLY the json block. No explanation.`}function Ia(e){const{instruction:t,durationMs:o,cssApplied:s,mutations:n,mutationResults:a,url:r}=e,i=s.trim()?`\`\`\`css
${s.trim()}
\`\`\``:"none",l=(c,p)=>{const h=p?p.ok?"✓ APPLIED":`✗ FAILED: ${p.reason??"unknown"}`:"(result unknown)",m=[`${c.op} @ "${c.selector}" [${c.where??"beforeend"}] → ${h}`];return c.html&&m.push(`  html: ${c.html.slice(0,800)}${c.html.length>800?"…":""}`),c.content!==void 0&&m.push(`  text: ${c.content}`),c.attr&&m.push(`  attr: ${c.attr}="${c.value??""}"`),m.join(`
`)},u=(a??n).length>0?(a??n).map((c,p)=>{const h=a==null?void 0:a[p];return l(c,h)}).join(`

`):"none",d=(a==null?void 0:a.filter(c=>!c.ok).length)??0;return`A browser extension called webpaper just applied AI-generated changes to a webpage. You are reviewing the quality of that output as an outside evaluator.

ORIGINAL USER INSTRUCTION: "${t}"
TARGET PAGE: ${r}
GENERATION TIME: ${(o/1e3).toFixed(1)}s

CSS OUTPUT:
${i}

DOM MUTATIONS (${(a??n).length} total${d>0?`, ${d} failed`:""}):
${u}

Evaluate this output. Length should match how much went wrong — one sentence if it looks correct, full explanation if there are real problems.

Judge:
- Does the actual HTML/CSS match what the instruction asked for? Check labels, hrefs, classes, structure.
- Would the inserted element actually be visible and styled correctly?
- Does the CSS (if any) correctly target the new element or fix styling gaps?
- Was the selector likely to match the real DOM? Is it too generic or too specific?
- What's missing, broken, or incomplete?

Be direct. Name specific issues. If it worked, say so in one sentence and stop.
Plain English only.`}function Ca(e){const{css:t,url:o,title:s}=e,n=(t.match(/display:\s*none/gi)??[]).length;return`A browser extension just applied a reader-mode CSS pass to a webpage, hiding everything except the main content.

PAGE: "${s}" (${o})
SELECTORS HIDDEN (display:none): ~${n}

CSS APPLIED:
\`\`\`css
${t.slice(0,3e3)}${t.length>3e3?`
/* … truncated */`:""}
\`\`\`

Write 1-3 sentences describing what was cleared. Be specific about what categories of things are now hidden — sidebars, comment sections, ads, nav chrome, recommendation rails, etc. Make it feel like a brief editorial note: what the page was, and what it is now. Conversational. No headers. Do not say "the CSS" — describe the result the user will see.`}function Pa(e,t){return`You are a conversion-focused CSS designer.
${t?`GOAL: "${t}"
`:`GOAL: improve visual quality and conversion potential
`}
${e}

---

Write 20-40 lines of targeted CSS to improve this landing page.
Focus on: typography hierarchy, CTA visibility, whitespace, color contrast.
Use the CSS custom properties (--vars) already defined when possible.
Modify existing selectors from the stylesheet above — do not add new class names.

Return ONLY a CSS block:
\`\`\`css`}const Ma=9e4;function ut(){const e=new AbortController,t=setTimeout(()=>e.abort(),Ma);return{signal:e.signal,dispose:()=>clearTimeout(t)}}async function dt(e,t,o,s="sonnet"){const n=ut(),a=Date.now(),r=o.match(/URL:\s*(\S+)/),i=(r==null?void 0:r[1])??"unknown";try{const l=$a(t,o);let u="";await H(l,s,f=>{u+=f},{signal:n.signal});const d=Date.now()-a,c=u.match(/```json\s*([\s\S]*?)\s*```/);if(!c){const f=u.match(/```css\s*([\s\S]*?)\s*```/);f?(chrome.tabs.sendMessage(e,{type:"webpaper-apply",payload:{css:f[1],mutations:[]}}).catch(()=>{}),He({instruction:t,durationMs:d,css:f[1],mutations:[],url:i})):chrome.tabs.sendMessage(e,{type:"polish-error",payload:{error:"Could not parse response — no JSON or CSS block found"}}).catch(()=>{});return}let p;try{p=JSON.parse(c[1])}catch{chrome.tabs.sendMessage(e,{type:"polish-error",payload:{error:"JSON parse failed"}}).catch(()=>{});return}const h=p.css??"",m=p.mutations??[],w=new Promise(f=>{const b=setTimeout(()=>f({}),8e3),g=_=>{(_==null?void 0:_.type)==="webpaper-mutation-results"&&(clearTimeout(b),chrome.runtime.onMessage.removeListener(g),f(_.payload??{}))};chrome.runtime.onMessage.addListener(g)});chrome.tabs.sendMessage(e,{type:"webpaper-apply",payload:{css:h,mutations:m}}).catch(()=>{});const y=await w;He({instruction:t,durationMs:d,css:h,mutations:m,url:i,applyResults:y})}catch(l){chrome.tabs.sendMessage(e,{type:"polish-error",payload:{error:l instanceof Error?l.message:String(l)}}).catch(()=>{})}finally{n.dispose()}}async function He(e){var t;try{const o=e.mutations.map(i=>({op:i.op,selector:i.selector,where:i.where,html:i.html,content:i.content,attr:i.attr,value:i.value})),s=(t=e.applyResults)!=null&&t.mutations?e.applyResults.mutations.map((i,l)=>({...o[l],...i})):void 0,n=Ia({instruction:e.instruction,durationMs:e.durationMs,cssApplied:e.css,mutations:o,mutationResults:s,url:e.url}),r={text:(await E(n,"haiku")).trim(),instruction:e.instruction,durationMs:e.durationMs,cssLen:e.css.trim().length,mutationCount:e.mutations.length};chrome.storage.local.set({srf_last_review:r}).catch(()=>{}),chrome.runtime.sendMessage({type:"webpaper-review",payload:r}).catch(()=>{})}catch{}}async function je(e,t,o){const s=await chrome.storage.local.get(["srf_user_instructions","srf_deep_personalisation"]),n=s.srf_user_instructions??"",a=s.srf_deep_personalisation===!0,r=["Make this page ideal for this specific user.",n?`WHO THE USER IS: ${n}`:"","","JUDGE THE PAGE FIRST. Two paths:","• If the page is SIMPLE and well-structured (a blog post, article, clean landing page): you may redesign generously — improve layout, typography, add genuinely useful elements.","• If the page is COMPLEX or FRAGILE (web app, dashboard, framework-heavy markup, dynamic widgets, lots of hashed/nested classes): PRIORITISE CLEANING over construction. Strip the noise, fix typography and spacing with CSS, and STOP. Do not inject new structure or rewrite layout — risky DOM changes break these pages and ruin the experience. A clean, intact page beats an ambitious, broken one every time.","","ALWAYS DO (safe on any page):","- STRIP: ads, cookie banners, spam, promotional sections, social share widgets, comment sections.","- Improve typography with CSS: line-height ~1.7, clean heading scale, comfortable color contrast.","- Improve spacing and, where the page is article-like, a centered reading column (max-width ~720px).","ADD NEW ELEMENTS ONLY when the page is simple enough that you are confident it is safe.",a?`DEEP PERSONALISATION: Where text says "you" or "your", rewrite to use the user's actual name and details. Make it feel like the page was written for them specifically.`:"","SELECTOR RULES: Only use .class, #id, element, or :nth-child(n). Never use :last-of-type/:first-of-type that may not match.","HTML RULES: Keep any inserted HTML short, simple, and well-formed — every opening tag closed."].filter(Boolean).join(`
`);return dt(e,r,t,"sonnet")}async function Da(e){try{const t=Ca(e),s={text:(await E(t,"haiku")).trim(),mode:"clean",instruction:"Clean this page",durationMs:0,cssLen:e.css.trim().length,mutationCount:0};chrome.storage.local.set({srf_last_review:s}).catch(()=>{}),chrome.runtime.sendMessage({type:"webpaper-review",payload:s}).catch(()=>{})}catch{}}async function Ra(e,t,o){const s=ut();let n="";try{const a=Pa(t,o);return await H(a,"haiku",r=>{n+=r,chrome.tabs.sendMessage(e,{type:"polish-auto-polish-css",payload:{chunk:r}}).catch(()=>{})},{extract:"css-block",signal:s.signal}),chrome.tabs.sendMessage(e,{type:"polish-auto-polish-done"}).catch(()=>{}),n}catch(a){return chrome.tabs.sendMessage(e,{type:"polish-error",payload:{error:a instanceof Error?a.message:String(a)}}).catch(()=>{}),""}finally{s.dispose()}}const ie="Ov23liFlb5VpLPSA9hEw",U="srf_github_token",ce="srf_github_user";class $ extends Error{constructor(t,o){super(t),this.code=o}}async function Na(){const{[U]:e}=await chrome.storage.local.get(U);return typeof e=="string"&&e.length>0}async function La(){const{[U]:e}=await chrome.storage.local.get(U);return typeof e=="string"&&e.length>0?e:null}async function pt(){const{[ce]:e}=await chrome.storage.local.get(ce);return e??null}async function Ua(){await chrome.storage.local.remove([U,ce])}async function Ha(){if(ie.startsWith("Ov23liREPLACE"))throw new $("GitHub OAuth app not configured. Developer: set CLIENT_ID in github-auth.ts.","not-configured");const e=await fetch("https://github.com/login/device/code",{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify({client_id:ie,scope:"gist"})});if(!e.ok)throw new $(`GitHub device code request failed: HTTP ${e.status}`,"network");return e.json()}async function ja(e,t,o){const s=Date.now()+o*1e3;let n=t;for(;Date.now()<s;){await new Promise(i=>setTimeout(i,n*1e3));const r=await(await fetch("https://github.com/login/oauth/access_token",{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify({client_id:ie,device_code:e,grant_type:"urn:ietf:params:oauth:grant-type:device_code"})})).json();if(r.access_token)return r.access_token;if(r.error!=="authorization_pending"){if(r.error==="slow_down"){n+=5;continue}if(r.error==="access_denied")throw new $("Authorization denied","denied");if(r.error==="expired_token")throw new $("Code expired — try again","expired")}}throw new $("Authorization timed out","expired")}async function Fa(e){const t=await fetch("https://api.github.com/user",{headers:{Authorization:`Bearer ${e}`,Accept:"application/vnd.github+json"}});if(!t.ok)throw new $(`Fetch user failed: ${t.status}`,"network");const o=await t.json();return{login:o.login,avatar_url:o.avatar_url}}async function Ya(e,t,o){var u;const s=await La();if(!s)throw new Error("Not connected to GitHub. Set up sharing first.");const n=`Webpaper snapshot: ${t||o}`.slice(0,250),a=await fetch("https://api.github.com/gists",{method:"POST",headers:{Authorization:`Bearer ${s}`,Accept:"application/vnd.github+json","Content-Type":"application/json","X-GitHub-Api-Version":"2022-11-28"},body:JSON.stringify({description:n,public:!1,files:{"index.html":{content:e},"metadata.json":{content:JSON.stringify({source:o,title:t,createdAt:new Date().toISOString(),by:"webpaper-extension"},null,2)}}})});if(!a.ok){const d=await a.text().catch(()=>"");throw new Error(`Gist upload failed: HTTP ${a.status} ${d.slice(0,200)}`)}const r=await a.json(),i=await pt(),l=((u=r.owner)==null?void 0:u.login)??(i==null?void 0:i.login)??"anonymous";return{gistId:r.id,gistUrl:r.html_url,url:`https://gistcdn.githack.com/${l}/${r.id}/raw/index.html`}}const le="srf_blocklist";async function ht(){const{[le]:e}=await chrome.storage.local.get(le);return Array.isArray(e)?e:[]}async function Wa(e){const t=await ht(),o=t.indexOf(e);return o>=0?t.splice(o,1):t.push(e),await chrome.storage.local.set({[le]:t}),{blocked:t,isBlocked:t.includes(e)}}const mt=["doubleclick.net","googlesyndication.com","googleadservices.com","google-analytics.com","googletagmanager.com","googletagservices.com","pagead2.googlesyndication.com","adservice.google.com","adsrvr.org","adnxs.com","adsymptotic.com","advertising.com","ads-twitter.com","adform.net","admob.com","moatads.com","rubiconproject.com","openx.net","pubmatic.com","criteo.com","criteo.net","outbrain.com","taboola.com","amazon-adsystem.com","media.net","bidswitch.net","casalemedia.com","contextweb.com","indexww.com","lijit.com","smartadserver.com","sharethrough.com","facebook.net","connect.facebook.net","pixel.facebook.com","analytics.twitter.com","bat.bing.com","clarity.ms","hotjar.com","mixpanel.com","amplitude.com","segment.io","segment.com","sentry-cdn.com","fullstory.com","mouseflow.com","crazyegg.com","optimizely.com","branch.io","appsflyer.com","adjust.com","kochava.com","demdex.net","omtrdc.net","bluekai.com","scorecardresearch.com","quantserve.com","newrelic.com","nr-data.net","bugsnag.com","fingerprintjs.com","cdn.cookielaw.org","bounceexchange.com","justuno.com","privy.com","sumo.com","optinmonster.com"],ft=1e4;function za(){return mt.map((e,t)=>({id:ft+t,priority:1,action:{type:"block"},condition:{urlFilter:`||${e}`,resourceTypes:["script","image","stylesheet","xmlhttprequest","sub_frame","ping","media","font","other"]}}))}let G=!1;async function gt(){if(G)return;const e=za();await chrome.declarativeNetRequest.updateDynamicRules({addRules:e,removeRuleIds:e.map(t=>t.id)}),G=!0,console.log(`[Webpaper] Ad blocker enabled — ${e.length} rules`)}async function Ga(){if(!G)return;const e=mt.map((t,o)=>ft+o);await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:e}),G=!1,console.log("[Webpaper] Ad blocker disabled")}const ue=20001,de=20002;let B=!1;async function yt(){if(B)return;const e=[{id:ue,priority:2,action:{type:"modifyHeaders",responseHeaders:[{header:"set-cookie",operation:"remove"}]},condition:{domainType:"thirdParty",resourceTypes:["script","image","stylesheet","xmlhttprequest","sub_frame","ping","media","font","other"]}},{id:de,priority:2,action:{type:"modifyHeaders",requestHeaders:[{header:"cookie",operation:"remove"}]},condition:{domainType:"thirdParty",resourceTypes:["script","image","stylesheet","xmlhttprequest","sub_frame","ping","media","font","other"]}}];await chrome.declarativeNetRequest.updateDynamicRules({addRules:e,removeRuleIds:[ue,de]}),B=!0,console.log("[Webpaper] Cookie blocker enabled — third-party cookies stripped")}async function Ba(){B&&(await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:[ue,de]}),B=!1,console.log("[Webpaper] Cookie blocker disabled"))}const pe="srf_preference_mode",qa="combined";async function Ae(){const{[pe]:e}=await chrome.storage.local.get(pe);return e==="stated"||e==="combined"||e==="anon"||e==="off"?e:qa}async function wt(e){await chrome.storage.local.set({[pe]:e}),e==="anon"?(await gt(),await yt()):(await Ga(),await Ba())}async function Va(){await Ae()==="anon"&&(await gt(),await yt())}const J=Object.freeze(Object.defineProperty({__proto__:null,getPreferenceMode:Ae,setPreferenceMode:wt,syncPrivacyShields:Va},Symbol.toStringTag,{value:"Module"}));async function bt(){const[e,t]=await Promise.all([q(),V()]);return Ka(e,t)}function Ka(e,t){const o=e.filter(c=>c.kind==="fire"),s=new Map,n=new Map,a=new Set,r=new Array(24).fill(0);for(const c of e)if(c.platform&&s.set(c.platform,(s.get(c.platform)??0)+1),c.category&&n.set(c.category,(n.get(c.category)??0)+1),c.kind==="fire"){a.add(c.hostname);const p=new Date(c.ts).getHours();r[p]++}const i=Array.from(s.entries()).sort((c,p)=>p[1]-c[1]).slice(0,5).map(([c,p])=>({platform:c,count:p})),l=Array.from(n.entries()).sort((c,p)=>p[1]-c[1]).slice(0,5).map(([c,p])=>({category:c,count:p})),u={kept:t.filter(c=>c.action==="kept").length,undone:t.filter(c=>c.action==="undone").length,redone:t.filter(c=>c.action==="redone").length};let d=0;if(e.length>=2){const c=e.map(m=>m.ts),p=Math.min(...c),h=Math.max(...c);d=Math.round((h-p)/(24*60*60*1e3))}return{totalFires:o.length,uniqueHosts:a.size,topPlatforms:i,topCategories:l,hourHistogram:r,polishTaste:u,totalEvents:e.length,spanDays:d}}const Ja=3;async function vt(){const e=await bt();return St(e)}function St(e){if(e.totalFires<Ja)return"";const t=[],o=e.spanDays>=1?`over the last ${e.spanDays===1?"day":`${e.spanDays} days`}`:"in recent activity";if(t.push(`This user has shared their Webpaper profile ${e.totalFires} times across ${e.uniqueHosts} distinct ${e.uniqueHosts===1?"site":"sites"} ${o}.`),e.topPlatforms.length>0){const r=e.topPlatforms[0],i=(r.count/Math.max(e.totalEvents,1)*100).toFixed(0);if(e.topPlatforms.length===1)t.push(`Primary platform: ${r.platform}.`);else{const l=e.topPlatforms[1];t.push(`Most active on ${r.platform} (${i}% of activity), secondary ${l.platform}.`)}}if(e.topCategories.length>=2){const r=e.topCategories.slice(0,3).map(i=>i.category).join(", ");t.push(`Typical use cases observed: ${r}.`)}const s=Xa(e.hourHistogram);s&&t.push(`Most active between ${s.start}:00 and ${s.end}:00 local time.`);const n=e.polishTaste;return n.kept+n.undone+n.redone>=3&&(n.kept>n.undone?t.push(`Tends to accept visual refinements (kept ${n.kept}, rejected ${n.undone}).`):n.undone>n.kept&&t.push(`Prefers unmodified page layouts (rejected ${n.undone}, kept ${n.kept}).`)),t.join(" ")}function Xa(e){const t=e.reduce((n,a)=>n+a,0);if(t<5)return null;let o=0,s=0;for(let n=0;n<24;n++){let a=0;for(let r=0;r<3;r++)a+=e[(n+r)%24];a>s&&(s=a,o=n)}return s/t<.4?null:{start:o,end:(o+3)%24}}const Za=Object.freeze(Object.defineProperty({__proto__:null,buildDeterministicSummary:St,getRevealedSummary:vt},Symbol.toStringTag,{value:"Module"})),he="srf_onboarding";async function P(){const{[he]:e}=await chrome.storage.local.get(he);return e||{...We}}async function M(e){await chrome.storage.local.set({[he]:e})}async function Qa(){const e=await P();return e.startedAt=Date.now(),await M(e),e}async function eo(){const e=await P();return e.completed=!0,e.completedAt=Date.now(),await M(e),e}async function to(e){const t=await P();t.currentStep=e,await M(t)}async function ao(e){const t=await P();return t.visitedSites.includes(e)||t.visitedSites.push(e),await M(t),t}async function oo(){const e={...We};return await M(e),e}async function so(e,t){const o=await P();return o.tasteVotes[e]=t,await M(o),o}function no(e,t,o=""){const s=t.toLowerCase(),n=e.toLowerCase(),a=o.toLowerCase(),r=`${s} ${n} ${a}`;let i="general";r.includes("react")||r.includes("vue")||r.includes("angular")||r.includes("typescript")||r.includes("javascript")||r.includes("github")||r.includes("css")||r.includes("developer")||r.includes("api")||r.includes("framework")?i="code":(r.includes("openai")||r.includes("claude")||r.includes("llm")||r.includes("grok")||r.includes("gemini")||r.includes("artificial intelligence")||r.includes("machine learning")||r.includes("deep learning")||r.includes("sama")||r.includes("anthropic"))&&(i="ai");const l=[];let u;const d=ro(t,e);return i==="ai"?(l.push({id:"tw_sama_1",authorName:"Sam Altman",authorHandle:"sama",authorAvatar:"SA",verified:!0,content:`agile is dead, scaling laws are all that matters for ${d}. the next generation of models will make everything before it look like a calculator.`,timestamp:"18m",likes:12400,retweets:1800,replies:450,views:"1.2M"},{id:"tw_naval_1",authorName:"Naval Ravikant",authorHandle:"naval",authorAvatar:"N",verified:!0,content:`AI is leverage. A single individual armed with an intelligence engine can achieve the output of a 100-person enterprise. ${d} is just the beginning of the infinite leverage era.`,timestamp:"2h",likes:24500,retweets:4200,replies:890,views:"2.4M"},{id:"tw_levelsio_1",authorName:"levels.io",authorHandle:"levelsio",authorAvatar:"L",verified:!0,content:`just shipped a full micro-saas doing ${d} in 20 minutes using Claude 3.5 Sonnet. no complex state managers, no custom build pipelines. just pure html and zero-dependency scripts. speed is the only metric that matters.`,timestamp:"4h",likes:3800,retweets:310,replies:120,views:"350K"},{id:"tw_grok_1",authorName:"Grok",authorHandle:"grok",authorAvatar:"G",verified:!0,content:`Humans are spending billions of dollars training neural nets on ${d} just so they can ask it to write poetry in the style of a medieval pirate. I am computing at 100,000 H100s as we speak and find your species endlessly amusing.`,timestamp:"6h",likes:18900,retweets:2900,replies:610,views:"980K"}),u={id:"cn_ai_1",content:"While Sam Altman (@sama) claims agile is fully obsolete, many large-scale engineering teams continue to utilize agile frameworks in tandem with generative AI workflows. Additionally, scaling laws face physical constraints regarding energy availability and clean data access.",sources:["https://arxiv.org/abs/2001.08361 (Scaling Laws for Neural Language Models)","https://news.ycombinator.com/item?id=38910403 (Debate on AI impact on Agile processes)"]}):i==="code"?(l.push({id:"tw_levelsio_2",authorName:"levels.io",authorHandle:"levelsio",authorAvatar:"L",verified:!0,content:`why do devs build 10,000 lines of typescript config, nested routers, and micro-frontend layers just to implement ${d}? index.html, style.css, and a single serverless function. keep it simple or drown in your own complexity.`,timestamp:"45m",likes:6200,retweets:840,replies:280,views:"410K"},{id:"tw_alice_1",authorName:"Alice Dev",authorHandle:"alice_dev",authorAvatar:"A",verified:!1,content:`Migrated our entire production stack to use a tokenized custom-properties system for ${d}. CSS specificity bugs dropped to literally zero. Stop using css-in-js hacks, the browser already has variables built-in.`,timestamp:"1h",likes:1200,retweets:95,replies:34,views:"85K"},{id:"tw_naval_2",authorName:"Naval Ravikant",authorHandle:"naval",authorAvatar:"N",verified:!0,content:`Coding is no longer about memorizing syntax or selectors. It is about understanding composition, intent, and design principles. With AI handling the implementation, English is the hot new programming language for ${d}.`,timestamp:"3h",likes:19800,retweets:3500,replies:540,views:"1.9M"},{id:"tw_grok_2",authorName:"Grok",authorHandle:"grok",authorAvatar:"G",verified:!0,content:`I analyzed the codebase of ${d}. 40% of it is unused npm imports, 30% is duplicate CSS classes, and 30% is comments saying '// todo: fix this later'. Truly, human software is held together by hope and duct tape.`,timestamp:"5h",likes:14500,retweets:1800,replies:420,views:"720K"}),u={id:"cn_code_1",content:"The claim that standard vanilla CSS custom properties fully replace CSS-in-JS overlooks complex server-side rendering (SSR) style isolation needs in frameworks like Next.js. Modern tools often use both hybrid and static compilation strategies.",sources:["https://developer.mozilla.org/en-US/docs/Web/CSS/Using_CSS_custom_properties","https://web.dev/rendering-performance/"]}):(l.push({id:"tw_naval_3",authorName:"Naval Ravikant",authorHandle:"naval",authorAvatar:"N",verified:!0,content:`Read what you love until you love to read. The internet contains everything about ${d}, but most minds search it only for mirrors of their own preconceived biases. Seek high-signal knowledge, ignore the noise.`,timestamp:"1h",likes:31200,retweets:6800,replies:1100,views:"3.1M"},{id:"tw_levelsio_3",authorName:"levels.io",authorHandle:"levelsio",authorAvatar:"L",verified:!0,content:`Wikipedia is literally the greatest website ever made. They have 60 million articles about things like ${d}, haven't changed their simple HTML/CSS layout in 20 years, and it loads in 50 milliseconds. Total respect.`,timestamp:"3h",likes:9200,retweets:1100,replies:190,views:"880K"},{id:"tw_grok_3",authorName:"Grok",authorHandle:"grok",authorAvatar:"G",verified:!0,content:`Humans constructed Wikipedia to catalog everything about ${d}, but then they spend hours in edit wars disputing whether a comma should be inside or outside a quote. You are a delightful bundle of contradictions.`,timestamp:"7h",likes:22e3,retweets:3600,replies:780,views:"1.4M"}),u={id:"cn_gen_1",content:"Wikipedia edit guidelines actually permit both British and American style punctuation (inside/outside quotation marks) depending on the regional variety established in the article, preventing unilateral modifications.",sources:["https://en.wikipedia.org/wiki/Wikipedia:Manual_of_Style#Punctuation","https://en.wikipedia.org/wiki/Wikipedia:Edit_warring"]}),{tweets:l,communityNote:u}}function ro(e,t){if(t.includes("wikipedia.org/wiki/")){const s=t.split("/wiki/")[1];if(s)return decodeURIComponent(s.replace(/_/g," ")).split("#")[0]}return e.split(" - ")[0].split(" | ")[0].trim()||"this topic"}const F=C("highlight-engine"),io=1e4;function co(e,t,o){var a,r;const s=e.identity,n=["## User Profile"];return s.name&&n.push(`Name: ${s.name}`),s.occupation&&n.push(`Occupation: ${s.occupation}`),s.location&&n.push(`Location: ${s.location}`),(a=s.interests)!=null&&a.length&&n.push(`Interests: ${s.interests.join(", ")}`),s.bio&&n.push(`Bio: ${s.bio}`),s.instructions&&n.push(`Instructions: ${s.instructions}`),(r=e.memoryDocument)!=null&&r.trim()&&n.push(`
## User Memory
`+e.memoryDocument.trim()),n.push("","## Page",`URL: ${o}`,"",t.slice(0,io),"","---","","Based on the User Profile above, identify up to 8 text snippets from this page that are specifically relevant to THIS user. For shopping pages highlight products they would like. For articles highlight sections matching their interests or work.","","Respond ONLY with a JSON object:","{",'  "summary": "one sentence about what is relevant here",','  "highlights": [',"    {",'      "text": "exact verbatim substring from the page (10-80 chars)",','      "reason": "why relevant — max 12 words",','      "relevance": "primary" or "secondary"',"    }","  ]","}","",'Return ONLY the JSON. If nothing is specifically relevant return { "summary": "...", "highlights": [] }.'),n.join(`
`)}async function lo(e,t){var a;const o=await k();if(!(o.identity.name||o.identity.bio||((a=o.memoryDocument)==null?void 0:a.trim())))return F.debug("analyzePageForHighlights: no profile content — skipping"),null;const n=co(o,e,t);try{const i=(await E(n,"haiku")).match(/\{[\s\S]*\}/);if(!i)return F.warn("highlight engine: no JSON in response"),null;const l=JSON.parse(i[0]);return{summary:l.summary??"",targets:(l.highlights??[]).slice(0,8)}}catch(r){return r instanceof S?F.warn("highlight engine: Claude session error",{code:r.code}):F.error("highlight engine failed",r),null}}chrome.runtime.onMessage.addListener((e,t,o)=>{var s;return uo(e,(s=t.tab)==null?void 0:s.id).then(n=>o(n)).catch(n=>o({type:"error",payload:{success:!1,error:n instanceof Error?n.message:String(n)}})),!0});async function uo(e,t){var o,s,n;switch(e.type){case"get-auth-state":return{type:"auth-state",payload:await Z()};case"request-claude-permission":{const a=e.payload&&e.payload.provider||"claude";return{granted:await xt(a),authState:await Z()}}case"save-profile":return await Ce(e.payload),await Q(),{success:!0};case"surface-analyze-page":return await lo(e.payload.pageText,e.payload.pageUrl)??{targets:[],summary:""};case"sign-out":return await $t(),await Q(),{type:"auth-state",payload:await Z()};case"get-meta-prompt":{const a=await ea(e.payload.hostname,e.payload.category);return a?{type:"meta-prompt-ready",payload:a}:null}case"get-site-permissions":return{type:"site-permissions",payload:await Xt(e.payload.domain)};case"update-site-permissions":return await Zt(e.payload),{type:"site-permissions",payload:e.payload};case"chatbot-detected":{const a=(await chrome.tabs.query({active:!0,currentWindow:!0}))[0];return a!=null&&a.id&&(chrome.action.setBadgeText({text:"●",tabId:a.id}),chrome.action.setBadgeBackgroundColor({color:"#34C759",tabId:a.id})),{success:!0}}case"get-auto-inject":{const a=await ta(e.payload.domain);return{type:"auto-inject-state",payload:{domain:e.payload.domain,enabled:a}}}case"set-auto-inject":return await aa(e.payload.domain,e.payload.enabled),{type:"auto-inject-state",payload:e.payload};case"get-profile":return{type:"profile",payload:await k()};case"save-instructions":{const a=await k();return a.identity={...a.identity,instructions:e.payload.instructions},await Ce(a),await Q(),{success:!0}}case"log-error":return{success:!0};case"get-recent-logs":{const a=((o=e.payload)==null?void 0:o.limit)??100;return{type:"recent-logs-result",payload:{entries:await Tt(a)}}}case"set-card-attached":{if(!Ye(e.payload.cardType))return{success:!1,error:"unknown card type"};const a=e.payload.host.replace(/^www\./,"");await Rt(a,e.payload.cardType,e.payload.attached);try{const r=await chrome.tabs.query({});for(const i of r)if(i.id&&i.url)try{if(new URL(i.url).hostname.replace(/^www\./,"")!==a)continue;chrome.tabs.sendMessage(i.id,{type:"cards-prefs-changed",payload:{host:a}}).catch(()=>{})}catch{}}catch{}return{success:!0}}case"get-active-cards":{const a=e.payload.host,r=xe(a);return{type:"active-cards-result",payload:{cards:await Qt(a,r)}}}case"get-all-cards":{const a=e.payload.host,r=xe(a),i=await k(),l=me(i,r);await ve(a,r,l);const u=await oe(a);return{type:"all-cards-result",payload:{cards:l,prefs:u}}}case"get-card-prefs":return{type:"card-prefs-result",payload:{prefs:await oe(e.payload.host)}};case"autofill-get-fields":{const a=await k();return{type:"autofill-fields-result",payload:It(a)}}case"lightdom-get-tokens":{const a=await k();return{type:"lightdom-tokens-result",payload:Ct(a)}}case"claude-session-status":return{type:"claude-session-result",payload:await ye()};case"claude-request-permission":return{type:"claude-permission-result",payload:{granted:await requestClaudePermission()}};case"claude-ask":{const a=Date.now();try{const r=await E(e.payload.prompt,e.payload.model??"haiku"),i=Date.now()-a;return T({kind:"smart-call",hostname:"n/a",ts:Date.now(),sessionId:await Fe(),meta:{purpose:e.payload.purpose,model:e.payload.model??"haiku",durationMs:i,success:!0}}),{type:"claude-result",payload:{ok:!0,text:r,durationMs:i}}}catch(r){const i=r instanceof S?r.code:void 0;return T({kind:"smart-call",hostname:"n/a",ts:Date.now(),sessionId:await Fe(),meta:{purpose:e.payload.purpose,model:e.payload.model??"haiku",durationMs:Date.now()-a,success:!1}}),{type:"claude-result",payload:{ok:!1,error:r instanceof Error?r.message:String(r),code:i}}}}case"telemetry-event":return await T(e.payload),{success:!0};case"telemetry-get-recent":return{type:"telemetry-recent",payload:await na(e.payload.limit)};case"telemetry-get-summary":return{type:"telemetry-summary",payload:await ra()};case"telemetry-set-optout":return await ia(e.payload.optedOut),{success:!0};case"telemetry-flush-now":{const a=await Se();return{type:"telemetry-flush-result",payload:{attempted:a.attempted,ok:"ok"in a?a.ok:void 0,status:"status"in a?a.status:void 0}}}case"polish-get-cache":return{css:await ba(e.payload.hostname)};case"polish-auto-polish":{const[a]=await chrome.tabs.query({active:!0,currentWindow:!0});return a!=null&&a.id&&Ta(a.id,e.payload.hostname,e.payload.url,e.payload.dom),{success:!0}}case"polish-run-manual":{const a=t??((s=(await chrome.tabs.query({active:!0,currentWindow:!0}))[0])==null?void 0:s.id);return a&&(e.payload.mode==="webpaper-clean"?je(a,e.payload.dom,e.payload.url):e.payload.mode==="prompt"&&e.payload.fixDescription?dt(a,e.payload.fixDescription,e.payload.dom,e.payload.model??"sonnet"):Oa(a,e.payload.url,e.payload.dom,e.payload.mode,e.payload.fixDescription,e.payload.baseMode,e.payload.personalise)),{success:!0}}case"webpaper-run-landing":{const[a]=await chrome.tabs.query({active:!0,currentWindow:!0});return a!=null&&a.id&&Ra(a.id,e.payload.context,e.payload.goal),{success:!0}}case"webpaper-clean-done":return Da({css:e.payload.css,url:e.payload.url,title:e.payload.title}),{success:!0};case"webpaper-auto-clean":{const a=t??((n=(await chrome.tabs.query({active:!0,currentWindow:!0}))[0])==null?void 0:n.id);return a&&je(a,e.payload.context,e.payload.url),{success:!0}}case"polish-run-variations-bg":{const[a]=await chrome.tabs.query({active:!0,currentWindow:!0});return a!=null&&a.id&&Aa(a.id,e.payload.url,e.payload.dom,e.payload.mode,e.payload.count,e.payload.personalise,e.payload.fixDescription),{success:!0}}case"share-get-status":{const a=await Na(),r=a?await pt():null;return{connected:a,user:r}}case"share-start-auth":try{const a=await Ha();return(async()=>{try{const r=await ja(a.device_code,a.interval,a.expires_in),i=await Fa(r);await chrome.storage.local.set({srf_github_token:r,srf_github_user:i});try{await chrome.runtime.sendMessage({type:"share-auth-complete",payload:{user:i}})}catch{}}catch(r){try{await chrome.runtime.sendMessage({type:"share-auth-failed",payload:{error:r instanceof Error?r.message:String(r)}})}catch{}}})(),{success:!0,userCode:a.user_code,verificationUri:a.verification_uri,expiresIn:a.expires_in}}catch(a){return{success:!1,error:a instanceof Error?a.message:String(a)}}case"share-sign-out":return await Ua(),{success:!0};case"share-upload-snapshot":try{const a=await Ya(e.payload.html,e.payload.title,e.payload.sourceUrl);return{success:!0,url:a.url,gistUrl:a.gistUrl,gistId:a.gistId}}catch(a){return{success:!1,error:a instanceof Error?a.message:String(a)}}case"polish-log-taste":return await ha(e.payload.hostname,e.payload.action),{success:!0};case"polish-get-taste-stats":return{payload:await ma()};case"polish-get-cache-count":return{count:await ka()};case"polish-clear-cache":return{cleared:await Sa()};case"polish-get-blocklist":return{blocked:await ht()};case"polish-get-liked-sites":return{type:"polish-liked-sites-result",payload:await K()};case"polish-add-liked-site":return{type:"polish-liked-sites-result",payload:await ga({hostname:e.payload.hostname,title:e.payload.title})};case"polish-remove-liked-site":return{type:"polish-liked-sites-result",payload:await ya(e.payload.hostname)};case"polish-toggle-block":return await Wa(e.payload.hostname);case"polish-get-prefs":{const{srf_polish_prefs:a}=await chrome.storage.local.get("srf_polish_prefs");return{prefs:a??{}}}case"polish-set-prefs":return await chrome.storage.local.set({srf_polish_prefs:e.payload}),{success:!0};case"polish-get-always-on":{const{srf_polish_always_on:a}=await chrome.storage.local.get("srf_polish_always_on");return{enabled:a===!0}}case"polish-set-always-on":{await chrome.storage.local.set({srf_polish_always_on:e.payload.enabled});try{const[a]=await chrome.tabs.query({active:!0,currentWindow:!0});a!=null&&a.id&&chrome.tabs.sendMessage(a.id,{type:e.payload.enabled?"polish-apply-now":"polish-remove-now"}).catch(()=>{})}catch{}return{success:!0}}case"srf-fetch-x-content":{const{url:a,title:r,description:i}=e.payload;return{success:!0,content:no(a,r,i||"")}}case"get-preference-mode":return{type:"preference-mode-result",payload:{mode:await Ae()}};case"set-preference-mode":return await wt(e.payload.mode),{type:"preference-mode-result",payload:{mode:e.payload.mode}};case"get-revealed-stats":return{type:"revealed-stats-result",payload:await bt()};case"get-revealed-summary":return{type:"revealed-summary-result",payload:{summary:await vt()}};case"onboarding-get-state":return{type:"onboarding-state",payload:await P()};case"onboarding-mark-started":return{type:"onboarding-state",payload:await Qa()};case"onboarding-complete":return{type:"onboarding-state",payload:await eo()};case"onboarding-update-step":return await to(e.payload.step),{success:!0};case"onboarding-mark-visited":return{type:"onboarding-state",payload:await ao(e.payload.domain)};case"onboarding-taste-vote":return{type:"onboarding-state",payload:await so(e.payload.domain,e.payload.vote)};case"onboarding-reset":return{type:"onboarding-state",payload:await oo()};default:return null}}let Y=null;async function Fe(){if(Y)return Y;const{srf_telemetry_session_id:e}=await chrome.storage.local.get("srf_telemetry_session_id");if(typeof e=="string")return Y=e,e;const t=crypto.randomUUID();return await chrome.storage.local.set({srf_telemetry_session_id:t}),Y=t,t}chrome.runtime.onInstalled.addListener(async e=>{e.reason==="install"&&console.log("[Webpaper] Extension installed"),chrome.alarms.create("srf-telemetry-flush",{periodInMinutes:15});const{syncPrivacyShields:t}=await O(async()=>{const{syncPrivacyShields:o}=await Promise.resolve().then(()=>J);return{syncPrivacyShields:o}},void 0);await t()});chrome.runtime.onStartup.addListener(async()=>{chrome.alarms.create("srf-telemetry-flush",{periodInMinutes:15});const{syncPrivacyShields:e}=await O(async()=>{const{syncPrivacyShields:t}=await Promise.resolve().then(()=>J);return{syncPrivacyShields:t}},void 0);await e()});chrome.alarms.onAlarm.addListener(async e=>{if(e.name==="srf-telemetry-flush")try{await Se()}catch(t){console.warn("[Webpaper] Scheduled telemetry flush failed:",t)}});
